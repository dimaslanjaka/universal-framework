<?php

require_once('core/App.php');
require_once('core/Controller.php');
require_once('core/Database.php');
require_once('core/Session.php');

// config
require_once('config/config.php');
require_once('config/whatsapp.php');
require_once('config/function.php');
require_once('config/csrf_token.php');
require_once('config/ovo-class.php');
require_once('config/bca-class.php');
require_once('config/gopay-class.php');
require_once('config/class.phpmailer.php');
