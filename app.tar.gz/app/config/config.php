<?php

/*
 OFFICIAL PANEL SMM PPOB SCRIPT BY MENZCREATE
 Creator:
    - ILMAN SUNANUDDIN | FOUNDER M-PEDIA , M-CREATE
    HTTPS://FACEBOOK.COM/ILMAN.SN
    HTTPS://INSTAGRAM.COM/ILMAN.SN
   
 */
date_default_timezone_set('Asia/jakarta');

define('DB_HOST', 'localhost');
define('DB_NAME', 'chandrap_smm');
define('DB_USER', 'chandrap_smm');
define('DB_PASS', 'dX5d[)_8d*&?');
define('BASEURL', 'https://chandrapedia.my.id/public/');
define('WEB_NAME', 'Chandra Pedia');



$ttt = new DateTime();
$date = date('Y-m-d');
$time = date('H:i:s');

define('DATE', $date);
define('TIME', $time);


//error_reporting(0);
