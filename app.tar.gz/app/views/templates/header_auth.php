<!DOCTYPE html>
<!-- 


Credit by : Ilman sunanuddin.
Facebook : https://facebook.com/ilman.sn
instagram : https://instagram.com/ilman.sn
 -->
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Ilman Sunanuddin">
    <meta name="description" content="M Pedia Penyedia Pulsa & Followers Murah Indonesia">
    <meta name="keywords" content="M Pedia Pulsa PPOB & Followers Murah #1 Indonesia followersinstagram followers panel followers scriptpanel m pediapanel autolike autolikes pulsamurah jualanpulsa bisnisonline panelsmmindonesia panel smm indonesia panel pusat smm indonesia">
    <title><?= $data['title']; ?></title>
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/iofrm-style.css">
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/iofrm-theme3.css">

</head>

<body>