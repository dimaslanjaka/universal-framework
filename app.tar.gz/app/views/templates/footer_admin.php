<script src="<?= BASEURL; ?>js/vendor/bootstrap.bundle.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/Chart.bundle.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/chartjs-plugin-datalabels.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/moment.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/fullcalendar.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/datatables.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/perfect-scrollbar.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/progressbar.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/jquery.barrating.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/select2.full.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/nouislider.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/Sortable.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/mousetrap.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/glide.min.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/dore.script.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/scripts.js" type="text/javascript"></script>
<script src="<?= BASEURL; ?>js/vendor/select2.full.js"></script>
<script src="<?= BASEURL; ?>js/vendor/bootstrap-datepicker.js"></script>
<script src="<?= BASEURL; ?>js/vendor/bootstrap-tagsinput.min.js"></script>


</body>

</html>