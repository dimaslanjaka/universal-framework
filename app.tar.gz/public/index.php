<?php
date_default_timezone_set('Asia/jakarta');


session_start();
require_once('../app/init.php');
new App;
