<?php
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK
/* Version :1.01
/* You can add your own function here! 
/* But don't change anything in this file!
/*-----------------------------------------------*/

remove_action( 'init', 'ktz_register_css');
function ktz_register_css_child() {
	if( !is_admin() ) {
		wp_register_style( 'ktz-bootstrap-min',ktz_url . 'includes/assets/css/bootstrap.min.css', array(), '1.0', 'screen, projection' );
		wp_register_style( 'ktz-video-min',ktz_url . 'includes/assets/video-js/video-js.min.css', array(), '1.0', 'all' );
		wp_register_style( 'ktz-woocommerce-css', ktz_url . 'woocommerce/assets/css/woocommerce.css', '1.0', 'screen' ); 
		wp_register_style( 'ktz-main-css',get_stylesheet_directory_uri() . '/style.css',array(), '1.0', 'all' );
		}
	}
add_action( 'init', 'ktz_register_css_child' );

?>