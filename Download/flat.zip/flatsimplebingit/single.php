<?php 
/**
 * KENTOOZ SINGLE PAGE TEMPLATE
**/
get_header(); ?>
	<section class="col-md-12">
		<section class="new-content">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'content', 'single' ); ?>
			<?php endwhile; // end of the loop. ?>
		</section>
		<hr><H3><center>Please Like U.s</center></H3><div id="fb-root"></div><style type="text/css"> .fb-wrap{width:50%; margin: 0 auto;}@import url("https://gist.githubusercontent.com/smeranda/2571173/raw/93df0ef337f8903dc19337485b88285c1edaf8c7/facebook_like-box_responsive.css");/* .fb-like-box, .fb-like-box span, .fb-like-box span iframe[style]{width: 100% !important;}*/</style> <script>(function(d, s, id){var js, fjs=d.getElementsByTagName(s)[0]; if (d.getElementById(id)){return;}js=d.createElement(s); js.id=id; js.src="//connect.facebook.net/en_US/all.js#xfbml=1"; fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script><div class="fb-wrap">  <div class="fb-like-box" data-href="http://www.facebook.com/secretnetworkforces" data-width="992" data-show-faces="true" data-show-border="false" data-colorscheme="light" data-stream="false" data-header="false"></div></div>

		<?php if ( ot_get_option('ktz_def_com_activated') == 'yes' || ot_get_option('ktz_facebook_com_activated') == 'yes' || ot_get_option('ktz_active_autbox') == 'yes' ) : ?>
		<div class="tab-comment-wrap" id="comments">
		
		<ul class="nav nav-tabs" id="kentooz-comment">
			<link rel="amphtml" href="<?php if ( get_option('permalink_structure') ) { echo get_permalink($post->ID); } ?>amp/"><center><a rel="follow" href="<?php if ( get_option('permalink_structure') ) { echo get_permalink($post->ID); } ?>amp/"><?php if ( get_option('permalink_structure') ) { echo get_permalink($post->ID); } ?>amp/</a></center><hr>

			<?php if ( ot_get_option('ktz_def_com_activated') == 'yes' ) : ?>
			<li><a href="#comtemplate" data-toggle="tab" title="Default comment"><span class="fontawesome ktzfo-comment-alt"></span> <?php _e( 'Comments', 'ktz_theme_textdomain' ); ?></a></li>
			<?php endif; ?>		
		
			<?php if ( ot_get_option('ktz_facebook_com_activated') == 'yes' ) : ?>
			<li><a href="#comfacebook" data-toggle="tab" title="Facebook comment"><span class="fontawesome ktzfo-facebook"></span> <?php _e( 'FB Comments', 'ktz_theme_textdomain' ); ?></a></li>
			<?php endif; ?>
			
		</ul>
		
		<div class="tab-content">
		
			<?php if ( ot_get_option('ktz_def_com_activated') == 'yes' ) : ?>
			<div class="tab-pane" id="comtemplate">
				<div class="wrapcomment">
				<?php do_action( 'ktz_comments_default'); // function in _comment_ktz.php ?>
				</div>			
			</div>
			<?php endif; ?>		
		
			<?php if ( ot_get_option('ktz_facebook_com_activated') == 'yes' ) : ?>
			<div class="tab-pane" id="comfacebook">
				<div class="wrapcomment">
				<?php do_action( 'ktz_comments_facebook'); // function in _comment_ktz.php ?>
				</div>
			</div>
			<?php endif; ?>
			
		</div>
		<hr><div align="left"><?php echo do_shortcode('[amp-sitemap max="5" heading="Recent Posts"]'); ?></div>
                
		</div>
		<?php endif; ?>
	</section>
<?php get_footer(); ?>