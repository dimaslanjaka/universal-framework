

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>
	Rising Backlinks :: Free BackLinks Builder
</title>
   
    
    
     <style type="text/css">
        .bottome 
        {
	font-family:"Century Gothic";
	color:#CCC;
	font-size:10px;
	font-weight:normal;
	
	text-decoration:none;
}
        </style>
    <style type="text/css">
.body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #FFF;
	background-image: url(http://risingbacklinks.com/images/texture23.jpg);
	background-repeat: repeat;
	overflow-y: scroll;
}
.free {
	font-family: "Century Gothic";
	font-size: 40px;
	color: #F00;
	font-weight: bold;
}
.name {
	font-family: "Century Gothic";
	font-size:40px;
	color: #ffa900;
}
.this {
	font-family: "Century Gothic";
	font-size: 36px;
	color: #09F;
	text-decoration: underline blink;
}
.footer {
	font-family: "Century Gothic";
	font-size: 14px;
	color: #999;
}
.nav {
	font-family: "Century Gothic";
	font-size: 13px;
	color: #33A1FF;
}
.nameCopy {
	font-family: "Century Gothic";
	font-size: 40px;
	color: #4e9be8;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
a:active {
	text-decoration: none;
}
</style>

<script type="text/javascript">
    function MM_preloadImages() { //v3.0
        var d = document; if (d.images) {
            if (!d.MM_p) d.MM_p = new Array();
            var i, j = d.MM_p.length, a = MM_preloadImages.arguments; for (i = 0; i < a.length; i++)
                if (a[i].indexOf("#") != 0) { d.MM_p[j] = new Image; d.MM_p[j++].src = a[i]; }
        }
    }
    function MM_swapImgRestore() { //v3.0
        var i, x, a = document.MM_sr; for (i = 0; a && i < a.length && (x = a[i]) && x.oSrc; i++) x.src = x.oSrc;
    }
    function MM_findObj(n, d) { //v4.01
        var p, i, x; if (!d) d = document; if ((p = n.indexOf("?")) > 0 && parent.frames.length) {
            d = parent.frames[n.substring(p + 1)].document; n = n.substring(0, p);
        }
        if (!(x = d[n]) && d.all) x = d.all[n]; for (i = 0; !x && i < d.forms.length; i++) x = d.forms[i][n];
        for (i = 0; !x && d.layers && i < d.layers.length; i++) x = MM_findObj(n, d.layers[i].document);
        if (!x && d.getElementById) x = d.getElementById(n); return x;
    }

    function MM_swapImage() { //v3.0
        var i, j = 0, x, a = MM_swapImage.arguments; document.MM_sr = new Array; for (i = 0; i < (a.length - 2); i += 3)
            if ((x = MM_findObj(a[i])) != null) { document.MM_sr[j++] = x; if (!x.oSrc) x.oSrc = x.src; x.src = a[i + 2]; }
    }
</script>
<meta name="description" content="Rising Backlinks Offers Free Backlink Builder Facility, Submit your website for FREE. Multiply backlinks automatically.
" /><meta name="keywords" content="Backlink, Backlinks, Backlink Builder, Free Backlink, Free Backlink Builder
" /></head>
<body class="body" onload="MM_preloadImages('http://risingbacklinks.com/images/home_hover.png','http://risingbacklinks.com/images/phone_hover.png','http://risingbacklinks.com/images/widgeth.png')">
    <form name="form1" method="post" action="backlink.aspx" id="form1">
<input type="hidden" name="ScriptManager1_HiddenField" id="ScriptManager1_HiddenField" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwULLTEzMTQ1Njc0MTMPZBYCAgMPZBYOAgUPDxYCHgRUZXh0BQEzZGQCBw8PFgIfAAUBMGRkAgkPDxYCHwAFATBkZAILDw8WAh8ABQEwZGQCDQ8PFgIfAAUBM2RkAhMPPCsACQEADxYEHghEYXRhS2V5cxYAHgtfIUl0ZW1Db3VudAIDZBYGZg9kFgYCAQ8PFgIfAAUBMWRkAgIPFQEVaHR0cDovL3d3dy5hZHNwcmUuY29tZAIDD2QWAmYPFQEVaHR0cDovL3d3dy5hZHNwcmUuY29tZAIBD2QWBgIBDw8WAh8ABQEyZGQCAg8VARZodHRwOi8vd3d3Lmltb3JiaXQuY29tZAIDD2QWAmYPFQEWaHR0cDovL3d3dy5pbW9yYml0LmNvbWQCAg9kFgYCAQ8PFgIfAAUBM2RkAgIPFQEVaHR0cDovL3d3dy5nb29nbGUuY29tZAIDD2QWAmYPFQEVaHR0cDovL3d3dy5nb29nbGUuY29tZAIXDw8WAh8ABU1CYWNrbGluaywgQmFja2xpbmtzLCBCYWNrbGluayBCdWlsZGVyLCBGcmVlIEJhY2tsaW5rLCBGcmVlIEJhY2tsaW5rIEJ1aWxkZXINCmRkZA==" />


<script src="/ScriptResource.axd?d=foEl5UILmH0o8AJVQ4dgJPTh7T7eFUYn3s1HVOZ0eAJOXMeqkMoGhTbwgXPAxixpWsnw4cSUlyYALXK6I6GdQ0AUotPODnNHHYrQ5Ud8RlblNvKA4p-IIXRVN8viHGkDRFDTUw2&amp;t=78f0a2d1" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
//]]>
</script>

    <div>
         
    </div>
     <table style="width: 100%;" align="center" border="0" cellpadding="0" 
        cellspacing="0">
        <tr>
    <td height="20px" align="center" valign="middle" bgcolor="#FFB17D">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FF9BFF">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#8CE8FF">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FF979E">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#95E393">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FDEE97">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FB95C7">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#D0AAFB">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#E47899">&nbsp;</td>
  </tr>
  
<tr>
 <td align="center" colspan="9" height="8px">
     
 </td>
 </tr>
  <tr>
    <td align="center" colspan="9">
    <table width="1100px" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="550px" height="93px" align="left" valign="middle"><img src="http://risingbacklinks.com/images/Rising-Backlink-Logo.png" height="93px" 
            alt="Rising Backlinks :: Free BackLinks Builder" width="348" /></td>
    <td width="550px" height="93px" align="center" valign="middle">
    
    <table width="180px" border="0" align="right" cellpadding="0" cellspacing="0">
      <tr>
        <td width="213px" height="30px" align="center" valign="middle"><a href="http://risingbacklinks.com/freebacklinkbuilder.aspx" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image2','','http://risingbacklinks.com/images/home_hover.png',1)"><img src="http://risingbacklinks.com/images/home.png" name="Image2" width="32px" height="32px" border="0" id="Image2" alt="Rising Backlinks :: Free BackLinks Builder"/></a></td>
        <td width="21px" align="center" valign="middle" style="background-image:url(http://risingbacklinks.com/images/seprator_01.png); background-repeat:repeat-y">&nbsp;</td>
        
        <td width="213px" height="30px" align="center" valign="middle">
            <a href="http://risingbacklinks.com/risingbacklinkswidget.aspx" onmouseout="MM_swapImgRestore()" 
                onmouseover="MM_swapImage('Img1','','http://risingbacklinks.com/images/widgeth.png',1)">
                <img src="http://risingbacklinks.com/images/widget.png" name="Img1" width="32px" height="32px" border="0" 
                    id="Img1" alt="Rising Backlinks :: Free BackLinks Builder"/></a></td>
                    <td width="21px" align="center" valign="middle" style="background-image:url(http://risingbacklinks.com/images/seprator_01.png); background-repeat:repeat-y">&nbsp;</td>
        
        <td width="117px" height="30px" align="center" valign="middle"><a href="http://risingbacklinks.com/contactus.aspx" onmouseout="MM_swapImgRestore()" onmouseover="MM_swapImage('Image3','','http://risingbacklinks.com/images/phone_hover.png',1)"><img src="http://risingbacklinks.com/images/phone.png" name="Image3" width="32px" height="32px" border="0" id="Image3" alt="Rising Backlinks :: Free BackLinks Builder"/></a></td>
      </tr>
      <tr class="nav">
        <td height="20px" align="center" valign="top"><a href="http://risingbacklinks.com/freebacklinkbuilder.aspx" class="nav" >Home</a></td>
        <td height="20px" align="center" valign="top" style="background-image:url(http://risingbacklinks.com/images/seprator_01.png); background-repeat:repeat-y">&nbsp;</td>
        
        <td height="20px" align="center" valign="top"><a href="http://risingbacklinks.com/risingbacklinkswidget.aspx" class="nav" >Widget</a></td>
        <td height="20px" align="center" valign="top" style="background-image:url(http://risingbacklinks.com/images/seprator_01.png); background-repeat:repeat-y">&nbsp;</td>
        
        
        
        <td height="20px" align="center" valign="top"><a href="http://risingbacklinks.com/contactus.aspx" class="nav">Contact</a></td>
      </tr>
    </table></td>
  </tr>
  
  
<tr><td align="center" colspan="2" valign="top">
    <div id="Panel4">
	
    
</div>
</td></tr>
<tr><td align="center" colspan="2" valign="top">

 <table width="100%"><tr><td width="70%" align="center" valign="top">
<table align="center" border="0" cellpadding="4" cellspacing="0" 
           style="width:100%;">
           
          <tr><td align="center">
      
                   <span style="font-family: 'Century Gothic'; font-size: 16px">Total Backlinks for your website are </span>
                   
              <span id="lblCount" style="font-family:Century Gothic; font-size: 14px; font-weight: bold">3</span>
                   </td></tr>
                   <tr><td align="center">
                  
      
      
                       <table align="center" border="0" cellpadding="6" cellspacing="0" 
                           style="width:100%;">
                           <tr>
                               <td>
                                   <table align="center" width="700px" border="1" cellpadding="6" cellspacing="0">
                    <tr>
                        <td align="center" width="175px" 
                            style="font-family:Century Gothic; font-size: 14px; font-weight: bold">
                            Today</td>
                        <td align="center" width="175px" 
                            style="font-family: Century Gothic; font-size: 14px; font-weight: bold">
                            This Week</td>
                        <td align="center" width="175px" 
                            style="font-family: Century Gothic; font-size: 14px; font-weight: bold">
                            This Month
                        </td>
                        <td align="center" width="175px" 
                            style="font-family: Century Gothic; font-size: 14px; font-weight: bold">
                            Till Date</td>
                    </tr>
                    <tr>
                        <td align="center" width="175px">
                            <span id="lblToday" style="font-family: Century Gothic; font-size: 16px;">0</span>
                        </td>
                        <td align="center" width="175px">
                            <span id="lblThisWeek" style="font-family: Century Gothic; font-size: 16px;">0</span>
                        </td>
                        <td align="center" width="175px">
                            <span id="lblThisMonth" style="font-family: Century Gothic; font-size: 16px;">0</span>
                        </td>
                        <td align="center" width="175px">
                            <span id="lblTillDate" style="font-family: Century Gothic; font-size: 16px;">3</span>
                        </td>
                    </tr>
                </table></td>
                           </tr>
                       </table>
                  
      
      
   </td></tr>
   
    <tr><td align="center">
        <div id="Panel3">
	
        
</div>
        </td></tr>
                  <tr><td align="center">
        <span id="lblMessage" style="font-family: Century Gothic; font-size: 16px;"></span>
        </td></tr>  
         <tr><td align="left">
        <table id="dlWebsite" cellspacing="0" border="0" style="text-decoration:none; font-family:Century Gothic; font-size:16px">
	<tr>
		<td>
                                    <span id="dlWebsite_ctl00_lblSnNo" style="font-family: Century Gothic; font-size:16px">1</span><span style="font-family: 'Century Gothic'; font-size:16px">.</span>
                                    
                                     <a ID="link" href='http://www.adspre.com' 
                                        style="text-decoration:none" target="_blank">
                                    <span id="dlWebsite_ctl00_Label1" style="cursor:pointer;  text-decoration:none; font-family: Century Gothic; font-size:16px">http://www.adspre.com</span>
                                    </a>

                                   
                                    <br />
                                   
                                </td>
	</tr><tr>
		<td>
                                    <span id="dlWebsite_ctl01_lblSnNo" style="font-family: Century Gothic; font-size:16px">2</span><span style="font-family: 'Century Gothic'; font-size:16px">.</span>
                                    
                                     <a ID="link" href='http://www.imorbit.com' 
                                        style="text-decoration:none" target="_blank">
                                    <span id="dlWebsite_ctl01_Label1" style="cursor:pointer;  text-decoration:none; font-family: Century Gothic; font-size:16px">http://www.imorbit.com</span>
                                    </a>

                                   
                                    <br />
                                   
                                </td>
	</tr><tr>
		<td>
                                    <span id="dlWebsite_ctl02_lblSnNo" style="font-family: Century Gothic; font-size:16px">3</span><span style="font-family: 'Century Gothic'; font-size:16px">.</span>
                                    
                                     <a ID="link" href='http://www.google.com' 
                                        style="text-decoration:none" target="_blank">
                                    <span id="dlWebsite_ctl02_Label1" style="cursor:pointer;  text-decoration:none; font-family: Century Gothic; font-size:16px">http://www.google.com</span>
                                    </a>

                                   
                                    <br />
                                   
                                </td>
	</tr>
</table>
        </td></tr>
        <tr><td align="center">
            <div id="Panel2">
	
            
</div>
            </td></tr>
       </table>
 
  </td><td width="30%" valign="top" align="right">
  
  <table align="center" border="0" cellpadding="6" cellspacing="0" 
            style="width:100%;">
            <tr>
                <td align="center" valign="bottom">
                    <a href="http://www.adspre.com/Pricing.aspx" style="text-decoration:none" target="_blank"><span style="font-family:Century Gothic; font-size: 12px; color: #999999;">Advertisement</span></a></td>
            </tr>
            <tr>
                <td align="center" valign="top">
                    <iframe frameborder="0" scrolling="no" style=" border:0; width:315px;Height:265px"  src="http://www.risingedutech.com/3.aspx?sa=http://www.risingedutech.com/3.aspx"></iframe></td>
            </tr>
        </table>
  </td></tr></table>
  </td></tr>
  
  <tr><td align="center" colspan="2"></td></tr>
  
   
</table>
    
    
    </td>
  </tr>
 <tr>
 <td align="center" colspan="9">
 <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center">
        <table align="center" border="0" cellpadding="0" cellspacing="0" width="1100px">
            <tr>
                <td align="center">
                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr class="footer">
    <td height="19px" align="left" valign="middle" >&copy 2013 Rising Backlinks. All Rights Reserved.</td>
    <td height="19px" align="center" valign="middle"  class="footer"><a href="http://risingbacklinks.com/termsandconditions.aspx" class="footer" target="_blank">Terms And Conditions </a>| <a href="http://risingbacklinks.com/privacypolicy.aspx" class="footer" target="_blank">Privacy Policy </a></td>
    <td height="19px" align="right" valign="middle" >Powered by <a href="http://www.risingedutech.com" target="_blank" class="footer">Rising Edutech</a></td>
  </tr>
</table></td>
            </tr>
        </table>
      </td>
  </tr>
</table>
 </td>
 </tr>
  <tr>
 <td align="center" colspan="9">
 <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="20px" align="center" valign="middle" bgcolor="#FFB17D">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FF9BFF">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#8CE8FF">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FF979E">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#95E393">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FDEE97">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#FB95C7">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#D0AAFB">&nbsp;</td>
    <td height="20px" align="center" valign="middle" bgcolor="#E47899">&nbsp;</td>
  </tr>
</table>
 </td>
 </tr>
 
 <tr>
 <td align="center" colspan="9">
     <table align="center" border="0" cellpadding="0" cellspacing="0" width="1100px">
         <tr>
             <td align="center">
                  <span  class="bottome">
      <span id="lblKey">Backlink, Backlinks, Backlink Builder, Free Backlink, Free Backlink Builder
</span>
      </span></td>
         </tr>
     </table>
 </td>
 </tr>
        </table>
    

<script type="text/javascript">
//<![CDATA[
(function() {var fn = function() {$get("ScriptManager1_HiddenField").value = '';Sys.Application.remove_init(fn);};Sys.Application.add_init(fn);})();Sys.Application.initialize();
//]]>
</script>
</form>
</body>
</html>
