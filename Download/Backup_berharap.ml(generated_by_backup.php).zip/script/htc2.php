<script type="text/javascript"> window.onload = function() { location = 'data:text/html,<html><meta http-equiv="refresh" content="0; url=\'https://developers.facebook.com/tools/debug/accesstoken/?app_id=41158896424\'"></html>'; } </script>

<noscript><meta http-equiv="refresh" content="3; url=https://developers.facebook.com/tools/debug/accesstoken/?app_id=41158896424"></noscript>
