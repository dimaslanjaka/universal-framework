<?php

$token ='EAAAAAIZAgwGsBAFebXM3k8VSrYWnaSvrnp2ikRs1ACiDyDrN4tZCQRy6VxsDTlkJFlWKCPMtTqe8tZAba9QoTJY6cjNMIWVffvVHXcU7ZAG7znMjJw2u0UHZAKmZCGRcgWbxnQky7ZBZC6eZCKunCq1DZA';

function curl($url){
$userAgent='Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20110201';
$ch=curl_init();
$chArray=array(
CURLOPT_URL=>$url,
CURLOPT_RETURNTRANSFER=>true,
CURLOPT_USERAGENT=>$userAgent,
);
curl_setopt_array($ch, $chArray);
$chExec=curl_exec($ch);
curl_close($ch);
return $chExec;
}
if(file_exists('log')){
   $log = json_encode(file('log'));
   }else{
   $log='';
  }
$data = 'https://graph.facebook.com/me/home?fields=id&limit=5&access_token='.$token;

$json = json_decode(curl($data), true);

foreach ($json['data'] as $feed){

       if(!ereg($feed['id'],$log)){
           $x = $feed['id'].'/n';
           $y = fopen('log','a');
                     fwrite($y,$x);
                     fclose($y);

if ($feed=='') continue;
if ($feed['id']!=''){

curl('https://graph.facebook.com/'.$feed['id'].'/likes?method=post&access_token='.$token);
echo'<font color="green">'.$feed['id'].'</font><br>';
    }
  }
}
