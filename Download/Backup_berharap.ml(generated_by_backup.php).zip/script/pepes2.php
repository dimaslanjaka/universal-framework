<?php
/*


*/


class bot{
//private $dataLog;
function __construct(){
   $this->pass = 'henry42l';
   $this->email ='henri_nugraha@ymail.com';
    }


private function _req($url,$type=null,$fields=null){
   $opts = array(
            19913 => 1,
            10002 => $url,
            10018 => 'Opera/9.80 (Android; Opera Mini/7.5.33361/31.1350; U; en) Presto/2.8.119 Version/11.10',
            );
   $ch=curl_init();
   if($type){
       if($type == 1){
              $opts[10082] = 'coker_log';
              }
       if($type == 3){
              $opts[42] = 1;
             }
       $opts[10031] = 'coker_log';
    }
  if($fields){
      $opts[47] = true;
      $opts[10015] = $fields;
      }
   curl_setopt_array($ch,$opts);
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
  }


public function HtcToken(){
   $url = $this->getUrl('developers','tools/debug/accesstoken/',array(
             'app_id' => '41158896424',
             'refid' => '18',
          )
       );
   $getToken = $this->_req($url,3); 
   if(ereg('name="q" value="',$getToken)){
$accessToken= $this->cut($getToken,'name="q" value="','"');
       }
   if($accessToken){
       $this->saveFile('my_token_htc.txt',$accessToken);
       return'Token Htc True..: <input value="'.$accessToken.'">';
       }else{
       return false;
       }
 }
public function NokiaToken(){
     $url = $this->getUrl('developers','tools/debug/accesstoken/',array(
             'app_id' => '200758583311692',
             'refid' => '18',
          )
       );
   $getToken = $this->_req($url,3); 
   if(ereg('name="q" value="',$getToken)){
$accessToken= $this->cut($getToken,'name="q" value="','"');
       }
   if($accessToken){
       $this->saveFile('my_token_nokia.txt',$accessToken);
       return'Token Nokia True..: <input value="'.$accessToken.'">';
       }else{
       return false;
       }
 }


private function cut($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
}
private function saveFile($x,$y){
   $f = fopen($x,'w');
        fwrite($f,$y);
        fclose($f);
   }
private function getUrl($domain,$dir,$uri=null){
    if($uri){
         foreach($uri as $key =>$value){
             $parsing[] = $key . '=' . $value;
                }
             $parse = '?' . implode('&',$parsing);
                }
     return 'https://' . $domain . '.facebook.com/' . $dir . $parse; 
       }


public function login(){
  $login = array(
     'pass' => $this -> pass,
     'email' => $this -> email,
     'login'  => 'Login',
             );
  $this->_req($this->getUrl('m','login.php'),1,$login);
   }

}

$bot = new bot;
if($bot->HtcToken()){
    echo $bot->HtcToken();
    echo'<br>';
    echo $bot->NokiaToken();
    }else{
    $bot->login();
    }

?>