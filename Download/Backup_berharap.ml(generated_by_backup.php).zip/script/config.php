<?php
$dataLog  =  array(
'email' => 'rastafara098',
'pass' => 'henry42l',
'apps' =>'2254487659',# ID Applikasi nya
);

?>