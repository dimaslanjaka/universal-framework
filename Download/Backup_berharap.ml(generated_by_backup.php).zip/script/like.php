<?php     
function auto($url){
$data = curl_init();
curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($data, CURLOPT_URL, $url);
$hasil = curl_exec($data);
curl_close($data);
return $hasil;

}

$access_token= file_get_contents("token.txt");

if(file_exists('jembutmu')){ $log=json_encode(file('jembutmu')); }else{ $log=''; }
$stat=json_decode(auto('https://graph.facebook.com/me/home?fields=id&limit=50&access_token='.$access_token),true);
for($i=1;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i-1][id],$log)){
$x=$stat[data][$i-1][id]."\n";
$y=fopen('jembutmu','a');
fwrite($y,$x);
fclose($y);
auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/likes?method=post&access_token='.$access_token);
echo ''.$stat[data][$i-1][id].' [SUCCESS] ';

}
else
{
if(file_exists('jembutku')){ $log=json_encode(file('jembutku')); }else{ $log=''; }
$jembut=json_decode(auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?fields=id&access_token='.$access_token),true);
for($e=1;$e<=count($jembut[data]);$e++)
{
if(!ereg($jembut[data][$e-1][id],$log)){
$x=$jembut[data][$e-1][id]."\n";
$y=fopen('jembutku','a');
fwrite($y,$x);
fclose($y);
auto('https://graph.facebook.com/'.$jembut[data][$e-1][id].'/likes?method=post&access_token='.$access_token);
echo 'Komen id ke > '.$e.' | like sukses';
}
else
{
echo('Semua jembut udah dijilat');
}
}
}
}
?>