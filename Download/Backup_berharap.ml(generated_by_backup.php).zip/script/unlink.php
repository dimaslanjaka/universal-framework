<?php
unlink('jembutmu');
unlink('jembutku');
unlink('error_log')
?>