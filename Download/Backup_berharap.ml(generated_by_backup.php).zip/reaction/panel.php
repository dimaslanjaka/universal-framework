<?php
 /* -> RobotReactionV3 by Ifur <- */
session_start();
if(!$_SESSION[nama]){
header('Location: index.php');
die();
}	
$nama= $_SESSION[nama];
$token= $_SESSION[token];
$me=getUrl('/me',$token);
if($me[id]){
$head = "Panel Robot";
head($head);
panel($nama,$me);
menu($nama,$me);
cokor();
}else{
 $ambil=getToken('https://m.facebook.com/v2.0/dialog/oauth?redirect_uri=http://account.nokia.com/acct/account/_COPY_All_URL_ACCESS_TOKEN_FROM_ADDRESS_BAR_&scope=email,publish_actions,user_about_me,user_actions.books,user_actions.music,user_actions.news,user_actions.video,user_activities,user_birthday,user_education_history,user_events,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_notes,user_photos,user_questions,user_relationship_details,user_relationships,user_religion_politics,user_status,user_subscriptions,user_videos,user_website,user_work_history,friends_about_me,friends_actions.books,friends_actions.music,friends_actions.news,friends_actions.video,friends_activities,friends_birthday,friends_education_history,friends_events,friends_games_activity,friends_groups,friends_hometown,friends_interests,friends_likes,friends_location,friends_notes,friends_photos,friends_questions,friends_relationship_details,friends_relationships,friends_religion_politics,friends_status,friends_subscriptions,friends_videos,friends_website,friends_work_history,ads_management,create_event,create_note,export_stream,friends_online_presence,manage_friendlists,manage_notifications,manage_pages,photo_upload,publish_stream,read_friendlists,read_insights,read_mailbox,read_page_mailboxes,read_requests,read_stream,rsvp_event,share_item,sms,status_update,user_online_presence,video_upload,xmpp_login&response_type=token,code&client_id=200758583311692',$cokis);
$tokenx=substr($ambil,strpos($ambil,'token=')+6,(strpos($ambil,'&')-(strpos($ambil,'token=')+6)));
$me=getUrl('/me',$tokenx);
  if($me[id]){
  $_SESSION[token]=$tokenx;
  $head = "Panel Robot";
head($head);
  panel($nama,$me);
  menu($nama,$me);
cokor();
  }else{
  $head = "Server Error";
head($head);
  $apa='Gagal Ambil Access Token Gan, Silahkan Hubungi Admin. Buat Kasih Pencerahan atau Ulangi Login.';
  eror($apa);
  session_destroy();
cokor();
  }
}

 function getFb($ah,$uh){
      $um=array(
      'graph',
      'facebook',
      'com',
      );
      $go='https://'.implode('.',$um);
      return $go.$ah.$uh;
}
function getToken($url,$xx=null,$cokis=null){
$me='Opera/9.80 (Series 60; Opera Mini/6.5.27309/34.1445; U; en) Presto/2.8.119 Version/11.10';
  if($cokis){
     $ch=curl_init();
    curl_setopt_array($ch,array(
      CURLOPT_URL => $xx,
     CURLOPT_RETURNTRANSFER => 1,
     CURLOPT_USERAGENT => $me,
       CURLOPT_REFERER => $xx,
        CURLOPT_POST => 1,
         CURLOPT_POSTFIELDS => $url,
        CURLOPT_SSL_VERIFYPEER => true,
          CURLOPT_ENCODING => '',
        CURLOPT_COOKIEJAR => 'cokisx/'.$cokis,
   CURLOPT_COOKIEFILE => 'cokisx/'.$cokis,));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
       curl_close($ch);
          return ($cx);
             }else{
     $ch=curl_init();
     curl_setopt_array($ch,array(
     CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_USERAGENT => $me,
    CURLOPT_HEADER => 1,
    CURLOPT_ENCODING => '',
    CURLOPT_COOKIEFILE => 'cokisx/'.$xx,));
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      $cx=curl_exec($ch);
  curl_close($ch);
     return ($cx);
}
        }           
function auto($url){
   $ch=curl_init();
   curl_setopt_array($ch,array(
   CURLOPT_URL => $url,
   CURLOPT_RETURNTRANSFER => true,
   CURLOPT_CONNECTTIMEOUT => 5,
   ));
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
   curl_close($ch);
   return $cx;
}
function getUrl($string,$token,$as=null){
  $plin=array(
  'access_token' => $token,
  );
  if($as){
  $mer=array_merge($plin,$as);
  }else{
  $mer=$plin;
  }
  foreach($mer as $k => $o){
  $jek[]=$k.'='.$o;
  }
  $im='?'.implode('&',$jek);
  $im=getFb($string,$im);
  $im=json_decode(auto($im),true);
  if($im[data]){
  return $im[data];
  }else{
  return $im;
  }
}
function panel($nama,$me){
$idfb = $me[id];
$type= file_get_contents('typex/'.$idfb);
if($type){
$rini=explode('×',$type);
if($rini[0]=='type=1'){
$ifur= '<font color="blue">Reaction Suka</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=2'){
$ifur= '<font color="blue">Reaction Super</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=4'){
$ifur= '<font color="blue">Reaction Haha</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=3'){
$ifur= '<font color="blue">Reaction Wow</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=7'){
$ifur= '<font color="blue">Reaction Sedih</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=8'){
$ifur= '<font color="blue">Reaction Marah</font>, Sudah aktif, Tidak jalan? hubungi admin';
}else{
$ifur='<font color="blue">Reaction Random</font>, Sudah aktif, Tidak Jalan? hubungi admin';
}
}else{
$ifur='<font color="red">Reaction Belum aktif</font>, Silahkan aktifkan di form di bawah';
}
if($_POST[type]){
echo'<div class="container"><div class="alert alert-info"><button type="button" class="close" data-dismiss="alert">&times;</button><b>INFO: </b>Perubahan Berhasil Di Simpan,,,,</div></div><p>';
}
echo '<div class="container"><div class="panel panel-primary">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/ya/r/MKnpbwZylPG.png"> Panel Robot Reaction</div>
<div class="panel-body">
<a href="http://facebook.com/'.$me[id].'"><img src="https://graph.facebook.com/v2.5/'.$me[id].'/picture?type=large" alt="Profile" style="height:100px;width:100px;-moz-box-shadow:0px 0px 20px 0px red;-webkit-box-shadow:0px 0px 20px 0px red;-o-box-shadow:0px 0px 20px 0px red;box-shadow:0px 0px 20px 0px red"> </a><br><br>
Name: <b>'.$me[name].'</b><br>
UserId: <b>'.$me[id].'</b><hr>
Bot '.$ifur.' <hr>
Ingin Hapus Bot? <a href="/?Hapus='.$nama.'" title="Hapus">Klik Disini</a></div></div></div>';
}
function menu($nama,$me){
if($_POST[type]){
$type=$_POST[type];
$idfb=$me[id];
   $jam=gmdate("h-i",time()+60*60*7);
   $tulis=fopen('typex/'.$idfb,'w');   fwrite($tulis,$type.'×'.$nama.'×'.$idfb.'×'.$jam);
   fclose($tulis);
   print '<meta http-equiv="refresh" content="0;url="panel.php"/>';
}
echo '<div class="container"><div class="panel panel-success">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yD/r/Ca7mbVY4VCk.png"> Instal Robot</div>
<div class="panel-body">
<center>
<form action="" method="POST">
Pilih Type Reaction :<br>
	<select name="type" class="form-control input">
	<option value="type=1">Suka</option>
	<option value="type=2">Super</option>
	<option value="type=4">Haha</option>
	<option value="type=3">Wow</option>
	<option value="type=7">Sedih</option>
	<option value="type=8">Marah</option>
   <option value="random">Random</option></select><hr>
<input type="Submit" class="btn btn-success" value="Simpan"/>
</form></center>
</div></div></div>
';
         echo '<div class="container"><div class="panel panel-info">
<div class="panel-heading">Tahukah Kamu ?</div>
<div class="panel-body">
<li>Bot Berjalan 5 Menit Sekali</li>
<li>Bot Akan Berhenti Jika Facebook Kamu Log Out Dengan Sendirinya, Tinggal Kembali Ke Sini Terus Login Lagi.</li>
     </div></div></div>';

}
function eror($apa){
echo '<div class="container"><div class="panel panel-primary">
<div class="panel-heading"> <img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yt/r/bMltPkpSVR1.png"> Pemberitahuan </div><div class="panel-body">
'.$apa.'
</div></div></div>';
}
function head($head){
echo '<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head title="Robot Beranda Facebook">
<title>AutoReaction.Cf | '.$head.'</title>
<link rel="shortcut icon" href="//bertena.ga/Material/img/favicon.ico">
<meta name="description" content="Robot Beranda | Tanggapi Status Teman Facebook Kamu Secara Otomatis" />
<meta charset="utf-8">
<meta name="keywords" content=" Robot Beranda, Robot Wow, Robot Super, Robot Like, Robot Sad, Robot Sedih, Robot Marah, Robot Angry, Robot Like, Robot Love, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, CST Liker, Indonesia Autolike, Autolike status, Autolike Photo, ,Autolike Fans Page ,Bot komen ,Bot Like, Bom Like,Bomer Like, Big Like, Facebook, Google, Yahoo, Mywapblog, Bot koplak, Alexa, Ping, Twitter, Indonesian Likers, Autoliker, FB Autolike, FB Autoliker, FB Status Autolike, Indonesian Liker, Autolike 2014, Autolike, Jempol, Hublaa, Like" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="//bertena.ga/Material/img/icon.png"/>
<meta http-equiv="expires" content="0">
<meta name="copyright" content="Copyright © Bertena.Ga">
<meta name="author" content="Ahmad Saepur Ramdan">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike,hublaa,CST Liker,Yaz4rt,IndoLikerz,Hembus,auto follower,autolike page,auto komen">
    <link href="/css/bootstrap.css" rel="stylesheet">         
    <link href="/css/bootstrap.min.css" rel="stylesheet">
           <link href="/css/bootstrap-theme.css" rel="stylesheet">
  <link href="/css/bootstrap-theme.min.css" rel="stylesheet">
<script type="text/javascript">
var uid = "37480";
var wid = "297490";
</script>
<script type="text/javascript" src="//cdn.popcash.net/pop.js"></script>
</head>
  <body>
<!-- Static navbar -->
<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
<span class="sr-only"> Toggle navigation </span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="/">AutoReaction.Cf</a>
</div>
<div id="navbar" class="navbar-collapse collapse">
<ul class="nav navbar-nav navbar-right">
<li class="active">
<a href="//bertena.ga/">Home</a></li>
<li><a href="//bertena.ga/terms.php">Terms</a></li>
<li><a href="//bertena.ga/privacy.php">Privacy</a></li>
<li><a href="//bertena.ga/contact.php">Contact</a></li>
<li><a href="//bertena.ga/about.php">About</a></li>
</ul>
</div>
</div>
</nav>';
}
function cokor(){
echo '<div class="progress progress-striped active">
<div class="progress-bar" style="width: 100%"></div></div>
         <div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;">
<div id="google_translate_element"></div>
<hr>
<div id="histats_counter"></div>
<strong>Copyright &copy; 2015 <a href="//bertena.ga">BertenaGa.</a> All Right Reserved. </strong></font>
</div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
</body>
</html>';
}
?>
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.startgif', '1,3681801,4,10042,"div#histatsC {position: absolute;top:0px;left:0px;}body>div#histatsC {position: fixed;}"']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('//s10.histats.com/js15_gif_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<noscript><a href="/" alt="site hit counter" target="_blank" ><div id="histatsC"><img border="0" src="http://s4is.histats.com/stats/i/3681801.gif?3681801&103"></div></a>
</noscript>
<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'inggris', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>