<?php 
 /* -> RobotReactionV3 by Ifur <- */
$op=opendir('typex');
while($isi=readdir($op)){
if($isi != '.' && $isi != '..'){
$nama=$isi;
$type= file_get_contents('typex/'.$nama);
$rini=explode('×',$type);
$irma = $rini[1];
$lv=explode('=',$rini[0]);
  switch($lv[1]){
            case 1:
            $siap = "type=1";
            break;
            case 2:
            $siap = "type=2";
            break;
            case 3:
            $siap = "type=3";
            break;
            case 4:
            $siap = "type=4";
            break;
            case 7:
            $siap = "type=7";
            break;
            case 8:
            $siap = "type=8";
            break;
           default:
 $acak = array('type=1','type=2','type=3','type=4','type=7','type=8');   $siap=$acak[rand(0,count($acak)-1)];
       break;
        }

mulai($irma,$siap);
}
}

function mulai($nama,$type){
$url=getx('https://m.facebook.com/home.php',$nama);
   $konten = strstr($url,'class="_3-8w">');
   $ft_id = explode('/reactions/picker/',$konten);   
   $limit=count($ft_id);
for($i=0; $i<=$limit; $i++){
$id=cut($ft_id[$i],'ft_id=','&');
     echo $id;
      if($id){
       if(getLog($id,$nama)){
        getReaction($id,$nama,$type);
         }else{
       echo' <font color="red">Success..</font>';
  }
echo'<br>';
}
}
}
function getx($url,$xx=null,$cokis=null){
$me='Opera/9.80 (Series 60; Opera Mini/6.5.27309/34.1445; U; en) Presto/2.8.119 Version/11.10';
  if($cokis){
     $ch=curl_init();
        curl_setopt_array($ch,array(
           CURLOPT_URL => $xx,
              CURLOPT_RETURNTRANSFER => 1,
               CURLOPT_USERAGENT => $me,
                CURLOPT_REFERER => $xx,
                 CURLOPT_POST => 1,
                     CURLOPT_POSTFIELDS => $url,
                 CURLOPT_SSL_VERIFYPEER => true,
             CURLOPT_ENCODING => '',
        CURLOPT_COOKIEJAR => 'cokisx/'.$cokis,
   CURLOPT_COOKIEFILE => 'cokisx/'.$cokis,
));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
       curl_close($ch);
          return ($cx);
             }else{
                $ch=curl_init();
                    curl_setopt_array($ch,array(
                       CURLOPT_URL => $url,
                  CURLOPT_RETURNTRANSFER => 1,
               CURLOPT_USERAGENT => $me,
                CURLOPT_HEADER => 1,
             CURLOPT_ENCODING => '',
             CURLOPT_COOKIEFILE => 'cokisx/'.$xx,
          ));
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      $cx=curl_exec($ch);
  curl_close($ch);
     return ($cx);
}
        }
   
function saveFile($x,$y){
   $f = fopen($x,'w');
        fwrite($f,$y);
        fclose($f);
   }
function cut($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
}
function getReaction($edo,$nama,$type){
$cokis=$nama;
$gerr ='https://m.facebook.com/reactions/picker/?ft_id='.$edo;
    $sukaa= getx($gerr,$cokis); 
    $suka= cut($sukaa,'tanggapan</h1>','<div id="static');
    $ha= explode('/ufi/reaction/',$suka);
    $liha= count($ha);
  // echo $suka;
for($hai=0; $hai<=$liha; $hai++){
  $getha= cut($ha[$hai],$type,'"');
    if($getha){
      $hajarm='https://m.facebook.com/ufi/reaction/?ft_ent_identifier='.$edo.'&amp;reaction_'.$type.''.$getha;
      $hajar= str_replace('&amp;','&',$hajarm);
    //  echo $hajar;
     getx($hajar,$cokis);
      
    }
}
}

function getLog($y,$nama){
   if(file_exists('logx/'.$nama.'.txt')){
       $log=file_get_contents('logx/'.$nama.'.txt');
       }else{
       $log=' ';
       }

  if(ereg($y,$log)){
       return false;
       }else{
if(strlen($log) > 5000){
   $n = strlen($log) - 5000;
   }else{
  $n= 0;
   }
       saveFile('logx/'.$nama.'.txt',substr($log,$n).' '.$y);
       return true;
      }
 } 
?> 