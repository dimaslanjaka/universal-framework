# glype

Glype is a web-based proxy script written in PHP. 



This repository is a copy from  https://www.glype.com/

update 2016/10/26

discuss: http://githubs.cn



