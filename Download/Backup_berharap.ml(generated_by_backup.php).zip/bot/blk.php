<?php
$title = 'Boom Like Komentar';
include'moduls/header.php';
include "/moduls/css/fmb.css";
$token = $_REQUEST['token'];
$uid = $_REQUEST['uid'];
$post_id = $_REQUEST['post_id'];
$a = explode('_',$post_id);
$cid=$a[1];
$id=$a[0];
$access_token=$token;
if(empty($access_token)){
echo '<div class="menu"><a href="'.$dialog_url.'"><b>Izinkan Aplikasi Menghubungkan Ke Facebook</b></a></div>'; 

include'moduls/foot.php';
exit;
}

$me = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token.'&fields=id'),true);

if(!$uid){
echo '<div class="clip"><form action="" method="GET">
<input type="hidden" name="token" value="'.$access_token.'">
Masukkan user id anda/teman: <br/>
<input type="text" name="uid" value="'.$me[id].'">
<br/>
<input type="submit" value="OKE">
</form>
</div>';
include'moduls/foot.php';
exit;
}

$stat = json_decode(file_get_contents('https://graph.fb.me/'.$uid.'/feed?fields=id,from,message,likes,comments&access_token='.$access_token.'&offset=1&limit=50'),true);

if(!$post_id){
for($i=0;$i<count($stat[data]);$i++){
if($stat[data][$i][comments][count] > 0) echo '<hr>'.($i+1).'.'.$stat[data][$i][from][name].': '.$stat[data][$i][message].'<br/>'.$stat[data][$i][likes][count].' like '.$stat[data][$i][comments][count].' komentar <a href="?token='.$access_token.'&uid='.$uid.'&post_id='.$stat[data][$i][id].'" class="ibtn">Boom</a><hr>';
}
include'moduls/foot.php';
exit;
}

$com = json_decode(file_get_contents('https://graph.fb.me/'.$post_id.'/comments?access_token='.$access_token.'&limit='.$stat[data][$i][comments][count].'&fields=id,from'),true);

if(count($com[data]) > 0){
for($c=0;$c<count($com[data]);$c++){
if($com[data][$c][from][id] != $me[id]) {
echo'<a href="https://graph.fb.me/'.$com[data][$c][id].'/likes?access_token='.$access_token.'&method=post"><img src="https://graph.fb.me/'.$com[data][$c][id].'/likes?access_token='.$access_token.'&method=post" alt="'.($c+1).'">'.htmlspecialchars($com[data][$c][from][name]).'</a><hr>';
}
}

}

echo '<hr><a href="?token='.$access_token.'">&laquo; Kembali</a> | <a href="http://m.facebook.com/story.php?story_fbid='.$cid.'&id='.$id.'">Lihat hasil &raquo;</a><hr>';
include'moduls/foot.php';
?>
