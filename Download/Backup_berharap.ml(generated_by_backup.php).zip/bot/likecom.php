<?php
$title='Auto Likes + Comment News Feed';
$token = $_REQUEST['token'];
$uid = $_REQUEST['id'];
$komentar = $_REQUEST['komentar'];
$next = $_REQUEST['next'];

if(empty($token)||empty($uid)){
echo'<a href="index.php">Silahkan Kembali</a></div>';
include'moduls/foot.php';
exit;
}

if(empty($next)){
include'moduls/header.php';
echo'<div class="clip"><form action="" method="GET"><input type="hidden" name="token" value="'.$token.'"><input type="hidden" name="id" value="'.$uid.'">Tambah komentar (kosongkan jika tanpa komentar):<br/><textarea class="list1" name="komentar"></textarea><br/>Jumlah status yang mau anda sukai:<br/><select name="next">';
for($i=1;$i<101;$i++){
echo'<option value="'.$i.'">'.$i.'</option>';
}
echo'</select><br/>Usahakan 10 atau 20 saja, jika kebanyakan bisa di blokir oleh pihak facebook<br/><input class="header" type="submit" value="OKE"></form></div>';
include'moduls/foot.php';
exit;
}
include'moduls/header.php';
include "/moduls/css/fmb.css";
$get_stream = 'https://graph.fb.me/me/home?access_token='.$token.'&method=GET&limit='.$next.'&fields=id,from,type';

$stream = json_decode(file_get_contents($get_stream),true);
for($i=0;$i<$next;$i++){
$post_id=$stream[data][$i][id];
$d = explode('_', $post_id);
$fbid = $d[1];
$id=$stream[data][$i][from][id];
$type=$stream[data][$i][type];
echo'<a href="http://m.facebook.com/story.php?story_fbid='.$fbid.'&id='.$id.'"><img src="https://api.facebook.com/method/stream.addLike?post_id='.$post_id.'&access_token='.$token.'" alt="'.($i+1).'" style="height:16px;display:inline;"> '.$type.' </a>';
if($komentar){
echo'<a href="http://fb.com/profile.php?id='.$id.'"><img src="https://api.facebook.com/method/stream.addComment?post_id='.$post_id.'&comment='.urlencode($komentar).'&access_token='.$token.'" alt="sukses"></a>';
}
echo'<hr>';
}
echo'<div class="list1"><a href="'.$post_login_url.'">&laquo; Kembali</a> | <a href="http://fb.com">Lihat hasil di beranda &raquo;</a></div></div>';
include'moduls/foot.php';
?>
