<?php
session_start();
$access_token = $_SESSION['token'];
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
$title = 'Markas nya Bot | Cyber Merah Putih';
include'moduls/header.php'; ?>
<?php
if (!$access_token){
echo '<div class="mainzag">Insert Your Access Token </div>';
} elseif ($_SESSION['timeout'] + 10 * 60 < time()) {
session_start();
session_destroy();
echo'<div class="mainzag" align="center">Sesi Login anda Telah Habis
<br/>
Silahkan Login Kembali <a href="/index.php">Disini</a></div>';
}
else
 {
?>
<?php  echo'<div class="menu"> <div class="main"> <center><b>Apa yang ';
echo $user->first_name; echo' Pikirkan..?</b></center>
<form action="updatestatus.php" method="post" id="comment_form"/><textarea cols="20" rows="2" name="wall"></textarea><input type="hidden" name="token" value="'.$access_token.'"/></textarea><input type="submit" value="Bagikan"/></form></center>
</div>
</div>';
?>
<div class="footer"><center><b>MY BEST PARTNER: </b></center></div>
<div class="menu"> <div class="menu"> <a href="http://s-liker.mobi/">[-] S Liker</a> <font color="red">[Not Active]</a> </div>
<div class="menu"> <a href="http://mawar.me/">[-] MAWAR.ME</a> <font color="red">[Not Active]</font></div>
<div class="menu"> <a href="http://pubiwayliker.com">[-] Pubiway</a> <font color="lime">[Active]</font></div>
<div class="menu"> <a href="http://nobar-anime.blogspot.com">[-] Nobar-anime</a> <font color="red">[HOT]</font></div>
<div class="menu"> <a href="http://bot-host.gq">[-] Bot-host | Website Bot Terlengkap</a> <font color="red">[HOT]</font></div>
<div class="menu"> <a href="http://naruhadame.mywapblog.com/">[-] Naruhadame</a> <font color="red">[HOT]</font></div></div>
<div class="menu"> <a href="http://www.anihanzsub.net/">[-] Anihanzsub | Tempat download Film 18+</a> <font color="red">[HOT]</font></div></div>
<div class="menu"> <a href="http://www.suakainfo.ga/">[-] Suakainfo.ga</a> <font color="red">[HOT]</font></div></div>
<div class="menu"> <a href="http://www.facebook.com/Cyber.Mer4h.Putih">[-] Fanspage Resmi kami</a> <font color="red">[HOT]</font></div></div>
<div class="menu"> <a href="http://www.facebook.com/Mr-Hanz-200246580311939">[-] Pesan SC Bot Disini</a> <font color="lime">[Ready]</font></div></div>
<hr></hr>
<div class="footer"><center><b>-=[ New Feature Bot ]=- </b> </center></div>
<div class="menu">
<div class="menu"> <a href="/bot/like.php?access_token=<?php echo $access_token; ?>">[!] Bot Like Beranda</a>
</div><div class="menu"> <a href="bot/botSimple.php?access_token=<?php echo $access_token; ?>">[!] Bot Simple</a> <font color="red">[Bikin Baper]</font></div>

<div class="menu"> <a href="bot/botEmoticons.php?access_token=<?php echo $access_token; ?>">[!] Bot Komen Emoticon</a> v3 <font color="lime">[Active]</font>
</div>
<div class="menu"> <a href="bot/botMotivasi.php?access_token=<?php echo $access_token; ?>">[!] Bot Motivasi Emo</a> <font color="lime">[Active]</font>
</div>
<div class="menu"> <a href="bot/responComment.php?access_token=<?php echo $access_token; ?>">[!] Respon Comment</a> <font color="lime">[Active]</font>
</div> <div class="menu"> <a href="bot/responStatusSendiri.php?access_token=<?php echo $access_token; ?>">[!] Respon Status Sendiri</a> <font color="lime">[Active]</font>
</div>
<div class="menu"> <a href="bot/responLike.php?access_token=<?php echo $access_token; ?>">[!] Auto Respon Like</a> <font color="lime">[Active]</font>
</div> 
<div class="menu"> <a href="bot/responStatus.php?access_token=<?php echo $access_token; ?>">[!] Respon Status</a> <font color="lime">[Active]</font>
</div>
<div class="menu"> <a href="bot/responUltah.php?access_token=<?php echo $access_token; ?>">[!] Auto Respon Ultah</a> <font color="red">[New]</font>
</div><div class="menu">
 <a href="bot/inbox.php?access_token=<?php echo $access_token; ?>">[!] Auto Respon Inbox/PM <font color="lime">[Active]</font>[New]</a>
</div>
<div class="menu"> <a href="bot/phokes.php?access_token=<?php echo $access_token; ?>">[!] Auto Colek Teman <font color="lime">[Active]</font>[HOT]</a></a></div></div>

<?php  include 'moduls/iklan.php';  ?>
<hr></hr>
<div class="footer"><center><b>Old Feature Bot In Facebook </b></center></div>

<div class="menu">
<div class="menu"> <a href="bot/del-com.php?access_token=<?php echo $access_token; ?>">[!] Auto Delete Comment</a> </div>
<div class="menu"> <a href="likecom.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">[!] Bom Like+Komentar</a></div>
<div class="menu"> <a href="blk.php?token=<?php echo $access_token; ?>">[!] Bom Like Komentar</a></div>
<div class="menu"> <a href="bomkom.php?token=<?php echo $access_token; ?>">[!] Bom Komentar</a></div> <div class="menu"> <a href="https://m.facebook.com/home.php?sk=fl_668531613186610">Auto Follow</a>
<font color="lime">[Via HP]</font></div>
<div class="menu"> <a href="https://www.facebook.com/lists/668531613186610">[!] Auto Follow</a> <font color="lime">[Via PC]</font></div>
<div class="menu"> <a href="cari_id.php?access_token=<?php echo $access_token; ?>">[!] Cari ID Teman</a> </div>
<div class="menu"> <a href="wall.php?access_token=<?php echo $access_token; ?>">[!] Post To Wall</a></div>
<div class="menu"> <a href="place.php?token=<?php echo $access_token; ?>&nama=<?php echo $user->name; ?>&id=<?php echo $user->id; ?>">[!] Daftar Masuk+Tag Teman</a>
</div></div>
<?php  include 'moduls/iklan.php';  ?>
<hr></hr>
<div class="footer"><center><b> All Feature Multy Post </b></center></div>
<div class="menu"> <div class="menu"> <a href="multy_friends.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">[!] Multy Post To Friends</a></div>
<div class="menu"> <a href="multy_pages.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">[!] Multy Post To Pages</a></div>
<div class="menu"> <a href="multy_groups.php?token=<?php echo $access_token; ?>&id=<?php echo $user->id; ?>">[!] Multy Post To Groups</a>
</div></div>
<hr></hr>
<div class="footer"><center><b> Upload Photo & Video</b> </center></div>
<div class="menu"> <div class="menu"> <a href="photo.php?access_token=<?php echo $access_token; ?>">[!] Upload Photo</a></div>
<div class="menu"> <a href="photourl.php?access_token=<?php echo $access_token; ?>">[!] Upload Photo Dari Url</a></div>
<div class="menu"> <a href="video.php?access_token=<?php echo $access_token; ?>">[!] Upload Video</a>
</div></div>
<?php  include'moduls/iklan.php';  ?>
<hr></hr>
<div class="footer"><center><b> Feature Update Status </b></center></div>
<div class="menu">
<div class="menu"> <a href="stat.php?access_token=<?php echo $access_token; ?>">[!] Status Style</a></div>
<div class="menu"> <a href="status.php?access_token=<?php echo $access_token; ?>">[!] Status Latin Style Bold</a></div>
<div class="menu"> <a href="status_1.php?access_token=<?php echo $access_token; ?>">[!] Status Bold Italic Small Style Small Bold Italic</a></div>
<div class="menu"> <a href="status_2.php?access_token=<?php echo $access_token; ?>">[!] Status Bold Sanserif Style Small Double Struk</a></div>
<div class="menu"> <a href="status_3.php?access_token=<?php echo $access_token; ?>">[!] Status Circled Capital Style Italic</a>
</div></div>
<hr></hr><br/>
<?php } ?><?php include'moduls/foot.php'; ?>
</body>
</html>
