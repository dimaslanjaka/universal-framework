<?php
$liad=array('http://click.buzzcity.net/click.php?partnerid=147737','http://click.buzzcity.net/click.php?partnerid=147737','http://click.buzzcity.net/click.php?partnerid=147737','http://wap4dollar.com/ad/nonadult/serve.php?id=vibq134tvs');
$linad=array_rand($liad);
header('location: '.$adds=$liad[$linad].' ');
?>
