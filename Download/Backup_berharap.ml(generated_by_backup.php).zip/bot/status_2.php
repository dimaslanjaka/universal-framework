<?php
$title= 'Status Bold Sanserif+Style Small Double Struk';
$access_token = $_GET['access_token'];
//supaya aya profile urang
   $user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
include'moduls/header.php';
include "moduls/css/fmb.css";
?>
<?php    
if (!$access_token){
echo 'access tokenmu bosok mbah... Wkwkwk...'; 
} else { ?>
<div class="list1">  
<script type="text/javascript" src="message/boldsanserif.js"></script>
<script type="text/javascript" src="name/smalldoublestruk.js"></script>
<script type="text/javascript" src="status.js"></script>
<form name="baretyas">   
<li>Tulis status :</li> 
<input name="box" size="18" type="text" class="list1" value="TULIS DNG HURUF BESAR"><br><input onclick="startText();" type="button" style="background:#3b5998;color:white" value="Lihat Hasil"><br>
<textarea class="list1" name="message" cols="15" row="3"></textarea>
<li>Link:</li>
<input type="text" class="list1" name="link" value="http://baretyas.xtgem.com">
<li>Name/Style :</li>

<input class="list1" name="kotak" size="18" type="text" value="tulis dng huruf kecil"><br>
<input onclick="startTex();" type="button" style="background:#3b5998;color:white" value="Lihat Hasil"><br>
<textarea name="name" class="list1" cols="15" row="3"></textarea>
<li>Tulisan Abu-abu :</li>

(bisa dikosongkan)<br>
<input class="list1" name="dess" type="text" value=""/>
<li>Sisipkan Photo Masukan ID photo kamu :</li>
<li>Contoh m.facebook.com/photos.php?fbid=<font color="red">11215432</font></li>
<li>yang merah itu id photo :</li>
(bisa dikosongkan)<br>
<input name="photo" class="list1" type="text" value=""/>
<input type="hidden" name="token" value="<?php echo $access_token; ?>">
<br><input style="background:#3b5998;border-color:#8a9ac5 #29447E #1a356e;color:#ffffff;width:70px" name="calculate" type="button" value="UPDATE" onclick="cal()"><input type="hidden" name="output" value="">
</form>
</div>
<?php } ?>
<?php include'moduls/foot.php'; ?>
</body>
</html>
