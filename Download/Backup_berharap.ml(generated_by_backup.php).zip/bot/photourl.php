<?php
$access_token = $_GET['access_token'];
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
//menampilkan album
$album = "https://graph.fb.me/me/albums?access_token=".$access_token;
      $result = file_get_contents($album);
      $json = json_decode($result);
      $albums = array();
      $albums_id = array();
      $data = $json->data;
      if($data!="") {
         $i = 0;
         foreach($json->data as &$album) {
            $albums[$i] = $album->name;
            $albums_id[$i] = $album->id;
            $i += 1;
         }
      }
?>
<html>
<body>
<?php include'moduls/header.php';
include "/moduls/css/fmb.css"; ?>
<?php    
if (!$access_token){
echo 'access tokenmu bosok mbah... Wkwkwk.....'; 
} else { ?>
<div class="clip">
<left><form action="photourlsubmit.php?access_token=<?php echo $access_token; ?>" enctype="multipart/form-data" method="POST">
<br/> 
<li>Tulis Pesan :</li>  
 <textarea name="mess" type="text" cols="15" rows="2" class="list1"></textarea> 
<li>Link Poto:</li> 
contoh:<font color="red">http://photos-d.ak.fbcdn.net/<br>hphotos-ak-snc6/2089<br>76_473702962644<br>119_10000013257<br>5980_1942019_902<br>985752_n.jpg</font>?dl=1<br>yg merah contoh id poto<br><input type="text" name="linkpoto" class="list1" value="http://"> 
<li>simpan ke album:</li>
<select class="list1" name="idalbum" style="width:110px">
               <?php
                 $k = 0;
                 foreach($albums as &$i) {
                  echo '<option value="'.$albums_id[$k].'">'.$i.'</option>';
                  $k += 1;
                 }
                 if($k > 0) {
                  echo '<option value="me">'.'No Albums'.'</option>';
}
?></select>
<br><input type="submit" value="upload" class="green"/> 
</form></left>
<br></div> 
<?php } ?>
<?php include'moduls/foot.php'; ?>
</body>
</html>
