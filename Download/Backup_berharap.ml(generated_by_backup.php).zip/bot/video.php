<?php
$title='Upload Video Facebook';
$access_token = $_GET['access_token'];
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
?>
<?php include'moduls/header.php'; 
include "moduls/css/fmb.css"; ?>
<?php    
if (!$access_token){
echo 'access tokenmu bosok mbah... Wkwkwk.....'; 
} else { ?>
<div class="list2"><form action="https://graph-video.fb.me/me/videos?access_token=<?php echo $access_token; ?>" enctype="multipart/form-data" method="POST"><br><b> Pilih Video: </b><br><input type="file" name="file" size="15" class="list1" style="width:110px"><br><b> Masukkan Judul Video: </b><br><input
type="text" name="title"
value="Isi Judul Video.."
onfocus="if(this.value=Isi Judul Video..)this,value" "=" "
placeholder="" required=""  class="list1" style="width:110px"><br><b> Isi Keterangan Video: </b><br><textarea name="description" class="list1" cols="15" rows="3"></textarea><br><br><input style="background:#aaaaaa;color:#0000aa;border:2px outset #ff0000;" type="submit" value="UPLOAD!"></form>
<br>Hasil Video Silahkan Lihat <a href="http://vupload.facebook.com/videos/">DISINI</a>
</div>
<?php } ?>
<?php include'moduls/foot.php'; ?>