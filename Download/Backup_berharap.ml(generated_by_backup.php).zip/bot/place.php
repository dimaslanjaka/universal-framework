<?php 
session_start(); 
$token = $_GET['token']; 
$aran = $_GET['nama']; 
$id = $_GET['id']; 
 
if(empty($token)||empty($aran)||empty($id)){ 
echo'kesalahan'; 
exit; 
} 
$me = json_decode(file_get_contents('https://graph.fb.me/me?fields=id&access_token='.$token),true);  
if(!$me[id]){ 
session_destroy(); 
echo'id mu salah'; 
exit; 
} 
 
$cari = $_REQUEST["q"]; 
$title='Daftar Masuk '.htmlspecialchars($cari).''; 
include'moduls/header.php';
include "/moduls/css/fmb.css";
echo'<div class="phdr">Cari Tempat :</div> 
<div class="list1"><form action="" method="GET"> 
<input class="list1" type="hidden" name="nama" value="'.$aran.'"><input type="hidden" name="token" value="'.$token.'"><input type="hidden" name="id" value="'.$id.'"><input type="text" name="q" value="'.htmlspecialchars($cari).'"> 
<input type="submit" class="green" value="Cari"/> 
</form></div>'; 
 
if(!empty($cari)){ 
$tempat_url = "https://graph.fb.me/search?q=".urlencode($cari)."&type=place&access_token=".$token; 
$result = json_decode(file_get_contents($tempat_url),true); 
 
echo '<div class="list1">Hasil pencarian untuk '.htmlspecialchars($cari).'</div>'; 
if(count($result[data])>0){ 
echo'<div class="list1"><form action="places.php?" method="GET">'; 
echo'<input type="hidden" name="nama" value="'.$aran.'">';
echo'<input type="hidden" name="token" value="'.$token.'">';
echo'<input type="hidden" name="id" value="'.$id.'">';
echo'Pilih Tempat :<br/>'; 
echo'<select name="placeID">'; 
 
for($i=0;$i<count($result[data]);$i++) { 
$tempat = $result[data][$i][name]; 
$places_id = $result[data][$i][id]; 
if(!empty($tempat)) echo '<option value="'.$places_id.'">'.$tempat.'</option>'; 
} 
echo'</select> 
<br/> 
<input class="clip" type="submit" value="Masuk!"/> 
</form></div>'; 
}else{ 
echo'Tempat yang anda cari tidak di temukan!<hr>'; 
} 
}
include'moduls/foot.php';
?>
