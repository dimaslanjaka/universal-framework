<?php
session_start();
$access_token = $_SESSION['token'];
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
$title = 'Wellcome To BOT Facebook Clients';
include'moduls/header.php';
include "/moduls/css/fmb.css";
if (!$access_token){
echo '<div class="mainzag">Insert Your Access Token </div>';
}
else
{
echo'<div class="menu"><center>
<div class="quote">Selamat Datang di Facebook Clients</center>
<div class="menu">
<br><center>
<br/> 
Anda Bisa Menggunakan Tools Yg kami Sediakan Seperti : <br/>
<script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=g9l0y3iqf3"></script>
</center></div>
<div class="list">&raquo; <b>Auto Like</b>[Berbagai Server]</div>
<div class="list">&raquo; <b>Full Bot Facebook</b></div>
<div class="list">&raquo; <b>Tools Facebook</b></div>
<div class="list">&raquo; <b>Multy Post</b></div>
<div class="list">&raquo; <b>Status Style</b></div>
<div class="list">&raquo; <b>Dan Masih Banyak Lagi...</b></div>
<div class="menu"><center>
<br><br>
<a class="footer" href="/"/>Go To Home</a>
<br/>
</center>
</div></div></div>';
}
include'moduls/foot.php';
?>
