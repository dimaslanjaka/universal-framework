<?php    
if(isset($_GET["access_token"])) {     
$idalbum = $_POST['idalbum'];   
$mess = $_POST['mess'];     
$linkpoto = $_POST['linkpoto'];     
 $access_token = $_GET['access_token'];  
$args = ''.$idalbum.'/photos?url='.$linkpoto.'&method=POST&message='.urlencode($mess); }    
 
if(isset($args))  
 {  $url = 'https://graph.fb.me/'.$args.'&access_token='.$access_token;  
$result = file_get_contents($url);  
   $respon = json_decode($result);  
   } ?>  
<html>
<body>
<?php include'moduls/header.php';
include "/moduls/css/fmb.css"; ?>
<?php
if(!$access_token) {  
echo 'Mau apa anda disini Hayoo??'; }
elseif($respon->id){
   echo 'Sukses Mbah... '.$user->name;
echo '<br/>Ini ID postingan anda<br/><a href="http://m.facebook.com"><b>BERANDA FACEBOOK</b></a><br/>';
print_r($respon->id);
   }elseif(!$place['id']){
   echo '<br/>';
print_r($result);
   }else{
   echo 'Maaf ada kesalahan silahkan ulangi lagi..<br/>';
print_r($result);
   }
echo '</strong>';
?>
<?php include'moduls/foot.php'; ?>
</body>
</html>
