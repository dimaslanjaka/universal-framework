<?php
$text = array("   Apapun yg terjadi, nikmati hidup ini. Hapus air mata, berikan senyummu. Kadang, senyum terindah datang setelah air mata penuh luka.
",
"


    Jika kamu tahu seseorang telah ada yg memiliki, kamu seharusnya menghargai. Jangan menjadi alasan hubungan mereka berakhir.
",
"


    Mencemaskan apa yg mungkin terjadi hanya membuang waktumu. Itu hanya membebani pikiranmu dan mengambil kebahagiaanmu.
",
"


    Jangan menunggu waktu yg tepat tuk melakukan hal yg baik. Jangan terus bertanya apa yg mungkin terjadi, beranikan diri!
",
"

    Jika seseorang mampu memberi alasan mengapa dia mencintaimu, dia tak mencintaimu, dia menyukaimu. Cinta itu emosi, bukan definisi.
",
"

    Dalam hidup, kamu harus menyadari, kadang orang yg paling kamu inginkan, adalah orang yg buat hidupmu lebih baik jika tanpanya
",
"

    Dia yg tulus mencintaimu takkan berjalan di depanmu, atau tertinggal di belakangmu. Dia akan selalu berjalan di sampingmu.
",
"

    Kadang, masalah adalah satu-satunya cara tuk tahu siapa yg tulus peduli padamu dan siapa yg berpura-pura jadi temanmu.
",
"

    Mereka yg mencintaimu slalu ingin yg terbaik untukmu, hanya saja cara mereka bukan slalu yg terbaik.
",
"

    Jangan menyerah atas sesuatu yg sangat kamu inginkan. Memang sulit tuk menunggu, tapi akan lebih sulit jika akhirnya kamu menyesal.
",
"

    Masalah adalah ujian pendewasaan. Jadi tidak ada alasan menyalahkan orang lain. Benahi diri sendiri dan jadi pribadi yg dewasa.
",
"

    Setiap cobaan yg terjadi, adalah atas kehendak Tuhan. Dan setiap kehendak Tuhan adalah untuk memuliakan.
",
"

    Sahabat, adalah mereka yang tetap ada, walau seluruh dunia berkata kau tak lagi berharga. ",
"

    Terkadang, yg tidak baik menurut kita adalah yg terbaik menurut Tuhan. Gunakan kebesaran hati untuk dapat menyikapi hal itu.
",
"

    COBAAN = LATIHAN. Dan dengan latihan ini kita akan menjadi pribadi yg lebih tangguh, lebih tegar dan lebih bisa bersabar.
",
"

    Ketika hati sedang gundah, gelisah dan dipenuhi dengan keputusasaan, ingatlah bahwa hanya kepada Tuhan kita mengadu.
",
"

    Jangan menunda sebuah pekerjaan, lebih baik menyesali apa yg kamu kerjakan, daripada menyesali apa yg tak pernah kamu kerjakan.
",
"

    Dalam cinta, tak perlu dia yg berkata bersedia MATI untukmu, karena yg kamu butuh dia yg bersedia HIDUP bersama denganmu ^^
",
"

    Sahabat adalah mereka yg tetap ingin menemani harimu, tak peduli apa yg dikatakan orang lain tentangmu. ",
"

    Sahabat adalah mereka yg tahu kapan saat yg tepat tuk menyemangati, membiarkanmu sendiri, dan saat tuk berbagi. 
",
"

    Kau selalu bs mempercayai tanpa hrs mencintai, tp kau tdk akan prnh bs mencintai tanpa mempercayai. 
",
"

    Cinta memberimu alasan tuk tersenyum, momen indah tuk ditertawakan, tapi cinta jg memberimu kenangan yg tak pernah bisa dilupakan.
",
"

    Dalam hidup. jangan paksa apa yg tak bisa kamu lakukan. Lakukan saja apa yg bisa kamu lakukan, biarkan Tuhan melakukan sisanya.
",
"

    Kadang meski terus terluka, kamu tetap tak ingin melepasnya. Meski terdengar bodoh, tapi kamu masih berharap dia akan berubah.
",
"

    Kadang, ketika sedih, kamu menyendiri. Karena kamu tahu satu-satunya orang yg mampu buatmu tersenyum kembali adalah dirimu sendiri.
",
"

    Kadang meski tahu bahwa terlalu berharap bisa buatmu sangat terluka, kamu tetap tak mau berhenti berharap sebelum dapat jawabannya.
",
"

    Hanya karena kamu tahu dia mencintaimu, tak berarti kamu harus berusaha mencintainya. Jujurlah drpd akhirnya seseorang akan terluka
",
"

    Km tak bisa mengubah sgala sesuatu dalam satu malam, tapi km dapat mengubahnya sedikit demi sedikit.
",
"

    Kasih sayang tak hanya ditunjukkan oleh sanjungan dan pujian, tetapi juga teguran atas kesalahan dan kelalaian.
",
"

    Mempertahankan mungkin lebih sulit daripada mendapatkan, tetapi tak akan ada yang sulit jika telah ada niat.
",
"

    Segala sesuatu lebih mudah diucapkan daripada dilakukan. Tapi ingat:  Semua itu tidak akan bisa dilakukan tanpa diucapkan .
",
"

    Adalah wajar jika kamu bersedih, tapi jangan pernah kesedihan membutakan hatimu hingga kamu berputus asa.
",
"

    Jgn sia-siakan air matamu utk org yg meninggalkanmu. Bkn kau yg kehilangan mrk, tp mrk yg telah kehilangan dirimu.",
"

    Berlarut dalam kesedihan tak akan bisa membuatmu bangkit. Hapus air matamu, segera bergerak maju!
",
"

    Bahagialah dengan apa yang kamu miliki. Jangan melepasnya hanya karena rasa takut. Kamu mungkin tak akan mendapatkannya kembali.
",
"

    Mengeluh tak akan pernah menyelesaikan apapun, tapi hanya akan menambah beban. Berhentilah mengeluh, segera ambil tindakan!
",
"

    Dalam cinta, terkadang kamu harus belajar tuk melupakan apa yg kamu rasakan dan mulai menemukan apa yg pantas kamu dapatkan.
",
"

    Kadang kamu harus berhenti peduli pada seseorang, bukan karena kamu membencinya, tapi karena dia tak pernah menyadari kepedulianmu.
",
"

    Mampu tertawa ketika segala sesuatu dalam dirimu terluka, adalah salah satu bukti seberapa kuat kamu dalam menjalani hidup ini.
",
"

    Hal tersulit ketika kamu berpura-pura kuat adalah orang-orang mulai berpikir bahwa kamu pasti akan baik-baik saja meski disakiti.
",
"

    Siapapun yg membaca ini, kamu tidak sendiri. Ada seseorang di luar sana yg menyayangimu lebih dari yg kamu tahu.
",
"

   Ketahuilah, hal-hal terindah di dunia ini terkadang tak bisa terlihat dalam pandangan atau teraba dengan sentuhan, mereka hanya bisa terasakan dengan hati.
",
"

    Ketika kekuatan akan cinta melebihi kecintaan akan kekuasaan, maka dunia pun menemukan kedamaian.
",
"

    Jika Anda bisa membuat orang lain tertawa, maka Anda akan mendapatkan semua cinta yang Anda inginkan.
",
"

    Jangan lihat siapa yg berbicara, tapi dengarkan apa yg mereka bicarakan. 
",
"

    Tiada siapa paling pandai & paling bodoh di dunia ini krn setiap yg pandai itu boleh mjd bodoh & setiap yg bodoh itu boleh mjdi pandai
",
"

    Pengetahuan ditingkatkan dgn belajar; kepercayaan dgn perdebatan; keahlian dgn latihan & cinta dgn kasih sayang
",
"

    Proyek besar tak bisa diselesaikan sekaligus, tapi hrs di bagi2 kebagian yg kecil & dapat dikendalikan
",
"

    Mgkn saja setiap masalah & tantangan yg kita anggap sulit itu masih ada solusinya, namun blom terpikirkan oleh kita
",
"

    Barangsiapa membawa berita tentang orang lain kepadamu, maka dia akan membawa berita tentang dirimu kepada orang lain
",
"

    Kualitas dari kehidupan se2orang itu tergantung pada komitmennya utk berhasil, bidang apapun yg dia tempuh
",
"

    Manusia biasanya lebih menghargai sesuatu yg sukar diperoleh tapi sering melupakan nikmat yg telah tersedia
",
"

    Orang yg berjaya dalam hidup adalah orang yg nampak tujuannya dengan jelas & menjurus kepadanya tanpa menyimpang
",
"

    Seseorang dgn wawasan yg cukup untuk mengakui kekurangannya berada paling dekat dgn kesempurnaan
",
"

    Orang2 berhasil tidak hanya keras hati, mereka juga pekerja keras yg percaya pada kemampuan dirinya
",
"

    Berfikir itu cahaya, kelalaian itu kegelapan, kejahilan itu kesesatan & manusia yg paling hina ialah orang yg menganiaya orang bawahannya
",
"

    Bkn mereka yg terkuat & terbesar yg akan dapat mempertahankan eksistensinya. Tapi hanya mereka yg mampu beradaptasi terhadap perubahan
",
"

    Mimpi mmg sangat perlu utk memelihara gairah hidup & kemajuan, tapi mimpi tanpa disertai tindakan hanyalah seperti pepesan kosong belaka
",
"

    Kawan sejati ialah orang yg mencintaimu meskipun telah mengenalmu dengan sebenar-benarnya ia itu baik dan burukmu
",
"

    Kekecewaan mengajar kita arti kehidupan. Teruskan perjuangan kita walau terpaksa utk hadapi rintangan demi rintangan hidup
",
"

    Barangsiapa yg hari ini sama dgn kemarin, maka tertipulah dia, & barangsiapa hari ini lebih jahat dari kemarin, maka terkutuklah dia
",
"

    Kita tidak dapat meneruskan hidup dengan baik jika tidak dapat melupakan kegagalan dan sakit hati di masa lalu
",
"

    Ketakutan-ketakutan akan membatasi Anda untuk melakukan berbagai hal yang sangat berarti bagi Anda
",
"

    Tak ada rahasia utk menggapai sukses. Sukses itu dpt terjadi krn persiapan, kerja keras & mau belajar dari kegagalan
",
"

    Lupakan kekecewaan, karena harapan dimasa depan masih terbentang luas dan begitu cerah
",
"

    Dalam kerendahan hati ada ketinggian budi. Dalam kemiskinan harta ada kekayaan jiwa. Dalam kesempitan hidup ada kekuasaan ilmu
",
"

    Kita akan belajar lebih banyak mengenai sebuah jalan dengan menempuhnya, daripada dengan mempelajari semua peta yag ada di dunia
",
"

    Menuliskan tujuan akan sangat membantu dalam menjaga alasan melakukan sesuatu
",
"

    Sukses dalam hidup tidak ditentukan oleh kartu baik, tapi dengan cara memainkan kartu buruk dengan baik
",
"

    Yang anda butuhkan untuk meraih cita2 adalah keinginan kuat yg akan membawa anda menjadi pekerja keras
",
"

    Anda bisa sukses sekalipun tak ada orang yang percaya anda bisa. Tapi anda tak pernah akan sukses jika tidak percaya pada diri sendiri
",
"

    Sukses dalam hidup tidak ditentukan oleh kartu baik,tapi dengan cara memainkan kartu buruk dengan baik
",
"

    Kalaulah anda tidak mampu untuk menggembirakan orang lain, janganlah pula anda menambah dukanya
",
"

    Jangan sekali-kali kita meremehkan sesuatu perbuatan baik walaupun hanya sekadar senyuman
",
"

    Mimpi tidak hanya membantu Anda berhadapan dengan kegagalan, tetapi mereka juga memotivasi Anda secara konstan
",
"

    Mustahil itu OPINI. Ketika Anda TIDAK YAKIN dapat mencapai IMPIAN, sesungguhnya Anda sudah GAGAL SEBELUM MEMULAI
",
"

    Seribu perkataan dan pengetahuan tdk berarti tanpa ada satu tindakan yang nyata. ACTION !!!
",
"

    KEKUATIRAN tidak pernah memperbaiki hari esok, bahkan hanya melemahkan SUKACITA pada hari ini
",
"

    Memaafkan memang takan mengubah MASA LALU, tapi pasti akan mempermudah MASA DEPAN
",
"

    Berapa Besar ukuran CINTA? Sebesar PERJUANGAN kita untk MEMPERTAHANKAN nya
",
"

    Kata-kata itu tenaga yang luar biasa. Seandainya mulut HItler diplester, Perang Dunia ke 2 tak akan ada.
",
"

    Jadilah berkat bagi banyak orang. Berbagi itu indah teman :
",
"

    Memiliki IMPIAN saja belum cukup. Miliki komitmen untuk MERASA HARUS dan BERTEKAD mencapai impian tersebut
",
"

    Dalam Takut, yg Tampak adlh Hambatan. Dalam YAKIN, yg Tampak adlh KESEMPATAN
",
"

    WORKING......is to win the WAR to be THE KING
",
"

    Kesempatan tidak datang dua kali . Just do it !!! Jangan sampai menyesal karena kesempatan tersebut berlalu begitu saja
",
"

    Hidup tanpa mempunyai TUJUAN sama seperti   Layang-layang putus  Miliki tujuan dan PERCAYALAH anda dapat mencapainya
",
"

    BERPIKIR POSITIF dapat menghancurkan semua tembok pemisah antara  tidak bisa  dan  bisa 
",
"

    Do what you LOVE , and LOVE what you do. And you will get what you want
",
"

    You can t go back and make new start.. But you can start now to make new end...
",
"

    Tidak akan ada langkah ke-2 bila tak ada langkah pertama. , Just Do it !!!
",
"

    Jangan Merangkak dalam Keraguan, Berlarilah dengan KEYAKINAN
",
"

    syukuri untuk semua apa yg terjadi hari ini dan tidurlah dengan nyenyak.
",
"

    Friendship doubles your joys, and divides your sorrows
",
"

    Never tell God that u have a big PROBLEM, but tell ur problem that u have a BIG GOD
",
"

    orang bijak adalah orang yang selalu belajar dari kegagalannya sedangkan orang yang bodoh adalah orang yang selalu menutupi kegagalannya
",
"

    orang yang gagah perkasa itu bukan orang yang bertubuh kekar melainkan orang yang mampu mengendalikan emosinya ketika marah
",
"

    lakukan apa yang dapat anda lakukan, dengan apa yang anda miliki dan di tempat anda berada
",
"

    Kebanyakan orang gagal adalah orang yang tidak menyadari betapa dekatnya mereka ke titik sukses saat mereka memutuskan untuk menyerah
",
"

    Jangan biarkan bayangan masa lalu merusak sinar matahari untuk hari esok, Hiduplah untuk hari ini.
",
"

    Lakukanlah apa yang anda ingin lakukan. selama itu bernilai positif bagi anda.
",
"

    Terkadang terasa pesimis,namun bangkitkanlah dengan bayangkan euforia yg nanti kalian raih
",
"

    Jangan pernah berfikir tidak akan pernah bisa mendaptkan dia,meraih cita-cita,dan segala hal yg kau inginkan
",
"

    Tetap semangat ! Tetap berkontribusi bagi bangsa dan negeri ini
",
"

    Selamat pagi,awali hari dengan penuh semangat !
",
"

    Lelah?menyerah? Padahal kesuksesan sudah di depan mata
",
"

    Berusahalah terus jangan pantang menyerah seakan akan besok kau akan mendapatkan kebahagian tak terkira
",
"

    Semangatlah karena kau tahu esok akan menjadi kesuksesanmu
",
"

    Kau takkan pernah tahu kesuksesan itu jikalau tak pernah mencoba dan hanya menyerah
",
"

    Mimpikan yang kau mau dan kejarlah impianmu itu
",
"

    Belajar memang melelahkan,namun lebih lelah nanti kelak jikalau saat ini tidak belajar
",
"

    Hidup ini penuh warna,kitalah yang harus berusaha mengisi tuk hidup penuh warna cerah
",
"

    Orang sukses takkan pernah mengeluh bagaimana kalau akan gagal,namun berusaha bagaimana untuk berhasil
",
"

    lakukanlah yang terbaik dan anda akan dapat hasil yang terbaik pula
",
"

    kesuksesan itu penuh tantangan,gagal sekali dua kali itu biasa,tetaplah konsisten dengan mimpi kita
",
"

    Hadapi masalah tnpa masalah agar masalah tidak mnjadi risalah kesalahan spanjang perjalanan ini
",
"

    Genggamlah bumi sblm bumi menggengam anda,pijaklah bumi sblm bumi memijak anda,maka perjuangkanlah hidup ini sblm anda memasuki perut bumi.
",
"

    berlarilah sekencang mungkin,realisasikan lah target yg telah dicanangkan untuk hidup yg lebih baik
",
"

    Hanya seseorang yg bs takut bertindak berani. Tanpa rasa takut itu tidak ada apapun yg bisa disebut berani.
",
"

    Tindakan benar memerlukan kekuatan besar.
",
"

    Tidak ada beban yg berat kalau semua orang mau mengangkatnya.
",
"

    Buka mata kita lebar-lebar sebelum menikah, dan biarkan mata kita setengah terpejam sesudahnya.
",
"

    Berbahagialah mereka yang dapat bertahan di saat menerima keberuntungan dan ketidakberuntungan.
",
"

    Uang tdk akan pernah cukup untuk menyembunyikan perasaan sakit dan kebingungan.
",
"

    Dalam dunia ini, tidak ada kesilapan atau ketidak sengajaan. Semua yg mendatangi kita adalah untuk dipelajari.
",
"

    Ketka kita sedang tdk mengingat-Nya bahkan Ia selalu bsama kita dan menurunkan semua anugerah-Nya. Lalu pantaskah kita merusak semuanya?.
",
"

    Ketika kita berencana maka biarkanlah Tuhan yg menjadi penghapusnya dan menggantinya dengan yg lebih baik.
",
"

    Kejujuran adalah batu penjuru dari segala kesuksesan, Pengakuan adalah motivasi terkuat.
",
"

    Mengucapkan kta2 negatif sprti halnya sseorang menancapkan paku2 di sebatang pohon.Walaupun paku sdh tercabut,tetap aj meninggalkan bekas.
",
"

    Anda tdk pernah merencanakan masa depan dimasa lalu. (Edmund)
",
"

    Ilmu itu di dapat dari lidah yg gemar bertanya dan akal yg suka berpikir. 
",
"

Tdk ada org yg dpt menyakitimu, kecuali mereka yg benar2 kau peduli, atau mereka yg tdk benar2 peduli padamu.
",
"

Sahabat tak akan menghilang saat masalah datang, tapi menggandeng tanganmu dan menghadapinya bersama-sama.
",
"

Jangan awali hari dengan penyesalan hari kemarin, karena akan menggangu hebatnya hari ini, dan akan merusak indahnya hari esok. 
",
"

Percayalah, hari ini akan lebih indah daripada kemarin jika kita mengawalinya dengan doa dan senyuman.
",
"

Doaku hari ini: Tuhan, tetapkan aku dalam keimanan yang kokoh, datangkanlah kebaikan dan jauhkanlah segala keburukan.
",
"

Sahabat slalu ada untukmu, ketika kamu punya masalah. Bahkan terkadang memberi saran yg bodoh hanya tuk lihat kamu tertawa.
",
"

Tidak pernah ada kata terlambat untuk memulai. Begitu juga untuk mengakhiri. 
",
"

Ketika keadaan mengharuskan untuk menangis, tak usah berpura, menangislah. Tak semua air mata berarti lemah.
",
"

Jgn hitung brp kali org menyakiti & meninggalkanmu, tp brp kali kau menyakiti Tuhan & Ia tdk prnh meninggalkanmu 
",
"

Saat kau membalas kebencian dgn amarah & caci maki, saat itulah musuhmu menang. 
",
"

Orang hadir di hidupmu karena sebuah alasan. Mereka berimu bahagia dan kecewa. Ada yg sesaat, tapi ada yg selamanya
",
"

Bersedih dengan orang yg tepat lebih baik daripada berbahagia dengan orang yg salah. 
",
"

Hal yang paling sulit adalah mengalahkan diri sendiri. Tapi itu bisa kamu mulai dengan memaafkan diri sendiri. 
",
"

Ketika km berharap yg terbaik tp km hanya mendapat yg biasa, bersyukurlah km bukan yg terburuk. 
",
"

Cinta sejati bukanlah yg berusaha utk mengubahmu, tp yg berhasil menerimamu & tumbuh dewasa bersama dgnmu.
",
"

Jangan membalas mereka yg membencimu. Tersenyum & berbahagialah di depan mereka, tak ada yg lebih menyakiti mereka daripada itu.
",
"

Bahagia bukan milik dia yg hebat dalam segalanya, namun dia yg mampu temukan hal sederhana dlm hidupnya dan tetap bersyukur.
",
"

Bahagia dan memilih sendiri jalan hidup adalah sesuatu yg harus kamu sadari. Jangan biarkan seorangpun yg menentukannya untukmu.
",
"

Jangan hiraukan mereka yg berusaha jatuhkanmu. Karena mereka akan kalah dengan sendirinya ketika melihatmu masih tegak berdiri. 
",
"

Dalam hidup, kamu berhak bahagia. Oleh karena itu, jangan biarkan bahagiamu ditentukan orang lain. Bahagia harus ada dlm dirimu.
",
"

Banyak hal yang bisa menjatuhkanmu. Tapi satu-satunya hal yang benar-benar dapat menjatuhkanmu adalah sikapmu sendiri.
",
"

Saat suatu hubungan berakhir, bkn berarti 2 org berhenti saling mencintai. Mereka hny berhenti saling menyakiti. 
",
"

Jangan mengeluhkan hal-hal buruk yg datang dalam hidupmu. Tuhan tak pernah memberikannya, kamulah yg membiarkannya datang.
",
"

Jangan pernah menyerah jika kamu masih ingin mencoba. Jangan biarkan penyesalan datang karena kamu selangkah lagi tuk menang.
",
"

Jangan biarkan orang lain menghalangimu tuk mengejar impianmu. Tetap berjuang, dan percayalah, semua akan indah pada waktunya.
",
"

Setiap manusia pasti pernah berbuat salah, namun selama kamu mau melepaskan masa lalu, kamu akan punya masa depan yang cerah.
",
"

Dlm cinta, jgn berdusta hanya karena kamu tak ingin dia terluka. Karena ketika dia temukan kebenaran, dia akan lebih menderita. 
",
"

Suatu hubungan berakhir, karena salah satu hati terlalu sedikit mencintai, dan atau terlalu banyak.
",
"

Mereka tak peduli dari mana kamu memulainya. Mereka melihat dari bagaimana caramu mengakhirinya. 
",
"

Mencintai seseorang berarti menjadikannya bagian dari dirimu. Itu sebabnya akan terasa sakit saat kehilangannya. 
",
"

Cinta tidak hanya tentang: Aku sangat beruntung memilikimu",
" tapi juga: Kau sangat beruntung memilikiku.
",
"

Cinta itu antara 2 hati, bukan 3, apalagi 1.. (^_^)v 
",
"

Tanpa LO, nggak akan ada LOVE! 
",
"

Ketika Tuhan memberimu masalah, Dia tahu bahwa kamu pasti bisa melaluinya. Mungkin akan ada luka, tapi itu semua buatmu dewasa. 
",
"

Tidak perlu memfokuskan memikirkan orang yg membenci kita, karena masih banyak org yg menyayangi kita. 
",
"

Berhentilah berprasangka buruk. Karena prasangka itulah yang akan membuatmu menyesal dikemudian hari.
",
"

Setiap orang berbeda, unik dengan caranya. Kamu harus menghargainya, tapi tak berarti kamu harus menyukai semuanya.
",
"

Hidup ini sederhana. Jika kamu ingin hidup bahagia, mulailah meninggalkan segala sesuatu yang membuatmu tak bahagia.
",
"

Jika kamu tak bisa menjadi PENSIL tuk menulis kebahagiaan seseorang, jadilah PENGHAPUS tuk menghilangkan kesedihannya.
",
"

Kamu tak akan dapatkan apa yang kamu inginkan, jika kamu terlalu sibuk mengeluh apa yang kamu miliki saat ini tak cukup bagimu.
",
"

Kekecewaan adalah cara Tuhan tuk mengatakan. Bersabarlah, Aku punya sesuatu yg lebih baik untukmu.
",
"

Fokus pada masalahmu, km tak akan mendapat solusi. Fokus pada Tuhan, Dia akan memberimu solusi.
",
"

Trkdg mereka yg tersenyum paling lebar adl mereka yg telah melalui masa tersulit & meneteskan air mata terpahit.
",
"

Akan ada solusi untuk setiap masalah. Hidup terlalu singkat jika hanya untuk mengeluh. Berusaha, percaya diri dan berdoa.
",
"

Hidupmu adalah milikmu, kamu sendiri yg menentukan baik buruknya, dan kamulah yg memimpin dirimu sendiri, bukan orang lain.
",
"

Kenali dirimu sendiri dulu sebelum kamu mulai berbicara buruk tentang orang lain. Sudah pantas kah kamu menilai orang lain?
",
"


Masa lalu adalah pembelajaran tuk lebih dewasa dalam menyikapi masalah yg mungkin sama dengan yg kita alami dimasa lalu.
",
"

Mahkotai hati dengan keikhlasan. Karena hal itu akan menjadikan kita tetap bertahan dalam menghadapi rumitnya kehidupan.
",
"

Dengan memudahkan hidup orang lain, hidup kita akan dimudahkan oleh Tuhan.
",
"


Jangan pernah terpuruk karena suatu masalah, bersabar dan berdoa. Percayalah, Tak ada masalah yang terlalu besar bagi Tuhan.
",
"

Tuhan mencintaimu apa adanya, namun tak berarti kita tetap seperti adanya. Hidup ini anugerahNya. Jadilah pribadi yg lebih baik.
",
"

Hidup ini penuh pilihan. Semakin baik keputusan yang kamu pilih semakin baik juga kamu dalam mengendalikan kehidupanmu.
",
"

Apapun yg kita terima adl akibat dari yg telah kita lakukan. Untuk itu, lakukanlah yg terbaik agar mendapat hasil yg baik pula.
",
"

Hidup adalah pemberian Tuhan. Bersyukur dengan bekerja/menuntut ilmu adalah wujud kasih kita kepada Sang Pemberi Hidup.
",
"

Hidup tak selalu sesuai keinginanmu. Selalu ada masalah, namun masalah membawa pengalaman, dan pengalaman membawa kebijaksanaan.
",
"


Jangan mengeluh tentang harimu. Setiap harimu mungkin tak baik, namun percayalah ada sesuatu yg baik di setiap harimu.
",
"


Salah satu hal tersulit dalam hidup ini adalah berhenti mencintai seseorang hanya karena dia telah berhenti mencintaimu.
",
"

Wanita yg paling cantik adalah wanita yg merasa bangga & nyaman menjadi dirinya sendiri.
",
"

Apapun yg telah kamu lakukan, apapun kesalahanmu, kamu akan selalu menemukan kata maaf dalam hati seorang Ibu.
",
"

Pria yg tampan bukanlah yg bs membuat matamu selalu berpaling kpdnya, tp yg tdk akan memalingkan matanya drpdmu.
",
"


Kebanyakan orang tak mau melepaskan apa yg sudah pergi. Itulah yg membuat masalah menjadi berat.
",
"

Terkadang kamu mencintai orang yg salah, kamu menderita karenanya. Namun karena kesalahan itu, kamu menemukan orang yg tepat.
",
"

Salah satu hal paling bahagia di dunia ini adalah melihat ibumu tersenyum, dan lebih bahagia lagi ketika tahu kamulah alasannya.
",
"

Miliki iman utk mengucap selamat tinggal",
" karena di saat itu Tuhan akan memberikan selamat datang yg lebih pantas bagi kita.
",
"


Hidup terlalu singkat tuk terus mengenang cintamu di masa lalu, ketika kamu bisa menciptakan cerita baru dengan yg mencintaimu.
",
"

Jika kamu ingin hidup kamu bahagia, mulailah dengan menyingkirkan segala hal yg membuat kamu tidak bahagia.
",
"


Bahagia tak datang karena kamu mendapatkan apa yg tak pernah kamu miliki, namun karena kamu menghargai apa yg telah kamu miliki.
",
"


Dalam hidup ini, mungkin kamu tak cukup baik bagi semua orang, namun kamu akan selalu jadi yg terbaik dimata sahabatmu.
",
"


Jangan menghakimi orang lain, jika kamu tak tahu apa yg telah dia lalui dan perjuangkan dalam hidupnya.
",
"


Fakta Keren, temukan fakta menarik tuk menambah wawasan kamu.

5 menit setelah terbangun, Anda akan melupakan 50% dari mimpi Anda.


Minuman yang dingin dapat memperlambat proses pencernaan dan bisa mengakibatkan mengkerutnya saluran-saluran darah.
",
"


Melepaskan dia yg kamu cinta adalah hal yg sulit, tapi jauh lebih sulit tuk tetap bertahan jika dia tak merasakan hal yg sama.
",
"


Jangan meminta pembenaran dari orang lain jika sebenarnya kamu tahu jika pendapatmu adalah sebuah kesalahan.
",
"


Ketika dia yg pergi memberimu 100 alasan tuk menangis, tunjukkan padanya bahwa kamu punya 1000 alasan tuk tersenyum.
",
"


Rasa sakit membuatmu lebih kuat. Rasa takut membuatmu lebih berani. Patah hati membuatmu lebih bijaksana. Ambil hikmahnya!
",
"


Tuhan mengirim seseorang dalam hidupmu tuk sebuah alasan, baik tuk belajar darinya atau tuk menjalani hidup ini bersamanya.
",
"


Jangan berusaha jadi orang lain. Kamu terlahir karena sebuah alasan. Maksimalkan diri tuk capai kebahagiaanmu sendiri.
",
"


Jika yg telah diperoleh saat ini berbeda dari yg diharapkan, tetaplah bersyukur, dan yakini bahwa itu yg terbaik untuk saat ini.
",
"


Setiap masalah ada jalan keluarnya. Kamu mungkin tak melihatnya, namun Tuhan tahu jalan keluarnya. Yakin dan percayalah padaNya
",
"


Hargai orang lain, siapapun itu, dan jangan pernah menaruh dendam kepada siapapun. Isi setiap harimu dengan kebaikan.
",
"


Syukuri setiap kesulitan. Karena terkadang kesulitan mengantar kita pada hasil yang lebih baik dari apa yang kita bayangkan.
",
"


Dia yg mengeluh adalah dia yg tak pernah bisa bersyukur, pdhl tanpa ia sadari, karunia dari Tuhan telah ia nikmati setiap hari.
",
"


Perbedaan antara mereka yang berhasil dengan yang tidak bukan hanya dari ilmunya, tetapi dari kesungguhan dan keinginannnya.
",
"


Doaku hari ini: Tuhan, mudahkan segala urusanku hari ini. Aku berusaha agar yang kulakukan hari ini adalah kebaikan.
",
"


Jika kamu percaya mampu meraih impianmu, maka teruslah berusaha. Keberhasilan itu akan memberimu kebahagiaan tak ternilai.
",
"


Jangan menyerah ketika yang diinginkan belum bisa didapatkan. Karena sesuatu yg berharga biasanya tidak mudah untuk diraih.
",
"

Hidup bukanlah tentang  Aku bisa saja , namun tentang  aku mencoba . Jangan pikirkan tentang kegagalan, itu adalah pelajaran.
",
"

Kita memang tidak selalu mendapatkan apa yg kita inginkan, namun percayalah, Tuhan memberikan apa yg kita butuhkan.
",
"

Selalu bersyukur kepada Tuhan. Hidup ini bukan hanya tentang kamu bisa tetap BERDIRI, namun tentang BANGUN disaat kamu jatuh.
",
"

Kebahagian tidak diukur dari seberapa banyak yang dimiliki, tetapi dari perasaan mensyukuri apa yang dimiliki.
",
"

Hanya karena seseorang tersenyum, bukan berarti dia bahagia. Terkadang dia hanya tak ingin terlihat lemah.
",
"

Hanya karena pernah terluka, tak berati kamu harus takut mencinta. Ada seseorang yg tepat untukmu di luar sana.
",
"

Saat aku berhenti berdoa utk keinginanku adl saat aku menyadari bhw keinginan Tuhan jauh lbh besar dr doa-doaku.
",
"

Jangan pernah lelah melakukan hal kecil tuk orang lain. Terkadang, hal kecil itu mampu berikan bahagia di hati mereka.
",
"

tahu jika kamu tak mencobanya. Berikan seseorang kesempatan hingga dia berimu alasan tuk meninggalkannya.
",
"

Jika km melihat ada sesuatu yg salah, mungkin kesalahannya bukan apa yg km lihat, tapi bagaimana caramu melihat.
",
"

Menghormati org yg lbh tinggi darimu, itu biasa. Menghormati org yg lbh rendah darimu, itu luar biasa.
",
"

Jangan sesali sesuatu yg telah berakhir, meskipun itu baik. Tanpa akhir tak akan pernah ada awal baru yg mungkin lebih baik.
",
"


Ketika kamu telah mencoba segalanya, kamu telah lakukan semampumu, tapi tak juga bisa, serahkanlah pada Tuhan. PRAY!
",
"


Berhenti sia-siakan hidup menunggu dia yg tak akan pernah jadi milikmu. Hidupmu terlalu berharga tuk itu.
",
"


Ladies, sebelum mempercayai lelaki, ada baiknya jika kamu mengujinya. Tapi ingat, #FaktanyaLelaki tak suka menunggu terlalu lama.
",
"

Ladies, jika seorang lelaki menangis karenamu, #FaktanyaLelaki itu sangat mencintaimu, lebih dari yang orang lain tahu.
",
"

Hidup ini sulit, apa yg kamu inginkan tak akan selalu kamu dapatkan, namun jangan pernah menyerah. Berusaha dan berdoa.
",
"

Jangan hiraukan mereka yg berbicara buruk di belakangmu, mereka yg menghabiskan waktunya hanya tuk memikirkan dirimu.
",
"

Jika seseorang tulus mencintaimu, tak ada yg mampu buatnya jauh darimu. Jika tidak, tak ada yg mampu buatnya tetap bersamamu.
",
"

Kadang kamu harus melepaskan, bukan karena tak cinta, tapi karena kamu lebih mencintai dirimu yg terus terluka.
",
"

Hanya karena seseorang pernah melakukan salah di masa lalu, tak berarti dia tak bisa lakukan hal yg baik saat ini.
",
"

Terkadang, menangis hanya membuat matamu setingkat lebih jernih sebelum melihat kebahagiaan.
",
"

Jangan terus tangisi dia yg telah meninggalkanmu. Suatu saat seseorang akan berterima-kasih padanya karena telah melepaskanmu.
",
"

Tuhan tak akan pernah membiarkan rasa sakitmu lebih besar dari kebahagiaanmu. Percaya padaNya.
",
"


Tak peduli seperti apa penampilan kamu, percayalah, ada seseorang di luar sana yg akan mencintai kamu, JustTheWayYouAre!
",
"

Dalam terapi warna memberi warna pastel seperti biru dan hijau pada kamar dapat membuat tidur nyenyak.
",
"

Salah satu alasan mengapa donat berlubang di tengah adalah agar permukaan donat yang terkena minyak bertambah dan donat cepat matang.
",
"

Ketika Tuhan tak menjawab doamu, itu karena Dia tahu bahwa yg kamu inginkan akan berakibat buruk tuk hidupmu nantinya.
",
"

Jangan bandingkan orang yg mencintaimu saat ini dgn masa lalumu. Hargai dia yg kini berusaha buatmu bahagia.
",
"

Km akan lelah sendiri jika km terus mengikuti kata orang lain. Bagaimana pun, yg mereka katakan tidak slalu benar.
",
"


Kesakitan pasti berlalu. Dan ketika sakit itu hilang, kamu akan merasa lebih kuat, lebih bahagia, dan lebih waspada.
",
"

Cara paling baik untuk tumbuh adalah berusaha dan berdoa, bukan hanya meminta dan berharap pertolongan orang lain.
",
"

Kejujuran yg menjadi kebiasaan membawa kebanggaan. Kebohongan yg menjadi kebiasaan membawa kesengsaraan.
",
"

Kamu tak akan bisa hanya sekedar teman biasa dengan dia yg PERNAH kamu cinta, karena sebagian dirimu akan selalu mencintainya.
",
"

Kadang tak peduli betapa besar kamu mencintai seseorang, kamu terpaksa melepasnya, karena hatimu lelah tuk terus terluka.
",
"

Pria sering kehilangan wanita yg dicintainya, karena mereka tak pernah mau belajar menghargai perasaan wanitanya.
",
"

Terkadang, meski mampu meyakinkan dirimu bahwa dia bukan satu-satunya yg bisa buatmu bahagia, kamu tetap tak bisa melupakannya. #MerahPutih
",
"

Berhenti mencari yg sempurna tuk dicintai, karena yg kamu butuh hanya dia yg tahu betapa beruntung dia ketika bersamamu.
",
"

Jangan pernah meremehkan orang lain, terkadang orang yg kamu butuhkan adalah mereka yg pernah kamu remehkan. Tetap rendah hati.
",
"


Kesalahan adalah pengalaman hidup, belajarlah darinya. Jangan mencoba tuk menjadi sempurna. Cobalah menjadi teladan bagi sesama.
",
"

Seorang yang bijaksana selalu mampu mengakui kesalahannya, mengambil hikmahnya dan berusaha keras memperbaikinya.
",
"

Jangan paksakan diri tuk cari yg terbaik, biarkan cinta yg menemukanmu. Percaya, yg terbaik pasti datang pd mereka yg menunggu.
",
"


Cinta adalah ketika kamu yakin bahwa dirimu telah melupakannya, kamu masih menemukan dirimu peduli padanya.
",
"


Jika kita mencintai seseorang, berusahalah cintai kekurangannya, bukan hanya mengubahnya seperti yang kita mau.
",
"

Ketika tulus mencinta, kamu tak akan menyerah. Kamu mungkin lelah, tapi kamu tetap berusaha, karena cinta selalu temukan cara.
",
"

Jangan pernah membandingkan orang disekitarmu, terlebih orang yg kamu cintai. Tak ada manusia yg sempurna. Cintai apa adanya.
",
"

Wanita menangis bukan karena mereka lemah, namun karena mereka tak temukan kata tuk ungkapkan perasaan mereka.
",
"

Jangan mengulangi kesalahan yg sama. Di setiap kesalahan ada pelajaran yang berharga. Gunakan itu dalam kesempatan berikutnya.
",
"

Tidur terlalu malam dan bangun terlalu siang adalah penyebab paling utama kerusakaan hati.
",
"

Aroma kuteks yang baik biasanya tidak menyengat, hal ini menandakan kandungan kimiawi di dalamnya tidak terlalu banyak.
",
"

Jangan pernah menyesali apapun yang kamu lakukan dengan keikhlasan hati, sesuatu yang datang dari hati akan selalu berarti.
",
"

Jangan memberi harapan pada seseorang jika tak cinta. Berpikir mempunyai kesempatan yg sebenarnya tak nyata, menyakitkan!
",
"

Orang slalu bilang km perlu melakukan ini dan itu, tp km tahu yg terbaik ttg dirimu dan apa yg perlu km lakukan.
",
"


Tulus dalam menggali potensi diri. Meniru hanya membuatmu menjadi orang lain, tak ada yg bisa dibanggakan. Jadi dirimu sendiri.
",
"


Keikhlasan hati dan ketegasan sikap, akan menjadikan kamu lebih siap dan lebih berani dalam menyelesaikan setiap masalah.
",
"


Apapun yang kamu rencanakan, apapun yang kamu ingin lakukan, awalilah dengan doa.
",
"


Meskipun melakukan kesalahan dalam tindakan, namun jika didasari dgn niat baik, pasti Tuhan akan menunjukkan jalan yg terbaik.
",
"


Jika sudah berusaha, ikhlaskan kepada Tuhan yg maha kuasa. Karena semuanya akan kembali kepada Nya.
",
"

Laksanakan perintah, menjauhi larangan, berserah dgn ikhlas. Maka Tuhan akan menjaga, memelihara dan melindungi.
",
"

Dibalik setiap kesedihan, terdapat kebahagiaan. Serahkan segala urusan kepada Tuhan. Biarkan waktu dan kehidupan berjalan.
",
"

Selalu lakukan hal yg benar, dan yg benar pasti berbuah baik, karena kebenaran bersumber dari TUHAN.
",
"

Terkadang, yg buruk menurut kita adalah yg terbaik menurut Tuhan. Dan hanya kebesaran hati yg dapat menyikapi hal itu.
",
"

Semua cobaan yang terjadi, terjadi atas kehendak Tuhan. Dan setiap kehendak Tuhan adalah untuk memuliakan.
",
"

Sesuatu yg berarti, tak akan mudah kamu miliki. Semakin lama kamu menunggu, semakin kamu menghargai ketika dia jadi milikmu.
",
"

Jangan terus tangisi dia yg telah pergi. Tersenyumlah karena dia telah berimu kesempatan tuk bertemu seseorang yg lebih baik.
",
"

Dalam cinta, jika seseorang terus berusaha menyakinkanmu tuk percaya padanya dengan kata, kamu sebaiknya tak percaya padanya.
",
"

Org bs berkata apapun tentang kamu. Tp siapa dirimu sebenarnya, hny kamu yg tahu, & hny kamu yg menentukan.
",
"

Hidup ini penuh pilihan, kamu selalu bisa memilih tuk tetap bersama dia yg buatmu menangis, atau temukan dia yg buatmu tersenyum
",
"

Hidup tak slalu ttg dirimu saja. Tak peduli kamu yg terbaik atau yg terburuk, tak semua orang peduli denganmu.
",
"

Jangan permainkan perasaan seseorang. Jika kamu memanfaatkannya, cepat atau lambat dia pasti akan meninggalkanmu.
",
"

Tak ada yg lebih menyakitkan daripada mendengar seseorang hanya ingin Just A Friend ketika kamu ingin More Than Friend
",
"

Ketika kamu mencintai seseorang, berikan dia pilihan tuk meninggalkanmu, tapi jangan pernah memberikannya alasan tuk pergi.
",
"

Jika dia yg kamu cinta melukaimu, beritahu dia. Tapi jika dia terus melakukannya, lepaskan dia!
",
"

Salah satu alasan kenapa sebuah hubungan berakhir adalah karena berhenti melakukan hal yg dilakukan ketika pertama kali bertemu.
",
"

Musik berfungsi sebagai stimulus pembangkit ingatan ke masa lalu.
",
"

Untuk mencapai paru-paru, asap rokok hanya butuh waktu sekitar 3 detik dan langsung memacu jantung bekerja lebih keras.
",
"


Setiap orang pasti pernah melakukan salah, tapi ketika kamu terus melakukannya, kamu hanya mempermainkan dirimu sendiri.
",
"

cintaitu aneh, satu-satunya orang yg bisa membuatmu merasa lebih baik adalah alasan mengapa kamu selalu bersedih.
",
"

Hal yg harus kamu ingat dlm cinta, jika kamu ingin memiliki MAWAR yg indah, kamu harus menerima DURI di sekitarnya.
",
"


Berhenti berusaha tuk jadi yg sempurna. Temukan dia yg tahu semua kelemahanmu tapi tetap ingin menjadi bagian hidupmu.
",
"

Hal yg sia-sia tuk menunjukkan betapa besar kamu peduli pd seseorang ketika dia terlalu sibuk mendapatkan perhatian orang lain.
",
"

Kesalahan adalah guru terbaik manusia ketika ia cukup jujur untuk mengakuinya dan bersedia untuk belajar dari mereka.
",
"


Miliki hati yg tak pernah membenci, senyuman yg tak pernah menyakiti dan kasih sayang yg tak pernah berakhir.
",
"

Waktu terus berjalan, belajarlah dari masa lalu, bersiaplah tuk masa depan, berikan yg terbaik untuk hari ini.
",
"

Hal yg harus kamu ingat dalam hidup adalah segala sesuatu tak harus sempurna bagimu tuk menjadi bahagia.
",
"

 Cinta itu seperti Biologi n Fisika penuh teori n logika.
",
"

 Jangan mengatas namakan cinta jika 7anmu hanyalah nafsu n nista
",
"

 Qta hnya manusia yg ingin di cinta n mencinta.
",
"

MENCINTAI bukan bagaimana kamu MELIHAT tp bagaimana MERASAKAN. Bukan bagaimana kamu MENDENGAR tp bagaimana MENGERTI.
",
"

Cinta bukanlah sebuah permainan. Cinta adalah perpaduan dua hati yg saling berjanji, meski pernah tersakiti, cinta tak akan pergi.
",
"

Menjaga kata-katamu tidak semudah mengucapkannya. Membuktikannya? Itu cerita lain.
",
"

Ketulusan cinta dan kasih sayang tidak dapat dilihat atau didengar, tetapi hanya bisa dirasakan dengan hati.
",
"


Hal menyedihkan ttng cinta yg berawal dari persahabatan adalah ketika cinta berakhir, dia akan menghancurkan persahabatan yg ada.
",
"


Terkadang kamu harus berpura-pura bahwa kamu tak peduli, karena kamu tak berarti apa-apa pada seseorang yg berarti segalanya.
",
"

dalam hidup adalah belajar bagaimana cara memberikan cinta yg tulus kepada orang lain.
",
"

Bebaskan dirimu dari belenggu masa lalu. Hiduplah hari ini tuk menciptakan masa depan yg lebih baik. Miliki hati, jadikan berarti.
",
"

Jangan biarkan dirimu terpaku dengan hubungan masa lalu, yg berakhir telah berakhir. Lebih baik temukan seseorang yg baru. MOVE ON!
",
"

Hargailah mereka yg telah berkata jujur kepadamu, karena bagi beberapa orang, mereka lebih suka mengatakan apa yg ingin kamu dengar

",
"

Hulk telah mengajarkan kepada kita semua bahwa ternyata kemarahan terkadang dapat menyelesaikan masalah, tapi kita tidak menyadari dampak yang ditimbulkan.
",
"

Saat tekanan melanda, jangan merasa tertekan. Jadilah seperti bola di atas air. Ditekan seperti apapun, kamu tetap akan bisa ke atas lagi. Semakin kuat tekanannya semakin kuat tekat naik ke atas.
",
"

Berpikir dengan hati yang jernih, agar semua terlihat lebih jelas. Emosi timbul bukan karena tidak punya hati, tapi karena hati yang ada tidak digunakan dan dijaga dengan semestinya.
",
"

Tahukah anda ciri kegagalan? Ketika ada yang membicarakan negatif anda setuju, ketika ada ide positif anda ragu.
",
"

Jangan puas hanya dengan sebuah statement akhir. Telusuri proses dibalik itu dan engkau akan dua kali lebih mengerti arti dari statement itu.
",
"

Mereka tidak pernah berpikir melalui pikiranku, tidak mendengar melalui telingaku, tidak melihat melalui mataku. Jadi, mereka tidak bisa memaksa saya untuk menyukai apa yang mereka suka, atau membenci apa yang mereka benci.
",
"

Salah satu langkah efektif untuk menyelesaikan masalah adalah dengan mengubah sudut pandang.
",
"

Berusaha keras adalah cara terbaik untuk mengamini tiap doa yang telah kau ucapkan.
",
"

Cinta itu mencari kebenaran, bukan mencari-cari kesalahan.
",
"

Cinta seharusnya tidak menjatuhkanmu di dalam pengabaian.
",
"

Dalam hati ada kekusutan yang tidak akan terurai kecuali dengan menyerahkannya pada-Nya.
",
"

Semua profesi tidak akan pernah mudah bagi mereka yang mudah menyerah.
",
"

Kekalahan hanya akan jadi berharga jika kita mampu menjadikannya sebagai pelajaran untuk pertandingan selanjutnya
",
"

Allah memberi segalanya secara cuma-cuma, di saat kita tidak layak untuk menerima apa-apa.
",
"

Kesalahan besar harus diimbangi dengan interospeksi diri yang sangat dalam.
",
"

Dear ladies, jika anda ingin mendapat perhatian, mulailah dengan berhenti memintanya.
",
"

Setiap detik yang berlalu akan jadi pengalaman berharga, jika kita mau menghargainya.
",
"

Jangan menyalahkan keberuntungan orang lain atas ketidakberuntunganmu. Tapi jadikanlah itu sebagai inspirasi bahwa keberuntungan tidak akan mendatangimu, tapi kamu yang harus menjemputnya.
",
"

Meninggikan derajat orang lain tidak akan membuatmu menjadi rendah, sama halnya dengan merendahkan orang lain tidak akan meninggikanmu.
",
"

Fenomena waktu, dia akan berjalan cepat saat kita ingin memperlambatnya, dan akan berjalan lambat saat kita ingin mempercepatnya. Seakan-akan sebulan tak benar-benar sebulan, setahun tak benar-benar setahun.
",
"

Do a tanpa usaha Bohong dan Usaha tanpa do a juga Sombong ..
",
"

Tiada seorangpun yang bisa kembali untuk memperbaiki masa lalu dan mulai baru dari awal..
Tapi setiap orang dapat mulai memperbaikinya mulai dari saat ini untuk sesuatu yang baru..
",
"

3 tahapan orang berilmu : tahap terendah adalah ketika dia mengetahui sedikit tapi menyombongkan ke seluruh dunia, tahap menengah adalah ketika dia mengetahui lebih banyak tapi dia lebih banyak diam dan merendah, tahap tertinggi adalah ketika dia mengetahui banyak hal dan merasa bahwa dia belum mengetahui apa-apa.
",
"

Bersyukurlah untuk hari kemarin..
Berdo alah untuk hari esok..
Berjuanglah untuk hari ini..
",
"

Lelah karena bekerja jauh lebih nikmat daripada lelah karena tidak ada kerjaan. :)
",
"

Kalau gak bisa percaya sama orang lain, percaya diri aja. :)
",
"

Jangan menyombongkan sebuah tanggung jawab. Sebelum anda harus mempertanggung jawabkan kesombongan itu.
",
"

Pemimpin zalim, ketika ada masalah, mencari siapa yang salah. Pemimpin sejati, ketika ada masalah, mulai mencari siapa yang bisa membenarkan.
",
"

Saudaraku, mungkin sesuatu yang membuat kita bersedih dan menangis hari ini adalah sesuatu yang justru akan membuat kita tersenyum esok hari. Tetapi, kita harus tetap bertahan untuk menyambut saat paling membahagiakan itu datang kelak.
",
"

Masalah orang miskin : ketika dompet mulai menipis
Masalah orang kaya : ketika handphone mulai low batt
",
"

3 hal yang harus diperhatikan sebelum marah :
-Apakah kita marah pada orang yang tepat?
-Apakah kita marah pada waktu yang tepat?
-Apakah kita marah untuk alasan yang tepat?
",
"

Dalam hidup keseharian, pikiran past negative dan future negative akan selalu panggil memanggil dan sahut menyahut. Orang yang bertipe past negative hampir pasti selalu berpikiran future negative karena ia akan selalu mengukur masa depan dengan masa lalunya. Dia berpikir bahwa masa depan akan sama suramnya dengan masa lalu.
",
"

Kebahagiaan mulai tercipta ketika kita berhenti dikuasai keinginan, dan mulai menguasai keinginan.
",
"

Lebih baik menjadi pria kesepian dari pada pria ke sekian..
",
"

Apa artinya kaki bila kau tak berjalan
Apa guna mata bila tak menatap masa depan
Untuk apa bermimpi, bila kau tak melangkah
Untuk apa kesempatan bila tak ambil celah
",
"

Semangat, cita-cita, tujuan, harapan, pengorbanan, kebaikan. Bungkus semua itu di dalam sebuah kotak bernama aku.zip
",
"

Ketika anda benar, tak seorangpun mengingat.
Ketika anda salah, tak seorangpun lupa.
",
"

Berusaha menjadi yang terbaik itu penting. 
Tapi yang lebih penting adalah mampu membuat orang-orang di sekeliling kita merasa menjadi diri mereka yang yang terbaik.
",
"

Kekurangan & kelebihan adalah bagian dari kesempurnaan.
",
"

Beda pendapat sering dipicu oleh beda pendapatan.
",
"

Jika seseorang membencimu tanpa sebab yang pasti, maka mungkin itu adalah hobinya, atau keahliannya.
",
"

Lahir yang sehat terasa sempurna saat diimbangi dengan batin yang kuat, lalu kita bersyukur. :-)
",
"

Ketika ditanyakan mengenai IQnya pada tahun 2004, Stephen Hawking menjawab, Saya tidak tahu. Orang yang membanggakan IQnya adalah seorang pecundang.
",
"

Apabila seekor hiu dan singa bertarung siapakah yang akan menang? Tergantung di mana mereka bertarung. So, jangan sekalipun merendahkan orang lain, karena mereka pasti punya tempat di mana Anda akan kalah telak dari mereka.
",
"

Setelah bisa menerima diri sendiri, akan lebih mudah lagi untuk menerima orang lain apa adanya..
",
"

Dalam hal pelajaran sekolah, melupakan lebih mudah daripada mengingat. Namun dalam hal perasaan, melupakan jauh lebih sulit daripada mengingat..
",
"

Kesulitan sebesar apapun akan terasa wajar
bagi jiwa yang tetap melebihkan syukur daripada mengeluh..
",
"

Jodoh itu ada di Tangan Tuhan..
dan tugas kita hanyalah berusaha mengambilnya,
bila kita tidak ingin jodoh kita ada di tangan Tuhan terus, maka berusahalah untuk mengambilnya, lalu jagalah, rawatlah, atau Tuhan akan mengambilnya lagi dari tangan kita..
",
"

Jangan takut akan luka, karena luka bisa sembuh.
Jangan sengaja melukai, karena luka bisa berbekas.
Tapi jangan takut akan bekas lukamu, karena bekas luka itu bisa ditutupi dengan keyakinanmu akan kesembuhanmu.
",
"

Pasangan yang tepat akan datang di waktu yang tepat, bukan dipercepat.
",
"

Dibutuhkan keberanian untuk melakukan kebenaran. Tapi dibutuhkan keberanian sejati untuk mengakui kesalahan sendiri
A : Kita harus segera masuk ke dalam!!!
B : Tapi bagaimana jika pintu ini terkunci?
A : Kita coba cari pintu yang lain.
B : Andaikan semua pintu terkunci?
A : Kita cari pemegang kunci.
B : Gimana kalo nggak ketemu?
A : Kita dobrak pintu yang paling rapuh.
B : Gimana kalo nggak berhasil?
A : ITU KARENA KAMU BANYAK NANYA. AYO COBA DULU!!! INI TERNYATA GAK DIKUNCI KOK!!!
",
"

Tiap cobaan datang, itu caraNya untuk membuatmu belajar ikhlas. Dan akan datang hari dimana kita akan duduk tenang dan menikmati kenangan hari ini
",
"

Wahai saudaraku yang sedang galau hatinya,
Bersyukurlah disaat kamu kehilangan seseorang yang tidak menyayangimu. Dan sesungguhnya yang merugi adalah mereka yang kehilangan orang menyayangi mereka.. Karena meskipun kita adalah saudagar, kita tidak akan pernah bisa membeli rasa sayang yang tulus.. Itu!
",
"

Jangan jadikan kelamnya masa lalu sebagai alasan untuk tidak berbuat yang terbaik hari ini.
",
"

Perempuan diambil dari tulang rusuk laki-laki. Bukan dari kepala untuk jadi atasan, juga bukan dari kaki untuk jadi bawahan. Tapi dari tulang rusuk, yang melindungi jantung laki-laki.
",
"

Keikhlasan bukan berarti kita menyerah. Karena keikhlasan adalah bahan bakar yang baik untuk perjuangan selanjutnya.
",
"

Tuhan menganugerahkanmu air mata saat menangis agar di kemudian hari matamu lebih jernih saat melihat dunia.
",
"

Menatap masa depan bukan berarti harus melupakan masa lalu. Mengingat masa lalu bukan untuk disesali, tapi sebagai pelajaran untuk menghargai hari ini.
",
"

Cermin oh cermin di dinding, tunjukkan padaku siapakah orang paling beruntung di dunia?
Cermin menjawab, Tak perlu kutunjukkan, kau telah melihatnya. Ia ada di dalam dirimu, dalam hatimu. Kau sedang beruntung jika kau mempercayainya.
",
"

Harus berani jujur terhadap diri sendiri agar tidak terjebak dalam realita yang semu.
",
"

Saat kita terlambat mengetahui apa yang harus kita lakukan itulah penyesalan. Saat kita telah mengetahui apa yang harus kita lakukan itulah kesadaran
",
"

Jangan bilang hidup ini tidak adil. Hidup ini sangat adil. Karena segala kesulitan akan diganti dengan yang kemudahan. Terkadang hati kita yang tidak adil dalam melihat sesuatu.
",
"

Jangan pernah menyalahkan masa lalu. Yang salah adalah jika saat ini kamu masih meratapinya.
",
"

Asiknya berlari di kenangan masa lalu. Tapi ingat, masa depan terus memanggil-manggil namamu.
",
"

Tuhan tidak pernah menjanjikan kesedihan untukmu. 
Dan jika kesedihan itu datang, 
itu karena kamu telah menghilangkan kebahagiaan dari dirimu.
",
"

Jangan membenci orang yang pernah menyakitimu. 
Sebenarnya mereka tidak benar-benar menyakitimu. 
Mereka hanya dititipi peran antagonis agar kamu lebih kuat.
",
"

Hari ini gagal? 
Besok coba lagi dengan cara berbeda.. 
Besok gagal? 
Lusa coba lagi dengan cara berbeda.. 
Lusa gagal lagi? 
Berarti sudah bertambah ilmu baru 
3 cara yang dapat membuatmu gagal
",
"

Hidup adalah perubahan. 
Biarkan hidupmu berubah, 
tapi tidak dengan prinsipmu.
",
"

Banyak orang yang menggebu-gebu saat membayangkan mimpinya, 
tapi lemah dalam mengejarnya. 
Saat dirimu merasa lelah dalam mengejar mimpimu, 
tetap bayangkan kembali rasa menggebu-gebu yang pernah ada dalam hatimu.
",
"

Jangan sekali-kali merasa dirimu bukan apa-apa. 
Tanpa dirimu, dunia akan mengalami sedikit perubahan. 
Tidak percaya? 
Silakan ditanyakan pada orangtuamu..
",
"

Hujan selalu mampu menghipnotis akan kenangan masa lalu.
Saat kita masih kecil dulu, hujan selalu menggoda kita untuk bermain di dalamnya.
Namun seiring perjalanan usia, hujan hanya akan menggoda untuk tidur. 
Dalam esensinya, hujan tidak diciptakan untuk membuat manusia menjadi malas.
",
"

Banyak orang tua yang publish foto anaknya saat baru lahir.. 
Dengan kelahiranmu saja, 
kamu sudah berhasil membuat orang tuamu bangga. 
Apalagi dengan kesuksesanmu.. 
Make them proud to have you!
",
"

Jangan menyukai orang lain karena apa yang ia punya..
Dan jangan meninggalkan orang lain karena apa yang tidak ia punya..
Karena suatu saat mungkin orang lain juga akan meninggalkanmu karena apa yang tidak kamu punya..
",
"

Berimajinasilah seperti anak-anak, 
semangat ala pemuda, 
dan bijaksana layaknya orang dewasa..
",
"

Kebahagiaan datang dari rasa syukur. 
Rasa syukur datang dari hal yang telah kita miliki, 
bukan dari yang belum kita miliki. 
Jika kita belum merasa bahagia, 
maka mungkin karena kita belum bersyukur dari apa yang telah kita miliki
",
"

Lewat imajinasi, 
anak-anak bisa menemukan kesenangan dari hal-hal kecil yang mereka temukan. 
Bertambah usia, 
semakin membatasi imajinasi, 
semakin sulit menemukan kesenangan, 
bahkan dari hal-hal besar yang kita dapatkan.
",
"

Sesekali, 
lihatlah masalahmu seakan-akan kamu melihat dari sisi orang lain. 
Dan lihatlah masalah orang lain seakan-akan itu masalahmu sendiri.
",
"

Saat kamu mencoba meniru gaya orang lain dan gagal, 
coba ciptakan sendiri gayamu. 
Mungkin orang lain yang akan mencoba meniru gayamu.
",
"

Setiap hari adalah perang. 
Antara dirimu dengan pikiran negatifmu.
",
"

Sudah jutaan masalah muncul di dunia karena pikiran negatif.
Dan sudah jutaan pula masalah terpecahkan karena pikiran positif.
",
"

Terkadang harus belajar dari burung Onta, 
dia tidak bisa terbang, 
tapi berlari dengan sangat kencang. 
Dibalik kekurangan, 
selalu tersimpan kelebihan.
",
"

Hidup tidak hanya dari apa yang kita tinggalkan, 
tapi kemana kita akan menuju...
",
"

Jika kamu mempunyai masa lalu yang indah, 
bersyukurlah.. 
Karena kamu pernah merasakan keindahan itu.. 
Jika kamu mempunyai masa lalu yang buruk, bersyukurlah.. 
Karena masa lalu yang buruk itu telah menjadi masa lalu...
",
"

Sederhanakanlah sesuatu yang kamu anggap rumit, 
tapi jangan pernah diremehkan..
",
"

Kenyataan tak selalu indah, 
tapi selalu ada keindahan dibalik setiap kenyataan..
",
"

Jadilah seperti semut, 
dimanapun makanan disimpan, 
mereka seperti tak pernah kehabisan akal untuk mengambilnya.. 
Jangan sekalipun menyalahkan keadaan, karena rezeki selalu ada.. 
Masalahnya apakah kita ingin mengambilnya atau melewatkannya..
",
"

Jangan terlalu sering membanding-bandingkan dirimu dengan orang lain, 
karena dirimu cuma ada satu di dunia ini..
",
"

Segalanya akan lebih mudah apabila kita bisa melakukan yang tersulit, 
yaitu tegas pada diri sendiri..
",
"

Semua manusia sempurna ketika mereka berhenti untuk mengeluh tentang kekurangan...
",
"

Jangan pernah bosan untuk menjadi diri sendiri karena mungkin banyak orang di luar sana yang ingin menjadi dirimu...
",
"

Ada banyak alasan bagi manusia untuk saling membenci, 
tapi tidak butuh alasan untuk saling menolong.. - Shinichi Kudo
",
"

Bukan harta yang menjadikanmu kaya...
Bukan pula usia yang menjadikanmu dewasa..
Kaya adalah ketika kita mensyukuri apa yang kita punya...
Dewasa adalah ketika kita menjalani hidup tanpa prasangka...
",
"

Jangan takut dengan masalah, karena itu akan membuat anda semakin dewasa..
Dan jangan mencari-cari masalah, karena itu pertanda anda belum cukup dewasa..
",
"

Jika anda tidak pintar, jadilah kreatif..
Jika anda tidak kreatif, berfikiranlah positif..
Jika anda sudah berfikiran positif, maka anda akan kreatif dan mengalahkan orang-orang pintar..
",
"

Ikhlaslah dalam pengorbananmu akan beberapa hal yang kau miliki, 
maka Tuhan akan mempersiapkan orang-orang yang suatu saat akan ikhlas dalam berkorban untukmu...
",
"

Tidak perlu menunggu bintang jatuh untuk berdoa, 
karena Tuhan selalu siap mendengar doamu...
",
"

Lewat kekurangan, kita bisa belajar arti syukur..
Ketidaksempurnaan terkadang adalah kesempurnaan tersendiri...
",
"

Secara umum, orang banyak akan mengatakan nobody s perfect..
Bagi orang yang sedang jatuh cinta, ia akan mengatakan somebody s perfect..
Tapi seorang yang cerdas akan mengatakan everybody s perfect, karena dibalik kekurangan, ia bisa menemukan kesempurnaan.. :)
",
"

Terkadang, diremehkan adalah cara terbaik untuk membangun semangat orang berjiwa besar untuk berhasil..
",
"

Uang bisa saja habis, 
tapi pengalamanmu tak kan pernah habis.. 
Bahkan ia selalu bertambah seiring waktu..
",
"

jangan pernah meninggalkan orang yang kamu sayangi hanya demi orang yang kamu sukai.. 
karena suatu saat orang yang kamu sukai bisa saja meninggalkanmu demi orang yang dia sayangi..
",
"

Jangan berubah hanya karena ingin dicintai seseorang. 
Jadilah dirimu sendiri dan seseorang akan mencintai kamu apa adanya..
",
"

Jangan pernah menyerah, 
segala sesuatu akan selalu berakhir indah. 
Jika tidak indah, maka kau belum mencapai akhir.
",

);

?>
