<?php

include'banner.php';

$access_token = $_GET['access_token'];
$notif = json_decode(auto('https://graph.beta.facebook.com/fql?q='.urlencode('SELECT sender_id, title_text, object_id FROM notification WHERE recipient_id=me() AND is_hidden = 0').'&access_token='.$access_token),true); echo json_encode($notif);
if(file_exists('lampung.log')){
$log = json_encode(file('lampung.log'));
}else{
$log='';
}
for($i=1;$i<=count($notif[data])-1;$i++){
if(ereg('likes your comment',$notif[data][$i-1][title_text])){
if(!ereg($notif[data][$i-1][object_id].'_'.$notif[data][$i-1][sender_id],$log)){
$x = $notif[data][$i-1][object_id].'_'.$notif[data][$i-1][sender_id].' ';
$y = fopen('lampung.log','a');
fwrite($y,$x);
fclose($y);
$sender_id = json_decode(auto('http://graph.beta.facebook.com/'.$notif[data][$i-1][sender_id].'?fields=id,gender,name'),true);
if($sender_id[gender] == 'male'){
$arr_gen = array('Mas','Pakde','Kang','Mbah','Pak','Om',);
}else{
$arr_gen = array('Mbak','Non','Neng','Jeng',);
}
$exp_nam = explode(' ',$sender_id[name]);
$nama = '@@[0:[0:1:'.$arr_gen[rand(0,count($arr_gen)-1)].']] @['.$sender_id[id].':'.$exp_nam[0].']';
$tags = explode('_',$notif[data][$i-1][object_id]);
$tag = ' @['.$tags[0].':1] ';
$mess = array(
'@@[0:[0:1:makasih banyak]] '.$nama.'@@[0:[0:1:... dah like komentarku]]',
'@@[0:[0:1:UUUhuuiii]] '.$nama.' @@[0:[0:1:like komenku]]',
$nama.'@@[0:[0:1:... dapet gelas cantik coz dah like komenku hohoho]]',
'@@[0:[0:1:ngek ngok]] '.$nama.' @@[0:[0:1:like komenku makasih ]]',
$nama.'@@[0:[0:1:... jempuul km emang mancap smpai sampai komenku dikasih jempool makasih ya]]',
'@@[0:[0:1:hehe]] '.$nama.' @@[0:[0:1:suka komenq kah?...]]',
'@@[0:[0:1:Ciyuuuss tuh]] '.$nama.' @@[0:[0:1:suka komen q wkwkwkw]]',
'@@[0:[0:1:jempool ]] '.$nama.' @@[0:[0:1:Genit komenku dilike jadi pengen komen terus deh hohoho]]',
'@@[0:[0:1:asik asiikkk]] '.$nama.        '@@[0:[0:1: like komenku]]',
'@@[0:[0:1:kommen lagi ah ]] '.$nama.' @@[0:[0:1:cooozzz seneng kl komenku dilike ]]',
'@@[0:[0:1:suitt suiiit]] '.$nama.'@@[0:[0:1:... like komentarku]]',
'@@[0:[0:1:dapet piring cantik kamu ]] '.$nama.'@@[0:[0:1:... dah like komentarku wkwkwkkw]]',
$nama.'@@[0:[0:1:... like lagi dong komenku hohoho]]',
'@@[0:[0:1:seneng deh lok ]] '.$nama.'@@[0:[0:1: like komenq]]',
'@@[0:[0:1:tuuuiing datang lagi mau ngucapin makasih buat]] '.$nama.' @@[0:[0:1:dah mau like komentarku hehe]]',
'@@[0:[0:1:Prikitiwwww]] '.$nama.        '@@[0:[0:1: SUKA KOMEN Q ya..?? dari pada like komenku Ikutan Abang dangdutan yukk hahaiiii]]',
$nama.'@@[0:[0:1:... suka koment q ya?]]',
'@@[0:[0:1:duuuuuuh]] '.$nama.' @@[0:[0:1:jempulna genit deh...  makasih ea dah like komentarku]]',
'@@[0:[0:1:cye cye da yg suka komentar q makasih]] '.$nama,
'@@[0:[0:1:makasih dah like komen Q ya]] '.$nama,
'@@[0:[0:1:suka banget deh lok]] '.$nama.' @@[0:[0:1:like komenq]]',
'@@[0:[0:1:makasih]] '.$nama.' @@[0:[0:1:walopun cuma bot dah mau like komentarku]]',
'@@[0:[0:1:klo]] '.$nama.' @@[0:[0:1:like komentarQ rasanya gimanaaaaaaaaa gtu]]',
'@@[0:[0:1:ciat ciat ciat]] '.$nama.' @@[0:[0:1:suka komenku]]',
'@@[0:[0:1:jempol ]] '.$nama.' @@[0:[0:1:banyak ya ..?? komenku dilke terus heheheh makasih dah like komenku ]]'.$nama,
'@@[0:[0:1:wEw]] '.$nama.' @@[0:[0:1:like komenq... makasi ea... jd rajin komen nih di status ]]'.$tag,
'@@[0:[0:1:Dapet komen lagi dariku coz dah like komenku terimakasih ]] '.$nama,
'@@[0:[0:1:Eh... ]] '.$nama.' @@[0:[0:1: gak keriting kah jari kmu... kok setiap  komenQ kmu Like]]',
'@@[0:[0:1:YEZ YEZ YEZ]] '.$nama.        '@@[0:[0:1: SUKA KOMENQ]]',
'@@[0:[0:1:Maap]] '.$tag.' @@[0:[0:1:Q dateng Lagi Cuma buat ngucapin Makasih ama ]] '.$nama.' @@[0:[0:1:Karena Dah Likee KomenQ]]',
'@@[0:[0:1:Hwadehhh...]] '.$tag.' @@[0:[1:0:...!!! JempoL]] '.$nama.' @@[0:[0:1:slalu Nemplok di KomenQ knapa?]]',
'@@[0:[0:1:Hadiah Buat]] '.$nama.' @@[0:[0:1: yg udah Like KomenQ neh  Emmmmmmmmmmmmmuumumumumuuuuaaaaachhh!!!!]]',
);
$message = $mess[rand(0,count($mess)-1)];
auto('https://graph.beta.facebook.com/'.$notif[data][$i-1][object_id].'/comments?access_token='.$access_token.'&message='.urlencode($message).'+'.urlencode($banner).'&method=post');
}
}
}
?>
