<?php

include'banner.php';

$access_token = $_GET['access_token']; 
if(file_exists('cmy2_log')){
$log=json_encode(file('cmy2_log'));
}else{
$log='';
}
$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Met dini 🌙 hari .. ','Met jelang pagi . ','Selamat 🌷 Pagi 🌷 ','Met 🌷 Pagi 🌱 ','｡◕‿◕｡ ','☀~ ','Breakfast time 🍔☕🍸🍺 . ','Met Tifitas 💻 ','Have a nice day ☀ . ','Good ☀ Day . ','Time for 🍔☕🍸🍺 lunch . ','Met 🍴 makan 🍵  🍔☕🍸🍺 siang ☀ .','Good siang ☀ . ','Met jelang sore . ','Good afternoon . ','☀~ ','Salam kompak 👈👍 jempol er👉 ','Good evening . ','Time for 🍔☕🍸🍺 dinner . ','Met 📺 Online ~ . ','Met 💤 rehat .','Have 💤 nice 💤 dream . ','Good 🌙 night 🌙 ','Good merem 💤💤 ','Met rehat 💤💤 ',);
$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);
$aiueo = array('Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M','q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m',);
$uuu = array('ҩ','ω','є','ʀ','т','γ','µ','ɨ','ღ','ρ','ɑ','s','∂','ƒ','ɢ','ɦ','ʆ','ќ','ℓ','ẕ','х','ς','ν','в','и','ʍ','ҩ','ω','є','ʀ','т','γ','µ','ɨ','ღ','ρ','ɑ','s','∂','ƒ','ɢ','ɦ','ʆ','ќ','ℓ','ẕ','х','ς','ν','в','и','ʍ',);
$me = json_decode(auto('https://graph.beta.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat=json_decode(auto('https://graph.beta.facebook.com/me/home?fields=id,message,created_time,from,comments,type&access_token='.$access_token.'&offset=0&limit=15'),true);

for($i=1;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i-1][id],$log)){
if($stat[data][$i-1][from][id] != $me[id]){
$x=$stat[data][$i-1][id].'  ';
$y = fopen('cmy2_log','a');
fwrite($y,$x);
fclose($y);
$bot=array('nomer','latah','biasa',);
$robot=$bot[rand(0,count($bot)-1)];
$s=$stat[data][$i-1][message];
$qwerty = array('0','1','2','3','4','5','6','7','8','9','10',);
$font = array(' 🎓 ',' 🍸 ',' 🎉 ',' 🍔 ',' 🎈 ',' 💃 ',' 🐬 ',' 🎶 ',' 👀 ',' 😱 ',' 🌟 ',);
$inc=array('emojitor.php',);
include $inc[rand(0,count($inc)-1)];
$mess = $text[rand(0,count($text)-1)];
$motivator = str_replace($qwerty,$font,$mess);

$gen=json_decode(auto('http://graph.beta.facebook.com/'.$stat[data][$i-1][from][id].'?fields=gender'),true);

if($gen[gender] == 'male'){
$arr_gen = array(' 👮 Mas_',' 👮 Mas_',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}else{
$arr_gen = array(' 👈😍👉  ',' 👈😍👉 ',' 👈😍👉 ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}


$exp_nam = explode(' ',$stat[data][$i-1][from][name]);
$nama = $gender.' '.$exp_nam[0];
$tags = explode(' ',$stat[data][$i-1][from][id]);
$tagged_name = ' @['.$tags[0].':1] ';



if($stat[data][$i-1][type] == 'photo' ){
$salah= array(
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

Very cool picture  
'.$tagged_name.' '.$motivator .'

I like it ........

'.$ucapan.' '.$nama.' 

',

'
'.$tagged_name.' '.$motivator .' ... 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

Waw exist terus nich '.$tagged_name.' '.$motivator .' 
 
'.$ucapan.' '.$nama.' 
',

'
---------------------- 👈😍👉 Ooo...
'.$motivator .'

itu foto asli bukan '.$tagged_name.' '.$motivator .' ? hixhixhix 
 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

gilee benerr dach foto-nya.. '.$tagged_name.' '.$motivator .' ... 

'.$ucapan.' '.$nama.'

',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

jempol deeeh buat fotonya ..'.$tagged_name.' '.$motivator .' ... 
 
.. 👼 👼 👼 😹 😹 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' ...  duch foto-nya bikin tangan gatel pengen like :P
 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

fotonya bagus banget.. download boleh gak '.$tagged_name.' '.$motivator .' ?
 
👼 👼 👼 😹 😹

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

itu foto kayaknya udah gak asing lagi dech '.$tagged_name.' '.$motivator .' ... 
hmmm.. tapi siapa ya??? apa mungkin aku yang nglindur kalee yaa?? 👈😷👉..

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

karena udah jempolin foto-kamu..
'.$tagged_name.' '.$motivator .' ... 
Waktunya untuk bilaang... 

[s][e][m][p][u][r][n][a]😹 😹

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

Foto lagi yaa  '.$tagged_name.' '.$motivator .' ... 
Siap - siap ?  1.. 2.. 3.. senyum !!
Jepreeett.. grompyang.. dhuaaarr !! 
hallah potone kobong kabeeeh .. :v 
👼 👼 👼  ...... hahahaaaaaa

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

rajin banget '.$tagged_name.' '.$motivator .' online😹 😹
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

really good picture.. '.$tagged_name.' '.$motivator .' ... 
 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' picture who is that ?? hehee ..
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

double thumbs up for this photo.. 👼 👼 👼 😹 😹 
 
Setuju yaaa ?? :P '.$tagged_name.' '.$motivator .' ... 

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

I was struck by the picture '.$tagged_name.' '.$motivator .' ...
.. asek hahahaa..
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

👦 👧  ..... fotonya keyyen '.$tagged_name.' '.$motivator .' ... 
 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

Okee siiaaapp '.$tagged_name.' '.$motivator .' ... 1 2 3.. action !!
Jepreeett.. grompyang.. dhuaaarr !! hallah 
potone kobong kabeeeh .. :v wkwkwk 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

bagus  tenan  tuh fotone ..'.$tagged_name.' '.$motivator .' ... 
 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

apik tenan photo-ne '.$tagged_name.' '.$motivator .'

like ndiz wae lah 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

nice picture '.$tagged_name.' '.$motivator .' 👼 👼 👼 😹 😹 
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

Okee siiaaapp '.$tagged_name.' '.$motivator .' ... 1 2 3.. action !!
Jepreeett.. grompyang.. dhuaaarr 
!! hallah potone kobong.. :v hihihiii ....
like ndizZ aja dech 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

steady picture '.$tagged_name.' '.$motivator .' ... 👼 👼 👼 😹 😹 
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

drop-dead gorgeous picture..
'.$tagged_name.' '.$motivator .' ... 
i like it.. 
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

i love it with this photo..😹 😹
'.$tagged_name.' '.$motivator .' ... 
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

foto-nya siiip '.$tagged_name.' '.$motivator .' ... 
jempol  untukmu.. 👼 👼 👼 😹 😹 
 
'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' ... 
kayak pernah liat dech fotonya :P
........

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

Really gooooood picture '.$tagged_name.' '.$motivator .' 😹 😹 
 
'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

jempol-jempil dach 
'.$tagged_name.' '.$motivator .' buat fotonya.. 👈😷👉 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

keren fotonya  '.$tagged_name.' '.$motivator .' ...?? :P
 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

hahahaa.. photo-nya capa twuh '.$tagged_name.' '.$motivator .' ...?? 

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

wha wha whaduuh '.$tagged_name.' '.$motivator .' gak keliatan photo-nya.. 
maklum aja dah cuma make hp layar banting nih :D
hahaha..

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

ciat ciat ciat photonya bikin tuink tuink dech  
'.$tagged_name.' '.$motivator .' ... 
👈😷👉 absen jempol yaaa
 
oke sip !

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

👈😷👉... Mantaabs photo-nya '.$tagged_name.' '.$motivator .' 
komen aaach ...
 
'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

Jempooooooooool '.$tagged_name.' '.$motivator .' 

'.$ucapan.' '.$nama.'  '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

gimana sich cara nya upload photo 
biar bisa keren kayak gitu.. '.$tagged_name.' '.$motivator .' 

'.$nama.' ... '.$ucapan.' '.$nama.' 
',

);

}else{
if(ereg('jancok',$s) || ereg(' asu ',$s) || ereg('taek',$s) || ereg('jancox',$s) || ereg('jamput',$s) || ereg('raimu',$s) || ereg('ndasmu',$s) || ereg('kontol',$s) || ereg('itil',$s) || ereg('anjing',$s) || ereg('hancok',$s) ){
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

waduuh lagi esmosi nih 😱 .. '.$tagged_name.' '.$motivator .' 
numpang lewat aja deeh  
. . . . . 
Do not be angry or sad, 
because it will not solve anything.
Jangan marah atau sedih, 
karena itu tidak akan menyelesaikan apapun.

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.'  😱 Wew - Ge Marah...! What Happen ? ... '.$motivator .'

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' marah2 cpet tua loh 😱 
. . . . . 
Do not waste your time to think in a long time. 
Act immediately and prioritize for goodness.
Jangan buang waktu  untuk terlalu lama berpikir. 
Bertindaklah dengan segera dan utamakan kebaikan.

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' 😒 sabar sabar dan tetap semangat 
A careless tongue can be more dangerous than a sword.

'.$ucapan.' '.$nama.' 
',
);
}else{
if(ereg('panas',$s) || ereg('sumuk',$s) || ereg('puanas',$s) || ereg('puanaz',$s) || ereg('panaz',$s) || ereg('gerah',$s) || ereg('neroko',$s) || ereg('koyo kobong',$s) || ereg('Panas',$s) ){
$salah=array(
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' sama di sini juga ... 

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' masuk kulkas 
pasti adem😹 😹heee 

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' nyemplung kolam , 
biar adem 

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' minum es campur pasti enak 
... seger haha.. 

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' deket sumur aj 
dem loh.. wkwkwk 

'.$ucapan.' '.$nama.' 
',
);
}else{
if(ereg('cape',$s) || ereg('kesel',$s) || ereg('keju',$s) || ereg('linu',$s) || ereg('klenger',$s) || ereg('lempoh',$s) || ereg('lesu',$s) || ereg('kemeng',$s) || ereg('nggregesi',$s)){
$salah=array(
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' jalan-jalan refreshing 
biar seger lagiii . .

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' cape ya '.$tagged_name.' '.$motivator .' 
sini tak pijitin :P

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' istirahat dulu kalo cape :D

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' jempol dulu , 
kalo sempet mampir ke status ku 
yaa

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' mampir ke status ku aja , 
tak kenalin ma temenku biar 
banyak temen hee😹 😹 _ 

'.$ucapan.' '.$nama.' 
',
);
}else{
if(ereg('cinta',$s) || ereg('love',$s) || ereg('rindu',$s) || ereg('kangen',$s) || ereg('LOVE',$s) || ereg('nyayang',$s) || ereg('kekasih',$s) || ereg('peluk',$s) || ereg('Cinta',$s)){
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' lagi kasmaran😹 😹heee...

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Curhat nya di fb , 
datengin aja langsung hehee😹 😹

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Moga aja dia ngerti 
apa yang kamu rasain :) ..

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' lagi cinta-cintaan di fb :P
tak laporin pak RT loh ... wkwkwk :v :v 
'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' 
siT 💑 sUiiiiiiit.........!!!

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' sMoga statusmu di baca 
sama si dia ehm ...😹 😹 .. 

'.$ucapan.' '.$nama.' 
',
);
}else{
if(ereg('like',$s) || ereg('Like',$s) || ereg('salkomsel',$s) || ereg('SALKOMSEL',$s) || ereg('jempol',$s) || ereg('Jempol',$s) || ereg('Salkomsel',$s) || ereg('JEMPOL',$s) || ereg('LIKE',$s)){
$salah=array(
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Numpang Like Gitu 
Haha....SALKOMSEL!!!

'.$ucapan.' '.$nama.' 
',
'baca status nya '.$tagged_name.' '.$motivator .' 
jempolku langsung nemplok ! wkwkwk ..

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' SALKOMSEL aja deh !

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Yes like This :D
You can when you believe.
pasti bisa ketika  percaya ...
setuju gak ??

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

Dua jempol sekaligus 
buat Statusnya  '.$tagged_name.' '.$motivator .' 
jempol satunya pinjem punya 
pak RT :P

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

Dua Jempol Sekaligus 
Buat status nya '.$tagged_name.' '.$motivator .' 
yg satunya Minjem tetangga👈😜👉

'.$ucapan.' '.$nama.' 
',

);
}else{
if(ereg('sepi',$s) || ereg('sunyi',$s) || ereg('sendiri',$s) || ereg('Sepi',$s) || ereg('Sunyi',$s) || ereg('Sendiri',$s) || ereg('Dewean',$s) || ereg('dewekan',$s) || ereg('dewean',$s))
{
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' denger musik 
biar terhibur 🎶

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' nonton 📺 dangdutan geh , 
biar gak manyun😹 😹

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

Di sini rame  '.$tagged_name.' '.$motivator .' 

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Like dulu akh... 

'.$ucapan.' '.$nama.' 
',

);
}else{
if(ereg('off',$s) || ereg('OFF',$s) || ereg('Off',$s) || ereg('ngantuk',$s) || ereg('ngantok',$s) || ereg('bobo',$s) || ereg('bubu',$s) || ereg('tidur',$s) || ereg('molor',$s)){
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' met rehat aj 

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' smoga besok lebih fresh 
met rehat...

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' met rehat aj '.$tagged_name.' '.$motivator .' :D...

'.$ucapan.' '.$nama.' 
',
);
}else{
if(ereg('Good morning',$s) || ereg('Good afternoon',$s) || ereg('nite',$s) || ereg('pagi',$s) || ereg('malam',$s) || ereg('Good nite',$s) || ereg('hello',$s) || ereg('hallo',$s) || ereg('pa kabar',$s)){
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

apa kabar - how are you '.$tagged_name.' '.$motivator .' ?? 

'.$ucapan.' '.$nama.' 
',
);
}else{
if(ereg('luwe',$s) || ereg('lapar',$s) || ereg('laper',$s) || ereg('mangan',$s) || ereg('mbadok',$s) || ereg('nguntal',$s) || ereg('nyosor',$s) || ereg('ewul',$s) || ereg('hungry',$s)){
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' 🍔 makanan  nya tak kirim 
lewat sms yaaa 👦 👧  i 
'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' makan dyu 
ntar sakit loh😹 😹 ..

'.$ucapan.' '.$nama.' 
',

);
}else{
if(ereg('benci',$s) || ereg('sebel',$s) || ereg('muak',$s) || ereg('muntah',$s) || ereg('gila',$s) || ereg('gendeng',$s) || ereg('edan',$s) || ereg('koclok',$s) || ereg('cengoh',$s) ){
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

ampe sgitunya _ ? 
sabar yaa.'.$tagged_name.' '.$motivator .' 
sabar yaa . . .
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Sabar - sabar orang sabar 
anu-nya lebar 👦 👧 . . . 

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Waduuuuh ? kenapa tuh👈😜👉 ..

'.$ucapan.' '.$nama.' 
',
);
}else{
if(ereg('adus',$s) || ereg('mandi',$s) || ereg('mande',$s) || ereg('siram',$s) || ereg('Mandi',$s) || ereg('lumban',$s) || ereg('MANDI',$s) || ereg('Lumban',$s) || ereg('slulop',$s) ){
$salah=array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .'😹 😹udah brapa hari tuh 
gak mandi ? :P

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .'😹 😹cepetan mandi ntar mati lampu 
malah gak jadi mandi Wkwkwwkk ..

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .'😹 😹jarang ya mandi hehee 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .'😹 😹udah brapa hari tuh 
gak kena aer WkWkWk👈😜👉..

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' udah sana cepetan mandi 
udah di tungguin tuh 👦 👧  ...hhi :D

'.$ucapan.' '.$nama.' 
',
);
}else{

if($robot == 'kata-kata'){
$konyol=auto('http://zbot.ap01.aws.af.cm/motivasi.php');
$motivasi=auto('http://zbot.ap01.aws.af.cm/motivasi.php');
$salah=array($konyol,$motivasi,);

}

if($robot == 'latah'){
if(($i-1 > 0 ) && ($i-1< count($stat[data])-1)){
$salah = array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

statusnya '.$tagged_name.' '.$motivator .' di sulap dulu 
biar tambah cetar :P

----------------------O 👈😍👉 Ooo...

'.str_replace($aiueo,$uuu,$stat[data][$i-1][message]).'


----------------------O 👈😍👉 Ooo...

Gimana twuh .. '.$tagged_name.' '.$motivator .' 
cetar gak .... ? 👦 👧  ...

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

biar telat yg penting hadir 
'.$tagged_name.' '.$motivator .'  :v wkwkwk 

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

dua jempol '.$tagged_name.' '.$motivator .' 
satunya pinjem jempol pak Lurah ....
 
:v :v :v  
'.$ucapan.' '.$nama.' 
',


);
}else{
$salah = array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

lapor '.$tagged_name.' '.$motivator .'..!!!
statuz sampean sudah saya jempul

laporan selesai.. !! :v :v 👦 👧 
mampir ke statusku ea  ... :D

'.$ucapan.' '.$nama.' 
',

);

}
}
if($robot == 'biasa'){
$salah = array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' as friend  i am trying to keep 
good relation , 
thats why i always come for jempolin status mu
are you agree ?😹 😹 👦 👧   ...

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' (Y) Jempol dulu , 
if you have a time please come to my stats 
LOLZ :v :v :v 

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' are you fine ??😹 😹

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

i am coming for a very special status
'.$tagged_name.' '.$motivator .' double jempol (Y) 👦 👧  ... ...

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' again and again to give you 
one thumbs and comments :v for u my friend 😹 😹..

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' I am so sorry because im using a robot  
if you dont like it just please inbok me 

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

everytime you make a stats , 
I always come to give thumbs here ..
whats about you '.$tagged_name.' '.$motivator .' ?  

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' apa kabar , how are you today ?😹 😹...

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

Where are you been my friend 
'.$tagged_name.' '.$motivator .' its long time not see ur stats 

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' jempol keseleo like terus👈😜👉

'.$ucapan.' '.$nama.' 
',
);
}

if($robot == 'nomer'){
$compret=json_decode(auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=50&fields=message,from'),true);
$nom = $stat[data][$i-1][comments][count]+1;
$cm_id_a = $compret[data][0][from][id];
$taga='@['.$cm_id_a.':1]';
if(count($compret[data]) == 1 ) $hahay = '0'; else $hahay = count($compret[data])-1;
$cm_id_z = $compret[data][$hahay][from][id];
$tagz='@['.$cm_id_z.':1]';
$cmno = count($compret[data])-1;
if($cmno <= 0 ){
$mescma = $compret[data][0][message];
$mescmz = $mescma;
}else{
$mescma = $compret[data][0][message];
$mescmz = $compret[data][$hahay][message];
}
if($nom == 1){
$salah = array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

My comments always hadir No- '.$nom.'
hehe.... apa kabar '.$nama,

'I wont be late just for 
Hadiiir No- '.$nom.'  '.$tagged_name.' '.$motivator .' 
👈😷👉

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

mampir jempolin status nya ....
.... Hahay how are you '.$nama,

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

apa kabar ? '.$nama,

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

Selalu hadir No-'.$nom.' 
semoga aja ada yg baik hati nawarin makanan 
wkwkwk :v 😹 😹

'.$ucapan.' '.$nama.' 
',
);
}else
{
$salah = array(
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

Special buat status '.$tagged_name.' '.$motivator .' 
di like dulu . . . . .

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' hadiiiiir

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

bwt status'.$tagged_name.' '.$motivator .' jempol deh

'.$ucapan.' '.$nama.' 
',

'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' status nya nongol lagi - 
di like dulu 

'.$ucapan.' '.$nama.' 
',

'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

(Y) double jempol (Y)  '.$tagged_name.' '.$motivator .' 
thanks a lot ya😹 😹hee..

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Jempol mendarat !👈😜👉
Special thumbs for you :v

'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' apa kabar ...😹 😹How are you ? :D

'.$ucapan.' '.$nama.' 
',
'
----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' (Y)  Jempol nancep ! 
'.$ucapan.' '.$nama.' 
',
'

----------------------O 👈😍👉 Ooo...
'.$motivator .'

'.$tagged_name.' '.$motivator .' Jempol udh keriting nih hihhiii 
like terus👈😜👉

'.$ucapan.'
',
);
}
}


}
}
}
}
}
}
}
}
}
}
}
}


$TimeZone="+7";
$_time=gmdate("H", time() + ($TimeZone * 60 * 60));
if ($_time > 01) $_sambutan = "Ohayou gozaimas .";
else if ($_time > 24) $_sambutan = "Konbanwa . ";
else $_sambutan = "Selamat Pagi  ";

$gentime = microtime();
$gentime = explode(' ',$gentime);
$gentime = $gentime[0];
$pg_end = $gentime;
$totaltime = ($pg_end - $pg_start);
$showtime = number_format($totaltime, 1, '.', '');

$hari=gmdate("D", time()+60*60*7);
if((gmdate("D", time()+60*60*7))=="Sun"){ $hari="Sunday"; }
if((gmdate("D", time()+60*60*7))=="Mon"){ $hari="Monday"; }
if((gmdate("D", time()+60*60*7))=="Tue"){ $hari="Tuesday"; }
if((gmdate("D", time()+60*60*7))=="Wed"){ $hari="Wednesday"; }
if((gmdate("D", time()+60*60*7))=="Thu"){ $hari="Thursday"; }
if((gmdate("D", time()+60*60*7))=="Fri"){ $hari="Friday"; }
if((gmdate("D", time()+60*60*7))=="Sat"){ $hari="Saturday"; }
$jame=" ".gmdate("g:i:s a", time()+60*60*7);
$tgl=" ".gmdate("j - m - Y", time()+60*60*7);

$nomerku = $stat[data][$i-1][comments][count]+1;
$total = $stat[data][$i-1][comments][count];
$habiscomment = $stat[data][$i-2][from][name];

$crot = $me[id];
$tot='@['.$crot.':1]';
$we='@[0:0: ]';

$habiscomment1='
@@[0:[0:1:===============oOOo===============]]
:|] '.$ucapan.' '.$nama.'
:|] '.$hari.' ♂ '.$tgl.' ♂ '.$jame.'
βø† βψ : https://facebook.com/profile.php :)
:|] вøт вч : http://www.anihanzsub.net (y)
@@[0:[0:1:===============oOOo===============]]';
$habiscomment3 = '[['.$stat[data][$i-1][from][id].']] ';
$message1 = ''
.$salah[rand(0,count($salah)-1)];

$message=($habiscomment3.$nama.$message1.$habiscomment1.$banner);

auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/likes?access_token='.$access_token.'&method=post');
auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message).'&method=post');
echo $stat[data][$i-1][from][name].'=> '.htmlspecialchars($stat[data][$i-1][message]).'
Comment => '.$message.'';
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}

?>