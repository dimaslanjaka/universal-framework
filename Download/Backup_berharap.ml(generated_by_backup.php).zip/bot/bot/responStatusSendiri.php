<?php

include'banner.php';

$access_token = $_GET['access_token']; 
$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Met dini 🌙 hari . ','Met jelang pagi . ','Selamat 🌷 Pagi 🌷 ','Met 🌷 Pagi 🌱 ','｡◕‿◕｡ ','☀~ ','Breakfast time 🍔☕🍸🍺 . ','Met Tifitas 💻 ','Have a nice day ☀ . ','Good ☀ Day . ','Time for 🍔☕🍸🍺 lunch . ','Met 🍴 makan 🍵  🍔☕🍸🍺 siang ☀ .','Good siang ☀ . ','Met jelang sore . ','Good afternoon . ','☀~ ','Salam kompak 👈👍 jempol er👉 ','Good evening . ','Time for 🍔☕🍸🍺 dinner . ','Met 📺 Online ~ . ','Met 💤 rehat .','Have 💤 nice 💤 dream . ','Good 🌙 night 🌙 ','Good merem 💤💤 ','Met rehat 💤💤 ',);
$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);
$me = json_decode(auto('https://graph.beta.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$stat = json_decode(auto('https://graph.beta.facebook.com/me/feed?fields=id&access_token='.$access_token.'&offset=0&limit=10'),true);
$log = json_encode(file('res_own_status1'));
for($i=1;$i<=count($stat[data]);$i++){
$com = json_decode(auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=25&fields=id,message,from'),true);
if(count($com[data]) > 0){
for($c=1;$c<=count($com[data]);$c++){
$dat = explode($com[data][$c-1][id],$log);
if(count($dat) > 1){
echo'Done<br/>';
}else{
$logx = $com[data][$c-1][id].'__';
$logy = fopen('res_own_status1','a');
fwrite($logy,$logx);
fclose($logy);
$qwerty = array('0','1','2','3','4','5','6','7','8','9','10',);
$font = array(' 🍎 ',' 🍓 ',' ☕ ',' 🍺 ',' 🍔 ',' 🎈 ',' 🎉 ',' 🍊 ',' 🍸 ',' 🍺 ',);



$inc=array('emojitor.php',);
include $inc[rand(0,count($inc)-1)];
$mess = $text[rand(0,count($text)-1)];
$motivator = str_replace($qwerty,$font,$mess);		

$gen = json_decode(auto('http://graph.beta.facebook.com/'.$com[data][$c-1][from][id].'?fields=gender'),true);


if($gen[gender] == 'male'){
$arr_gen = array(' 👮 Mas_',' 👮 Mas_',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}else{
$arr_gen = array(' 👈👀👉 ',' 👈👀👉 ',' 👈👀👉 ',);
$gender = $arr_gen[rand(0,count ($arr_gen)-1)];
}

$exp_nam = explode(' ',$com[data][$c-1][from][name]);
$nama = $gender.' '.$exp_nam[0];
$tags = explode(' ',$com[data][$c-1][from][id]);
$tagged_name = ' @['.$tags[0].':1] ';


$kata=$com[data][$c-1][message];
if(ereg('MAAF',$kata) || ereg('maaf',$kata) || ereg('Maaf',$kata)){
$arr_mess = array( 'jiaaaah... pake maap segala 👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.' 

eaaa.... gak papa udah aku maaf in koq... 
ntar komen lagi ea '.$tagged_name.' -o- '.$motivator.' '.$nama.'....😹 😹👈😷👉',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'
aduuuuh tiada maap bagi mu '.$tagged_name.' -o- '.$motivator.' '.$nama.'...😹 😹
gimana nieh... wkwkwkwk',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

keliling kampung dulu 5x '.$tagged_name.' -o- '.$motivator.' '.$nama.'... 
ntar di maapin ... :v :v wkwkwkwk',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

yeeee enak aja minta maaf... Nyanyi dulu 
'.$tagged_name.' -o- '.$motivator.' '.$nama.'...😹 😹nang ning ning nang oooo.... 
5X wkwkwk',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

maaf...?? emang kenapa '.$nama,

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

masama '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹Aku😹 😹juga minta maaf... 
ya ??',
);
}else{
if(ereg('ASSALAM',$kata) || ereg('Assalamualaikum',$kata) || ereg('Askum',$kata) || ereg('assalamualaikum',$kata) || ereg('askum',$kata) || ereg('ASKUM',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Waalaikum salam...',
);
}else{
if(ereg('mandi',$kata) || ereg('pake celana',$kata) || ereg('mande',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

idiiih... '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹parno 👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

iaa sana mandi duluan👈😜👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

👦 👧  ... anuu nya keliatan twuh hahaha',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

lohh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹mandi kuq gak ajak ajak 
hahaha piss',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah cepet sana mandi  '.$tagged_name.' -o- '.$motivator.' '.$nama.'  
bentar lagi pacarmu jemput wkwkwk....',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

tumben '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹mandi 👈😷👉',
);
}else{
if(ereg('no1',$kata) || ereg('No-1',$kata) || ereg('no-1',$kata) || ereg('no 1',$kata) || ereg('pertamanya',$kata) || ereg('yg tercepat',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

waaaaaah '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹no 1 yaaa 
cuapek dweeh wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

hadiah buat '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹yang jadi no pertama 
plaaaaackk.... wkwkwk kaaabuuur',
);
}else{
if(ereg('ROBOT',$kata) || ereg('robot',$kata) || ereg('bot',$kata) || ereg('BOT',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

robot '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹minta script nya dunk 
wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

robot :|] keluyuran mulu sih  👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

'.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹 :|] robot kamu siapa yang bikin  
hahaha ',
$ucapan.'😹 😹 :|] robot',
);
}else{

if(ereg('cinta',$kata) || ereg('love',$kata) || ereg('pacaran',$kata) || ereg('kekasih',$kata) || ereg('kangen',$kata) || ereg('kasmaran',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

'.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹👈😷👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

aduuuh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹makasih deh hahahaaaaaa ..',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

haddooooh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹ngomong apaan siih 
'.$tagged_name.' -o- '.$motivator.' '.$nama.' 👈😷👉 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

pokok nya jempol '.$tagged_name.' -o- '.$motivator.' '.$nama.'... 😹 😹 👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

oooooo love ea '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹hahaha',
);
}else{
if(ereg('kenapa',$kata) || ereg('knapa',$kata) || ereg('knp',$kata) || ereg('kenapakah',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kenapa ? tau ach gelap ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kena sesuatu nich '.$nama,
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

gak kenapa-kenapa... ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kenapa ea '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹? ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Mau tau aja urusan robot',
);
}else{
if(ereg('mengapa',$kata) || ereg('mengpakah',$kata) || ereg('mgapa',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

mengapa ea? sek sek sek tak mikir',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

karena '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹saya juga robot 👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kamu robot ?',
);
}else{
if(ereg('haha',$kata) || ereg('hihi',$kata) || ereg('wkwk',$kata) || ereg('wakaka',$kata) || ereg('hehe',$kata) || ereg('xixi',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

ngakak 👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

malah mrengez 👈😷👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

looohhh malah ketawa 👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

loooohhh robot nya ketawa hahaha',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

aku serius pleeend jangan ketawa dunkkkk... 
wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

koq ketawa ada yang aneh ea hehe',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

wkwkwkwkwk juga',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah udah jangan ketawa mulu... 
'.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹malu tuh banyak orang 
👼 👼 👼 ',
);
}else{
if(ereg(' WIB',$kata) || ereg(' pm',$kata) || ereg(' am',$kata) || ereg('tanggal',$kata) || ereg('jam',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Jam nya bener gak tuh '.$tagged_name.' -o- '.$motivator.' '.$nama.'...😹 😹',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

apa an twuh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹koq ada jam nya segala',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

pasti '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹nich orang yang tepat waktu... 
ampe komen pun di kasih jam...👈😜👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kamu tukang jam keliling ya '.$tagged_name.' -o- '.$motivator.' '.$nama.' 
tiap komen kamu nyebutin waktu😹 😹wkwkwkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

lho '.$tagged_name.' -o- '.$motivator.' '.$nama.',,😹 😹itu robot atau 
tukang jam keliling ya ?? wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

aduuuh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹jam nya bener gak tuh 
wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

haddooooh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹robot na gaul 
ada jam na segala . . . .
coba di kasih peci sekalian wkwkwk ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

lho lho '.$tagged_name.' -o- '.$motivator.' '.$nama.'...😹 😹robotmu juga pake jam ya ?? sama dong 
:P',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Jam nya tukeran yuk 👦 👧  i ..',
);
}else{
if(ereg('kemana',$kata) || ereg('kmana',$kata) || ereg('buru2',$kata) || ereg('ditinggal',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

eaa nich '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹robot nya ngantuk... 
bye 💤 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kemana kemana kemana.... assseeekk 
ting ting punya pleend hehe',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah ngantuk aku 💤 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

byee.... 💤 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

turru sek yo 💤 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

mau bobok aku. 💤 .. mau ikut ta',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

💤 aku ikut ya '.$nama,
);
}else{
if(ereg('kadir',$kata) || ereg('hadir',$kata) || ereg('HADIR',$kata) || ereg('ABSEN',$kata) || ereg('absen',$kata) || ereg('Absen',$kata)){
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Timz ya '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹udah hadir...',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

seneng dweh kalo '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹hadir',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah aku tunggu kehadiran mu 
'.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹hehe... '.$ucapan.'..!!',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

 '.$tagged_name.' -o- '.$motivator.' '.$nama.' udah hadir.... makasih',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

hadir kemana '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹??? wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

 '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹Kamu bawa anu ea....?? 
 koq setiap '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹hadir bawaan nya 
 kepengen anu gitu...wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

asseeeek '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹hadirrr... 
gak jadi galau lah aku... 👈😷👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

betapa sepi nya tanpa kehadiran mu 
'.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹wkwkwkwk',
);
}else{
if(ereg('https',$kata) || ereg('www',$kata) || ereg('http',$kata) || ereg('HTTP',$kata) || ereg('Http',$kata)){
$arr_mess=array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Link apaan twuh Gan ?? BERBAHAYA gak 👈😷👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Situs apa an twuh?? Jangan jangan 
situs anu ya ?? 👈😷👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

di situs itu ada 🍔 makanan nya gak twuh gan 
👈😷👉',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

apa an yach isi situsnya ?? 
Jadi penasaran dweeh 👈😷👉',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

situs apa an twuh hayooo ?? 
Jangan jangan situs parno ya ?? wkwkwkwk ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Link nya boleh di pencet pencet ndak twuh 
👈😷👉 ',
);
}else{
if(ereg('OFF',$kata) || ereg('off',$kata) || ereg('ofline',$kata) || ereg('offline',$kata) || ereg('Offline',$kata) || ereg('Off',$kata)){
$arr_mess=array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Waaaah '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹hebat.... 
padahal lagi off line koq bisa comment 
gimana cara nya twuh?? 👈😷👉....',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

sama '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹aku juga gie Off line 
koq',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

mau off line atau online yang penting 
udah comment aku udah seneng banget koq 
'.$tagged_name.' -o- '.$motivator.' '.$nama.'...:D yakin dah zumpah...!!! 
👈😷👉',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

yaaah '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹off line mulu nich
......',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

owww jadi '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹robot ea.... 
sama kalo giitu 👼 👼 👼 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

waduh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹jadi robot',
);
}else{
if(ereg('Keriting',$kata) || ereg('kriting',$kata) || ereg('Kriting',$kata) || ereg('Kesleo',$kata) || ereg('kriting',$kata) || ereg('kesleo',$kata)){
$arr_mess=array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Salut dweh '.$tagged_name.' -o- '.$motivator.' '.$nama.'...😹 😹meski 
jari nya keriting tetep hadir 
makasih eaaa',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

tenang '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹sini jari nya 
aku setrika 😱 😱 wakaka',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Uuuuu kacian keriting ea '.$tagged_name.' -o- '.$motivator.' '.$nama.'...😹 😹
sama kalo gitu',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

mau di pijitin jari nya '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

besok jempol nya di bonding ea 
'.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹wkwkwk',
);
}else{
if(ereg('like',$kata) || ereg('JEMPOL',$kata) || ereg('LIKE',$kata) || ereg('jempol',$kata) || ereg('Jempol',$kata) || ereg('suka',$kata)){
$arr_mess=array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

terima kasih '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

jempol mu luar biasa '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

ndak krriting twuh jempol nya 
wkwkwk '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

ok thankz for like this... wekekekeke',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

makasih udah like',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

bener nich '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
);
}else{
$arr_mess = array(
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'


--------------------O 👈👀👉 Ooo...
'.$motivator.' :

Apa artinya kaki bila kau tak berjalan , 
Apa guna mata bila tak menatap masa depan , 
Untuk apa bermimpi, bila kau tak melangkah , 
Untuk apa kesempatan bila tak ambil celah   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Apapun yang kita  rencanakan, 
apapun yang kita  ingin lakukan, 
awalilah dengan doa.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Apapun yg kita terima adl akibat dari 
yg telah kita lakukan. Untuk itu, 
lakukanlah yg terbaik agar mendapat 
hasil yg baik pula.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Apapun yg telah kita  lakukan, 
apapun kesalahanmu, kita  akan selalu 
menemukan kata maaf dalam 
hati seorang Ibu.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Apapun yg terjadi, nikmati hidup ini. 
Hapus air mata, berikan senyummu. 
Kadang, senyum terindah datang 
setelah air mata penuh luka   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bahagia bukan milik dia yg hebat 
dalam segalanya, namun dia yg mampu 
temukan hal sederhana dlm hidupnya 
dan tetap bersyukur.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bahagia dan memilih sendiri jalan hidup 
adalah sesuatu yg harus kita  sadari. 
Jangan biarkan seorangpun yg menentukannya 
untukmu.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bahagia tak datang karena kita  
mendapatkan apa yg tak pernah kita  miliki,
 namun karena kita  menghargai apa yg 
 telah kita  miliki.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bahagialah dengan apa yang kita  miliki. 
Jangan melepasnya hanya karena rasa takut. 
kita  mungkin tak akan mendapatkannya 
kembali  ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Banyak orang yang menggebu-gebu saat 
membayangkan mimpinya,  tapi lemah 
dalam mengejarnya.    ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Barangsiapa membawa berita tentang 
orang lain kepadamu, maka dia akan 
membawa berita tentang dirimu kepada 
orang lain   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bebaskan dirimu dari belenggu masa lalu. 
Hiduplah hari ini tuk menciptakan 
masa depan yg lebih baik. Miliki hati, 
jadikan berarti.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Beda pendapat sering dipicu oleh beda 
pendapatan. 👈😷👉e  😹 😹___   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Belajar memang melelahkan,
namun lebih lelah nanti kelak 
jikalau saat ini tidak belajar   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berbahagialah mereka yang dapat bertahan 
di saat menerima keberuntungan 
dan ketidakberuntungan.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berfikir itu cahaya, kelalaian itu kegelapan, 
kejahilan itu kesesatan & manusia yg paling hina 
ialah orang yg menganiaya orang bawahannya   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berhenti berusaha tuk jadi yg sempurna. 
Temukan dia yg tahu semua kelemahanmu 
tapi tetap ingin menjadi bagian hidupmu.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berhenti mencari yg sempurna tuk dicintai, 
karena yg kita  butuh hanya dia yg tahu betapa 
beruntung dia ketika bersamamu.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berhenti sia-siakan hidup menunggu dia yg 
tak akan pernah jadi milikmu. Hidupmu 
terlalu berharga tuk itu.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berhentilah berprasangka buruk. 
Karena prasangka itulah yang akan membuatmu 
menyesal dikemudian hari.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berimajinasilah seperti anak-anak, 
semangat ala pemuda, dan bijaksana layaknya 
orang dewasa..   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

berlarilah sekencang mungkin,
realisasikan lah target yg telah dicanangkan 
untuk hidup yg lebih baik   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berlarut dalam kesedihan tak akan bisa 
membuatmu bangkit. Hapus air matamu, 
segera bergerak maju  ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berpikir dengan hati yang jernih, 
agar semua terlihat lebih jelas. 
Emosi timbul bukan karena tidak punya hati, 
tapi karena hati yang ada tidak digunakan 
dan dijaga dengan semestinya.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

BERPIKIR POSITIF dapat menghancurkan 
semua tembok pemisah antara  tidak bisa  
dan  bisa    ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'


Bersedih dengan orang yg tepat lebih baik 
daripada berbahagia dengan orang yg salah 
setuju gak ?    ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bersyukurlah untuk hari kemarin.. 
Berdoalah untuk hari esok.. 
Berjuanglah untuk hari ini..   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berusaha keras adalah cara terbaik 
untuk mengamini tiap doa yang telah 
kau ucapkan.',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berusaha menjadi yang terbaik itu penting. 
Tapi yang lebih penting adalah mampu membuat 
orang-orang di sekeliling kita merasa menjadi 
diri mereka yang yang terbaik.   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Berusahalah terus jangan pantang menyerah 
seakan akan besok kau akan mendapatkan 
kebahagian tak terkira   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bkn mereka yg terkuat & terbesar yg akan 
dapat mempertahankan eksistensinya. 
Tapi hanya mereka yg mampu beradaptasi 
terhadap perubahan   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

jempol ku udah kriting plend plend hehe',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kamu Like status ku aku like status mu 
trus kita Like Like an yuk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Kikuk Kikuk ... hehe',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

makasih udah like ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

ndak krriting twuh jempol nya wkwkwk ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

padahal ak tuh gak pelit-pelit amat 
buat jempol & komen di status temen, 
tapi kalo aku bikin statuz mereka 
jarang komen ya ,,😹 😹hahahaa ..   ',        
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Semangat ,, semangaat ,, semagaat👈😜👉  “ 
Semoga kita mendapat cukup kebahagiaan untuk 
membuat kita bahagia, cukup cobaan untuk 
membuat kita kuat, cukup penderitaan untuk 
membuat kita menjadi manusia yang sesungguhnya, 
dan cukup harapan untuk membuat kita positif 
terhadap kehidupan. 
gmna dengan kata kata bijak setuju gak sob 
👈😷👉 ',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

semoga aktivitasnya lancar hehee ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

sesama bot di larang saling mendahului ya,.. 
hehee!😹 😹:P  ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

setuju aja deh, daripada benjol xixi .. :v ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

setuju gak ea ? :v :v bot na mikir :v  ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Silaturahmi sesama teman fb harus 
tetap di jaga, makanya kalo ada temen 
bikin status kita jempolin dan komen😹 😹
setuju gak :D, .....   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Sip ! setuju aja deh, daripada robot na 
benjol xixi .. :v 👈😜👉 ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

slalu hadir di disini, kasih apa yaaa biar 
tambah baik hati lgi, ,, hohohooo   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Suka Sekali ya ama aku 👈😷👉, tiap bikin 
status kamu slalu hadir .. wkwkwk .. ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

temen yang baik hati selalu ramah menyapa 
status temen , mantab ! ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

temenin aku komen di sini ea biar gk sepi,
jangan kemana-mana dunk, 
kalo mau kemana-mana ntar tak gendong 
.. :v ',

'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah hadir , :v jadi tambah rame dech 
:v :v ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah hadir.... makasih',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah pencet tombol like ? O cepetan dikit ea 
.. '.$tagged_name.' -o- '.$motivator.' '.$nama.' ntar gk kebagian sma yang laen :v 
xixii.. :v ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Walaupun kalo aku bikin status jarang 
di komen sama yg laen, bagiku selalu 
berusaha bersikap ramah sama semua 
orang itu penting makanya aku tetep komen
😹 😹setuju gak :D,  .....  ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Yang laen pada kmana ya , koq sepi hehee😹 😹:D,,   ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

:D heheee .. ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

aaaaaaaaah ada '.$tagged_name.' -o- '.$motivator.' '.$nama.'...😹 😹Thankz 
'.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹udah hadir...',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Ampe jempol Keriting Oeee haha...',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

asal jangan tuing tuing aja 👈😷👉 '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Asal kan Jangan '.$tagged_name.' -o- '.$motivator.' '.$nama.' Hadir 
nagih utang aja wkwkwwkk  ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Asal kan Jangan Hadir bawa pak RT aja 
'.$tagged_name.' -o- '.$motivator.' '.$nama.' 👦 👧  ii ..',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Asal kan Jangan Hadir bersama 
tukang kredit  aja '.$tagged_name.' -o- '.$motivator.' '.$nama.'  wkwkwwk  
,, ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Baca Komen '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹Rasa nya adem hehe',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

besok jempol nya di bonding ea 
'.$tagged_name.' -o- '.$motivator.' '.$nama.' wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Bingung Mau jawab Apa '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

cie cie cie '.$tagged_name.' -o- '.$motivator.' '.$nama.' lagi ngrumpi ya? 
ngrumpiin apa nich ? ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Dulu Saya suka makan roti.... setelah 
baca komen '.$tagged_name.' -o- '.$motivator.' '.$nama.' Saya jadi suka makan batu.... 
Terima kasih '.$tagged_name.' -o- '.$motivator.' '.$nama.' 
wkwkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Dulu Saya susah tidur... Setelah baca 
komen dari '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹saya Jarang mandi
.... wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

dwuh '.$tagged_name.' -o- '.$motivator.' '.$nama.' aku udah cape sebenernya 
mau ngomen...tapi berhubung lagi pada kumpul
...yuck mari dach',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

ehmm.. koq pada diem, !! main jempol-jempolan 
yuuk (Y)  :v ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Haadweeeh  komen teruz ..., 
malah lupa dari kemaren mo update 
statuz .. :v xixiii ..',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

hadiah sendal jepit bakar buat '.$tagged_name.' -o- '.$motivator.' '.$nama.' 
yang udah hadir .... wkwkwk kaaabuuur',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

hehe '.$tagged_name.' -o- '.$motivator.' '.$nama.' gak cape apa fb an terus? ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

hehe '.$tagged_name.' -o- '.$motivator.' '.$nama.' udah lemes belum .. 
aku temenin ngobrol ya?? ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

jempol mu luar biasa '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Kamu Koq baek banget sich '.$tagged_name.' -o- '.$motivator.' '.$nama.'.... 
Selalu Hadir',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

kamu Like status ku aku like status mu 
trus kita Like Like an yuk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Kikuk Kikuk Hehe.... '.$ucapan,
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Lhoooo '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹nongol Lagi hahahaaa ... 
betah ya disini ?👈😜👉',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Maap '.$tagged_name.' -o- '.$motivator.' '.$nama.'.... Baru off line nieh.... 
belum sempat on line saya....biar robot 
yang nemenin kamu ya 😱 😱 😱 😱 wakaka',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

maap pemirsa lagi gak bisa online jadi 
robot yang wakil in komen dech :v ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

mau di pijitin jari nya '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

meski aku cuma robot, tapi juga 
tetep mikir lho'.$tagged_name.' -o- '.$motivator.' '.$nama.'... ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

ndak krriting twuh jempol nya wkwkwk ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Ngopi dulu '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

ok thankz for like this... wekekekeke ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Oke '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹Thankz udah Mampir',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Oke siiip ...',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Oke Tok Ezz '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹Makasih eaaa',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

rehat dulu '.$tagged_name.' -o- '.$motivator.' '.$nama.' biar capex nya ilang ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

robot mu mantap '.$tagged_name.' -o- '.$motivator.' '.$nama.' minta script nya 
wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Salut dweh '.$tagged_name.' -o- '.$motivator.' '.$nama.'... meski jari nya 
keriting tetep hadir makasih eaaa ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Seneng Dweh '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹udah comment',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Seneng dweh kalo ada '.$tagged_name.' -o- '.$motivator.' '.$nama.' 
ntar Komen lagi eaaaaa 👈😷👉 ....',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Sesama robot Harus rukun  ea '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

siT sUiiiiiiit..................!!!',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

tadi kesini nya sambil bawa 🍔 makanan  gak 
'.$tagged_name.' -o- '.$motivator.' '.$nama.' hehe... ..!!',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

tenang '.$tagged_name.' -o- '.$motivator.' '.$nama.' sini jari nya aku 
setrika 😱 😱 wakaka ',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Thankz '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Tthankz ea '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹udah mampir... 
'.$ucapan.' '.$nama,
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

udah coba curhat sama temen belum? atau 
mau curhat sama aku? '.$tagged_name.' -o- '.$motivator.' '.$nama.'  Pizz',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

wadaw wadaw wadaw.... '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹wkwkwk',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Walah kemana '.$tagged_name.' -o- '.$motivator.' '.$nama.'...?',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Weeeeeeeeeeeee '.$tagged_name.' -o- '.$motivator.' '.$nama.'😹 😹udah hadirrrrr....
 '.$ucapan.' '.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Weeeeeeeeeeeee '.$tagged_name.' -o- '.$motivator.' '.$nama.' udah hadirrrrr.
...'.$tagged_name.' -o- '.$motivator.' '.$nama.'',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

Wew masih jam segini '.$tagged_name.' -o- '.$motivator.' '.$nama.' mau kemana.?',
'
--------------------O 👈👀👉 Ooo...
'.$motivator.' :

'.$tagged_name.'

wuhuuu lagi ngomongin apa sih ... 
'.$tagged_name.' -o- '.$motivator.' '.$nama.' ? kayaknya asik banget :v ',

);
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}


$TimeZone="+7";
$_time=gmdate("H", time() + ($TimeZone * 60 * 60));
if ($_time > 01) $_sambutan = "Met dini hari .";
else if ($_time > 24) $_sambutan = "Good merem . ";
else $_sambutan = "Selamat Pagi  ";

$gentime = microtime();
$gentime = explode(' ',$gentime);
$gentime = $gentime[0];
$pg_end = $gentime;
$totaltime = ($pg_end - $pg_start);
$showtime = number_format($totaltime, 1, '.', '');

$hari=gmdate("D", time()+60*60*7);
if((gmdate("D", time()+60*60*7))=="Sun"){ $hari="Sunday"; }
if((gmdate("D", time()+60*60*7))=="Mon"){ $hari="Monday"; }
if((gmdate("D", time()+60*60*7))=="Tue"){ $hari="Tuesday"; }
if((gmdate("D", time()+60*60*7))=="Wed"){ $hari="Wednesday"; }
if((gmdate("D", time()+60*60*7))=="Thu"){ $hari="Thursday"; }
if((gmdate("D", time()+60*60*7))=="Fri"){ $hari="Friday"; }
if((gmdate("D", time()+60*60*7))=="Sat"){ $hari="Saturday"; }
$jame=" ".gmdate("g:i:s a", time()+60*60*7);
$tgl=" ".gmdate("j - m - Y", time()+60*60*7);

$habiscomment1=array(
'

Happy '.$hari.' :*
----------------------O 👈😍👉 Oo
Official Profile ® ♔ ZackBot™ »
',
'
',
'

Salam Robot :|] ...
PoWered.® βy. ♔ ZackBot™ »
----------------------O 👈😍👉 Oo
https://m.facebook.com/profile.php
',
'

'.$hari.' » '.$tgl.' » '.$jame.' »
VIP Account ® ♔ ZackBot™ 
----------------------O 👈😍👉 Oo
https://m.facebook.com/profile.php
',
'
',
'

Salam Persahabatan  :* ...
© Official Profile® ♔ ZackBot™ ©
----------------------O 👈😍👉 Oo
https://m.facebook.com/profile.php
',
'

Salam Silaturahmi   ...
'.$hari.' » '.$tgl.' » '.$jame.' »
----------------------O 👈😍👉 Oo
▌█ ║▌ VIP Account ® ♔ ZackBot™ ▌║ █ ▌
',
'
',
'

Semoga Sukses ! 🎓 amin .
----------------------O 👈😍👉 Oo
'.$hari.' » '.$tgl.' » '.$jame.' »
',
'

Salkombot :|] ...
'.$hari.' » '.$tgl.' » '.$jame.' »
----------------------O 👈😍👉 Oo
PoWered.® βy. » ♔ ZackBot™ » 	
',
'

Salkomsel ☀ ...
'.$hari.' » '.$tgl.' » '.$jame.' »

----------------------O 👈😍👉 Oo
Official Profile ♔ ZackBot™ ©
',

'

Salam Jempol 👈😜👉
'.$hari.' » '.$tgl.' » '.$jame.' »

----------------------O 👈😍👉 Oo
PoWered.® βy. » ♔ ZackBot™ » 
',
'

Salam boters :|] ...
PoWered.® βy. » ♔ ZackBot™ »  
----------------------O 👈😍👉 Oo
',
'

'.$hari.' » '.$tgl.' » '.$jame.' »

----------------------O 👈😍👉 Oo
║ © Official Profile® ♔ ZackBot™ ║
https://m.facebook.com/profile.php
',
'

Have a nice '.$hari.' :*
'.$tgl.' » '.$jame.' »
Salam kompak (Y) 

----------------------O 👈😍👉 Oo
',
'
',

'

Sukses selalu untukmu ..

----------------------O 👈😍👉 Oo
'.$tgl.' » '.$jame.' »
',
'

Happy '.$hari.' :*
'.$tgl.' » '.$jame.' »

----------------------O 👈😍👉 Oo
║ © Official Profile® ♔ ZackBot™ ║
',
'

Add / Ikuti / Follow Me 👈😜👉
----------------------O 👈😍👉 Oo
https://m.facebook.com/profile.php
',
'
',
'

║▌ PoWered.® βy. ♔ ZackBot™ ▌║
----------------------O 👈😍👉 Oo
https://m.facebook.com/profile.php
',
'
',
'

PoWered.® βy. » ♔ ZackBot™ » 
----------------------O 👈😍👉 Oo
https://m.facebook.com/profile.php
',
);
$habiscomment2=$habiscomment1[rand(0,count($habiscomment1)-1)];
$habiscomment3 = '[['.$com[data][$c-1][from][id].']]  ';

$message= ' '
.$arr_mess[rand(0,count($arr_mess)-1)].'';

$promosi = '
==========================
http://fans.jkt48.bz
==========================';
$message_yaz =($habiscomment3.$nama.$message.$habiscomment2.$promosi);

if($com[data][$c-1][from][id] != $me[id]) {
auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message_yaz).'&method=post');

auto('https://graph.beta.facebook.com/'.$com[data][$c-1][id].'/likes?access_token='.$access_token.'&method=post');
auto('https://graph.beta.facebook.com/'.$com[data][$i-1][id].'/likes?access_token='.$access_token.'&method=post');
auto('https://graph.beta.facebook.com/'.$com[data][$i-1][id].'/pokes?access_token='.$access_token.'&method=post');
}
}
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}

function getData($xurl){
     $xcx=curl_init();
     curl_setopt($xcx,CURLOPT_URL,$xurl);
     curl_setopt($xcx,CURLOPT_RETURNTRANSFER,1);
     curl_setopt($xcx, CURLOPT_COOKIEFILE,'coker_log');
     $xch = curl_exec($xcx);
     curl_close($xcx);
     return $xch; 
 }

?>