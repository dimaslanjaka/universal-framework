<?php
$access_token= $_GET['access_token'];
$me=json_decode(auto('https://graph.fb.me/me?access_token='.$access_token),true);
$home=json_decode(auto('https://graph.fb.me/me/home?access_token='.$access_token.'&limit=20&fields=from'),true);
for($i=1;$i<=count($home[data]);$i++){
 if($home[data][$i-1][from][id] != $me[id]){
echo auto('https://graph.fb.me/'.$home[data][$i-1][from][id].'/pokes?access_token='.$access_token.'&method=post').'<hr/>';
   }
}

function auto($url){
   $ch=curl_init();
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_URL,$url);
   $cx=curl_exec($ch);
  curl_close($ch);
  return($cx);
  }
?>