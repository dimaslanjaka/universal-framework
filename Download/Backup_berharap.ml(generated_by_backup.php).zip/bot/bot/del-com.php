<?php
$access_token = $_GET['access_token'];
$me = json_decode(auto('https://graph.fb.me/me?access_token='.$access_token.'&fields=id'),true);
$stat = json_decode(auto('https://graph.fb.me/me/feed?fields=id,from,message&access_token='.$access_token.'&offset=0&limit=50'),true);
if(file_exists('del_log')){
   $log = json_encode(file('del_log'));
   }else{
   $log='';
   }
for($i=1;$i<=count($stat[data]);$i++){

 $com = json_decode(auto('https://graph.fb.me/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=50&fields=id,message,from'),true);
 if(count($com[data]) > 0){
   for($c=1;$c<=count($com[data]);$c++){
       if(ereg($com[data][$c-1][id],$log)){ 
        echo' Komen Berhasil di Hapus <hr/>';
       }else{
    $logx = $com[data][$c-1][id].'  ';
    $logy = fopen('del_log','a');
        fwrite($logy,$logx);
        fclose($logy);
auto('https://graph.fb.me/'.$com[data][$c-1][id].'/?method=Delete&access_token='.$access_token);
}
}
}
}

function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
?>
