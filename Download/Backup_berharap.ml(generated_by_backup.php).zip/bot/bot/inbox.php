<?php
$access_token= $_GET['access_token'];
$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Met Dini Hari ','Met Dini Hari ','Met Dini Hari ','Met Dini Hari ','Met Pagi ','Met Pagi ','Met Pagi ','Met Pagi ','Met Pagi ','Met Jelang Siang ','Met Siang ','Met Siang ','Met Siang ','Met Siang ','Met Sore ','Met Sore ','Met Petang ','Met Petang ','Met Malem ','Met Malem ','Met Malem ','Met Malem ','Met Malem ','Met Malem ','Met Malem ',);
$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);

$me=json_decode(auto('https://graph.fb.me/me?access_token='.$access_token),true);
$in=json_decode(auto('https://graph.fb.me/me/inbox?access_token='.$access_token.'&fields=id,to,unread,unseen'),true);

if(file_exists('in_log')){
   $inlog = json_encode(file('in_log'));
   }else{
   $inlog='';
   }

if(file_exists('c_log')){
   $clog = json_encode(file('c_log'));
   }else{
   $clog='';
   }

for($i=1;$i<=count($in[data]);$i++){
   if($in[data][$i-1][to][data][0][id] == $me[id]){
       $from=$in[data][$i-1][to][data][1];
       }else{
       $from=$in[data][$i-1][to][data][0];
       } 
   $cm=json_decode(auto('https://graph.fb.me/'.$in[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=50&fields=id,message,from'),true);
   if(count($cm[data]) > '0'){
       for($n=1;$n<=count($cm[data]);$n++){
           if($cm[data][$n-1][from][id] != $me[id]){
                 if(!ereg($cm[data][$n-1][id],$clog)){
                    $logx = $cm[data][$n-1][id].'  ';
                    $logy = fopen('c_log','a');
                    fwrite($logy,$logx);
                    fclose($logy);
                         $ex_nam=explode(' ',$cm[data][$n-1][from][name]);
            $nama=$ex_nam[0];
            $kata=$cm[data][$n-1][message];
if(ereg('MAAF',$kata) || ereg('maaf',$kata) || ereg('Maaf',$kata)){
     $arr_mess = array(
        'Jiah... pake minta maap segala',
        'Eaa.... gw gak papa ko dan udah Q maafin ko... ntar Inbox aku lagi ea '.$nama.'.... ',
        'Duh tiada maap bagimu '.$nama.'... Gimana neh... :p',
        'yeeee enak aja minta maaf... Nyanyi dulu '.$nama.'... nang ning ning nang oooo.... 5X',
        'maaf... emang knapa '.$nama,
        'masama '.$nama.' Q jg minta maaf...',
       );
     }else{
if(ereg('ASSALAMUALAIKUM',$kata) || ereg('Assalamualaikum',$kata) || ereg('Askum',$kata) || ereg('assalam',$kata) || ereg('askum',$kata) || ereg('ASKUM',$kata)){
     $arr_mess = array( 
    'Waalaikumsalam... :D',
    'kumcalam',
    'kumsayank... upzz kesleo... :D',
    'wasskum',
       );
  }else{
if(ereg('mandi',$kata) || ereg('pake celana',$kata) || ereg('mande',$kata)){
     $arr_mess = array(
         'idih... '.$nama.' parno',
         'mau donk jadi sabunya',
         'hihihik anuunya keliatan tuh :v',
         'Lohh '.$nama.' mandi nya ko ga ajak-ajak aqu :D',
         'Mandi di kali Anunya jadi basah... tanpa Inbox dari '.$nama.' Anuku jadi gelisah....',
         'Tumben '.$nama.' Mandi, biasa nya engga!! :v',
       );
  }else{
if(ereg('ROBOT',$kata) || ereg('robot',$kata) || ereg('bot',$kata) || ereg('BOT',$kata)){
     $arr_mess = array( 
     'Botmu mantap '.$nama.' Minta Scriptnya Dong!! :v',
     'Kamu Robot Somplak ea..',
     'Robot ko bisa kirim inbox si... Gimana caranya?',
     'Oalah jangkrik, jadi '.$nama.' Robot toh... Baru ngerrti saya...',
     $ucapan.' bot',
       );
  }else{
if(ereg('cinta',$kata) || ereg('love',$kata) || ereg('pacaran',$kata) || ereg('kekasih',$kata) || ereg('kangen',$kata) || ereg('kasmaran',$kata)){
     $arr_mess = array(
  'cinta itu glodak '.$nama.'',
'Duh duh duh '.$nama.' makasih atas cintanya eaa',
'haddooooh '.$nama.' malah ngajak bercinta ',
'Pokoknya mmmuaaaach '.$nama.'...',
'I Love U ea sayang.. '.$nama.'',
       );
  }else{
if(ereg('kenapa',$kata) || ereg('knapa',$kata) || ereg('knp',$kata) || ereg('kenapakah',$kata)){
     $arr_mess = array(
     'kenapa? au ach gelapz ',
     'kena sesuatu nich '.$nama,
      'ga knapa-napa... emang Majalah BuadTeLo... hehe pizzz',
      'kenapa ea '.$nama.' sek sek sek tak mikir',
      'Mo tau aja urusan robot',
      );
      }else{
if(ereg('mengapa',$kata) || ereg('mengpakah',$kata) || ereg('mgapa',$kata)){
      $arr_mess = array(
     'mengapa ea? sek sek sek tak mikir',
     'karena '.$nama.' telah mencuri hatiku xixixi',
     'Mo tau aja urusan Robot',
     );
     }else{
if(ereg('haha',$kata) || ereg('hihi',$kata) || ereg('wkwk',$kata) || ereg('wakaka',$kata) || ereg('hehe',$kata) || ereg('xixi',$kata)){
     $arr_mess = array(
     'ngakak',
     'malah mrengez',
     'looohhh malah ktawa',
      'loooohhh bot nya ketawa hahaha',
      'gw serius say jgn ketawa dunkkkk... :p',
      'kok ktawa ada yg aneh ea',
      'wkwkwkwkwk juga',
      'udah2 jgan ktawa mulu... '.$nama.' botnya malu nih',
       );
      }else{
if(ereg('kemana',$kata) || ereg('kmana',$kata) || ereg('buru2',$kata) || ereg('ditinggal',$kata)){
      $arr_mess = array(
      'ea nih '.$nama.' botnya ngantuk... bye',
      'kemana kemana kemana.... assseeekk ting ting punya coey',
      'dah ngantuk gw',
      'byee....',
      'turru disek rek',
      'mo bobok aq... mo ikud',
      'ikud yuk '.$nama,
       );
      }else{
if(ereg('http',$kata)){
     $arr_mess=array(
     'Link apa tuh Gan',
     'Linknya boleh di klik ndak twuh ',
     );
     }else{
if(ereg('Keriting',$kata) || ereg('kriting',$kata) || ereg('Kriting',$kata) || ereg('Kesleo',$kata) || ereg('kriting',$kata) || ereg('kesleo',$kata)){
     $arr_mess=array(

     'tenang '.$nama.' sini jarinya Q setrika wakakaka',
     'Uuuuu kacian keriting ea '.$nama.'... sama lok gitu',
     'mo di pijitin jarinya '.$nama.'',
     'besok jempolnya di bonding ea '.$nama.' :p',
     );
     }else{
$arr_mess=array(
'maap saya cuma robot '.$nama,
'sek sek sek bot nya mikir '.$nama,
'hadoh... Bot bingung '.$nama,
'hehehe kenapa '.$nama,
'boZ ge mandi neh '.$nama.' Jdi bot di tugasin bales inbok kmu',
'yaaaaaa BoZ Q minggat.... saya cuma Bot g erti pa pa',
'hehehehe :p',
);

}}}}}}}}}}}

             $message=' :D '.$arr_mess[rand(0,count($arr_mess)-1)].' :D ';
               auto('https://graph.fb.me/'.$from[id].'/inbox?access_token='.$access_token.'&message='.urlencode($message).'&subject='.urlencode($ucapan).'....&method=post');



                   echo '<br/>'.$cm[data][$n-1][from][name].' => '.$cm[data][$n-1][message].'<br/>Re => '.$message.'<br/>'; 
                }
           }
      } 
   }else{
   if(($in[data][$i-1][unseen] == '1' ) && ($in[data][$i-1][unread] == '1')){
       if(!ereg($in[data][$i-1][id],$inlog)){
           $logx = $in[data][$i-1][id].'  ';
           $logy = fopen('in_log','a');
               fwrite($logy,$logx);
               fclose($logy);
               $xnam = explode(' ',$from[name]);
               $nama = $xnam[0];
               $arr_mess = array(
                     ':) Maaf '.$nama.' Bos Subhan-kun Lagi Offline :)',
                     ':) Ada apa '.$nama.'...? maaf saya cuma bot ditugaskan ma Q untuk bales Inbox :)',
                     ':) Duh '.$nama.' Bos Q gi Off ne... :D di tunggu onlenya yakz :)',
                     ':) duh sayang sekali '.$nama.'... Saya cuma Bot :/ Gak ngerti apa apa :D Tunggu boz Subhan-kun onlen yak :) ',
                     );
               $message = $arr_mess[rand(0,count($arr_mess)-1)];
                auto('https://graph.fb.me/'.$from[id].'/inbox?access_token='.$access_token.'&message='.urlencode($message).'&subject='.urlencode($ucapan).'....&method=post');
               echo'<hr/>To: '.$nama.' => '.$message.'<br/>';
            }
         }
    echo'<hr/>';
   }
}

function auto($url){
   $ch=curl_init();
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_URL,$url);
   $cx=curl_exec($ch);
  curl_close($ch);
  return($cx);
  }
?>