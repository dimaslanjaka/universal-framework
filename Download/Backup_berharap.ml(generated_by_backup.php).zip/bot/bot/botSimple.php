<?php
$access_token = $_GET['access_token'];
function auto($url){
$data = curl_init();
curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($data, CURLOPT_URL, $url);
$hasil = curl_exec($data);
curl_close($data);
return $hasil;
}
if(file_exists('LOG')){ $log=json_encode(file('LOG')); }else{ $log=''; }
$stat=json_decode(auto('https://graph.fb.me/me/home?fields=id,from&limit=25&access_token='.$access_token),true);
for($i=1;$i<=count($stat[data]);$i++){
if(!ereg($stat[data][$i-1][id],$log)){
$x=$stat[data][$i-1][id]."\n";
$y=fopen('LOG','a');
fwrite($y,$x);
fclose($y);

$text = array( 
"Aku belajar Sabar dari Sebuah Kemarahan,
Aku belajar Mengalah dari Sebuah Keegoisan,
Aku belajar Tegar dari Kehilangan :')
Sepi bukan Berarti Hilang, Diam bukan berarti Lupa,
Jika kamu Tidak punya Waktu untukku, Aku akan mengerti...
Jika kamu Belum bisa Lupa darinya, Aku akan Mengerti...
Tetapi jika Suatu hari Nanti aku Berhenti mencintaimu, Disitulah Giliranmu untuk Mengerti. :)

Site Bot From: http://bot-host.gq (y)
Created by: Subhan-kun B-| :*",

":|] [R][O][B][O[T] [H][A][D][I][R] :|]

Site Bot From: http://bot-host.gq (y)
Created by: Subhan-kun B-| :*",

"Hi, Kamu pake kartu Axis ya..? Habis nya Sinyal-sinyal Cintamu Sangat Kuat sampai ke Hatiku.
Sampai-sampai aku yang Jauh dari kamu bisa merasakan nya.. :D

Site Bot From: http://bot-host.gq (y)
Created by: Subhan-kun B-| :*",

"Kamu mantan Pencuri ya...? -_-
Abisnya Kamu Udah Mencuri Hatiku sih!! :D :p

Site Bot From: http://bot-host.gq (y)
Created by: Subhan-kun B-| :*",

"*Aku buatkan Pantun buat kamu*
Kupu2 berwarna ungu..
Hinggap di pohon Jambu...
Kalo aku bilang I LOVE U 
Gimana jawabanmu..?? :D

Site Bot From: http://bot-host.gq (y)
Created by: Subhan-kun B-| :*",

"Please Jangan GR deh. Aku kangen kamu sedikit aja kok. ;)
..Sedikit berlebihan maksudnya. hhehe.. :D

Site Bot From: http://bot-host.gq (y)
Created by: Subhan-kun B-| :*",
                        );


$message1 = $text[rand(0,count($text)-1)];
$message=($message1);
auto('https://graph.fb.me/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.urlencode($message).'+'.urlencode($fx).'&method=post');
auto('https://graph.fb.me/'.$stat[data][$i-1][id].'/likes?method=post&access_token='.$access_token);
echo '<span style="color:blue">'.$stat[data][$i-1][from][name].'</span> <span style="color:red">[SUCCESS]</span><hr/>';
}
}
?>