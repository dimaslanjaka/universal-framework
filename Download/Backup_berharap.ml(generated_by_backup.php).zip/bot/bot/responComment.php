<?php

include'banner.php';

$access_token = $_GET['access_token'];

$me = json_decode(auto('https://graph.beta.facebook.com/me?access_token='.$access_token.'&fields=id'),true);
$jam=array('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','00',);
$sapa=array('Met 🍎 Dini 🍓 Hari ','Met 🍔 Dini ☕ Hari ','Met 🎏 Dini 👋 Hari ','Met 🐔 Dini 🎎 Hari ','Met 😪 Pagi ','Met 😫 Pagi ','Met 🐘 Pagi ','Met 🐛 Pagi ','Met 👿 Pagi ','Met 💘 Jelang 😜 Siang ','Met 🐔 Siang ','Met 🍓 Siang ','Met 🍓 Siang ','Met ☕ Siang ','Met 🎏 Sore ','Met 💘 Sore ','Met 🎎 Petang ','Met 🎎 Petang ','Met ❤ Malem ','Met ☝ Malem ','Met ☁ Malem ','Met ☀ Malem ','Met 🌹 Malem ','Met 🌹 Malem ','Met ❤ Malem',);
$ucapan = gmdate('H',time()+7*3600);
$ucapan = str_replace($jam,$sapa,$ucapan);

$stat = json_decode(auto('https://graph.beta.facebook.com/me/home?fields=id,from,message&access_token='.$access_token.'&offset=0&limit=10'),true);
if(file_exists('responteman_log')){ $log = json_encode(file('responteman_log')); }else{ $log=''; }
for($i=1;$i<=count($stat[data]);$i++){ 

$com = json_decode(auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&limit=50&fields=id,message,from'),true);
if(count($com[data]) > 0){
for($c=1;$c<=count($com[data]);$c++){
if(ereg($com[data][$c-1][id],$log)){
echo' wes di respon <hr/>';
}else{
$logx = $com[data][$c-1][id].'  ';
$logy = fopen('responteman_log','a');
fwrite($logy,$logx);
fclose($logy);
$gen=json_decode(auto('http://graph.beta.facebook.com/'.$com[data][$c-1][from][id].'?fields=gender'),true);
if($gen[gender] == 'male'){
$arr_gen=array('Mas ☔','Om ☁','Kang ☀','Mbah 🎍','Pak 🐸',);
}else{
$arr_gen=array('Mbak ❤','Jeng 😓','Non 💓','Neng 💘',);
}
$exp_nam=explode(' ',$com[data][$c-1][from][name]);
$nama=$arr_gen[rand(0,count($arr_gen)-1)].' '.$exp_nam[0];
$kata=$com[data][$c-1][message];
if(ereg('MAAF',$kata) || ereg('maaf',$kata) || ereg('Maaf',$kata)){
$arr_mess = array( '👦 jiaaaah... ☝ pake 🌺 maap 💪 segala 💩 xixixi 👯',
'😁 eaaa....👸 gak 👦 papa 💚 udah 🍎 aku 😷 maaf 😻 in 🍔 koq... 🍸 ntar 🐯 komen 👫 lagi 💩 ea 🐶 '.$nama.' 😭 .... 🐠 hehehe 🐛',
'🐙 aduuuuh 🙌 tiada 💃 maap 😡 bagi 😢 mu 🌵 '.$nama.' 🐔 ... 🐒 gimana 💐 nieh 👽 ... 🍸 wkwkwkwk 🍔',
'🌹😨 yeeee 😷 enak 😂 aja 😋 minta ☝ maaf ☕ ... ☔ Nyanyi 🎅 dulu 🎈 '.$nama.' 💪 ... 💽 nang 💚 ning 💢 ning ♥ nang ☺ oooo.... 😜 5X 💀 wkwkwk 💃',
'🌹 maaf...?? 😿 emang 🐫 kenapa 👐 '.$nama,
'💻 masama 👯 '.$nama.' 👮 Aku 🍊 juga 🐨 minta 👎 maaf 🌺 ... 🌻 ya 📺😡 ??',
);
}else{
if(ereg('ASSALAM',$kata) || ereg('Assalamualaikum',$kata) || ereg('Askum',$kata) || ereg('assalamualaikum',$kata) || ereg('askum',$kata) || ereg('ASKUM',$kata)){
$arr_mess = array(
'😨 Waalaikum 💃 salam... 👊',
);
}else{
if(ereg('mandi',$kata) || ereg('pake celana',$kata) || ereg('mande',$kata)){
$arr_mess = array(
'👄 idiiih... 👉 '.$nama.' 🙌 parno 🐘 xixix 😥',
'😚 mau 💐 donk 👽 jadi 🍸 sabun 🍔 nya 😷 xixixi 😂',
'👿 hihihik 😋 anuu ☝ nya ☕ keliatan ☔ twuh 🎅 hahaha 🎈',
'💂 lohh 💪 '.$nama.' 💽 mandi 💚 kuq 💢 gak ♥ ajak ☺ ajak 😜 hahaha 💀 piss 💃',
'🌹 mandi 😿 di 👐🐫 kali 💻 anu 👯 nya 👮 basah... 🍊 tanpa 🐨 comment 👎 '.$nama.' 🌺 hati 🌻 ku 😡 gelisah.... 📺',
'👊💃 tumben 👉 '.$nama.' 🙌 mandi 🐘 hehehe 😥',
);
}else{
if(ereg('no1',$kata) || ereg('No-1',$kata) || ereg('no-1',$kata) || ereg('no 1',$kata) || ereg('pertamanya',$kata) || ereg('yg tercepat',$kata)){
$arr_mess = array(
'😨 waaaaaah 😚 '.$nama.' 💐 no 👽 1 🍸 yaaa 🍔 cuapek 😷 dweeh 😂 wkwkwk 😋',
'☝ hadiah ☕ buat ☔ '.$nama.' 🎈🎅 yang 💪 jadi 💽 no 💚 pertama 💢 plaaaaackk.... ♥ wkwkwk ☺ kaaabuuur 😜',
);
}else{
if(ereg('ROBOT',$kata) || ereg('robot',$kata) || ereg('bot',$kata) || ereg('BOT',$kata)){
$arr_mess = array(
'👄👿 robot 💀 mu 💃 mantap 💂 '.$nama.' 😿 minta 👐🐫 script 💻 nya 👯 dunk 👮 wkwkwk ☝',
'🌹🌻 kamu 🍊 robot 🐨 ea 👎 wkwkwk 🌺',
'😨 robot 😡 kuq 📺 bisa 👉 komen 🐘 si... 💐 gimana 👊 cara 💃 nya 🍔 xixixi 😋',
'😥🙌 ooooh 👽 jadi 💢 '.$nama.' 💽 robot 🎅 toh... 😂 baru 😷 ngerrti ☔ saya... ♥ hahaha 😚',
$ucapan.' robot ☺',
);
}else{

if(ereg('cinta',$kata) || ereg('love',$kata) || ereg('pacaran',$kata) || ereg('kekasih',$kata) || ereg('kangen',$kata) || ereg('kasmaran',$kata)){
$arr_mess = array(
'😜 cinta 🍸 itu 🎈☕ glodak 💪 '.$nama.' 💚 hehehe 💀',
'👿 aduuuh 💃 '.$nama.' 💂 makasih 👄 atas 💝 cinta 💚 nya 👲 eaa 👫 wkwkwk 🎁',
'🐒👏 haddooooh ☁ '.$nama.' ☕ ngajak ☔ bercinta 🐯 hehehe 💻',
'💩 pokok 🐔 nya 👆 plaaaack 😲 '.$nama.' 👌 ... xixixi 📞',
'😡 oooooo 🍃 love 🐛 ea 👉 '.$nama.' 💓 hahaha 🐟',
);
}else{
if(ereg('kenapa',$kata) || ereg('knapa',$kata) || ereg('knp',$kata) || ereg('kenapakah',$kata)){
$arr_mess = array(
'😜 kenapa 👽 ? 👀 tau 🐾 ach 💝 gelap 👏💚',
'🐒 kena 👲 sesuatu ☕ nich ☔ '.$nama,
'☁ gak 🐯🎁 kenapa-kenapa... 👫 emang 💩 Majalah 💻 Buat 📞 kamu.. 🍃 hehe 😲 pizzz 💓',
'👌 kenapa 🐛 ea 👆 '.$nama.' 👉 sek 🐟 sek 👀 sek 👽 tak 😜 mikir 🐾',
'😡 Mau 🐔 tau 🔥 aja 💩 urusan 💤 robot 👐',
);
}else{
if(ereg('mengapa',$kata) || ereg('mengpakah',$kata) || ereg('mgapa',$kata)){
$arr_mess = array(
'😜 mengapa 🔥 ea? 💩 sek 💤 sek 👐 sek 😷 tak 🍎 mikir 🍔',
'✊ karena 🍸 '.$nama.' 🐱 telah 🎈 mencuri 🐸 hati 🐾 ku 🌻 xixixi 🌾',
'👄🌵 Mau 🐠 tau 🐛 aja 🐚 urusan 🐙 robot 🌷 hehehe 🌴',
);
}else{
if(ereg('haha',$kata) || ereg('hihi',$kata) || ereg('wkwk',$kata) || ereg('wakaka',$kata) || ereg('hehe',$kata) || ereg('xixi',$kata)){
$arr_mess = array(
'👿 ngakak 💤 xixixi 🐴👫',
'🐷🎉 malah 🍎 mrengez 💩 hehehe ❤',
'✊ looohhh 💀 malah 🐾 ketawa 🎈 xixixi ✌',
'💀 loooohhh ⛄ robot 😓 nya 👀 ketawa 🐔 hahaha ⚡',
'👽 aku 🐙 serius 🌷 pleeend 🌻 jangan 💤 ketawa 🐒 dunkkkk... 😷 wkwkwk 🍔',
'😜🐛 koq 🔥 ketawa 🍸 ada 🐱 yang 🌾 aneh 👐 ea 🐠 hehe 🐸',
'✊ wkwkwkwkwk 🐚 juga 🌴',
'👄👿 udah 🌵 udah 💤 jangan 🐴 ketawa 👫 mulu... ✌ '.$nama.' 🐚 malu 🌷 tuh 🌻 banyak 🍎 orang ❤ xixixi ✊',
);
}else{
if(ereg(' WIB',$kata) || ereg(' pm',$kata) || ereg(' am',$kata) || ereg('tanggal',$kata) || ereg('jam',$kata)){
$arr_mess = array(
'😜 lucu 🎉 komen 🐷 kamu ⛄ '.$nama.'... 😓⚡ ada 👀 waktu 🐔 nya 🐒 segala 👐',
'✊ apa 👽 an 🔥 twuh 💤 '.$nama.' 😷 koq 🍸 ada 💩 jam 🐱 nya 🎈 segala 🍔',
'👄🌵 pasti 🐸 '.$nama.' 🌾🐾 nich 🐠 orang 🐛 yang 🐙 tepat 🌴 waktu... 👿 ampe 💀 komen 💤 pun 🐴 di ❤ kasih 👐 jam... 🌵 hehehe 🌾',
'😜✊ kamu 🐱 tukang 🎉 jam 🐷 keliling ✌ ya 👀 '.$nama.' 😓 wkwkwkwkwk 🐾',
'👄 lho 👫 '.$nama.',, ⚡ itu ⛄ robot ✊ atau 🐔 tukang 👽 jam 🔥 keliling 🐒 ya 🐚 ?? 🌷 wkwkwk 🐠',
'💀 aduuuh 💩 '.$nama.' 💤 jam 😷 nya 🍎 bener 🍸 gak 🐸 tuh 🎈 wkwkwk 🐛',
'👿 haddooooh 🌴🐙 '.$nama.' 🌻 robot 😜 na 💤 gaul 🎉 ada ❤ jam ✌ na 👀 segala 🍔 wkwkwk 💀',
'✊ lho 🐴👫 lho 🐷 '.$nama.'... ⚡ Itu 😓 robot 🐒 fb 🐔 atau 🌻 tukang 🐙 service 🐚 jam 🐱 ya 😷👐 ?? 👽 wkwkwk ✊',
'👄 eeh 🔥 '.$nama.' 💩 jam ⛄ na 💤 berapa 🍸 harga 🍎 nya 🍔 ?? 🐾 wkwkwk 🌾',
);
}else{
if(ereg('kemana',$kata) || ereg('kmana',$kata) || ereg('buru2',$kata) || ereg('ditinggal',$kata)){
$arr_mess = array(
'🌴 eaa 🎈 nich 🌵 '.$nama.' 🐠 robot 🐸 nya 🌷 ngantuk... 🐛 bye 👿 ',
'😜 kemana 💤 kemana 👫 kemana.... 🎉🐴 assseeekk 🐷 ting 🐛 ting 🐸 punya 🍸 pleend 💩 hehe ✌',
'✊ udah ⛄ ngantuk ❤ aku 😓',
'👀⚡ byee.... 🌻',
'🌷 turru 💀 sek 🐙 yo 🐱',
'👄 mau 🍎😷 bobok 🐔 aku... ✊ mau 👽 ikut 🔥 ta 🐒',
'👿 aku 💤 ikut 🍔 ya 👐 '.$nama,
);
}else{
if(ereg('kadir',$kata) || ereg('hadir',$kata) || ereg('HADIR',$kata) || ereg('ABSEN',$kata) || ereg('absen',$kata) || ereg('Absen',$kata)){
$arr_mess = array(
'🌴🐚 Timz 🎈 ya 🐾 '.$nama.' 🌾 udah 🐠 hadir... 🌵',
'😜 seneng 💤 dweh 🐴👫 kalo]] 🎉 '.$nama.' ⛄🐷 hadir ❤',
'✊ udah 😓⚡ aku 👀 tunggu ✊ kehadiran ✌ mu 🐔 '.$nama.' 🐒 hehe... 🔥 '.$ucapan.'..!!',
'🍎 '.$nama.' 👽 udah 💩 hadir.... 💤 makasih 😷👐',
'👄 hadir 🍔 kemana 🍸 '.$nama.' 🐱 ??? 🐸🎈 wkwkwk 🐾',
'👿 '.$nama.' 🌻 Kamu 🌾 bawa 🐠 anu 🐛 ea....?? 🐚 koq 🐙 setiap 🌵 '.$nama.' 🌷 hadir 🌴 bawaan 💀 nya ❤ kepengen ✌ anu ✊ gitu... 💩 wkwkwk 👐 ',
'😜 asseeeek 💤 '.$nama.' 🐴👫 hadirrr... 🎉 gak 🐷 jadi 🐚 galau 🐙 lah 🌻 aku... 🎈 hehehe 💤',
'✊ :betapa ⛄ sepi ⚡ nya ❤ tanpa ✌ kehadiran 😓 mu 👀 '.$nama.' ✊ wkwkwkwk 🐾🐸',
);
}else{
if(ereg('https',$kata) || ereg('www',$kata) || ereg('http',$kata) || ereg('HTTP',$kata) || ereg('Http',$kata)){
$arr_mess=array(
'👄💀 Link 🐔 apaan 🐒 twuh 👽 Gan 🔥 ?? 💩 BERBAHAYA 👐 gak 😷 hehehe 🍎','🍔 Situs 🍸 apa 🐱 an 🌾 twuh?? 🐠 Jangan 🐛 jangan 🌷 situs 🌵 anu 🌴 ya 👿 ?? 💤 hehehe 👫','🐴 di 🎉 situs 🐷 itu ⛄ ada ⚡ makanan 🐠 nya 🐛 gak 🌻 twuh 🍸 gan 🍔 hehehe 🔥','🎈 apa 😓 an 💩 yach 💀 isi 🐚 situsnya 🌾 ?? ✊ Jadi 😜 penasaran 🌵 dweeh 🐙 hehehe 🐱','👐 situs 💤 apa 👀 an ❤ twuh ✊ hayooo ✌ ?? 🐔 Jangan 🌴 jangan 🌷 situs 👿 parno 🐸 ya 👄 ?? 🐾 wkwkwkwk 🍎 hehehe 👽','🐒 Link 😷 nya 💤 boleh 🐴👫 di 🎉 pencet ⛄ pencet 🐷 ndak ⚡ twuh 🍸 hehehe 🐚',
);
}else{
if(ereg('OFF',$kata) || ereg('off',$kata) || ereg('ofline',$kata) || ereg('offline',$kata) || ereg('Offline',$kata) || ereg('Off',$kata)){
$arr_mess=array(
'😜 Waaaah 😓 '.$nama.' ❤ hebat.... 👀 padahal ✊ lagi ✌ off 🐔 line 🌷 koq 🌵 bisa 🌻 comment 🐱 gimana 💩 cara 🐒 nya 👽 twuh?? 💤 hehehe.... 👐',
'✊ sama 🔥 '.$nama.' 😷 aku 🍎 juga 🍔 gie 🎈 Off 🐸 line 🐾 koq 🌾',
'👄 mau 🐠 off 🐛 line 🐙 atau 🌴 online 💀 yang 👿 penting 💤 udah 🐴👫 comment 🎉 aku 🐷 udah ⛄ seneng 🌾 banget 🐚 koq 🐾 '.$nama.'...yakin 🐱 dah 🐒 zumpah...!!! 👀 hehehe 🌴🌵',
'😜 yaaah ⚡ '.$nama.' 😓 off ❤ line ✊ mulu ✌ nich...... 🐔',
'✊ owww 👽 jadi 🔥 '.$nama.' 💩 robot 💤 ea.... 👐 sama 🍎😷 kalo 🍔 giitu 🍸 xixixixi 🎈',
'🐸 waduh 🐠🌻 '.$nama.' 🐛 jadi 🐙 robot 🌷',
);
}else{
if(ereg('Keriting',$kata) || ereg('kriting',$kata) || ereg('Kriting',$kata) || ereg('Kesleo',$kata) || ereg('kriting',$kata) || ereg('kesleo',$kata)){
$arr_mess=array(
'👄👿 Salut 💀 dweh 👫💤 '.$nama.'... 🐴 meski ❤😓 jari 💀 nya 🐙 keriting 🐚 tetep 🌾 hadir 🍔 makasih 🔥 eaaa 🐔',
'😜 tenang 🎉 '.$nama.' 🐷 sini ⛄ jari ⚡ nya 👀 aku ✊ setrika 🐒✌ wakakaka 👽',
'✊ Uuuuu 💩 kacian 💤 keriting 👐 ea 😷 '.$nama.'... 🍎 sama 🍸 kalo 🐱 gitu 🎈',
'👄 mau 🐸 di 🐾 pijitin 🌻 jari 🐠 nya 🐛 '.$nama.' 🌷',
'👿 besok 🌵 jempol 🌴 nya 🐧 di 🐚🐨 bonding 🐛 ea 😫 '.$nama.' 💅 wkwkwk 💃',
);
}else{
if(ereg('like',$kata) || ereg('JEMPOL',$kata) || ereg('LIKE',$kata) || ereg('jempol',$kata) || ereg('Jempol',$kata) || ereg('suka',$kata)){
$arr_mess=array(
'♥ terima 🌾 kasih]] 💋 '.$nama.' 💐',
'👷 jempol 🙌 mu ❤ luar 😡 biasa 😢 '.$nama.' 🐔',
'📀 ndak ✊ krriting 👄 twuh 👽 jempol 📲 nya 📞 wkwkwk 📺',
'🐙 ok 💽 thankz 👯 for 🎃 like 🎁 this... 😁 wekekekeke 😷',
'🌹 makasih 🍔 udah 🐬 like',
'🌻 bener 💜 nich 💪 '.$nama.' 👲',
);
}else{
$arr_mess = array(
'😭 Tthankz 🎍 ea 🔔 '.$nama.' 💀 udah 💂 mampir... 🙋 '.$ucapan.' 👆 '.$nama,
'👉 Suka 💂 dweh... 👀💏 '.$nama.' 👂 bisa 😜 hadir... 😡 '.$ucapan,
$ucapan.'🐙 Makasih 🌴 ea 🐙 '.$nama.' 🙏 Jempol 📺 + 💽 comment 👯 nya 🎃',
'🌹 Oke 🎁 '.$nama.' 😁 Thankz 😷 udah 🍔 Mampir 💜🐬',
'🌻 Seneng 💪 Dweh 👲 '.$nama.' 🎍 udah 🔔 comment 💂💀',
'😭 Baca 🙋 Komen 👆 '.$nama.' 👉 Rasa 🌂 nya 🌊 adem 🌊 hehe 🌟',
'🐙 aaaaaaaaah 🐑 ada 🐚 '.$nama.'... 👋 Thankz 😲 '.$nama.' 😜👂 udah 🙏 hadir... 💽',
'🌹 Kikuk 😳 Kikuk 🍊 Hehe.... 🍀 '.$ucapan,
'🌾 Oke 💂 Tok 💜 Ezz 👲 '.$nama.' 😷😁 Makasih 😡 eaaa 💏',
$ucapan.' 👀 '.$nama,
$ucapan.' 🌴 '.$nama.' 📺 rajin 🐙 banget 👯 comment 🎃 xixixixi 🎁 pizzz.... 🍔',
'🌻 Makaceeeeeeeehhhhhhh 🐬',
'😭👉 Andai 💪 Saja 🎍 kamu 🔔 tau 💀 '.$nama.' 💂 Setiap 🙋 Kamu 👆 Hadir 🌂 Rasa 🌊 nya 🌟 Gimanaaaaaa 🐑 Gitu 👋🐚',
'🐙 Maap 😲 '.$nama.'.... 😳 Baru 🍊 off 🍀 line 🌾 nieh.... 🙏🐙 belum 🔔 sempat 💜 on 🎃 line 😡 saya....biar 💂 robot 💏 yang 👀 nemenin 👂 kamu 😜 ya 🌴 wakakakakaka 📺',
'🌹 Seneng 💽 dweh 👯 kalo 🎁 ada 😁 '.$nama.' 😷 ntar 🍔 Komen 🐬 lagi 💪 eaaaaa 👲 hehehe.... 🎍',
$ucapan.' 🌻 '.$nama.'... 💀 kamu 💂 bawa 🙋 anu 👆 ya....?? 👉 Abisnya 😭 kalo 🌊🌂 deket 🌟 kamu 🐑 Bawaan 🐚 nya 👋 pengen 🔔 Anuuuuuuu 💀 Gitu 🎁 hehehe 💽',
'🐙 Weeeeeeeeeeeee 😲 '.$nama.' 😳 udah 🍊 hadirrrrr.... 🍀 '.$ucapan.' 😁 '.$nama.' 📺',
'🌹 kalau 🌾 '.$nama.' 💂 Gak 💏 komen 👀 bisa 👂 Gila 😜 aku... 😡 haha 🌴',
'🐙 Oke 🌻 siiip 🙏 Laaa... 👯',
'😭 Ampe 🎃 jempol 😷 Keriting 🍔 Oeee 🐬 haha... 💜',
'👉👆 Hampir 💪 Aja 👲 saya 🎍 Galau 💂 kalo 🙋 '.$nama.' ☕ Gak 🎏 comment... 🎎 '.$ucapan.' 🐸 '.$nama,
'😜 Thankz 👷 '.$nama.' 📺',
'🐍 Sipz 🔥',
'👿 WoW 💔💑 Bisa 😢 terbang 😥',
'💀 Ngopi ☕ dulu 😨 '.$nama.' 🌹',
'💅 '.$nama.' 🌺 Suka 🌻 Sekali 🐟 ya 🐛 ama 🐘 aku 🐗 hehehe 💃',
'🐘 yez 💻 yez 💾 yez 📞 '.$nama.' ✨ udah ❤ Hadir 😂😄',
'🌷 Sesama 💚💝 robot 👐 Harus 🍓 rukun 😷 ea 😻 '.$nama.' 😁',
'🌱 Se 😉 sepi 🎈 malam 🐴 tanpa 📀 rembulan 📞 se 🐺 hening 🐍 Lautan 👂 tanpa 👽 gelombang 👾 Begitu 💾💻 pula 📞 aku ✨ Terasa ❤ sepi 😄 tanpa 😂 komentar 💚 kamu.....hehehe 💝',
'🐘 Lhoooo 👐 '.$nama.' 🍓 nongol 😷 Lagi 😻',
'🌷🐺 jempol 😁 ku 😉 udah 🎈 kriting 🐴 plend 📞 plend 👽 hehe 📀',
'🌱 ciat 🐍 ciat 👂 ciat 👾 ciat 😍😁 hehehe ⚡',
'🐘 Bingung 🎏 Mau 🎎 jawab 🐷 Apa 👵 '.$nama.' 💿',
'💃 berrrrrr... 👽👂',
'🌷 kamu 💋💅 Like 👈 status 🌴 ku 💻 aku 💾 like 📞 status ✨ mu ❤ trus 😄 kita 👾 Like 🐴 Like 😁 an 💚 yuk 😂',
'🌱🐍 Asal 💝 kan 👐 Jangan 🍓 Hadir 😷 bersama 😻 pak 😉 RT 🎈 aja 📀 '.$nama.' 📞',
'🐺 Kamu 😍😁 Koq ⚡ baek 🎏 banget 🎎 sich 🐷 '.$nama.'.... 🐘🌷 Selalu 📞 Hadir 👐',
'🌱 asssSeeeeeekkkk 👵 '.$nama.' 💿 ngasih 💃 Coomment 💅',
'👾 hemmmmm 💋',
'👽 wadaw 👈 wadaw 🌴 wadaw.... 💻 '.$nama.' 💾 wkwkwk 📞',
'👂 Tanpa ❤✨ Comment 😄 mu 😂 Aku 💝 Galauuuu 💚',
'🐍🐺 Dulu 🍓 Saya 😷 suka 😻 makan 😁 roti.... 😉 setelah 🎈 baca 🐴 komen 📀 '.$nama.' 😁 Saya ⚡😍 jadi 🎏 suka 🎎 makan 🐷 batu.... 👐💚 Terima 🐴 kasih 😷 '.$nama.' 😄❤ wkwkwkwk 💋',
'🐘 Dulu 👵 Saya 💿 susah 💃 tidur... 💅 Setelah 👈 baca 🌴 komen 💻 dari 💾 '.$nama.' 📞 saya 📀 Jarang 🍓 mandi.... 📞 wkwkwk ✨',
'🌷🌱 Dulu 😂 Saya 💝 menderita 😻 kencing 😁 batu... 😉 setelah 🎈 baca 🐺 komen 🐍 dari 👂 '.$nama.' 👾 Batunya 👽 saya 😍😁 kumpulin 🎏 buat 👵🐷 bangun 💃 Rumah.... 📞 Terima 🐍🐺 kasih 😁😻 '.$nama.' 💚 wkwkwk ❤✨',
'🌱👾 aaah ⚡ '.$nama.' 💿🎎 bisa 💅 aja 💋 deeee 👈',
'🐘🌷 Trimz 👽 waaaaa 😷',
);
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}


$message= ' '.$nama.' @ '.$arr_mess[rand(0,count($arr_mess)-1)].'';
$message = str_replace($huruf,$ken_network_team,$message);
$message = ''.$bot[emo_ken_1].'
'.$message.'
'.$bot[emo_ken_3].'';
if($com[data][$c-1][from][id] != $me[id]) {
$rsp[$i][] = urlencode($message);
}
}
}
}

if(!empty($rsp[$i])){ $respon = implode('%0a',$rsp[$i]);
auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$access_token.'&message='.$respon.'+'.urlencode($banner).'&method=post');
//auto('https://graph.beta.facebook.com/'.$com[data][$c-1][id].'/likes?access_token='.$access_token.'&method=post');
//auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/likes?access_token='.$access_token.'&method=post');
auto('https://graph.beta.facebook.com/'.$stat[data][$i-1][id].'/pokes?access_token='.$access_token.'&method=post');
}
}
function auto($url){
$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_URL, $url);
$ch = curl_exec($curl);
curl_close($curl);
return $ch;
}
?>