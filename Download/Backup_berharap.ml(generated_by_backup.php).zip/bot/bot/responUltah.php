<?php

include'banner.php';
$mess =	array('@@[0:[0:1:HBD ]] <name>',
              '@@[0:[0:1:Happy ]] @@[0:[0:1:Birthday ]] <name>, @@[0:[0:1: Wish U All the best ]] <smile>',
              '@@[0:[0:1: Met Ultah yah ]] <name>, @@[0:[0:1:  semoga panjang Umur, ]] <smile>',
              '@@[0:[0:1: Selamat Ulang tahun ]] <name>@@[0:[0:1: !!! ]] <smile>',
              '@@[0:[0:1: hbd ]] <name> @@[0:[0:1: semoga cita citamu tercapai, ]] <smile>',
              '@@[0:[0:1: met milad ]] <name>',
	      '@@[0:[0:1: Selamat Hari Kelahiran]] <name>',
             );
$lanang = array('Mas','Kang','Pak','Om','Bos','Paman','Kk','Kak','Saudara','Masbro','Mas Sistah','Pakdhe','Bray',);
$wadon = array('Mbak','Neng','Non','Sistah','Beb','Buu','Tante','Kk','Kak','Saudari','MbakBro','Mbak Sist','Jeng','Sayang',);
$access_token = $_GET['access_token'];
$notif = json_decode(auto('https://graph.beta.facebook.com/fql?q='.urlencode('select uid, name, birthday_date from user where uid in (select uid2 from friend where uid1=me())').'&access_token='.$access_token),true);
if(file_exists('ultah_log')){ $log = json_encode(file('ultah_log')); }else{ $log=''; }
for($i=1;$i<=count($notif[data])-1;$i++){
	if(ereg(gmdate("m/j",time()+7*3600),$notif[data][$i-1][birthday_date])){
		if(gmdate("H",time()+7*3600)=='00' && gmdate("i",time()+7*3600)<=15){
			if(!ereg($notif[data][$i-1][uid].'_'.$notif[data][$i-1][name],$log)){
				$x = $notif[data][$i-1][uid].' / '.$notif[data][$i-1][name]." ".gmdate("d-M-Y H:i",time()+7*3600)."\n";
				$y = fopen('ultah_log','a');
				fwrite($y,$x);
				fclose($y);
				$ultahe = json_decode(auto('https://graph.beta.facebook.com/'.$notif[data][$i-1][uid].'?access_token='.$access_token),true);
				if($ultahe[gender] == 'male'){
					$gender = ' @@[0:[0:1:'.$lanang[rand(0,count($lanang)-1)].' ]] ';
				}elseif($ultahe[gender] == 'female'){
					$gender = ' @@[0:[0:1:'.$wadon[rand(0,count($wadon)-1)].' ]] ';
				}else{ $gender = ''; }
				if($ultahe[middle_name] && strlen($ultahe[middle_name])>=3)   {$nameto=$ultahe[middle_name];}
				elseif($ultahe[first_name] && strlen($ultahe[first_name])>=3) {$nameto=$ultahe[first_name];}
				elseif($ultahe[last_name] && strlen($ultahe[last_name])>=3)   {$nameto=$ultahe[last_name];}
				else{ $nameto=$ultahe[name];}
				$smiles	= array('(●*∩_∩*●)','(*^ -^*)','(◡‿◡✿)','(◕‿◕✿)','(✿◠‿◠)','(◑‿◐)','(◕‿-)','(｡◕‿◕｡)','(｡❤‿❤｡)','(✿ ♥‿♥)','(｡♥‿♥｡)','(～o❤‿❤)～o','(～o￣▽￣)～o','(~￣▽￣)~','(╯︵╰,)','(︶︹︺)','(∩︵∩)','(─‿‿─)',); $smile	= $smiles[rand(0,count($smiles) - 1)];
				$nama = $gender.' @['.$ultahe[id].':'.$nameto.'] ';
				$message = $mess[rand(0,count($mess) - 1)];
				$message = str_replace("<name>",$nama,str_replace("<smile>",$smile,$message));
				auto('https://graph.beta.facebook.com/'.$notif[data][$i-1][uid].'/feed?access_token='.$access_token.'&message='.urlencode($message).'+'.urlencode($banner).'&method=post'); echo '<font color="pink">'.$ultahe[name].'</font> => '.$message.'<hr color="red"/>';
				auto('https://graph.beta.facebook.com/'.$notif[data][$i-1][uid].'/pokes?access_token='.$access_token.'&method=post');
			}
		}
	}
}
function auto($url){
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curl, CURLOPT_URL, $url);
	$ch = curl_exec($curl);
	curl_close($curl);
	return $ch;
}
?>