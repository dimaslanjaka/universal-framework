<?php
$text=array("Cintailah pacar kamu, sebelum aku mencintainya

",
"

Sendal putus lebih menyusahkan ketimbang Putus Cinta.



",
"

Neng, jangan pake rok mini ya, ntar Aa jadi kangen 
So sweet, masa sih Aa kangen neng? 
Maksudnya, Aa jadi kangen make rok lagi
kan AA mantan bencong :v
",
"
*Kuis*
Hallo dengan siapa dimana 
| Ifin om di Jakarta 
| Oke, dek
Ifin mau uang 100juta..? 
| Mauuuu Mauu om | Kerja dulu gih!! 
| Njerr, ada yg punya Golok..? :v
#WTF#!&!'???

",
"

Wkwkwkwk*
Ketik REG (spasi) CINTA
Kaabbboooorrrrr

",
"
Jangan pergi Laa.. 
| Apa susahnya pacaran? Ketemuan gak pernah, jalan gak pernah? 
| Maaf... habis nya aku gak punya sendaal :D
| Ðˆ@??#$%&
",
"
    Kalau orang Pacaran= i love you beibz
    Kalau orang LDR= i Miss you beibz
    Kalau orang Jomblo= I Love Mie Sedap... :v
    wakakakaka.. :v
",
"
    .Kalo cinta jangan Lewat SMS karna SMS bisa di hapuss. .
    .Kalo cinta jangan Lewat Bunga karna Bunga bisa layu. .
    .Kalo cinta jangan Lewat Lagu karna Lagu bisa terlupakan. .
    .Tapi cinta itu Lewat mie sedap. . .
    .Karena MIE SEDAP ga pernah bohong. . . . (y)
    wkwkwkwwkwkwkwk.. *Kaborrr :v
",
"

Rajin Nabung.. 
duit di bawa kabur.. 
Rajin ngutang... 
nyawa bisa melayang.. 
",
"
TIPS= curigalah bila ukuran payudara manajer bank tempat anda menabung terlihat bertambah dari waktu ke waktu, 
dan mulailah berlatih bela diri secara intensif saat mengajukan aplikasi kartu kredit
",
"
    Seorang Wanita Gemuk pergi ke dokter. Si Wanita berkata Dok, obat apa yang bisa buat saya langsing?.
 Si Dokter menjawab 
Cukup Geleng-geleng kepala saja.
 Si Wanita pun berkata lagi seolah tidak percaya 
Masa sih semudah itu dok? kapan saya harus geleng-geleng kepala? 
dan si dokter menjawab Cukup Jika ada yang menawari anda Makan! hahahaha :v
",
"
*Cerita Indomie Part 2
Setiap Pagi Aku sering dibuatkan Indomie untuk Sarapan Oleh Ayahku
Namun Karena Aku suka Malas Bangun, 
Ayah membangunkan aku dengan Menyiram sisa Air Indomie Kewajahku..
Ini Deritaku, APa deritamu ??... :v
",
"
Waktu hujan aqu pingin sekali makan mie indomie...
Langsung aja aku pergi ke warung dekat rumah,,
Sesampainya di warung aku lupa ga bawa uang untungnya ada nenek tercinta 
Langsung aja aku tukerin nenek ku dengan sedus mie indomie
ini drita ku apa derita kalian..?
",
"
Belajarlah dari Kuntilanak, sesulit apapun hidup tapi selalu tertawa. . Hiii hii. Hiii hiii... Hiii...
Belajarlah dari Tuyul, masih kecil tapi sudah bisa cari duit sendiri..
Belajarlah dari Pocong, dari dulu pakaiannya itu-itu saja, hidup sederhana. .
Belajarlah dari Babi ngepet, kalo malem cuma pake lilin, hemat listrik donk. .
Belajarlah dari Jelangkung, Mandiri, datang tak dijemput, pulang tak diantar. . Kasihan yaa....????
",
"
Cara Agar Suami Tidak Sering Berbohong
Ingin suami Anda tidak terlalu sering berbohong? Caranya gampang. Anda jangan terlalu sering bertanya
",
"
Manusia VS Cicak
Manusia lagi santai baca koran tiba-tiba Cicak beol tepat mengenai si Manusia.
Sambil marah-marah
Manusia =Cicak, sialan lu â€¦.. beol lu kena gue nich !
Dengan pede cicak menjawab
Cicak =Manusia, dasar tidak tahu diri â€¦..
tau gak gue terbeol-beol gini gara-gara seharian nahan plafon rumah lu ini
biar tidak runtuh !! 
",
"
Tipe wanita
Tipe wanita dilihat dari CDnya
Pake CD sampe ke puser = LUGU
Pake CD mini = NAKAL
Pake berenda = KEIBUAN
Nggak pake CD = PENUH PENGERTIAN
wkwkwk... :v
",
"
Untuk bercinta, Wanita butuh sebuah Alasan. Pria butuh Alas...
",
"
Saat kulihat matamu.
nafasku pun berhenti.
jantngku berdetak kencang.
benarkah semua yang kurasakan ini
Aku pun memberanikan diri untuk bertanya kepadamu..
kau kentut yaâ€¦? :v
",
"
Anak kebo makan laler.
Met bobo jangan ngiler.
Nenek kebo maen disawah.
Mimpiin aku yah.
Mau bobo makan es.
Eh ada kebo baca sms.. 
",
"
kalau ada sumur diladang.
boleh kita menumpang mandi.
kalo ada umur yang panjang.
ngapain juga lu baca sms ini..?
",
"
Lupa AGAMA? oopss! NERAKA
Lupa ORANG TUA? ihh! DURHAKA
Lupa SESAMA? ah! BIASA
Tapi LUPA SAMA AKU? ehm.. MANA BISA!! :D
",
"
Ada bonus 10 sms enaknya di apain ya?
Buat pacar 4, aku kan sayang banget sama dia.
Buat teman aku 3, dia baik banget sih Buat mantan 2,
dia masih perhatian banget sama aku Buat lu 1,
abis lu jelek banget sih.. :v
",
"
Hidup ini bagaikan film
Saat kau tertawaâ€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦. KOMEDI
Saat kau menangis â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦ DRAMA
Saat kau berkelahi â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦ ACTION
Saat kau bercermin â€¦â€¦â€¦â€¦â€¦â€¦â€¦â€¦.. HORROR
",
"
Kasih itu putih
Kasih itu damai
Kasih itu menjiwai hati kita
Kasih itu mengandung bahagia
Kasih ituâ€¦.. KASIHAANNNN Deh loooo
",
"
Kalau kamu arjuna
aku mau jadi srikandi
kalau kamu kupu2
aku mau jadi bunganya
kalau kamu jelek dan miskinâ€¦
AKU MAU NINGGALIN KAMU !
",
"
Cinta itu buta
tapi tidak membutakan
Cinta itu indah
tapi tak selamanya indah
Karna cinta aQ bahagia
karna cinta pula aku merana
Ya, karena itulah cinta
",
"
Kalo aku nelayan
aQ akan memancing hatimu
yang paling dalam
dan kusimpan di hatiku yg terdalam
",
"
Jika ada pedagang yang menjual cintamu
aQ akan borong semua dagangannya
",
"
singa jantan mati mengejar rusa
rusa..takut mati berdiri..........
priya tampan gagah perkasa......
masa takut sama istri sendri..................?
",
"
cinta berjuta rasanya
cinta berjuta rasanya itu boong
rasakan hanya ada 4
1.manis
2.asam
3.asin
4.pahit
",
"
Waktu mengandung dirimu dulu, ibumu pasti ngidamnya kopi ya? Abis gara-gara kamu aku jadi susssaaahh tidurâ€¦
",
"
Sejuta kata cinta ingin kusampaikan. Apa daya pulsaku habis! Kirimkan pulsamu, aku akan kirimi SMS cintaku
",
"
Teman sejati selalu berbagi, 
kalo saya jadi laut, 
kamu jadi ikan, 
saya jadi kumbang kamu jadi bunga, 
saya jadi matahari kamu jadi bumi, 
kalo saya jadi tarzan, 
kamu mau jadi monyetnya?
",
"
Cintailah sesamamu seperti kamu mencintai dirimu sendiri, 
tapi jangan mencintai pacar sesamamu seperti kamu mencintai pacar kamu sendiri.
",
"
Saat aku sedih kau disampingku, 
saat aku marah kau ada di dekatku. 
Saat aku menangis kau disisiku, 
Sekarang aku sadar, 
jangan2 kau adalah pembawa sial untukku.
",
"
Sudah sejak lama aku memperhatikanmu, 
mencuri pandang hanya untuk melihatmu, 
ku tak tahu apa yang harus aku katakan kepadamu agar kau mengerti ada UPIL di hidungmu.
",
"
Saat anda membaca Status ini, 
mata anda akan terbuka, 
anda akan melihat tulisan ini, 
selanjutnyaâ€¦ 
terserah anda
",
"
Sayang sering aku telp kamuâ€¦ 
Aku sms kamuâ€¦ 
ternyata kini aku sadar, 
ternyataâ€¦ mmmmm aku lebih sayang sama PULSAKU.
",
"
Hari ini aku kangen banget sama kamu, 
aku sangat merindukanmu, 
aku ingin kamu kerumahku, 
PLEASE balik sama aku karena aku benar2 butuh 
seorang PEMBANTU!

",
"
Biarlah semua terjadi, 
biarlah semua berlalu, 
tapi aku nggak akan pernah lupa sama kamu, 
karena sampai saat iniâ€¦ 
kamuâ€¦ 
NGGAK PERNAH BAYAR UTANG! 
NUMPUK TUH!!
",
"

Kenapa koboi Meksiko kalo berpetualang selalu bawa gitar?
Emangnya disuruh bawa piano? yang bener ajaaa
",
"
Merasa sedih dan sepi?
Hubungi gue!!
Tak ada teman curhat?
Hubungi gue!!
Merasa strezz seperti mo gila?
Hubungi RUMAH SAKIT JIWA DONKKK!!!!!
JANGAN GUE MELULU!
",
"
Selintas lalu senyummu masih terlintas basah membasuh gurun di hatiku inginku bertanya dalam keraguanâ€¦â€¦â€¦????? 
Semalem tidur ngiler ya..!!! â€¦
",
"
Sayâ€¦ 
dikau adalah idamanku. 
Sayâ€¦ 
tanpamu terasa hampa. 
Sayâ€¦ 
daku menginginkanmu, 
merasakanmu, 
menikmatimu. 
Sayâ€¦ur Bayam seikat berapa ya??? â€¦
",
"
Jika hidupmu dalam kegelapan, 
berdoalah. 
Karena hanya dengan doa hidupmu akan tenang dan terang. 
Namun jika engkau sudah berdoa dan suasana disekitarmu masih gelap, berarti anda belum BAYAR LISTRIK. â€¦
",
"
Jatuh cinta berjuta rasanya â€¦
kalau jatuh dari sepeda cuma satu rasanya= SAAAAAKIIIIT!
",
"
Kalau jabatan Pemimpin Cabang kuperoleh, 
aku akan bersikap tegas
Kalau disuapâ€¦?
Tegas kuterima!
",
"
CiNta adaLah rasa CayaN9 YG lbh utk dpt memiliki & menJagaNya.
Tp kadang Rasa CinTa bisa di MAKAN api cemburu,di MAKAN rasa bNci
& di MAKAN nafsu, tp aP pUn MAKANANnya mnum nyA TEH BOTOL SOSROâ€¦
",
"
Takkan HADIR tanpa pertemuanâ€¦
Takkan TULUS tanpa kejujuranâ€¦
Takkan SUCI tanpa ikatanâ€¦
Takkan ABADI tanpa kesetiaanâ€¦
Takkan INDAH tanpa kasih sayangâ€¦
I LOVE YOU
",
"
bertemu dengan mu adalah takdir
menjadi sahabat mu adalah pilihan
tapi jatuh cinta pada mu itu sungguh diluar kendaliku
",
"
Di malam yang sunyi,di suasana yang sepi dan tak terasa rintik hujan pun
turun entah kenapa hanya kau yang ingin kutemui, tuk mengatakan 
GENTENG RUMAH LO BOCOR
",
"
Gue baca koran ttg bahaya rokok,
gue berhenti merokok.
Gue baca koran ttg bahaya minuman keras,
gue berhenti minum bir.
Pas gue baca koran ttg bahaya sex,
gue berhenti baca KORAN.
",
"
Kemarin aku terperangah, ada yang cakep banget di mall.
Sialan, ternyata itu cermin! Oh ternyata aku sendiri!
",
"
Q maw ngomong
Sblmq terlambat
N sblum org lain
Ktkn kpdmu
Mungkin terlalu cpt bwt u
Q gk maw bohongi ht q sendiri
Skarg saat yg tepat uyk jujur ma U
PULSAKU HABIS!!!!!!!!!
",
"
Prshbatn qt t indah bgd
Klo k ketawa
Aq juga ktawa
Klo kamu nangis
Aq jg nangis
Tp klo km kepleset
Aq ktawa mpe nangis2
Indh bgd kn?
",
"
Semalem masak kambing guling, 
kambingnya dpt dari maling 
hey my darling, 
you're my everything
",
"
Buah selasih , 
buah jambu , 
Biarkan ak menjadi kekasih , 
yg terbaik untukmu.
",
"
Anak gaja...h , 
anak gurita , 
cinta itu indah , 
bila kau tak hiasi dgn dusta.
",
"
Duduk di bangku, 
pake celana 
kamu ditambah Aku, 
jadi sempurna 
",
"
Jalan  ke kota, jgn lupa naik onta 
Dari sekian bnyak wanita, cuma kamu yg kucinta
",
"
Pergi ke bandung naik kereta.
Pulang nya naik pesawat.
Akan ku jaga cinta kita.
sampai datang kiamat.
",
"
Warnanya putih, isi buah duku 
Ketika ku sedang sedih, ku inginkan hadirmu disisiku. 
",
"
Pohon jati , 
pohon jambu , 
hingga aku mati , 
setia ku hanya untukmu. 
",
"
Pulau roti kota cikini, 
Haruskah ku mati untuk menunjukan cinta ku selama ini
",
"
Pergi kesekolah untuk meminum jamu, 
Galau itu adalah ketika aku tanpa kamu
",
"
Si syahrini sekarang dagang jamu . 
kuberikan semua cinta ini hanya untukmu
",
"
paling enak liburan ke bali, 
di bali nginep di villa. 
walau baru bertemu lo 1 kali, 
lo udah buat gue tergila gila.
",
"
Makan kue campur kolang-kaling. 
Cinta gue gak akan berpaling 
",
"
Depan tugu pahlawan, 
sekarang makin macet. 
Wajahmu yang rupawan, 
membuatku ingin selalu deket
",
"
Bukan tamu, 
tapi bikin sumpek. 
Senyum kamu, 
bikin abang klepek-klepek
",
"
naik kuda bareng yuyum
di belakang kuda ada kotak
kalau kamu terrsenyum
pasti jantungku berhenti berdetak
",
"

kamu anak arsitek ya? 
iya, kok tau? 
soalnya kamu jago banget sih membuat tata ruang di hati ku
",
"
Kamu tau nggak knp daun warnanya hijau?
krn kalau warnanya pink, 
sama dong sama aura cinta kita berdua.
",
"
Minum es serut, 
makannya brownies. 
Kalo lagi cemberut, 
kamu tambah manis
",
"
Matanya belo , 
sianak lembu , 
Mau tau kenapa aku jomblo , 
Karena ak nungguin KAMU
",
"
cinta aku ke kamu seperti barang antik, 
semakin lama aku mencintai kamu, 
semakin berharga dirimu di mata kyyu..
",
"
bener jg kalo ada yang blng, 
bahasa inggris adalah jendela dunia.., 
aku bilang I love you aja, 
serasa aku melihat dunia.. :)
",
"
Cow : demi kamu aq rela lari beribu2 kilometer.
Cew : yang bener?, emang kamu berani?
Cow : berani ajh, asalkan finishâ€™nya dihati kamu
",
"
Melihat tanggal, 
melihat waktu. 
Cintaku tertinggal, 
di hatimu. 
",
"
Kamu sengaja ya mau bunuh aku dear, 
abis kalo deket kamu aku susah nafas gituuu... 
",
"
Kamu tau arti' ceramah ' buat aku dear? 
Nggak lain adalah 'cerah masa depanku bila Kau jadi mamah' 
buat anak anak kita ..
",
"
Tolong bantu aku dear,
aku ndak bisa berdiri,
selama tulang rusukku yg kau pinjam belum kau kembalikan...
Utuh.
",
"
Ak paling suka mencatat|
emang catat apa bang?|
mencatat kenangan kita untuk disatukan dlm sebuah pernikahan
",
"
Seamis2nya bau ikan ak masih nahan, 
tapi kalo amis you (i Miss you) mana ak tahan
",
"
Km pasti juragan kompor, 
soalnya setiap di dkt km ak meleleh bagaikan mentega, 
terkena percikan panasnya cinta
",
"
si ujang main layangan, si petruk mencari ilmu. 
Akan kuterjang semua rintangan, untuk mendapatkan cintamu. 
",
"
Toko batik jualan kayu, 
hai cantik pacaran yu 

",
"
Nasi Uduk, 
Dikasih mbok jamu. 
Hatiku kayak diaduk, 
lo deket kamu
",
"
Pakai mata buat melihat. 
Hei cinta, you always in my heart
",
"
Nemu belati di dalam kue ketan. 
Masih susah buka hati, 
kuncinya ketinggalan di mantan.
",
"
papa kamu dokter spesialis jantung ya? 
jantungku berdetak kenceng banget kalo deket kamu.
 ",
"
-mama kamu dokter mata ya? 
soalnya mata kamu indah banget. 
",
"
lihat deh, bunga-bunganya layu, 
soalnya mereka malu, 
kalah indah sama kamu.
",
"
kamu jago lari ya? 
kamu gak capek2 lari di pikiranku terus sih.
",
"
tau gak? perasaanku ke kamu tuh kayak merapi, 
yg bisa setiap saat meledak-ledak setiap kamu senyum sama aku.
",
"
cintaku simpel, 
tanpa rumus, 
TAPI HAFALAN. 
karena cintaku gak terhitung dan bakal aku inget sampe kapanpun
",
"
kamu itu kayak kakiku menyertai dan menuntun kemanapun aku melangkah.
",
"
 aku itu kayak XL sama ST12.
 selalu untukmu dan aku padamu.
",
"
aku berharap kamu juga bisa jadi kayak mimpi, 
gak cuman setia waktu melek, 
tapi juga setia ada buat aku waktu merem.
",
"
 aku mau menjadi rusuk, 
karena aku bisa melindungi sebuah hati yg lembut dgn diriku. 
dan hati itu adalah kamu.
",
"
Musim Terindah adalah â€¦.
 Ketika kau nyalakan pagi dengan senyummu 
Ketika kau payungi siang dengan sapamu 
Ketika kau tutup malam dengan belai manjamu 
I luv uâ€¦
",
"
Nih dah kusiapin makan siang yg istimewa buatmu: 
segelas cinta, sepiring rindu, semangkok sayang, sepotong kasih, secuil cemburu, dan sebuah doa.. 
",
"
1 pohÑ†N bs jd HuTAN. 
1 seNyumaN bs jd /HATiAN. 
1 seNtuhAN bs jd Hal yg TAk TrlupAkAN 
1 orANg sprTimu bs jd rebutAN 
",
"
burung butuh sayap agar dia bs terbang dgn sempurna!! 
aku bth kamu tuk ngejalanin hidup ni&buat semuanya jd sempurnaâ€¦ 
",
"
Aku mungkin bukan teman yang â€œsempurnaâ€ yg kamu cari, 
bukan juga yg â€œterbaikâ€ diantara semuanya,
 tapi yang pasti aku adalah teman yang selalu ingat sama kamu
",
"
ktika kmu tidur,
kmu blh tu2p matamu..
ktika kmu sedih,
kmu blh tu2p matamu..
ktika kmu mkn,
kmu blh tu2p mulutmu.. 
tp jgn prnah kmu tu2p hatimuâ€¦krna didalamnya psti ada aku..
",
"
â€œâ€¦.JikÐ´ kÐ´ÑŒ kecewÐ´ dÐ´n bâ€™sedih krnÐ´ dâ€™lÑŒkÐ´i ÑŒcÐ´pÐ´n Q, â€¦.
izinkÐ´n kÑŒ hÐ´dir merÐ´wÐ´t lÑŒkÐ´mÑŒâ€¦ 
KrnÐ´ Ð´kÑŒâ€¦ JUAL PLESTER Rp 500 @Biji MAU BELI??? 
",
"
aku ga brharap utk mnjadi orang yg trpntg dlm hidupmu.. 
itu permintaan yg trlalu bsr bagiku.. 
ak hanya brharap suatu saat nanti jk kau mlihatku..
kau akn trsenyum & brkata.. â€œdia slalu menyayangikuâ€¦ 
",
"
Ga semua bunga bisa jd lambang cinta,
tapi mawar bisa..
ga semua pohon bisa berdiri kalau kehabisan air,
tapi kaktus bisa..
dan ga semua org bisa jd pacar yg baik,tapi kamu bisaâ€¦.
",
"
â€œAkan kurangkai semua kata cinta yang ada di bumi ini, 
Jadikan seikat kembang agar kau tau semua isi hatiku..â€ 
",
"
alam Sayur Ada Kalduâ€¦ 
Relung Hatiku Tersirat Rindu Bukan Maksudku Tuk Bilang I Miss Youâ€¦ 
Ataupun Bilang I Love Youâ€¦ 
Aa cuman mau bilang Sebelum Tidur Pipis Duluâ€¦
",
"
Kasihâ€¦ 
Aku rindu padamu saat aku sedih. 
Aku rindu padamu saat aku sendiri. 
Tetapi aku paling merindukanmu saat aku bahagia
",
"
xxx, xxx, xxx, xxx, xxx, xxx, 
aku ingin menulis sejuta kali namamu dihatiku. 
agar saat satu namamu terhapus, 
aku masih punya 999 ribu lagi. 
sehingga sampai matipun ga akan hilang namamu dihatikuâ€¦..
",
"
Setiap mlm setiap detikâ€¦. 
ku slalu terbayang senyummuâ€¦. 
rambutmu yg sgt indahâ€¦. 
ingin rasanya selalu disampingmu slamanya. trusâ€¦â€¦â€¦â€¦.. 
Isiin Pulsa gw Yah say..kalo mw lanjutannya 
",
"

Disaat hari panas maupun hujan ,kamu selalu bawa mobilmu 
Disaat aku lapar, kamu selalu ngirimin aku makanan delivery 
Disaat aku pengen ganti handphone baru, kamu yang gesek kartu kreditmu 
Disaat aku hamil, kamu dimana ? 
",
"
aku berusaha memberikan cinta terbaik yang aku punya buat kamu . 
aku pastikan klo hatiku cuma buat kamuâ€¦. 
jadi jgn marah lagi ya sayangâ€¦..
",
"
Pagi ini gw bangun diantara orang2 yang gw sayangi. 
tp gw ngerasa kok masih ada yg kurang ya. 
setelah gw cari kemana2 akhirnya gw tau itu siapa. orang itu adalah kamu
",
"
 Jika waktu dapat berenti mengalirâ€¦ Aku berharap itu waktu kita sedang bahagia. 
Jika waktu harus mengalir pergiâ€¦ A
ku berharap kamu ga kan ngelupain aku. 
",
"
satu tambah satu sama dengan dua.. 
mau gak mau lo jadian sama guaâ€¦â€¦..
",
"

Lupa agama? ===> ooopsâ€¦ Neraka! 
Lupa orang tua? ===> ichâ€¦ Durhaka! 
Lupa sesama? ===> achâ€¦ Byasa! 
Tapi lupa ama kamu? ===> Ehmâ€¦ mana bisa! : ) 

",
"
Tadi malam aku kirim bidadari untuk menjaga tidurmu. 
Eh, dia buru-buru balik. 
Katanya, â€˜Ah, masa bidadari disuruh jaga bidadari?â€™ 
",
"
Kalau kamu nanya berapa kali kamu datang ke pikiranku, 
jujur aja, cuma sekali. 
abisnya, ga pergi2 sih! 
",
"
Sempet bingung jg, 
kok aku bisa senyum sendiri. 
Baru nyadar, aku lagi mikirin kamu. 
",
"
Berusaha melupakanmu, 
sama sulitnya dengan mengingat seseorang yang tak pernah kukenal.
",
"
Kalau kamu ajak aku melompat bareng, 
aku ngga bakalan mau. Mending aku lari ke bawah, bersiap menangkapmu. 
",
"
Aku pernah jatuhkan setetes air mata di selat Sunda. 
Di hari aku bisa menemukannya lagi, itulah waktunya aku berhenti mencintaimu. 
",
"
Ga usah janjiin bintang dan bulan untuk aku, 
cukup janjiin kamu bakal selalu bersamaku di bawah cahayanya.
",
"
Kalau amu nanya mana yg lebih penting buat aku: 
hidupku atau hidupmu, 
aku bakal jawab hidupku. 
Eits, jangan marah dulu, 
karena kamulah hidupku. 
",
"
Pertama ketemu, 
aku takut ngomong sama kamu. 
Pertama ngomong sama kamu, 
aku takut kalau nanti suka sama kamu. 
Udah suka, aku makin takut kalau jatuh cinta. 
Setelah sekarang cinta sama kamu, aku jadi bener2 takut kehilangan kamu. Kamu emang menakutkan! 
",
"
Jika aku bisa jadi bagian dari dirimu, 
aku mau jadi airmatamu, yang tersimpan di hatimu, 
lahir dari matamu, hidup di pipimu, dan mati di bibirmu 

",
"
Mo bilang sayang, 
takut dianggap gk taw malu. 
Mo bilangâ€¦CINTA, 
Tkt dh ada yg poenya. 
Terpaksa dech cm bs bilang lg ngapa?? 
",
"
Musim Terindah adalah â€¦.
Ketika kau nyalakan pagi dengan senyummu 
Ketika kau payungi siang dengan sapamu 
Ketika kau tutup malam dengan belai manjamu 
I luv uâ€¦
",
"
Prtmnan qt 
g seperti esia yg setia 1 jm 
Gk seperti baygon yg setia 8 jm N 
gk sprt pepsodent Yg setia 12 jam 
Prtmanan qt hrs spertiâ€¦? 
Rexona Yg setia setiap saat 
",
"
PERINGATAN PEMERINTAH: 
HATI2 THD SMUA UNGKAPAN CINTA DAN RAYUAN LEWAT SMS, 
KARENA SEMUANYA BOHONG. KECUALI SMS DARIKU????
",
"
Rayulah aku,dan aku mungkin tak mempercayaimu. 
Kritiklah aku, dan mungkin aku tak menyukaimu. 
Acuhkan aku, dan mungkin aku tak memaafkanmu. 
Semangatilah aku, dan mungkin aku tak kan melupakanmu(William Arthur) 
",
"
Inginku kirim BUNGA, 
takut ia kn LAYU, 
ingin ku kirim SENYUM, 
takut tak DIBALAS, 
ingin ku kirim RINDU, 
takut HASRAT tak ksmpaian. 
jadi, ku kurim DOA agr dirimu sht sllu..
",
"
Kata PETERPAN hidup itu butuh dengan SAHABAT. 
Biar kita tidak KESEPIAN kayak DIGTA, 
Dan juga kita jangan kayak RATU yang bisanya cuma nyari TTM, 
Kan kita sudah dibilangin ama RADJA,kita harus JUJUR, 
Biar tidak PUDAR seperti ROSSA, 
Makanya kita harus bisa cari CINTA YANG SEMPURNA layaknya KANGEN BAND.
",
"
MetroTV, CNN, detikcom, Bang Napi, Liputan 6, Antara, ESPN, WordPress News adalah berita basi 
kabar darimu lah yang selalu kunanti 
",
"
tau ga knapa malem ini ga ada bintang ?? 
soalnya bintangnya pindah semua ke matamuâ€¦

",
"
Ingetin aku buat bawa kacamata hitam kalo ketemu kamu yak. 
Abisnya pesonamu menyilaukanku siyâ€¦ 
",
"
 senyuman kamu tuh ibarat SUSU BENDERA nikmat nya hingga tetes terakhir sayaang :)
",
"
 kalo setiap saat ada kamu disebelah aku,bikin teh manis udh gak perlu pake gula.liat kamu juga tehnya udah manis 
",
"
'papa kamu nahkoda ya? | bukan. | Masa sih? kok rasanya aku pengen terus berlabuh dihatimu'
",
"
 Mungkin aku bukan obama,tapi aku seneng kamu manggil aku Oh sayang 
",
"
 bahkan lalu lintas Jakarta terhenti dan macet bila mengingat cintaku padamu 
",
"
 aku kesamber petir kok biasa aja yaa?cuma kalo udh kesamber getar2ran cinta dari kamu pasti hati aku langsung meleleh 
",
"
 Org laen kalo ping!Abang di bbm cuma bbny yg geter kalo kamu yg ping, Jiwa raga aku gempa bumi 
",
"
 walaupun malem sudah larut,tapi percayalah cinta kamu ke kamu tidak pernah surut sedikitpun 
",
"
 aku gak perlu ramalan cuaca BMKG walaupun mau ada ujan,badai,tsunami. aku akan tetap pertahaan cinta aku demi kamu 
",
"
 Manisnya martabak kacang-coklat ini tak semanis wajah dirimu 
",
"
 Izinkan aku menjadi webcam notebookmu, agar setiap saat aku bisa berhadapan memandang wajah cantikmu 
",
"
 aku mau cinta kita seperti pelajaran SEJARAH yg selalu dikenang sepanjang masa 
",
"
 kalo aku jd bunga, aku ingin jd bunga bank yg mengisi tabungan cintamu. 
",
"
'Kamu pawang kan ? Ayo jinakan aku dengan cambuk cintamu'
",
"
'Bapa Kamu yg jaga LP Cipinang ya ? Pantes kau penjarakan hatiku di hatimu'
",
"
 hai aku Tarzan. Tarzandung cintamu sampai jatuh 
",
"
 wiiih itu orang dari belakang masa kini bgt bodynya,cuma pas diliat dari depan, mukanya masa gini?  
",
"
 wajah kamu makin hari makin cantik bgt,cuma lebih cantik lagi kalo tuh muka di tutupin pake karung beras 
",
"
 Kamu mau kentut dimukaku juga gapapa, karena pasti aroma kentutmu itu aroma2 cinta 
",
"
 ariel peterpan boleh bikin lagu 'tak ada yg abadi' cuma itu tak berlaku buat cinta kita yg abadi selamanya sayaaang :)  
",
"
 Eh yg bikin salep firaun siapa sih? Aku mau minta dikit nih buat ngawetin cinta kita biar abadi selamanya sayang 
",
"
 Hidup sengsara di gubuk derita, asalkan berdua denganmu menjadi gubuk cinta 
",
"
 Cintaku padamu bagaikan kancut, jika tanpanya aku akan merasa aneh menjalani hari 
",
"
 Rasa cintaku bagaikan mencret diare, tak bisa kutahan tapi terus keluar begitu saja 
",
"
'Kau adalah musim semiku, ketika kau datang bunga-bunga bermekaran di lubuk hati'
",
"
 ketika kau menyuapinku ubi namun terasa pizza dimulutku, ini namanya bumbu cinta? 
",
"
 Oh angin, sampaikan rasa rinduku ini yang tak terucapkan padanya melalui dedaunan yang berbisik 
",
"
 Kok aku gemeteran ya? Ini gempa apa getaran hatiku yang merindukanmu sayaang :)
",
"
 kalo einstein bisa bikin rumus e=mc2 aku juga bisa bikin rumus dong yaitu kamu+aku= Cinta 
",
"
 Kalau kamarmu gelap jangan kuatir, cintaku akan meneranginya 
",
"
 gara2 mikirin kamu pas bikin bakso, baksonya jd ga ada yg bulat, bentuknya hati semua 
",
"
 Bersamamu disini,misteri jeruk purut pun terasa romansa jeruk peras 
",
"
 jika langit dan bumi menjadi gelap, setidaknya masih ada secerca pancaran sinar wajah cantikmu 
",
"
 kamu kaya cantengan deh yang lama hilang di hati aku 
",
"
 kalo si baim bisa buat buku harian aku juga gamau kalah aku juga mau bikin buku harian tentang perjalanan cinta kita 
",
"
 kamu kaya anjing ya selalu gonggong kalo hati ini ada orang lain yg menempati 
",
"
Saat merasakan sentuhan cinta, semua orang menjadi seorang penyair
",
"
Cinta adlh perasaan romantis dan menghiasi perasaan dg beberapa kata2 cinta yang terbaik dan kutipan romantis dpt memperkuat hubungan Anda
",
"
Aq kecanduan,aq depresi,hingga tak terkendali,tp hanya kamu yang dpat menyubg aq kmbli,sperti dlu lg
",
"
didalam hubngan sang pangeran tak kan hilang apabila dia menganggap sang putri sbgai bidadari.
",
"
kejam prpishn ini,tpi krn aq bgt cntaimu,aq relkn itu,krn cma itu salah satu cra terakhr aq melhatmu bhgia.
",
"
mengenal mu adalah hal yang terindah dalam hidup kku.
",
"
kita ga usah bbm-an yah, hati abg kan udh ada ama neng. Jd tgl telepati aja.
",
"
Bla ku hnya sesaat bgimu jgn biarkn ku trlanjur mnyayangimu, bla ku tak mmpu prgi drimu krna kau yg buat aku mnyayangimu.
",
"
Tak akan pernah tahu, kemana mata hati melangkah dan berpijak. Sosokmu hanya banyang semu di hati. Abadilah asa bersama mimpiku.
",
"
Ketika hidup memberiku seratus alasan untuk menangis, kau datang membawa seribu alasan untuk tersenyum.
",
"
Walau aku jauh memandang dirimu, bahkan tak tampak dirimu dengan jelas disana. Namun slalu dekat dihatiku, memang engkau tak pernah hadir dihadapku tapi engkau slalu dipikiranku setiap aku berpikir
",
"
Berusaha melupakanmu, sama sulitnya dengan mengingat seseorang yang tak pernah kukenal.
",
"
Saat malaikat menghampiriku dia bertanya padaku, apa yg kauinginkn hari ini? Aku menjawab, tolong jaga orang yg membaca sms ini. karena aku SAYANG DIA
",
"
Kalau kamu nanya berapa kali kamu datang ke pikiranku, jujur aja, cuma sekali. abisnya, ga pergi2 sih!
",
"
Jika kamu bisa mengitung seluruh ikan yang ada di laut, di tambah seluruh bintang yang ada dilangit, di tambah seluruh rumput yang ada di darat. ketahuilah itu adalah jumlah rasa Rindu ku terhadap dirimu.
",
"
Aku tak meminta untuk dipilih, tpi lbih kpada bgmn kamu bsa menyayangi ku memperthankan aku.
",
"
Tak mungkin ku bisa melupakanmu. Di manapun slalu terbayang kamu. I love U... 
",
"
Di dunia ini yg tak bisa dihitung itu jumlah bintang di langit , ikan di laut dan cintaku padamu.
",
"
  sayang..., coba lihat rembulan malam itu..! , begitu sangat indah... seindah tahi lalat didekat hidungmu..!  
",
"
  sungguh memang indahnya ciptaan sang tuhan!, sampai aku begitu sangat terpesona melihat garis senyum manismu sayang..,  
",
"
  haloo...hany.. kamu lagi ngapain..? , han... aku kangen banget....sama Jerawat kamu  
",
"
  Jalan ini terang...namun sepi, Bunga itu harum...namun layu, Bumi ini luas...namun terbatas, tanpa SMS darimu sayang.... 
",
"
  Andai saja detik waktu ini dapat aku hentikan.., aku pasti akan selalu berada disampingmu sayang...tanpa harus diusir sama babehmu..! 
",
"
- Dulu aku heran, napa orang sampe berantem ? hanya karena cinta. Trus aku inget muka kamu, dan tiba-tiba, aku merasa siap menghadapi Perang Dunia Ketiga.
",
"
- Kalau kamu nanya berapa kali kamu datang ke pikiranku, jujur aja, cuma sekali. abisnya, ga pergi2 sih!
",
"
- Orangtuamu pengrajin bantal yah? Karena terasa nyaman jika di dekatmu.
",
"
- Sekarang aku gendutan gak sih ? kamu tau gak kenapa ? soalnya km udah mengembangkan cinta yang banyak dihatiku
",
"
- Tau ga knapa malem ini ga ada bintang ?? soalnya bintangnya pindah semua ke matamu?
",
"
- Jangan GR deh. Aku kangen kamu sedikit aja kok. Sedikit berlebihan maksudnya.
",
"
Cowok: Maaf mbak, jangan terlalu lama duduk dikursi itu, pindah deket saya saja?
Cewek: Loh? Emangnya kenapa??
Cowok: Biar gak dikerubung semut.. soalnya mbak manis sich?
",
"
Cowok : Kemarin aku ke dokter mata. Kamu tau apa kata dokter?
Cewek : Apa? Parah?
Cowok : Kata dokter ada kamu di mataku.
",
"
Cowok : Kamu punya kunci apa aja sih?
Cewek : Kunci rumah, kunci mobil, kunci lemari. Emang ada apa?
Cowok : Punya nggak kunci untuk membuka hatimu kepadaku?
",
"
- Bapak kamu pasti seorang astronot ??? 
Soalnya aku melihat banyak bintang di matamu.
",
"
- Kamu pasti kuliah di seni pahat ya ??? 
Soalnya kamu pintar sekali memahat namamu di hatiku.
",
"
- Kamu Mantan pencuri ya ??? 
Abisnya kamu mencuri hatiku sih!
",
"
- Setiap malam aku berjalan-jalan di suatu tempat. 
Kamu tau di mana itu ? 
Di hatimu.
",
"
-Kamu pake Indosat ya ??? Karena sinyal-sinyal cintamu sangat kuat sampai ke hatiku.
",
"
MENGAGUMIMU ADALAH KEINDAHAN MATAKU, TAPI DAPAT MEMILIKIMU ADALAH KEINDAHAN HATIKU
",
"
Menunggu itu tidak terlalu buruk, 
ketika kamu telah mengetahui pasti apa yang kamu tunggu. 
Jangan Menunggu  Yang Tak Pasti
",
"
Tidak peduli seberapa sederhananya dan ketidakjelasan kamu. 
tapi bagi aku kamu adalah kesempurnaan yang memiliki kejelasan.
",
"
SESAKIT-SAKITNYA KAMI DIKHIANATI, 
MASIH BAGUS KARENA BUKAN KAMU YANG BERKHIANAT!

",
"
Dalam hati ada rindu,
dalam jiwa ada cinta.
sampai mati kan ku tunggu,
wanita yang berhati mulia...!!
",
"

8 huruf
3 kata
1 arti
Bwt km tercinta...
I LOVE YOU
",
"
Cinta tuch ibarat sepatu...
walau berbeda bentuk tpi saling melengkapi
jika di antara'a mehilang
maka pasangan'a_pun tidak akan ada arti'a...
",
"
Jariku mungkin tak slalu bisa menyentuhmu
mataku mungkin tak slalu bisa melihat dirimu
ragaku mungkin tak slalu bisa menemani dirimu
tapi yakinlah dihatiku HANYA ADA DIRIMU

",
"
Aku Bukan lah Bandara
Tempat Untuk Berlabu Sementara. . .
Aku Bukan Gudang
Tempat Menyimpan Barang RongSokan
Bukan Pula Restoran
Tempat Menghilangkan Haus Dahaga
Tapi aku Manusia Yang Punya Hati,
Aku Manusia Yang
Butuh Cinta Dan Kasih Sayang...!
",
"
Bintang memang indah tapi tak bisa aku miliki,,,
bulan juga indah tapi hanya bisa aku kagumi,,,
yang paling berharga & paling indah adalah bumi ini,,,
karena di bumi ini aku bisa mengenalmu

I always Love U
",
"
Jika q jadii air matta mu...
q kan lahir dari mata mu...
hidup di pipimu...
dan mati di bibir mu...
tapi ...
bila qm jadi air mata q...
q tak kan pernah menangis...
karna... q takut kehilangan mu !!

",
"
Kupu2 berwarna ungu..
hinggap di pohon jambu...
kalo aq bilang I LOVE U 
gimana jawabmu???
",
"
buah mangis hitam warnanya,
kalo di kupas putih isinya..
salam maniz buat mertua 
karena aku suka anaknya...
",
"

Cinta yang suci dapat dilihat dari pengorbanan seseorang, 
bukanlah dari pemberian semata.

",
"
Cinta tidak selalu bersama jodoh, tapi jodoh selalu bersama cinta.
",
"
Jangan sebut cintaâ€¦
Sebelum tetes terakhirnya telah juga meresap ke jiwa
Lalu setiap ucapan dan tindakan yang tercipta
Selalu berlandaskan atasnya
",
"
Ketika matahari mulai tenggelam &
bergnti mlm kerinduan pun smkin mendalam,
teringat so2k wjh cantik yg di ikuti senyuman mnisy.
q tu2p mta q perlahan ku rskn hmbsan angin mlm di saat itulah q rsakn kerinduan yg men dalam &
di dlm keheningan q bertanya pd sang rembulan,,,
kpn diri ni kn di pertemukan?????
",
"
Orang bilang Venus adalah planet yang tercantik,
Yang lain bilang Saturnus yang terindah,
menurut aku, tuhan ciptakan bumi jauh lebih indah daripada Venus dan Saturnus,
Karena di sana ada kamu....
",
"

.kata mama : CINTA itu sperti BUNGA yg indah..
.kata papa : CINTA itu sperti KOPI & GULA yg saling mengisi..
.kata kakak : CINTA itu sperti TALI yg apabila putus dpat di sambung lagi..
.kata adek :CINTA itu hanyalah sebuah PERMAINAN..
.namun menurutku :CINTA itu sbuah anugerah dari TUHAN yg tak bisa terpisahkan...
",
"

Ku ingin selalu membuka mata karena ku tau ada yang selalu menunggu ku...
ku selalu ingin tertawa, karena ku tau ada yg selalu rindu akan tawa ku...
ku selalu ingin melangkahkan kaki ku, karena kutau doamu selalu mengiringi langkah ku...
walau kini kau jauh, ku tau kau selalu ada untuk ku....
",
"

#>>>>>>@<<<<<<#

Kukunci hati ini.. Dengan sebuah kesetiaan Tak pernah sekalipun kucoba tuk hadirkan cinta yg lain.
 Walau qm jauh dariku Hari-hariku sarat dgn doa Semoga rindu kita berdua utuh tak terbagi selamanya... 
AMMIIEENNNNN

#>>>>>>>@<<<<<#

",
"

Bila pacar qm lari kesurga kejarlah dgn amal baik... 
bila pacarmu lari ke laut kejarlah dgn perahu... 
tp bila pcar qm lari ke pelukan laki laki lain, 
SAMPLUK'EN DHASE NDAK TUMAN...
",
"

Keindahan itu adalah kamu... 
dimana begitu banyak warnamu yg sudah tergurat dlm kanvas hidupku... 
terbingkai dg ukuiran cinta & rindu... 
yg sedetikpun aku tak ingin melepaskan pandanganku... 
darimu.

",
"
Biarknlah  CINTA  tumbuh di dlm  HATI  
jangan biarkan  CINTA  itu layu di dalam  DIRI  
coz cinta adalah sumber kehidupan yang   ABADI  
dan gak kan pernah  MATI  ampe denyut nadi  BERHENTI ...

",
"
Aku belajar sabar dari sebuah kemarahan,
Aku belajar mengalah dari sebuah keegoisan,
Aku belajar tegar dari kehilangan :')
sepi bukan berarti hilang, diam bukan berarti lupa,
Jika kamu tidak punya waktu untukku, aku akan mengerti...
Jika kamu belum bisa lepas darinya, aku akan mengerti...
Tetapi jika suatu hari nanti aku berhenti mencintaimu, itulah giliranmu untuk mengerti.
",
"
When you're important to someone, 
they will always find a way to make time for you. 
No excuses, no lies, and no broken promises.
",
"
Senyum tak selalu berarti  Aku bahagia  . 
Terkadang..  Aku bisa mengatasinya . 
Dalam banyak hal:  aku lelah menangis .
",
"
Eh Nona, kalo cantik kira-kira dong! 
Klo saya naksir nona gimana? 
Apa mau tanggung jawab?
",
"
Aku mencintaimu! 
Jika kamu benci aku, 
panah saja diriku. 
Tapi jangan di hatiku ya, 
karena di situ kamu berada.
",
"
â€œKata dokter, 
berat otakku nambah. 
gimana gak nambah, 
kamu nangkring terus disituâ€
",
"

â€œKalo Indonesia punya dasar PANCASILA, 
kamu itu PANCA-RAN HATIKU!â€
",
"
â€œCintaku padamu lebih PAMUNGKAS ketimbang BAMBANG!â€
",
"
â€œSetiap aku ketemu kamu, 
ku selalu butuh injury time deh. 
Ga pernah cukup sih waktunya.â€
",
"
â€œOrang2 pada takjub liat panjangnya tembok Cina, 
padahal kan lebih panjang tembok Cinta kitaâ€
",
"
â€œKalo neng jadi nasi, 
abang mau jadi rice cookernya ah, 
biar bisa selalu menghangantkan neng.â€
",
"
â€œKalau jatuhnya bulu mata nandain ada yg kangen,
aku yakin punyamu rontok semua.â€
",
"
â€œBiarpun dunia lagi demam bola, 
cuma bola mata kamu yang bisa bikin aku demam.â€

",
"
â€œDidepanku ada kamu. 
Seketika detakku bergaya samba, 
hatiku tergocek, 
waktu kau giring bola mataku kesegala arah.â€
",
"
â€œKalo kamu ibarat bola yg diperebutkan pria, 
maka aku gawangnya. 
Selalu kepadakulah kamu kan datangâ€
",
"
â€œkamu juara lomba layangan nasional ya? 
Pantes paling pinter narik ulur perasaankuâ€
",
"
â€œDICARI: Programmer, 
buat nge-program ulang otak aku supaya gak kamuuuu terus isinya.â€
",
"
â€œNeng, GODA-GODA 1 porsi. 
Di sini adanya GADO-GADO bang.. 
Ooh, maaf neng, 
liat eneng abang jadi terGODA siihâ€
",
"
â€œâ€maaf sepertinya saya lihat sesuatu deh di mata anda..â€ 
â€œapa?â€
 â€œmasa depan saya.â€ 
",
"
â€œMinyak apa yang dicari orang? 
Minyaksikan kamu tersenyum.â€
",
"
â€œKamu bisa baca pikiran aku ga? 
Gampang sih, NGACA aja, itu yg ada di PIKIRANKUâ€
",
"
â€œanjing menggonggong, kafilah berlalu. 
Neng, boleh dong, kalo abang mikirin eneng selalu?â€
",
"
â€œKalo cintaku ke kamu bisa diuangin, 
jangankan century, utang negara pasti aku bayarin!â€
",
"
â€œEh aku lupa bilang pas di-sensus kemarin, 
di hatiku ada kamu. Masuk itungan mereka gak ya?â€
",
"
â€œKenapa Superman pake kolornya diluar? 
Soalnya dia buru-buru pengen ketemu kamu.â€
",
"
â€œwaktu foto kamu aku pajang d kamar,
poster miyabi jadi mirip mpok atiâ€
",
"
â€œSejak kamu hadir di dekatku,
semua produk LG ada di hidupku. 
Life's Good !!! â€",
);
?>
