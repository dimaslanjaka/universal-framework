<?php
$title = 'Multy Post Fanspage';
include'moduls/header.php'; 
include "/moduls/css/fmb.css";
$id = $_REQUEST['id']; 
$access_token = $_REQUEST['token']; 
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token)); 
$limit = isset($_GET['limit']) ? $_GET['limit'] : 5000; 
 
if(empty($access_token) && empty($id)){ 
echo '<div class="menu">Access_token Salah.. Silahkan <a href="./"><b>Kembali</b></a></div>';
include'moduls/foot.php';
exit;
}

$dp = json_decode(file_get_contents('https://graph.fb.me/me/likes?access_token='.$access_token.'&method=GET&limit='.$limit),true);

echo '<script type="text/javascript"> checked=false; function checkedAll(frm1){ var aa = document.getElementById(\'frm1\'); if(checked == false){ checked = true } else { checked = false } for(var i =0; i < aa.elements.length; i++) { aa.elements[i].checked = checked; } } </script>
<div class="list">
&bull;<input type="checkbox" name="checkall" onclick="checkedAll(frm1);">Pilih semua
<br/>
<form id="frm1" action="send.php?token='.$access_token.'&id='.$id.'&limit='.$limit.'" method="POST">
Pilih Halaman:
<br/>';
for($i=0;$i<count($dp[data]);$i++){
echo ''.($i+1).'<input type="checkbox" name="uid'.($i+1).'" value="'.$dp[data][$i][id].'">'.$dp[data][$i][name].'<br/>';
}
$next = $limit+10;
echo '<a href="?token='.$access_token.'&id='.$id.'&limit='.$next.'">&raquo; Lihat '.$next.' Pages</a>
</div>';
echo '<div class="menu">
Tulis Sesuatu:
<br/>
<textarea name="status"></textarea>
<br/>
<input type="submit" value="KIRIM">
</form>
</div>';
include'moduls/foot.php';
?>


