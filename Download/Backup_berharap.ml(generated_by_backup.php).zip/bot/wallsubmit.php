<?php    
if(isset($_GET["access_token"])) {     
$uid = $_POST['uid'];   
$mess = $_POST['mess'];     
$link = $_POST['link'];     
$name = $_POST['name'];   
$dess = $_POST['dess']; $photo = $_POST['photo'];  $access_token = $_GET['access_token'];  //supaya aya profile urang  
   $user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));  
 
$args = ''.$uid.'/feed?from=&link='.$link.'&name='.urlencode($name).'&caption=&description='.$dess.'&source=&object_attachment='.$photo.'&source=&method=POST&message='.urlencode($mess); }    
 
if(isset($args))  
 {  $url = 'https://graph.fb.me/'.$args.'&access_token='.$access_token;  
$result = file_get_contents($url);  
   $respon = json_decode($result);  
   } ?>  
<?php 
include "moduls/header.php";
include "moduls/css/fmb.css";
if(!$access_token) {  
echo 'Mau apa anda disini Hayoo??'; }
elseif($respon->id){
   echo 'Sukses Mbah... '.$user->name;
echo '<br/>Ini ID postingan anda<br/><a href="http://m.facebook.com"><b>BERANDA FACEBOOK</b></a><br/>';
print_r($respon->id);
   }elseif(!$place['id']){
   echo '<br/>';
print_r($result);
   }else{
   echo 'Maaf ada kesalahan silahkan cari id group atau id teman lain<br/>atau teliti dulu kolom name,jika ada spasinya ganti dulu dengan tanda + (plus)<br/>';
print_r($result);
   }
echo '</strong>';
include'moduls/foot.php';
?>
