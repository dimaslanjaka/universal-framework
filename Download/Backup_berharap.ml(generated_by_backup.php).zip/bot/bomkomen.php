<?php
$title='Bom Komen';
$access_token = $_REQUEST['access_token'];
$id = $_REQUEST['id'];
$komentar = $_REQUEST['komentar'];
$next = $_REQUEST['next'];
include "/moduls/css/fmb.css";
include'moduls/header.php';
if(empty($access_token)){
echo'access_token Salah Boss';

include'moduls/foot.php';
exit;
}

$stat = json_decode(file_get_contents('https://graph.fb.me/'.$id.'/comments?access_token='.$access_token.'fields=id,from&limit=1'),true);

if(empty($next)){
echo''.$stat[data][message].'<div class="clip"><form action="" method="GET"><input type="hidden" name="access_token" value="'.$access_token.'">ID Status Yg Anda Pilih tadi :<br><input type="text" class="list1" name="id" value="'.$id.'">
<br>
Komentarmu :<br/><textarea class="clip" cols="15" rows="3" name="komentar"></textarea><br/>Jumlah Bom Komentarmu:<br/><select name="next">';
for($i=1;$i<500;$i++){
echo'<option value="'.$i.'">'.$i.'</option>';
}
echo'</select><br/>Usahakan 10 atau 20 saja, jika kebanyakan bisa di blokir oleh pihak facebook<br/><input class="header" type="submit" value="HAJAR BOSS..!!"></form></div>';
}
for($i=0;$i<$next;$i++){
echo $i. 'cek <a href="http://www.facebook.com">Beranda</a> atau <a href="bomkom.php?token='.$access_token.'">Kembali Bom lagi</a><br><iframe type="hidden" src="https://graph.fb.me/'.$id.'/comments?method=POST&message='.$komentar.' '.$i.'&access_token='.$access_token.'"></iframe><br>';
}
include'moduls/foot.php';
?>