<?php  
$title = 'Cari ID Teman';
include "/moduls/css/fmb.css";
$access_token = $_GET['access_token'];
$objek = $_POST['objek'];
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
 //pencarian teman    
$link = "https://graph.fb.me/me/".$objek."?access_token=".$access_token;    
$result = file_get_contents($link);    
$json = json_decode($result);    
$friends = array();    
$friends_id = array();    
$data = $json->data;    
if($data!="") {    
$i = 0;
foreach($json->data as &$friend) {
$friends[$i] = $friend->name;
$friends_id[$i] = $friend->id;
$i += 1;
} }    
?>
<?php include'moduls/header.php'; ?>
<?php    
if (!$access_token){
echo'access_token Bosok...'; 
} else { ?>
<div class="menu"><center>
Untuk mencari id teman dan untuk nge tag nama teman distatus atau dikomentar tinggal klik cari id,copy id teman yang diinginkan lalu tinggal tempel distatus/koment<br><form action="<?php $PHP_SELF ?>" method="POST">    
 <input name="objek" type="hidden" value="friends">
<input type="submit" value="Cari ID Teman"/>    
 </form><br/></center>    
<left><?php    
if(isset($objek)){ ?>    
<?php 
foreach($json->data as &$friend) {
echo '<font color="red">'.$friend->name.' :<br><input type="text"  value="@['.$friend->id.':0],"><br>'; 
}} 
?> 
</left></div>
<?php } ?>
<?php include'moduls/foot.php'; ?>
