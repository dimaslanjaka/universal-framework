<?php
$title= 'Status Style';
$access_token = $_GET['access_token'];
//supaya aya profile urang
   $user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
?>
<?php include'moduls/header.php';
include "moduls/css/fmb.css"; ?>
<?php    
if (!$access_token){
echo 'access tokenmu bosok mbah... Wkwkwk....'; 
} else { ?>
<div class="menu">
<script type="text/javascript" src="status.js"></script>
<form name="idienz">   
<li>Tulis status :</li> 
<textarea class="menu" name="message" cols="15" row="3"></textarea>
<li>Link:</li>
<input type="text" class="list1" name="link" value="http://kreasiku.7uw.net">
<li>Name/Style :</li>

<textarea name="name" class="list1" cols="15" row="3"></textarea>
<li>Tulisan Abu-abu :</li>

(bisa dikosongkan)<br>
<input class="list2" name="dess" type="text" value=""/>
<li>Sisipkan Photo Masukan ID photo kamu :</li>
<li>Contoh m.facebook.com/photos.php?fbid=<font color="red">11215432</font></li>
<li>yang merah itu id photo :</li>
(bisa dikosongkan)<br>
<input name="photo" class="list2" type="text" value=""/><br>
<input type="hidden" name="token" value="<?php echo $access_token; ?>">
<input style="background:#3b5998;border-color:#8a9ac5 #29447E #1a356e;color:#ffffff;width:70px" name="calculate" type="button" value="UPDATE" onclick="cal()"><input type="hidden" name="output" value="">
</form>
</div>
<?php } ?>
<?php include'moduls/foot.php'; ?>
</body>
</html>
