<?
if (isset($_POST['token']))
{
echo'<meta http-equiv="Refresh" content="0; URL='.$_POST['token'].'"/>
';
exit;
}
echo '<center><div class="menu"><font color="red"><div class="mainzag"><b>Klik Link Dibawah untuk :</b></font></div> 
<a href="http://goo.gl/PXi341">Get Permission Access</a> | <a href="http://goo.gl/fGpUro">Get token Here</a>
</center></div>';
?>