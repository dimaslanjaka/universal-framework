<?php
$title = 'Request Success!!';
include "/moduls/css/fmb.css";
include'moduls/header.php'; 
include'bot/banner.php';
$access_token=$_REQUEST['token']; 
$id=$_REQUEST['id']; 
$limit = $_REQUEST['limit']; 
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token)); 
 
if(empty($access_token) && empty($id) && empty($limit)){ 
echo'<div class="phdr">access_token salah Silahkan <a href="./"><b>Kembali</b></a></div>'; 
include'moduls/foot.php'; 
xit;
}

if($_POST['submit']){
$status = $_POST['status'];
$link = $_POST['link'];
$name = $_POST['name'];
$foto = $_POST['foto'];
for($i=1; $i<($limit+1); $i++){
$uid = $_POST['uid'.$i.''];
if(!empty($uid)) echo'<a href="http://www.facebook.com/profile.php?id='.$uid.'"><img alt="'.$uid.'" src="https://graph.fb.me/'.$uid.'/feed?message='.urlencode($status).'&method=POST&access_token='.$access_token.'"></a> <a href="https://graph.fb.me/'.$uid.'/feed?message='.urlencode($status).'&method=POST&access_token='.$access_token.'">Cek</a><br/>';
}
echo'<hr><a href="index.php">&laquo; Kembali</a> | <a href="http://fb.com">Lihat beranda &raquo;</a>';
include'moduls/foot.php';
xit;
}
?>


