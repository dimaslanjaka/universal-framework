<?php
$token = $_GET['token'];
session_start();
if(!empty($token)){
$_SESSION['timeout'] = time();
$_SESSION['token'] = $token;
header('Location: home.php');
}
else
{
header('Location: /error.php');
}
?>