<?php
$access_token = $_GET['access_token'];
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
$title='Upload Photo Facebook';
      $album = "https://graph.fb.me/me/albums?access_token=".$access_token;
      $result = file_get_contents($album);
      $json = json_decode($result);
      $albums = array();
      $albums_id = array();
      $data = $json->data;
      if($data!="") {
         $i = 0;
         foreach($json->data as &$album) {
            $albums[$i] = $album->name;
            $albums_id[$i] = $album->id;
            $i += 1;
         }
      }
?>
<?php include'moduls/header.php';
include "/moduls/css/fmb.css"; ?>
<?php    
if (!$access_token){
echo 'Access Tokenmu Busuk sob... Wkwkwk... :v'; 
} else { ?>
<div class="clip"><div class="list1">Silahkan isi Form di bawah ini</div>
            <form action="photoup.php?code=<?php echo $access_token; ?>" enctype="multipart/form-data" method="post">
<div class="list2">Pilih File Gambar :</div>
               <input type="file" name="image" style="width:110px"/><br/>
<div class="list2">Pilih Album Anda :</div>
               <select name="album" style="width:110px">
               <?php
                 $k = 0;
                 foreach($albums as &$i) {
                  echo '<option value="'.$albums_id[$k].'">'.$i.'</option>';
                  $k += 1;
                 }
                 if($k > 0) {
                  echo '<option value="me">'.'No Albums'.'</option>';
                 }
               ?>
               </select><br/>
<div class="list2">Tulis Pesan Anda :</div>
               <input type="text" name="caption" value="" style="width:110px"/><br/>
               <input type="submit" value="Upload"/><br/>
            </form>
</div>
</div>
<?php } ?>
<?php include'moduls/foot.php'; ?>
</body>
</html>