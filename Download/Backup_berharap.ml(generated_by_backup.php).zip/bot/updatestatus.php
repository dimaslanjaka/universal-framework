<?php
$title = 'Update Status Success';
include 'moduls/header.php';
include "moduls/css/fmb.css";
include 'bot/banner.php';
echo '<div style="display:none">';
$access_token = $_POST["token"];
$url = "https://graph.beta.facebook.com/me/feed?method=POST";

$st = $_POST["wall"];

$status =($st.$banner);
$ch = curl_init();
$attachment =  array(   'access_token'  => $access_token,
'message'          => $status,
);

curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $attachment);
$result= curl_exec($ch);

curl_close ($ch);
echo "</div><div class='main'><font color='green'>status berhasil di buat..!!<br>silahkan klik <b>BACK</b> untuk kembali ke menu utama</div>";
?>

<div class="menu" align="center">
<form method="post" action="home.php">
<input type="submit" value="BACK"/>
<input name="access_token" value="<?php echo $_POST[token];?>" type="hidden"/>
</form>
<FORM>
</font></div>
<?php include 'moduls/foot.php';?>
