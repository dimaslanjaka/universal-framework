<?php
$title = 'Multy Post Grup';
include "moduls/css/fmb.css";
include'moduls/header.php'; 
$id = $_REQUEST['id']; 
$access_token = $_REQUEST['token']; 
$user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token)); 
$limit = isset($_GET['limit']) ? $_GET['limit'] : 200; 
 
if(empty($access_token) && empty($id)){ 
echo'<div class="menu">access_token salah... Silahkan <a href="./"><b>Kembali</b></a></div>'; 
include'moduls/foot.php';
exit;
}

$dg = json_decode(file_get_contents('https://graph.fb.me/me/groups?access_token='.$access_token.'&method=GET&limit='.$limit),true);

echo '<script type="text/javascript"> checked=false; function checkedAll(frm1){ var aa = document.getElementById("frm1"); if(checked == false){ checked = true } else { checked = false } for(var i =0; i < aa.elements.length; i++) { aa.elements[i].checked = checked; } } </script>
<div class="list">
&bull;<input type="checkbox" name="checkall" onclick="checkedAll(frm1);">Pilih semua
<br/>
<form id="frm1" action="send.php?token='.$access_token.'&id='.$id.'&limit='.$limit.'" method="POST">
Pilih Grup:
<br/>';
for($i=0;$i<count($dg[data]);$i++){
echo ''.($i+1).'<input type="checkbox" name="uid'.($i+1).'" value="'.$dg[data][$i][id].'">'.$dg[data][$i][name].'<br/>';
}
$next = $limit+10;
echo '<a href="?token='.$access_token.'&id='.$id.'&limit='.$next.'">&raquo; Lihat '.$next.' grup</a>
</div>';
echo '<div class="menu">
Tulis sesuatu:
<br/>
<textarea name="status"></textarea>
<br/>
<input type="submit" name="submit" value="KIRIM">
</form>
</div>';
include'moduls/foot.php';
?>


