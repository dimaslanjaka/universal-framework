<?php
$dev[1] = 'muhamad.arifin.52';
$dev[2] = 'subhanz.ashof';
$dev[3] = 'jejaksitamvan';
?>


<center>
</div><div class="mainzag"> Subscribe Developers Website Kami </div> 
<div class="main"align="center"><table width="100%"><tr>
<td>
 <a href="http://m.facebook.com/<?php echo $dev[1];?>"><img src="https://graph.facebook.com/<?php echo $dev[1];?>/picture?type=normal" width="50" height="60"/> </a><br/><iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F<?php echo $dev[1];?>&layout=box_count&show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:46px;" allowTransparency="true"></iframe></td>
<td>
 <a href="http://m.facebook.com/<?php echo $dev[2];?>"><img src="https://graph.facebook.com/<?php echo $dev[2];?>/picture?type=normal" width="50" height="60"/> </a><br/><iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F<?php echo $dev[2];?>&layout=box_count&show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:46px;" allowTransparency="true"></iframe></td><td>
 <a href="http://m.facebook.com/<?php echo $dev[3];?>"><img src="https://graph.facebook.com/<?php echo $dev[3];?>/picture?type=normal" width="50" height="60"/> </a><br/><iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F<?php echo $dev[3];?>&layout=box_count&show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:46px;" allowTransparency="true"></iframe></td></tr></table><br><iframe src="http://www.facebook.com/plugins/like.php?href=http://m.facebook.com/Cyber.Mer4h.Putih&amp;layout=button_count&amp;show_faces=false&amp;width=100&amp;action=like&amp;font&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe></div></div></center>