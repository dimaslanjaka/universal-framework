<?php
echo '<title>CPU Status</title>';
$cpu = sys_getloadavg();
echo '<div align="right">Cpu: '.$cpu[0].'%</div>'; 
echo'</div>';
?>