<?php
echo'<div class="menu" align="center"><div class="quote"><br><iframe src="http://www.facebook.com/plugins/like.php?href=http://m.facebook.com/Cyber.Mer4h.Putih&amp;layout=button_count&amp;show_faces=false&amp;width=100&amp;action=like&amp;font&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100px; height:21px;" allowTransparency="true"></iframe><br/><script type="text/javascript" src="http://click.buzzcity.net/click.php?partnerid=147737"></script></div></div>';
echo '<b><div class="mainzag" align="center"><script src="http://click.buzzcity.net/click.php?partnerid=147737" />
</script>
</div><div class="menu"><center><b>SHARE ON</b><br /><a href="http://facebook.com/sharer.php?u=http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'"><img src="http://animesubs-indo.heck.in/files/facebook.png" width="80" height="50" alt="Facebook"/></a> <a href="http://mobile.twitter.com/home?status=http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'"><img src="http://animesubs-indo.heck.in/files/twitter.png" width="80" height="50" alt="Twitter"/></a> <a href="https://plus.google.com/share?url=http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'"><img src="http://animesubs-indo.heck.in/files/google-plus.png" width="80" height="50" alt="Google+"></a><br />';
list($msec,$sec)=explode(chr(3),microtime());
echo 'Speed: '.round(($sec + $msec) - $conf['headtime'], 3).' Sec</div>'; include'iklan.php';
 echo'</div><div class="footer"><center><a href="http://www.anihanzsub.net/">Anihanzsub.net</a> &copy; '.date('Y').' <br/>
All Rights Reserved
</center></div></body></html>';
?>
