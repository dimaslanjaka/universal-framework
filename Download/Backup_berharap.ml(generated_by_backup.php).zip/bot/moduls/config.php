<?php
$site = 'www.anihanzsub.net';
$buzzban = array(
'<a href="http://click.buzzcity.net/click.php?partnerid=147737"><img src="http://ads.buzzcity.net/show.php?partnerid=147737" alt="Click Here!"/></a>',
'<a href="http://click.buzzcity.net/click.php?partnerid=147737&bn=2"><img src="http://ads.buzzcity.net/show.php?partnerid=147737&bn=2" alt="Click Here!"/></a>',
'<a href="http://click.buzzcity.net/click.php?partnerid=147737&bn=3"><img src="http://ads.buzzcity.net/show.php?partnerid=147737&bn=3" alt="Click Here!"/></a>',);
$buzztam = array_rand($buzzban);
$buzzban = $buzzban[$buzztam];
?>