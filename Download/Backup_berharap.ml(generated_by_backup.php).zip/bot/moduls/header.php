<?php
include 'config.php';
include 'cpu_limit.php';
error_reporting(0);
session_start();

echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>
<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.0//EN\" \"http://www.wapforum.org/DTD/xhtml-mobile10.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\">
<head>
<title>$title - Cyber Merah Putih</title>
<meta name=\"description\" content=\"Auto Like, Auto Like Beranda, Bot Facebook, Bot Fb, Bot Cron, Multy Post, Update Status, Status Via, Kreasi Facebook, Graph Api Facebook, Graph Facebook, Script Php, Anihanzsub,\" />
<meta name=\"author\" content=\"Anihanzsub.net\" />
<meta name=\"keywords\" content=\"Auto Like, Auto Like Beranda, Bot Facebook, Bot Fb, Bot Cron, Multy Post, Update Status, Status Via, Kreasi Facebook, Graph Api Facebook, Graph Facebook, Script Php, Anihanzsub, CMP, google, youtbe, facebook,\" />
<link rel=\"shortcut icon\" href=\"http://fb.com/favicon.ico\"><link rel=\"stylesheet\" href=\"http://animesubs-indo.heck.in/files/mobile.css\" type=\"text/css\"></style>
</head><body>";
echo"<div class=\"menu\" align=\"center\"><a href=\"/\"><img src='http://animesubs-indo.heck.in/files/alucard.jpg' width='300' height='150'></a><br/>";
$cpu = sys_getloadavg();
echo '<div align="right">Cpu: '.$cpu[0].'%</div>'; 
echo'</div><table class="post"><td class="footer"><center/><a href="/">Home</a></td><td class="menu"><center/><a href="http://www.anihanzsub.net">Download</a></td><td class="footer"><center/><a href="#">Menu</td></table></div>';
echo"<div class=\"title\"><center><b>$title</b></center></div>";

if(!isset($access_token)){

if(isset($_GET["ref"])){
$ref = $_GET["ref"];
echo'<div class="mainzag" align="center"> Subscribe Admin </div> 
<div class="main"align="center"><a href="http://m.facebook.com/'.$ref.'"><img src="https://graph.facebook.com/'.$ref.'/picture?type=normal" width="50" height="60"/> </a><br/><iframe align="center" src="//www.facebook.com/plugins/subscribe.php?href=https%3A%2F%2Fwww.facebook.com%2F'.$ref.'&layout=box_count&show_faces=false&colorscheme=light&font&width=75&appId=231341246993923" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:52px; height:46px;" allowTransparency="true"></iframe></div></div>';
}else{

include 'opendev.php';

}}else{   echo '<div
class="main" align="center"><img src="http://graph.facebook.com/'.$user->id.'/picture?" width="75" height="75"></div></div><div class="main">Hai <font color="red">'.$user->first_name.'  </font>';
include'ucapan.php';
echo '<br/> Nama : <b>'.$user->name.'</b><br> ID : <b>'.$user->id.'</b><br> Username : <b>'.$user->username.'</b><br> Lahir : <b>'.$user->birthday.'</b><br><div align="right"><a href="/out.php">[Log Out]</a></div></div></div>';
} 
include'iklan.php';
?>
