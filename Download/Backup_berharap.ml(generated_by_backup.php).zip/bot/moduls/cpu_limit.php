<?php
//Cek CPU Load
$load = sys_getloadavg();
$limit =100;
if ($load[0] >= $limit) {
header('HTTP/1.1 503 Too busy, Try again Later');
die('<center><h2>Mohon Maaf,, Server kami sedang Overload. Jadi Silahkan datang Beberapa waktu Lagi.</h2><br/><a href="http://www.anihanzsub.net">Anihanzsub.net&trade;</a> &copy; 2014-2016.</center>');
}
?>