<?php
$title = 'Bot Clients'; include'moduls/header.php'; ?>
</div>
<div class="menu"align="center">
<br/>
<form action="login.php" method="GET"> Masukkan Token Anda : <input type="text" name="token"> 
<br>
<input value="Masuk" type="submit" class="header" size="0" />
</form>
<br>
</div>
<?php  include 'token.php';  ?> </center> </div> </div>

<?php include'moduls/foot.php'; ?>