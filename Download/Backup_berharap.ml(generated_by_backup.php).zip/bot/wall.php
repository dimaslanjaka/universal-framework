<?php 
$title= 'Post To Friends,fanspage, Group';
$objek = $_POST['objek'];   
$access_token = $_GET['access_token'];
//supaya aya profile urang
   $user = json_decode(file_get_contents('https://graph.fb.me/me?access_token='.$access_token));
$link = "https://graph.fb.me/me/".$objek."?access_token=".$access_token;   
      $result = file_get_contents($link);   
         
      $json = json_decode($result);   
   
      $friends = array();   
      $friends_id = array();   
      $data = $json->data;   
      if($data!="") {   
         $i = 0;   
         foreach($json->data as &$friend) {   
            $friends[$i] = $friend->name;   
            $friends_id[$i] = $friend->id;   
            $i += 1;   
         }   
      }   
?>   
<html>
<body>
<?php include'moduls/header.php';
include "moduls/css/fmb.css"; ?>

<?php    
if (!$access_token){
echo 'access tokenmu bosok mbah... Wkwkwk...'; 
} else { ?>
<div class="list1">  
<li>Untuk update status sendiri langsung isi form di bawah</li>   
<li>Untuk kirim ke teman, grup, fans page. Silahkan klik Load terlebih dahulu</li> <form action="<?php $PHP_SELF ?>" method="POST">   
 <select name="objek" style="width:110px">   
 <option value="groups">Grup</option>   
 <option value="friends">Teman</option>   
 <option value="accounts">Halaman/Aplikasi</option>   
 </select><br/>   
 <input type="submit" value="Load" class="tmn"/>   
<hr>
 </form>
<form action="wallsubmit.php?access_token=<?php echo $access_token; ?>" enctype="multipart/form-data" method="POST">   
<?php   
if(isset($objek)){ ?>   
<li>Pilih Teman,Grup,atau FansPage :</li>   
<select name="uid" style="width:110px">
<?php
$k = 0;
foreach($friends as &$i) {
echo '<option value="'.$friends_id[$k].'">'.$i.'</option>'; 
$k += 1;
}
?>
 </select>
 <?php }else{ ?>  
<li>Isi form di bawah</li>
<?php } ?>
<li>Tulis Pesan :</li> 
 <textarea name="mess" class="list1" type="text" style="width:120px"></textarea>
<li>Link:</li>
<input class="list1" type="text" name="link" value="http://baretyas.xtgem.com">
<li>Name :</li> 
<textarea name="name" class="list2" type="text" style="width:120px"></textarea>
<li>Tulisan Abu-abu :</li>
               <input name="dess" type="text" class="list1" value=""/>
<li>Sisipkan Photo Masukan ID photo kamu :</li>
<li>Contoh m.facebook.com/photos.php?fbid=<font color="red">11215432</font></li>
<li>yang merah itu id photo :</li>
               <input name="photo" class="list2" type="text" value=""/><br>
<input type="submit" class="tmn" value="Kirim"/>
</form>
<br/></div>
<?php } ?>
<?php include'moduls/foot.php'; ?>
</body>
</html>