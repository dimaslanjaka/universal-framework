Saya ucapkan terimakasih telah Mendownload dan Menggunakan SC saya ini..
Script bot ini telah saya Re-design dan Modified by: Subhan-kun

Feature Bot:
[-] Bot Auto Like Beranda.
[-] Bot Auto Comment.
[-] Bot Like commentar.
[-] Bot Auto Respon Like.
[-] Multy post (Friend, Groups, Halaman/Fanspage)
[-] Bot bom commentar.
[-] Auto Respon Ultah. (new)
[-] Bot Emoticons.
[-] Bot Motivasi.
[-] Bot Auto colek teman.
[-] Bot Konyol.
[-] Bot Simple (Bikin Baper) :V
[-] Bot comment post sendiri.
[-] Bot Respon status.
[-] Dan masih banyak yang Lainnya.

[!] Cara pakai setelah anda edit sebelum nya. Perlu di ingat!! Jgn kalian ubah file yg bernama token.php!
1. Sediakan hosting anda, terserah mau yg berbayar ato yg gratis.
saya sendiri pakai gratis dgn server idhostinger, knp gratis? karena SC ini 100% sdh saya Fixed
agar tidak mudah ke detect Phising/Spam/Flood/Bot di server hosting yg gratis.
2. Upload ke hosting kalian di public_html
3. Extract file bot ini.
4. Setelah extract file nya, kalian buka web url bot kalian.
5. Klik Get permission access (Untuk mengizinkan aplikasi HTC aktif dlm profile kalian)
6. Setelah klik get permission access dan di izinkan, selanjut nya klik Get token.
7. Setelah dpt token HTC debugger nya, kalian paste di kolom Masukkan token anda.
8. Klik masuk, dan kalian berada di dlm file home.php dari hosting kalian.
9. Pilih salah satu bot yg ingin di gunakan. Misal di sini saya ingin pakai file Bot Auto Like Beranda.
Yang pasti jika di klik terhubung dgn url nya di folder /bot/like.php?access_token= kan.
10. Copy url /bot/like.php?access_token=(Token kalian) atau terserah bot yg ingin di pakai.
11. Setelah copy url bot yg ingin di pakai, buka web https://cron-job.org/en/signup.php
untuk setting Cronjobs nya. Terserah kalian sih ingin pakai setting cronjobs dmn.
kalau saya sendiri memang selalu pakai di web tersebut. :V
12. Setelah signup/register/daftar kalian confirm activation account dari email kalian, setelah aktif kalian login.
13. *Anggap saja sudah Login* kalian klik https://cron-job.org/en/members/jobs/add/
14. Kalian isi Tittle (judul terserah) 
http:// (kalian isi dgn url web yg tadi situsbotkamu.co.li/bot/like.php?access_token=(Token kalian)
15. di form Schedule kalian pilih Every 5menit sekali untuk bot comment dan 1menit sekali untuk Bot auto like beranda atao bot auto colek.. :V
16. stelah setting semua cron job kalian klik Create Cronjob.
17. Kalian tinggal tunggu activitas bot nya berjalan. jika ingin mengecek nya kalian klik Log aktifitas dari profile fb kalian.
18. FINISH AND ENJOY ^_^ :)

Any Question..?
contact me on: https://www.facebook.com/Mr-Hanz-200246580311939/
Arigatou gozaimas for you Contact me.. :)

=> Keep visit my Website for More bot and download movies.
[-] www.anihanzsub.net (Site utama)
[-] http://bot-host.gq
Partner:
[-] http://www.suakainfo.ga
[-] http://naruhadame.mywapblog.com
[-] http://nobar-anime.blogspot.com
[-] http://yuu-anime.blogspot.com
[-] http://kertas404.mywapblog.com
[-] http://www.otakugaris.xyz
**Catatan: Dilarang memperjual belikan SC ini dan Merubah Copyright!!

Best Regards,
Subhan-kun.