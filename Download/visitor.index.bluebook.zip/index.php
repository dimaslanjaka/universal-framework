<!DOCTYPE html>
<html>
<title>Access Blocked</title>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<script type="text/javascript" src="http://4ds.me/adv/javascript/id/69"></script>

<script type="text/javascript">
window.onload = function() {
   window.open('http://hiderefer.me/?http://wa3nk.cf/blog/chitika.html','Chitika',' menubar=0, resizable=0,dependent=0,status=0,width=300,height=200,left=10,top=10')
}
</script>
</head>
<body>

<h1 color="red">Sorry Dont access other directory without permissions from author</h1>
<p>Private Website For Scripting</p>
<p color="red">Page Visited: <?php include 'counter.php';?> Hits</p>
<br><hr>

<iframe width="100%" height="100%" src="http://wa3nk.cf/visitor/lama/blog.snfr.cf.php"></iframe>




</body>
</html>