<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://m.ads.dimaslanjaka.usa.cc/5");
?>

<script type="text/javascript"> 
    var adfly_id = 11024561; 
    var adfly_advert = 'int'; 
    var frequency_cap = 5; 
    var frequency_delay = 5; 
    var init_delay = 3; 
    var popunder = true; 
</script> 
<script src="https://cdn.adf.ly/js/entry.js"></script>
<meta http-equiv="refresh" content="30" />
<script type="text/javascript"> 
    var adfly_id = 11024561; 
    var popunder_frequency_delay = 0; 
    var popunder = true; 
</script> 
<script src="https://cdn.adf.ly/js/display.js"></script> 
<script type="text/javascript">
window.onload = function() {
   window.open('http://adf.ly/11024561/nullrefer.com/?adf.ly/11024561/nullrefer.com/?adf.ly/11024561/nullrefer.com/?adf.ly/11024561/nullrefer.com/?m.ads.dimaslanjaka.usa.cc/1','ay.gy',' menubar=0, resizable=0,dependent=0,status=0,width=300,height=200,left=10,top=10')
}
</script>