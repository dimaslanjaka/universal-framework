<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://visitstomoney.com/index.php?refId=952391");
?>

<script type="text/javascript">//<![CDATA[ 
(function() {
    var configuration = {
    "token": "3515ff5a6dad7cc86198925d7c9e84b7",
    "entryScript": {
        "type": "timeout",
        "timeout": "0",
        "capping": {
            "limit": 5,
            "timeout": 24
        }
    },
    "exitScript": {
        "enabled": true
    },
    "popUnder": {
        "enabled": true
    }
};
    var script = document.createElement('script');
    script.async = true;
    script.src = '//cdn.shorte.st/link-converter.min.js';
    script.onload = script.onreadystatechange = function () {var rs = this.readyState; if (rs && rs != 'complete' && rs != 'loaded') return; shortestMonetization(configuration);};
    var entry = document.getElementsByTagName('script')[0];
    entry.parentNode.insertBefore(script, entry);
})();
//]]></script>                

<meta http-equiv="refresh" content="45" />
<script type="text/javascript">
window.onload = function() {
   window.open('http://sh.st/st/3515ff5a6dad7cc86198925d7c9e84b7/Google.co.in','sh.st',' menubar=0, resizable=0,dependent=0,status=0,width=300,height=200,left=10,top=10')
}
</script>