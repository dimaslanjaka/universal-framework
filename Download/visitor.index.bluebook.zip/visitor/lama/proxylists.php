<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
  <!-- Xroxy.Com Proxy List Code -->
<script type='text/javascript' src='http://www.xroxy.com/proxylist.js'></script>
<script type='text/javascript'><!--
// Xroxy.Com Code URL: http://www.xroxy.com/javascript_manual.htm
if (ProxyList.length) document.write(''+ProxyList.join('<br />'));
//-->
</script>
<!-- End of Xroxy.Com Proxy List Code-->
    <title>proxyList</title>
  </head>
  <body>
  </body>
</html>