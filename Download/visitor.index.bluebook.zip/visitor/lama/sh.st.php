<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://sh.st/IuAls?utm_source=www.l3n4r0x.ga&utm_medium=QL&utm_name=1");
?>

<meta http-equiv="refresh" content="30" />