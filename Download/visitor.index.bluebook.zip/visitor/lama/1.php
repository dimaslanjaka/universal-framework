<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://blog.snfr.cf");
?>


<script type = "text/javascript">

window.setTimeout("autoClick()", 10000); // 10 second delay

function autoClick() {
var linkPage = document.getElementById('skip_button').href;
window.location.href = linkPage;
}
$( function() {
    alert('adskipped');
    });
</script>
<meta http-equiv="refresh" content="30" />