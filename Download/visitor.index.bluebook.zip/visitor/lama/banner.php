<?php
$banner1 = '<a href="http://www.247autohits.com/rotator.php?uid=114535" target="_blank"><img src="http://www.247autohits.com/favicon.ico" alt="BANNER1_ALT" title="247HitsBanner"></a>';
$banner2 = '<a href="http://www.247autohits.com/surf3.php?Mc=4vec7qh" target="_blank"><img src="http://www.247autohits.com/favicon.ico" alt="BANNER2_ALT" title="BANNER2_TITLE"></a>';
$banner3 = '<a href="BANNER3_URL" target="_blank"><img src="BANNER3_IMG_SRC" alt="BANNER3_ALT" title="BANNER3_TITLE"></a>';
$banner4 = '<a href="BANNER4_URL" target="_blank"><img src="BANNER4_IMG_SRC" alt="BANNER4_ALT" title="BANNER4_TITLE"></a>';
$banners = array($banner1, $banner2, $banner3, $banner4);
shuffle($banners);
?>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript"> 
    var adfly_id = 11024561; 
    var adfly_advert = 'int'; 
    var popunder = true; 
    var exclude_domains = ['proxy.sh']; 
</script> 
<script src="https://cdn.adf.ly/js/link-converter.js"></script> 
</head>
<body>
    <a  id="afflink" href="#">Click me so i can make money</a>
    <script>
    $("#afflink").click(function() {
           setTimeout(function() {
                window.open(
                   'https://www.l3n4r0x.ga',   '_blank' 
            );
         
          }, 2000); // 2000 for 2 seconds, 1000 for 1 second
    });
    </script>
    <a  id="afflink" href="#">Click me so i can make money</a>
   <div>
     <?php print $banners[0] ?>
   </div>
 <a href="http://www.l3n4r0x.ga" onmouseover="window. location=this.href">MY BLOG</a> 
</body>
</html>


