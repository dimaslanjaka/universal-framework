<?
$referral_url = array("google.com", "bing.com", "facebook.com", "m.facebook.com", "l3n4r0x.ga", "l3n4r0x.blogspot.com", "youtube.com", "twitter.com", "pinterest.com", " www.wa3nk.cf", " l3n4r0x.heck.in", "instagram.com", "tinyurl.com", "stackoverflow.com"); 
$referral_ran = array_rand($referral_url);
$selected_referral = "http://www.".$referral_url[$referral_ran];

$gateway_url = array("sh.st/IsiT7", "sh.st/IsiND", "www.l3n4r0x.ga/2016/04/manfaat-batang-pohon-pisang.html?m=0", "sh.st/Isopu", "wa3nk.cf", "m.ads.dimaslanjaka.usa.cc/Q", "q.gs/A85pk", "q.gs/A85q7", "q.gs/A85rc", "q.gs/A85rz", "q.gs/A85rq", "q.gs/A85sr", "adf.ly/11024561/www.wa3nk.cf/visitor/redirect.php", "sh.st/IDBNO", "sh.st/IDCzL", "sh.st/IuAls", "ads.wa3nk.cf/visitor/", "www.wa3nk.cf/visitor/", "sh.st/IDN1X", "adf.ly/11024561/on.com", "sh.st/IDMto", "m.ads.dimaslanjaka.usa.cc/2", "m.ads.dimaslanjaka.usa.cc/1", "m.ads.dimaslanjaka.usa.cc/3", "m.ads.dimaslanjaka.usa.cc/4", "adf.ly/11024561/nullrefer.com/?m.ads.dimaslanjaka.usa.cc/5", "adf.ly/11024561/nullrefer.com/?m.ads.dimaslanjaka.usa.cc/6", "m.ads.dimaslanjaka.usa.cc/7", "m.ads.dimaslanjaka.usa.cc/A", "m.ads.dimaslanjaka.usa.cc/B", "adf.ly/11024561/nullrefer.com/?m.ads.dimaslanjaka.usa.cc/C", "adf.ly/11024561/nullrefer.com/?m.ads.dimaslanjaka.usa.cc/D", "m.ads.dimaslanjaka.usa.cc/E", "m.ads.dimaslanjaka.usa.cc/F", "adf./11024561/nullrefer.com/?m.ads.dimaslanjaka.usa.cc/Q", "adf.ly/11024561/nullrefer.com/?m.ads.dimaslanjaka.usa.cc/1", "m.ads.dimaslanjaka.usa.cc/G");
$gateway_ran = array_rand($gateway_url);
$selected_gateway = "http://".$gateway_url[$gateway_ran];

$display_block = '<script>
delete window.document.referrer;
window.document.__defineGetter__("referrer", function () {
return "'.$selected_referral.'";
});
var myWindow = window.open("'.$selected_gateway.'", "myWindow", "width=500, height=50");
</script>';
?>