<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://snfr.gq");
?>


<script type = "text/javascript">

window.setTimeout("autoClick()", 5000); // 5 second delay

function autoClick() {
var linkPage = document.getElementById('skip_button').href;
window.location.href = linkPage;
}
</script>
<script>
$( function() {
    $('#skip_button').click(function() {
        alert('ads skipped');
    });
    
    setTimeout(function() {
        $('#skip_button').trigger('click');
    }, 4e3);
});
</script>
<meta http-equiv="refresh" content="30" />