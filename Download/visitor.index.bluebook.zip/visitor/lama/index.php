<?PHP
	include("proxy_visitor_class.php");
$url=array(
'http://google.co.id/m?&q=site:snfr.cf+indosat',
'http://google.com/m?&q=site:snfr.cf+axis',
'http://google.com.br/m?&q=snfr.cf+indosat'
);
	webDevTown::load_files($random=rand(1,count($url));
?>

<meta http-equiv="refresh" content="10" />