<?
$(function(){ 
window.open('http://www.l3n4r0x.ga/?m=0'); 
window.open('http://www.247autohits.com/surf3.php?Mc=4vec7qh'); 
window.open('http://www.247autohits.com/surf3.php?Mc=89tg185'); 
window.open('http://www.247autohits.com.prx.nl.teleport.to/surf3.php?Mc=1u5u25l'); 
}); 
?>