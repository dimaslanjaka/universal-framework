<?php
//*** Open Windows Directly ***//
?>

<!DOCTYPE html>
         <html>
             <head>
                <script src="open.js"></script>
             </head>
           <body>

           </body>
          </html>