<?php include "ref.php" ?>
<!DOCTYPE html>
<html>
<head>
<?php echo $display_block ?>
<script type="text/javascript"> 
    var adfly_id = 11024561; 
    var adfly_advert = 'int'; 
    var frequency_cap = 5; 
    var frequency_delay = 5; 
    var init_delay = 3; 
    var popunder = true; 
</script> 
<script src="https://cdn.adf.ly/js/entry.js"></script>

<script type="text/javascript"> 
    var adfly_id = 11024561; 
    var popunder_frequency_delay = 0; 
    var popunder = true; 
</script> 
<script src="https://cdn.adf.ly/js/display.js"></script> 

<meta http-equiv="refresh" content="30" />
</head>
<body>
<h1>AUTO Open ShortLink in new tab</h1>
</body>
</html>