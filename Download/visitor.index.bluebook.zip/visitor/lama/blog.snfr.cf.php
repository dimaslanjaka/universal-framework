<?PHP
	include("proxy_visitor_class.php");

        $a = ['http://blog.snfr.cf/', 'http://blog.snfr.cf/', 'http://blog.snfr.cf/'];

       // $website = $a[mt_rand(0, count($a) - 1)];

	webDevTown::load_files($a[mt_rand(0, count($a) - 1)]);
?>

<meta http-equiv="refresh" content="10" />