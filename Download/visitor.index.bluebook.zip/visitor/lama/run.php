<?php
$output = shell_exec('chmod 777 *.* && rm *.bak');
echo "<pre>$output</pre>";
?>