<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://m.ads.dimaslanjaka.usa.cc/7");
?>

<meta http-equiv="refresh" content="30" />