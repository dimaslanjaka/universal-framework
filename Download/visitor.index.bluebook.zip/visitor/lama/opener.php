<!DOCTYPE html>
<html>
<head>
<script src="https://hidemyass.io/anonymize.js" type="text/javascript"></script>
    <script type="text/javascript">
    var exclude_links = "http://www.google.com/";
    var do_encode = true;

    anonymize_links();
    </script>
    <script src="open.js"></script>