<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://whatsmyuseragent.com");
?>

<meta http-equiv="refresh" content="30" />