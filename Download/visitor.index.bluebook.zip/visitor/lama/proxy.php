<?
$lines = file('proxy.txt');

foreach($lines as $line_num => $line)
{
    $data = explode(' ', $line);
    $data = $data[1].'';
	$cek = explode('HTTP', $data);
	 $cek = $cek[0].'';
    echo "$cek";
	echo "<br>";
}
?>