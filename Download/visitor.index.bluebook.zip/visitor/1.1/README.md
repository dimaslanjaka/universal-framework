# Random-Proxy-Referal-and-Useragent-visitor
This script allows anyone you to increase their site impression/views for SEO purpose(for example ranking website higher on search engine). It loads the site using PHP cURL extention and sending random referral and useragent header along with the use of a random proxy form the proxy list.

Note that this method may be easily detected by reading headers.

List of useragents can be found here:
http://www.useragentstring.com/pages/useragentstring.php
