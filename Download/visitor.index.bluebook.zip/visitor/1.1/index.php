<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://adf.ly/1aZi1x");
?>

<meta http-equiv="refresh" content="20" />