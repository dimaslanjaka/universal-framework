<html>
<title>L3n4r0x SMS Zone</title>
<head>
<!-- Codes by HTML.am -->

<!-- CSS Code -->
<style type="text/css" scoped>
.GeneratedMarquee {
font-family:Baskerville, serif;
font-size:2em;
font-variant:small-caps;
line-height:1.3em;
color:#0099FF;
background-color:#000066;
padding:1.5em;

}
</style>

<!-- HTML Code -->
<marquee class="GeneratedMarquee" direction="left" scrollamount="19" behavior="scroll">SMS ONline</marquee></head>
<body>





<iframe src="http://www.freesmsvoip.com/index.php?do=widget" width="500" height="905" frameborder="0" scrolling="auto"></iframe>
<noframes></noframes>
<div><a href="http://wa3nk.cf/linkshrink.html">WorldWide SMS ONLINE</a>

<iframe src=http://smsgratis.web.id/wg3/?teks=DarkIT-Family frameborder=0 style=height:300px;width:400px;>Please upgrade your browser</iframe>
<iframe src=http://sms-online.web.id/widget frameborder=0 style=height:300px;width:400px;>Please upgrade your browser</iframe>
<iframe name="widgetsms" src="http://widget.sms.web.id/" width="270" height="350" frameborder="0"></iframe><br />  <a href="http://sms.web.id" target="_blank">. </a>  click <a href="http://widget.web.id/widget-sms-gratis/" target="_blank">here</a>



</body>
</html>