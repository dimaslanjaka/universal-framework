<html>
<title>L3n4r0x Zone</title>
<head>
<!-- Codes by HTML.am -->

<!-- CSS Code -->
<style type="text/css" scoped>
.GeneratedMarquee {
font-family:Baskerville, serif;
font-size:2em;
font-variant:small-caps;
line-height:1.3em;
color:#0099FF;
background-color:#000066;
padding:1.5em;

}
</style>

<!-- HTML Code -->
<marquee class="GeneratedMarquee" direction="left" scrollamount="19" behavior="scroll">SMS ONline</marquee></head>
<body>





<h1>SMS ONLINE</h1>
   <p>
   <script src="http://widget.sms2indo.com/sms_function.js" type="text/javascript"></script>
<div style="width:100%;height:100%;">
<iframe id="sms2indo" name="sms2indo" src="http://widget.sms2indo.com/widget-sms2indo.php" width="100%" height="600px" frameborder="0" scrolling="auto" onload='javascript:resizeIframe(this);'>
</iframe></div>
   </p>

<h1>WA ONLINE</h1>
   <p>
   <script src="http://widget.sms2indo.com/sms_function.js" type="text/javascript"></script>
<div style="width:100%;height:100%;">
<iframe id="sms2indo" name="sms2indo" src="http://widget.sms2indo.com/widget-wa-worldwide.php" width="100%" height="600px" frameborder="0" scrolling="auto" onload='javascript:resizeIframe(this);'>
</iframe></div>
   </p>



<iframe src="http://widget.sms2indo.com/widget-sms2indo-2.php" width="100%" height="600px" frameborder="0" scrolling="auto">Please Upgrade Your Browser</iframe>
</body>
</html>