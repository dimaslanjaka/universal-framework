<?PHP
	include("proxy_visitor_class.php");
	webDevTown::load_files("http://j.gs/7qAK");
?>

<meta http-equiv="refresh" content="20" />