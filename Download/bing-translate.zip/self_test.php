<?php

require_once('./BingTranslateLib/BingTranslate.class.php');
         
$gt = new BingTranslateWrapper('YOUR_BING_APPID');
$gt->selfTest();

?>


