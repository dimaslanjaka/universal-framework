Where is documentation or tutorial for this theme?? 

Below is link tutorial how to install and setting:
http://youtu.be/fvicX5QhmRw

In indonesian languange:
http://www.bostheme.com/cara-instalasi-theme-gratis-ktz-freaky-versi-1-0-3-keatas/

How to optimize performance kentooz theme:
http://www.kentooz.com/knowledgebase/how-to-optimize-performance-kentooz-theme/

How to update if available update version:
https://www.youtube.com/watch?v=8Br1tLScQe4

If any question about this theme just emailed me. :)

Where is the support:
Email: g14nblog@gmail.com
Helpdesk: member.kentooz.com/helpdesk/

!!! Important !!!
Please read documentation first before installation...