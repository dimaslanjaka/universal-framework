<?php
$_text['01']="Submitting...";
$_text['02']="Submission Complete.";
$_text['03']="Submission Failed.";
$_text['04']="URL : ";
$_text['05']="Email : ";
$_text['06']="Check all";
$_text['07']="Uncheck all";
$_text['08']="  Submit my site  ";
$_text['09']="<p><strong>Please wait while your site is submitted to search engines.</strong></p>";
$_text['10']="<strong>invalid email</strong>";
$_text['11']="<strong>invalid URL</strong>";
$_text['12']=" Are submited to search engines, please wait 6 - 14 days to resubmit many engines penalize multiples submission !<br>";
?>