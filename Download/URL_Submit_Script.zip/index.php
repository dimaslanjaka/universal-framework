
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Site Submit</title>

<style type="text/css">
body {
padding:1px;margin: 0px;color: #333;font-size: 11px;font-family: arial, helvetica, sans-serif;background-color:#e3e3e3;}
img{border:0px;}
h2 {border-left: 10px solid #636563;font-size: 18px;padding:5px;margin:5px;}
a{color: #000000;text-decoration: none;}
a:hover{text-decoration: none;color: #cc0000;}
.content {padding:0px;border: #9c9c9c 1px solid;background: #fff;margin: 10px auto;
width: 560px;}
/** TOP **/
.mytop { height:52px;padding:5px 0px 0px 2px;background-color:#fFfCF;margin: 0px;}
.mytop h1{font-size: 26px;padding: 10px 26px 10px 26px;color: #000000;text-decoration:none;margin:0px;}
.mytop h1 a {text-decoration:none;color:#fff;}
.center {padding:5px 2px 5px 5px;float: left;margin: 0px;width: 550px;}
#menutop {height: 12px;padding:3px;font-size: 10px;font-weight: bold;margin: 0px;text-align: left;border:#A30100 solid 1px;background-color:#D10506;}
#menutop li {display: inline;list-style-type: none;}
#menutop ul {padding:0px;margin:0px;}
#menutop a {font-weight: bold;color: #fff;padding:3px;padding-right:10px;padding-left:10px;}
#menutop a:hover {background: #850303;color: #fff}
#menutop .lcurrent{background: #850303;color: #fff}
.footer {background-color:#EDEDED;text-align: center;color:#000;clear: both;padding: 10px 0px 0px 10px;
margin:10px 0px 0px 0px;border-top: #9C9A9C 2px dashed;
min-height:20px;
}
#sucess{border:#669966 1px solid;padding:3px;margin:3px;font-weight: bold;color:#669966;font-size:12px;text-align:center;}
#error{padding:3px;margin:3px;font-weight: bold;color:#FF0000;font-size:10px;display:inline;} 
</style>
</head>
<body>
<div class="content">
<div class="mytop"><h1>Site Submit</h1></div>
<div id="menutop"></div>
<div class="center">


<?php
include("submit.php");?>
    </p>
    </form>
   </div>
<div class="footer">
<div align="left" style="font-size:9px"></div></div></div>
</body></html>		

