URL Submit Script  -  PHP script which allows users to submit website to over 130 engines in one time only, no lost your time in one click your site are listed in the most important engines
INSTALLATION:
------------------
unzip all files in a folder!
send all files from your server
features
------------------
install in 1 minute
requeriments
------------------
PHP 4.2+
Ioncube loaders
SUPPORT:
------------------
if you have any trouble with the installation of this software then please
feel free to send your problem from us. 

URL : http://www.urlsubmitscript.com/