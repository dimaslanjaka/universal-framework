<?php
/*
Plugin Name: Easy Stats PRO (shared on wplocker.com)
Plugin URI: http://whowp.com/portfolio/easystats/
Description: Do you want to track how many visitors you have, where they come from and what they do on your site? Than Easy Stats is the right choise for you!
Version: 1.0
Author: Who WP
Author URI: http://whowp.com
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

require_once( plugin_dir_path( __FILE__ ) . 'includes/noerror.php');
require_once( plugin_dir_path( __FILE__ ) . 'includes/Browser.php');
require_once( plugin_dir_path( __FILE__ ) . 'includes/es-geo.class.php');
require_once( plugin_dir_path( __FILE__ ) . 'includes/es-functions.php');
require_once( plugin_dir_path( __FILE__ ) . 'includes/es-functions-top-query.php');
require_once( plugin_dir_path( __FILE__ ) . 'includes/es-shortcodes.php');



define('es_plugin_url', WP_PLUGIN_URL . '/' . plugin_basename( dirname(__FILE__) ) . '/' );
define('es_plugin_dir', plugin_dir_path( __FILE__ ) );




function es_init_scripts()
	{
		wp_enqueue_script('jquery');

		wp_enqueue_script('jquery-ui-datepicker');
		wp_enqueue_style('easy-stats-style', es_plugin_url.'css/style.css');
		wp_enqueue_style('easy-stats-flags', es_plugin_url.'css/flags.css');
		wp_enqueue_script('easy-stats-js', plugins_url( '/js/scripts.js' , __FILE__ ) , array( 'jquery' ));
		wp_localize_script( 'easy-stats-js', 'es_ajax', array( 'es_ajaxurl' => admin_url( 'admin-ajax.php')));
		wp_enqueue_style('jquery-ui', es_plugin_url.'css/jquery-ui.css');
		
		//ESAdmin
		wp_enqueue_style('ESAdmin', es_plugin_url.'ESAdmin/css/ESAdmin.css');
		wp_enqueue_style('ESIcons', es_plugin_url.'ESAdmin/css/ESIcons.css');		
		wp_enqueue_script('ESAdmin', plugins_url( 'ESAdmin/js/ESAdmin.js' , __FILE__ ) , array( 'jquery' ));
		
		
		//jquery.jqplot
		wp_enqueue_style('jquery.jqplot', es_plugin_url.'css/jquery.jqplot.css');		
		wp_enqueue_script('jquery.jqplot.min', plugins_url( 'js/jquery.jqplot.min.js' , __FILE__ ) , array( 'jquery' ));		
		
		wp_enqueue_script('jqplot.pieRenderer.min', plugins_url( 'js/jqplot.pieRenderer.min.js' , __FILE__ ) , array( 'jquery' ));		
		wp_enqueue_script('jqplot.highlighter.min', plugins_url( 'js/jqplot.highlighter.min.js' , __FILE__ ) , array( 'jquery' ));					
		wp_enqueue_script('jqplot.enhancedLegendRenderer.min', plugins_url( 'js/jqplot.enhancedLegendRenderer.min.js' , __FILE__ ) , array( 'jquery' ));			
		
		wp_enqueue_script('jqplot.dateAxisRenderer.min', plugins_url( 'js/jqplot.dateAxisRenderer.min.js' , __FILE__ ) , array( 'jquery' ));			
		
		wp_enqueue_script('jqplot.canvasTextRenderer.min', plugins_url( 'js/jqplot.canvasTextRenderer.min.js' , __FILE__ ) , array( 'jquery' ));			
				
		wp_enqueue_script('jqplot.canvasAxisTickRenderer.min', plugins_url( 'js/jqplot.canvasAxisTickRenderer.min.js' , __FILE__ ) , array( 'jquery' ));		
		
		wp_enqueue_script('jqplot.canvasAxisLabelRenderer.min', plugins_url( 'js/jqplot.canvasAxisLabelRenderer.min.js' , __FILE__ ) , array( 'jquery' ));			
				
	}
add_action("init","es_init_scripts");







register_activation_hook(__FILE__, 'es_install');
register_uninstall_hook(__FILE__, 'es_uninstall');


function es_uninstall()
	{

		$es_delete_data = get_option( 'es_delete_data' );
		
		
		if($es_delete_data=='yes')
			{	
		
				global $wpdb;
				$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}es" );
				$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}es_online" );
				
				delete_option( 'es_version' );
				delete_option( 'es_delete_data' );
				delete_option( 'es_customer_type' );
			}
		

		
		

		
	}
	
	
	
function es_install()
	{
		
		global $wpdb;
		
        $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "es"
                 ."( UNIQUE KEY id (id),
					id int(100) NOT NULL AUTO_INCREMENT,
					session_id	VARCHAR( 255 )	NOT NULL,
					es_date	DATE NOT NULL,
					es_time	TIME NOT NULL,
					es_endtime	TIME NOT NULL,
					userid	VARCHAR( 50 )	NOT NULL,
					event	VARCHAR( 50 )	NOT NULL,
					browser	VARCHAR( 50 )	NOT NULL,
					platform	VARCHAR( 50 )	NOT NULL,
					ip	VARCHAR( 20 )	NOT NULL,
					city	VARCHAR( 50 )	NOT NULL,
					region	VARCHAR( 50 )	NOT NULL,
					countryName	VARCHAR( 50 )	NOT NULL,
					url_id	VARCHAR( 255 )	NOT NULL,
					url_term	VARCHAR( 255 )	NOT NULL,
					referer_doamin	VARCHAR( 255 )	NOT NULL,
					referer_url	TEXT NOT NULL,
					screensize	VARCHAR( 50 ) NOT NULL,
					isunique	VARCHAR( 50 ) NOT NULL,
					landing	VARCHAR( 10 ) NOT NULL

					)";
		$wpdb->query($sql);
		
		
		
        $sql2 = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "es_online"
                 ."( UNIQUE KEY id (id),
					id int(100) NOT NULL AUTO_INCREMENT,
					session_id VARCHAR( 255 ) NOT NULL,
					es_time  DATETIME NOT NULL,
					userid	VARCHAR( 50 )	NOT NULL,
					url_id	VARCHAR( 255 )	NOT NULL,
					url_term	VARCHAR( 255 )	NOT NULL,
					city	VARCHAR( 50 )	NOT NULL,
					region	VARCHAR( 50 )	NOT NULL,
					countryName	VARCHAR( 50 )	NOT NULL,
					browser	VARCHAR( 50 )	NOT NULL,
					platform	VARCHAR( 50 )	NOT NULL,
					referer_doamin	VARCHAR( 255 )	NOT NULL,
					referer_url	TEXT NOT NULL
					)";
		$wpdb->query($sql2);
		

		$es_version= "1.0";
		update_option('es_version', $es_version); 
		
		$es_customer_type= "free"; 
		update_option('es_customer_type', $es_customer_type); 



		}



function es_visit()
	{
		

	$es_date = es_get_date();
	$es_time = es_get_time();
	$es_datetime = es_get_datetime();	
	$es_endtime = $es_datetime;
	

	$browser = new Browser_es();
	$platform = $browser->getPlatform();
	$browser = $browser->getBrowser();
	$screensize = es_get_screensize();
	

	$ip = $_SERVER['REMOTE_ADDR'];
	$geoplugin = new geoPlugin();
	$geoplugin->locate();
	$city = $geoplugin->city;
	$region = $geoplugin->region;
	$countryName = $geoplugin->countryCode;


	$referer = es_get_referer();
	$referer = explode(',',$referer);
	$referer_doamin = $referer['0'];
	$referer_url = $referer['1'];



	$userid = es_getuser();
	$url_id_array = es_geturl_id();
	$url_id_array = explode(',',$url_id_array);
	$url_id = $url_id_array['0'];
	$url_term = $url_id_array['1'];
	
	$event = "visit";
	
	$isunique = es_get_unique();
	$landing = es_landing();
	$es_session_id = es_session();
	
	
	global $wpdb;
	$table = $wpdb->prefix . "es";
		
	$wpdb->query( $wpdb->prepare("INSERT INTO $table 
								( id, session_id, es_date, es_time, es_endtime, userid, event, browser, platform, ip, city, region, countryName, url_id, url_term, referer_doamin, referer_url, screensize, isunique, landing )
			VALUES	( %d, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s )",
						array	( '', $es_session_id, $es_date, $es_time, $es_endtime, $userid, $event, $browser, $platform, $ip, $city, $region, $countryName, $url_id, $url_term, $referer_doamin, $referer_url, $screensize, $isunique, $landing )
								));
		
		


$table = $wpdb->prefix . "es_online";	
$result = $wpdb->get_results("SELECT * FROM $table WHERE session_id='$es_session_id'", ARRAY_A);
$count = $wpdb->num_rows;


 

	if($count==NULL)
		{
			$wpdb->query( $wpdb->prepare("INSERT INTO $table 
								( id, session_id, es_time, userid, url_id, url_term, city, region, countryName, browser, platform, referer_doamin, referer_url) VALUES	(%d, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
							array( '', $es_session_id, $es_datetime, $userid, $url_id, $url_term, $city, $region, $countryName, $browser, $platform, $referer_doamin, $referer_url)
								));
		}
	else
		{
			$wpdb->query("UPDATE $table SET es_time='$es_datetime', url_id='$url_id', referer_doamin='$referer_doamin', referer_url='$referer_url' WHERE session_id='$es_session_id'");
		}


					
	}

add_action('wp_head', 'es_visit');




function login_with_email_address($username) {
        $user = get_user_by('email',$username);
        if(!empty($user->user_login))
                $username = $user->user_login;
        return $username;
}
add_action('wp_authenticate','login_with_email_address');

function change_username_wps_text($text){
       if(in_array($GLOBALS['pagenow'], array('wp-login.php'))){
         if ($text == 'Username'){$text = 'Username / Email';}
            }
                return $text;
         }
add_filter( 'gettext', 'change_username_wps_text' );

















add_action('admin_init', 'es_options_init' );
add_action('admin_menu', 'es_menu_init');


function es_options_init(){
	register_setting('es_options', 'es_version');
	register_setting('es_options', 'es_customer_type');	
	register_setting('es_options', 'es_delete_data');

    }

function es_settings(){
	include('es-settings.php');
	}
	
	
function es_dashboard(){
	include('es-dashboard.php');
	}
		
	
	
function es_admin_online(){
	include('es-admin-online.php');
	}

function es_admin_visitors(){
	include('es-admin-visitors.php');
	}

function es_admin_geo(){
	include('es-admin-geo.php');
	}

function es_admin_filter(){
	include('es-admin-filter.php');
	}




function es_menu_init() {





	add_menu_page(__('Easy Stats PRO','es'), __('Easy Stats PRO','es'), 'manage_options', 'es_settings', 'es_dashboard');

	add_submenu_page('es_settings', __('All Visitors','menu-es'), __('All Time Visitors','menu-es'), 'manage_options', 'es_admin_visitors', 'es_admin_visitors');	
	
	add_submenu_page('es_settings', __('Online Users','menu-es'), __('Online Users','menu-es'), 'manage_options', 'es_admin_online', 'es_admin_online');
	
	add_submenu_page('es_settings', __('Filter','menu-es'), __('Filter Statistics','menu-es'), 'manage_options', 'es_admin_filter', 'es_admin_filter');		

	add_submenu_page('es_settings', __('es Dashboard','menu-es'), __('Easy Stats Settings','menu-es'), 'manage_options', 'es_dashboard', 'es_settings');	

}

?>