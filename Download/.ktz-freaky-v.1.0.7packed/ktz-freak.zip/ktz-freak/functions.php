<?php
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK
/* Version :1.01
/* You can add your own function here! 
/* But don't change anything in this file!
/*-----------------------------------------------*/

// Do not load directly...
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

// Load kentooz framework
require_once (TEMPLATEPATH . '/includes/init.php');
$kentooz_declare = new KENTOOZ();
$kentooz_declare->init();