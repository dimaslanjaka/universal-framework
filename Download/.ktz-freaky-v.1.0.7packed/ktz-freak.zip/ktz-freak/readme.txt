<strong>INSTALL</strong>
1. Upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress dashboard and select Appearance.
3. Be sure to activate the kentooz theme
4. Inside your WordPress dashboard, go to themes options to setting your website.

<strong>Author link</strong>
<a href="http://www.kentooz.com/">http://kentooz.com</a>
