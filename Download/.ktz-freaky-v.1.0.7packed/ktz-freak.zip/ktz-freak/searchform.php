<?php $search_text = empty($_GET['s']) ? "Search" : get_search_query(); ?> 
    <form method="get" action="<?php echo esc_url( home_url( '' ) ); ?>"> 
		<div class="ktz-search has-feedback">
        <input type="text" name="s" id="s" class="form-control btn-box input-lg" placeholder="Search and enter" />
		<span class="glyphicon glyphicon-search form-control-feedback"></span>
		</div>
    </form>
