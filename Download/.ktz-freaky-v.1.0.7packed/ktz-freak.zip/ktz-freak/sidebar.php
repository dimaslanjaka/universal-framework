<div class="sbar col-md-4 widget-area wrapwidget" role="complementary">
	<?php 	
		// if BBpress active and in woocommerce page...
		if ( class_exists('bbPress') && is_bbpress() ) {
			
			if ( is_active_sidebar('sidebar_forum')) : 
				dynamic_sidebar('sidebar_forum'); 
			else : 
				echo 'Please go to appearance -> widget, and setting widget for bbpress sidebar'; 
			endif;
		
		// if in page or in single page
		} elseif ( is_page() || is_single() ) {
			$ktz_meta_values = get_post_custom($post->ID);
			
			if(!isset($ktz_meta_values['ktz_meta_sidebar'][0])){
				$ktz_meta_values['ktz_meta_sidebar'][0] = 'default';
			}
							
			if ($ktz_meta_values['ktz_meta_sidebar'][0] == "default") {
				
				if ( is_active_sidebar('sidebar_default')) : 
					dynamic_sidebar('sidebar_default'); 
				endif;
				
			} else {
				
				dynamic_sidebar($ktz_meta_values['ktz_meta_sidebar'][0]);
				
			}
			
		// Else using default sidebar
		} else {
			
			if ( is_active_sidebar('sidebar_default')) : 
				dynamic_sidebar('sidebar_default'); 
			endif;
			
		}
	?>
</div>
