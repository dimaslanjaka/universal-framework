<?php 
/**
 * Template Name: Magazine
*/ 
get_header(); ?>
	<section class="col-md-12">
	<div class="row">
	<?php 
		$ktz_meta_values = get_post_custom($post->ID);
		if ( ot_get_option('ktz_sb_layout') == 'left' ) : 
		get_sidebar(); 
		else :
			if(!isset($ktz_meta_values['ktz_meta_layout'][0])){
			 	$ktz_meta_values['ktz_meta_layout'][0] = 'right';
			}
			if ( $ktz_meta_values['ktz_meta_layout'][0] == 'left' ) { 
				get_sidebar(); 
			} else {
				echo '';
			}
		endif; ?>
	<div role="main" class="main col-md-8">
	<section class="new-content">
	<?php if ( is_active_sidebar('widget_bigmodule')) : dynamic_sidebar('widget_bigmodule'); endif; ?>
	<div class="row">
	<div role="main" class="col-md-6">
		<?php if ( is_active_sidebar('widget_leftmodule')) : dynamic_sidebar('widget_leftmodule'); endif; ?>
	</div>
	<div role="main" class="col-md-6">
		<?php if ( is_active_sidebar('widget_rightmodule')) : dynamic_sidebar('widget_rightmodule'); endif; ?>
	</div>
	</div>
	<?php if ( is_active_sidebar('widget_bigmodule_foot')) : dynamic_sidebar('widget_bigmodule_foot'); endif; ?>
	</section>
	</div>
	<?php if ( ot_get_option('ktz_sb_layout') == 'right' ) : 
		get_sidebar(); 
		else :
			$ktz_meta_values = get_post_custom($post->ID);
			if ($ktz_meta_values['ktz_meta_layout'][0] == 'right') { 
				get_sidebar(); 
			} else {
				echo '';
			}
		endif; ?>
	</div>
	</section>
<?php get_footer(); ?>
