/*
 * Copyright (c) kentooz
 * Kentooz Theme Custom Javascript
 */
 
var $ = jQuery.noConflict();

(function( $ ) {
	/* http://www.w3schools.com/js/js_strict.asp */
	"use strict";
	
$( document ).ready( function () {
// JS TOOLTIPS
	$('ul.ktz-socialicon a, ul.sharethis a').tooltip({placement: 'top'});
	$('ul.icon-author a').tooltip({placement: 'bottom'});
	$('a[rel=tooltip]').tooltip();

// JS TABS - Select first tab in shortcode
	$('#ktztab a:first').tab('show'); 
	
// JS POPOVER
	$(".ktzcarousel-little").owlCarousel({
		navigation: true,
		responsive: true,
		responsiveRefreshRate : 200,
		navigationText: [
			"<span class='fontawesome ktzfo-double-angle-left'></span>",
			"<span class='fontawesome ktzfo-double-angle-right'></span>"
		],
		pagination : false,
		items : 3
	});

// GALLERY
    $('.ktzcarousel-little .item img').click(function(){
		var oriSrc = $(this).attr('data-ori');
		var cropSrc = $(this).attr('data-crop');
		var titleImg = $(this).attr('data-title');
		$(this).closest('.box_gallery').find('#inner_box_gallery a.data-original-link').attr('href',oriSrc);
		$(this).closest('.box_gallery').find('#inner_box_gallery img.data-original').attr('src',cropSrc);
		$(this).closest('.box_gallery').find('#inner_box_gallery a.data-original-link').attr('data-title',titleImg);
    });
// JS SCROLL TOP	
    $('#back-top').click(function(){
        $("html, body").animate({ scrollTop: 0 }, 600);
		return false;
		});

// Back to top	
	var $scrolltotop = $("#ktz-backtotop");

	$scrolltotop.css('display', 'none');
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				$scrolltotop.slideDown('fast');
			} else {
				$scrolltotop.slideUp('fast');
			}
		});

		$scrolltotop.click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 'fast');
			return false;
		});
	});
	
// Responsive FB comment
	(function(w, d, s) {
	function go(){
		var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
		if (d.getElementById(id)) {return;}
		js = d.createElement(s); js.src = url; js.id = id;
		fjs.parentNode.insertBefore(js, fjs);
	};
	load('//connect.facebook.net/en_US/all.js#xfbml=1', 'fbjssdk');
	load('//apis.google.com/js/plusone.js', 'gplus1js');
	load('//platform.twitter.com/widgets.js', 'tweetjs');
	load('//assets.pinterest.com/js/pinit.js', 'pintit');
	}
	if (w.addEventListener) { w.addEventListener("load", go, false); }
	else if (w.attachEvent) { w.attachEvent("onload",go); }
	}(window, document, 'script'));
	
}); // End document Ready
})(jQuery);