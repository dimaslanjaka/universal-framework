<?php 
/**
 * Keep silent! / Kentooz folder for bootstrap framework, never change the framework code.
**/
?>
