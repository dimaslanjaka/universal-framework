<?php
/* Kentooz Framework widget for Tab sidebar. */

// Do not load directly...
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

class ktz_tabs_widget extends WP_Widget {
	
	function __construct()
	{
		$widget_ops = array( 'classname' => 'ktz_tabber', 'description' => __( 'Widget tab for display comment, popular and tags.','ktz_theme_textdomain') );
		parent::__construct( 'ktz_tabber', __( 'KTZ tabs','ktz_theme_textdomain'), $widget_ops );
	}
	
	function widget($args, $instance)
	{
		extract($args);
		$posts = $instance['posts'];
		$comments = $instance['comments'];
		$rates = $instance['rates'];
		$tags_count = $instance['tags'];
		$show_popular_posts = isset($instance['show_popular_posts']) ? 'true' : 'false';
		$show_comments = isset($instance['show_comments']) ? 'true' : 'false';
		$show_rates = isset($instance['show_rates']) ? 'true' : 'false';
		$show_tags = isset($instance['show_tags']) ? 'true' : 'false';
		echo $before_widget;
		?>
			<ul class="nav nav-tabs" id="ktzsbtab">
				<?php if($show_popular_posts == 'true'): ?><li class="active"><a href="#popular" data-toggle="tab" title="post tabs"><?php _e('Popular', 'ktz_theme_textdomain'); ?></a></li><?php endif; ?>
				<?php if($show_comments == 'true'): ?><li><a href="#comment" data-toggle="tab" title="comment tabs"><?php _e('Most view', 'ktz_theme_textdomain'); ?></a></li><?php endif; ?>
				<?php if($show_rates == 'true'): ?><li><a href="#rate" data-toggle="tab" title="comment tabs"><?php _e('Best rate', 'ktz_theme_textdomain'); ?></a></li><?php endif; ?>
				<?php if($show_tags == 'true'): ?><li><a href="#tag" data-toggle="tab" title="tags tabs"><?php _e('Tags', 'ktz_theme_textdomain'); ?></a></li><?php endif; ?>
			</ul>
			<div class="tab-content">
			<?php if($show_popular_posts == 'true'):
			$ktzpop = new WP_Query(array('showposts' => $posts, 'orderby' => 'comment_count','order' => 'desc','post_status' => 'publish','ignore_sticky_posts' => 1));
			if ( $ktzpop->have_posts() ) : 
			global $post; ?>
            <div class="tab-pane active" id="popular"><ul class="content-tabs ktz-recent-list">
				<?php  
			while ( $ktzpop -> have_posts() ) : $ktzpop -> the_post(); 
			$format = get_post_format();
			echo '<li class="clearfix">';
			echo ktz_featured_img( 80, 80 );
			echo '<div class="ktz-content-related">';
			echo '<div class="ktz-posttitle">';
			echo ktz_posted_title_a();
			echo '</div>';			
			echo '<div class="ktz-metapost-widget">';
			echo ktz_comment_num();
			echo '</div>';		
			echo '</div></li>';				
				endwhile; ?>
            </ul></div>
            <?php
			wp_reset_query(); 
			endif; ?>
			<?php endif; ?>
			
			<?php if($show_comments == 'true'):
			$ktzmostview = new WP_Query(array('showposts' => $comments, 'meta_key' => 'post_views_count','orderby' => 'meta_value_num','order' => 'desc','post_status' => 'publish','ignore_sticky_posts' => 1));
			if ($ktzmostview -> have_posts()) : 
			global $post; ?>
            <div class="tab-pane" id="comment"><ul class="content-tabs ktz-recent-list">
				<?php 
			while ( $ktzmostview -> have_posts() ) : $ktzmostview -> the_post(); 
			$format = get_post_format();
			echo '<li class="clearfix">';
			echo ktz_featured_img( 80, 80 );
			echo '<div class="ktz-content-related">';
			echo '<div class="ktz-posttitle">';
			echo ktz_posted_title_a();
			echo '</div>';			
			echo '<div class="ktz-metapost-widget">';
			echo ktz_getPostViews(get_the_ID());
			echo '</div>';		
			echo '</div></li>';				
				endwhile; ?>
            </ul></div>
            <?php
			wp_reset_query(); 
			endif; ?>
			<?php endif; ?>
			
			<?php if($show_rates == 'true'):
			$ktztoprate = new WP_Query(array('showposts' => $rates, 'post_type' => 'post','meta_key' => 'ktz_stars_rating','orderby' => 'meta_value_num','order' => 'desc','post_status' => 'publish','ignore_sticky_posts' => 1));
			if ($ktztoprate -> have_posts()) : 
			global $post; ?>
            <div class="tab-pane" id="rate"><ul class="content-tabs ktz-recent-list">
				<?php 
			while ( $ktztoprate -> have_posts() ) : $ktztoprate -> the_post(); 
			$format = get_post_format();
			echo '<li class="clearfix">';
			echo ktz_featured_img( 80, 80 );
			echo '<div class="ktz-content-related">';
			echo '<div class="ktz-posttitle">';
			echo ktz_posted_title_a();
			echo '</div>';			
			echo '<div class="ktz-metapost-widget">';
			echo ktz_ajaxstar_SEO_widget();
			echo '</div>';		
			echo '</div></li>';				
				endwhile; ?>
            </ul></div>
            <?php
			wp_reset_query(); 
			endif; ?>
			<?php endif; ?>
				
			<?php if($show_tags == 'true'): ?>
			<div class="tab-pane tagcloud clearfix content-tabs" id="tag">
				<?php wp_tag_cloud( apply_filters('widget_tag_cloud_args', array('smallest'=>10,'largest'=>10,'number'=> $tags_count,'format'=>'list') ) ); ?>
			</div>
			<?php endif; ?>
		</div>
		<!-- END WIDGET -->
		<?php
		echo $after_widget;
	}
	
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['posts'] = $new_instance['posts'];
		$instance['comments'] = $new_instance['comments'];
		$instance['rates'] = $new_instance['rates'];
		$instance['tags'] = $new_instance['tags'];
		$instance['show_popular_posts'] = $new_instance['show_popular_posts'];
		$instance['show_comments'] = $new_instance['show_comments'];
		$instance['show_tags'] = $new_instance['show_tags'];
		$instance['show_rates'] = $new_instance['show_rates'];
		
		return $instance;
	}

	function form($instance)
	{
		$defaults = array('posts' => 3, 'comments' => 3, 'rates' => 3, 'tags' => 20, 'show_popular_posts' => 'on', 'show_comments' => 'on', 'show_tags' =>  'on', 'show_rates' =>  'on');
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		<p>
			<label for="<?php echo $this->get_field_id('posts'); ?>"><?php _e( 'Number of popular posts:','ktz_theme_textdomain' ); ?></label>
			<input class="widefat" type="text" style="width: 40px;" id="<?php echo $this->get_field_id('posts'); ?>" name="<?php echo $this->get_field_name('posts'); ?>" value="<?php echo $instance['posts']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('comments'); ?>"><?php _e( 'Number of most view:','ktz_theme_textdomain' ); ?></label>
			<input class="widefat" type="text" style="width: 40px;" id="<?php echo $this->get_field_id('comments'); ?>" name="<?php echo $this->get_field_name('comments'); ?>" value="<?php echo $instance['comments']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('rates'); ?>"><?php _e( 'Number of best rate:','ktz_theme_textdomain' ); ?></label>
			<input class="widefat" type="text" style="width: 40px;" id="<?php echo $this->get_field_id('rates'); ?>" name="<?php echo $this->get_field_name('rates'); ?>" value="<?php echo $instance['rates']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('tags'); ?>"><?php _e( 'Number of tags:','ktz_theme_textdomain' ); ?></label>
			<input class="widefat" type="text" style="width: 40px;" id="<?php echo $this->get_field_id('tags'); ?>" name="<?php echo $this->get_field_name('tags'); ?>" value="<?php echo $instance['tags']; ?>" />
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_popular_posts'], 'on'); ?> id="<?php echo $this->get_field_id('show_popular_posts'); ?>" name="<?php echo $this->get_field_name('show_popular_posts'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_popular_posts'); ?>"><?php _e( 'Show popular posts','ktz_theme_textdomain' ); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_comments'], 'on'); ?> id="<?php echo $this->get_field_id('show_comments'); ?>" name="<?php echo $this->get_field_name('show_comments'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_comments'); ?>"><?php _e( 'Show most view','ktz_theme_textdomain' ); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_rates'], 'on'); ?> id="<?php echo $this->get_field_id('show_rates'); ?>" name="<?php echo $this->get_field_name('show_rates'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_rates'); ?>"><?php _e( 'Show best rate','ktz_theme_textdomain' ); ?></label>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['show_tags'], 'on'); ?> id="<?php echo $this->get_field_id('show_tags'); ?>" name="<?php echo $this->get_field_name('show_tags'); ?>" /> 
			<label for="<?php echo $this->get_field_id('show_tags'); ?>"><?php _e( 'Show tags','ktz_theme_textdomain' ); ?></label>
		</p>
	<?php }
}