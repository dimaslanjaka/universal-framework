<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ THEMES FUNCTION
/* Website    : http://www.kentooz.com
/* The Author : Gian Mokhammad Ramadhan (http://www.gianmr.com)
/* Twitter    : http://www.twitter.com/g14nnakal 
/* Facebook   : http://www.facebook.com/gianmr
/*-----------------------------------------------*/

// Do not load directly...
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/*
* Add social network share post
*/
function ktz_socialshare() {
    global $post;
	$href = get_permalink();
	echo '<div class="social-share clearfix">
	<fb:like href="'.$href.'" layout="box_count" action="like" show_faces="false" share="false" style="top:-5px;"></fb:like>
	<g:plusone size="tall" annotation="bubble" callback="ktz_gplus" href="'.$href.'"></g:plusone>
	<a href="http://twitter.com/share" class="twitter-share-button" data-url="'.$href.'" data-size="medium" data-count="vertical" data-lang="en">Tweet</a>
	</div>';
}
function ktz_socialshare_cat() {
    global $post;
	$href = get_permalink();
	echo '<div class="ktz-share">';
	echo '<div id="fb-root"></div><fb:like href="'.$href.'" layout="button_count" action="like" show_faces="false" share="false" style="top: -6px;margin-right:30px;"></fb:like>';
	echo '<a href="http://twitter.com/share" class="twitter-share-button" data-url="'.$href.'" data-size="medium" data-count="horizontal" data-lang="en">Tweet</a>';
	echo '<g:plusone size="medium" annotation="bubble" callback="ktz_gplus" href="'.$href.'"></g:plusone>';
	echo '</div>';
}

/*
* Add share post in single page
* add_action( 'do_ktz_singlecontent', 'ktz_share_post' ); in init.php
*/
if ( !function_exists('ktz_share_post') ) :
function ktz_share_post() { 
	global $wp_query, $post;
	if ( ot_get_option('ktz_active_shared') == 'yes' ) :
	echo '<div class="ktz-sharedpost clearfix">';
	echo ktz_socialshare_cat();
	echo '</div>';
	endif;
	} 
endif;

/*
* Social network icon
* add_action( 'do_ktz_header_sn', 'ktz_sn' ); in init.php
*/
if ( !function_exists('ktz_sn') ) {
function ktz_sn() {
	if ((ot_get_option('ktz_tweet_sn') != '') || (ot_get_option('ktz_fb_sn') != '') || (ot_get_option('ktz_gplus_sn') != '') || (ot_get_option('ktz_in_sn') != '') || (ot_get_option('ktz_dribble_sn') != '') || (ot_get_option('ktz_flickr_sn') != '') || (ot_get_option('ktz_deviant_sn') != '') || (ot_get_option('ktz_blogger_sn') != '') || (ot_get_option('ktz_vimeo_sn') != '') || (ot_get_option('ktz_youtube_sn') != '') || (ot_get_option('ktz_rss_sn') != '')) :
	echo '<div class="pull-right"><ul class="ktz-socialicon">';
			if (ot_get_option('ktz_tweet_sn') != '')
				echo '<li class="twitter"><a href="' . ot_get_option('ktz_tweet_sn') . '" title="Twitter" rel="nofollow"><span class="fontawesome ktzfo-twitter"></span></a></li>';
			if (ot_get_option('ktz_fb_sn') != '')
				echo '<li class="facebook"><a href="' . ot_get_option('ktz_fb_sn') . '" title="Facebook" rel="nofollow"><span class="fontawesome ktzfo-facebook"></span></a></li>';
			if (ot_get_option('ktz_gplus_sn') != '')
				echo '<li class="gplus"><a href="' . ot_get_option('ktz_gplus_sn') . '" title="GPlus" rel="nofollow"><span class="fontawesome ktzfo-google-plus"></span></a></li>';
			if (ot_get_option('ktz_in_sn') != '')
				echo '<li class="in"><a href="' . ot_get_option('ktz_in_sn') . '" title="LinkedIn" rel="nofollow"><span class="fontawesome ktzfo-linkedin"></span></a></li>';
			if (ot_get_option('ktz_dribble_sn') != '')
				echo '<li class="dribble"><a href="' . ot_get_option('ktz_dribble_sn') . '" title="Dribble" rel="nofollow"><span class="fontawesome ktzfo-dribbble"></span></a></li>';
			if (ot_get_option('ktz_flickr_sn') != '')
				echo '<li class="flickr"><a href="' . ot_get_option('ktz_flickr_sn') . '" title="Flickr" rel="nofollow"><span class="fontawesome ktzfo-flickr"></span></a></li>';
			if (ot_get_option('ktz_instagram_sn') != '')
				echo '<li class="instagram"><a href="' . ot_get_option('ktz_instagram_sn') . '" title="Instagram" rel="nofollow"><span class="fontawesome ktzfo-instagram"></span></a></li>';
			if (ot_get_option('ktz_tumblr_sn') != '')
				echo '<li class="tumblr"><a href="' . ot_get_option('ktz_tumblr_sn') . '" title="Tumblr" rel="nofollow"><span class="fontawesome ktzfo-tumblr"></span></a></li>';
			if (ot_get_option('ktz_youtube_sn') != '')
				echo '<li class="youtube"><a href="' . ot_get_option('ktz_youtube_sn') . '" title="YouTube" rel="nofollow"><span class="fontawesome ktzfo-youtube"></span></a></li>';
			if (ot_get_option('ktz_rss_sn') != 'no')
				echo '<li class="rss"><a href="' . get_bloginfo('rss2_url') . '" title="RSS" rel="nofollow"><span class="fontawesome ktzfo-rss"></span></a></li>';
	echo '</ul></div>';
	endif;
	} 
}