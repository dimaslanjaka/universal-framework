<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ THEMES FUNCTION
/* Website    : http://www.kentooz.com
/* The Author : Gian Mokhammad Ramadhan (http://www.gianmr.com)
/* Twitter    : http://www.twitter.com/g14nnakal 
/* Facebook   : http://www.facebook.com/gianmr
/*-----------------------------------------------*/

// Do not load directly...
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/*
* Add extra user field in admin panel
* add_action( 'show_user_profile', 'my_show_extra_profile_fields' ); in init.php
* add_action( 'edit_user_profile', 'my_show_extra_profile_fields' ); in init.php
* add_action( 'personal_options_update', 'my_save_extra_profile_fields' ); in init.php
* add_action( 'edit_user_profile_update', 'my_save_extra_profile_fields' ); in init.php
*/
function ktz_show_extra_profile_fields( $user ) {
	echo '<h3>Social network:</h3>';
	echo '<table class="form-table"><tr><th><label for="twitter">' . __('Twitter', 'ktz_theme_textdomain') . '</label></th>';
	echo '<td><input type="text" name="twitter" id="twitter" value="';
	echo esc_attr( get_the_author_meta( 'twitter', $user->ID ) ); 
	echo '" class="regular-text" /><br /><span class="description">' . __('Please enter your Twitter username without the @.', 'ktz_theme_textdomain') . '</span>';
	echo '</td></tr></table><table class="form-table"><tr>';
	echo '<th><label for="facebook">' . __('Facebook', 'ktz_theme_textdomain') . '</label></th>';
	echo '<td><input type="text" name="facebook" id="facebook" value="';
	echo esc_attr( get_the_author_meta( 'facebook', $user->ID ) );
	echo '" class="regular-text" /><br /><span class="description">' . __('Please enter your facebook full url example http://www.facebook.com/kentoozdotcom.', 'ktz_theme_textdomain') . '</span>';
	echo '</td></tr></table><table class="form-table"><tr><th><label for="googleplus">' . __('Google plus', 'ktz_theme_textdomain') . '</label></th>';
	echo '<td><input type="text" name="googleplus" id="googleplus" value="';
	echo esc_attr( get_the_author_meta( 'googleplus', $user->ID ) );
	echo '" class="regular-text" /><br /><span class="description">' . __('Please enter your google plus full url example http://plus.google.com/100237202599723142598.', 'ktz_theme_textdomain') . '</span>';
	echo '</td></tr></table>';
}
function ktz_save_extra_profile_fields( $user_id ) {
	if ( !current_user_can( 'edit_user', $user_id ) )
		return false;
	update_user_meta( $user_id, 'twitter', $_POST['twitter'] );
	update_user_meta( $user_id, 'facebook', $_POST['facebook'] );
	update_user_meta( $user_id, 'googleplus', $_POST['googleplus'] );
}

/* 
* Add author box in single page
* Add add_action( 'do_ktz_singlecontent', 'ktz_author_box' ); in init.php 
*/
if ( !function_exists('ktz_author_box') ) {
function ktz_author_box() { 
	if ( ot_get_option('ktz_active_autbox') == 'yes' ) :
	if (is_single()) {
		echo '<div class="ktz-authorbox clearfix">';
		echo '<div class="ktz-author-thumb pull-left">';
		echo get_avatar( get_the_author_meta( 'user_email' ), $size='52', '', $alt='author' );
		echo '</div>';
		echo '<div class="ktz-authordesc">';
		echo '<div class="ktz-headauthor">';
		echo __( 'Author:','ktz_theme_textdomain') . '&nbsp;';
		echo the_author_posts_link();
		echo '<ul class="ktz-socialicon pull-right">';
		if (get_the_author_meta('twitter') != '' || get_the_author_meta('facebook') != '' || get_the_author_meta('googleplus') != '' || get_the_author_meta('url') != '' ) {
		if (get_the_author_meta('twitter') != '' ) {
			echo '<li class="twitter"><a href="http://twitter.com/';
			echo the_author_meta('twitter');
			echo '" target="_blank" rel="nofollow" title="' . __( 'Follow','ktz_theme_textdomain') . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on Twitter','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-twitter"></span></a></li>';
			} if (get_the_author_meta('facebook') != '' ) {
			echo '<li class="facebook"><a href="';
			echo the_author_meta('facebook');
			echo '" target="_blank" rel="nofollow" title="' . __( 'Add','ktz_theme_textdomain') . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on facebook','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-facebook"></span></a></li>';
			} if (get_the_author_meta('googleplus') != '' ) {
			echo '<li class="google"><a href="';
			echo the_author_meta('googleplus');
			echo '" target="_blank" rel="nofollow" title="' . __( 'Cycle','ktz_theme_textdomain') . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on googleplus','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-google-plus"></span></a></li>';
			} if (get_the_author_meta('url') != '' ) {
			echo '<li class="rss"><a href="';
			echo the_author_meta('url');
			echo '" target="_blank" rel="nofollow" title="';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'site','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-rss"></span></a></li>';
			} 
		}
		echo '</ul>';
		echo '</div>';
		echo the_author_meta( 'description' );
		echo '</div>';
		echo '</div>';
		}
	endif;
	} 	
}

/* 
* Add author box in single page
* Add add_action( 'do_ktz_singlecontent', 'ktz_author_box' ); in init.php 
*/
if ( !function_exists('ktz_author_box_autpage') ) {
function ktz_author_box_autpage() { 
		echo '<div class="ktz-authorbox clearfix">';
		echo '<div class="ktz-author-thumb pull-left">';
		echo get_avatar( get_the_author_meta( 'user_email' ), $size='52', '', $alt='author' );
		echo '</div>';
		echo '<div class="ktz-authordesc">';
		echo the_author_meta( 'description' );
		echo '</div>';
		echo '<div class="ktz-headauthor">';
		echo '<ul class="ktz-socialicon pull-right">';
		if (get_the_author_meta('twitter') != '' || get_the_author_meta('facebook') != '' || get_the_author_meta('googleplus') != '' || get_the_author_meta('url') != '' ) {
		if (get_the_author_meta('twitter') != '' ) {
			echo '<li class="twitter"><a href="http://twitter.com/';
			echo the_author_meta('twitter');
			echo '" target="_blank" rel="nofollow" title="' . __( 'Follow','ktz_theme_textdomain') . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on Twitter','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-twitter"></span></a></li>';
			} if (get_the_author_meta('facebook') != '' ) {
			echo '<li class="facebook"><a href="';
			echo the_author_meta('facebook');
			echo '" target="_blank" rel="nofollow" title="' . __( 'Add','ktz_theme_textdomain') . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on facebook','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-facebook"></span></a></li>';
			} if (get_the_author_meta('googleplus') != '' ) {
			echo '<li class="google"><a href="';
			echo the_author_meta('googleplus');
			echo '" target="_blank" rel="nofollow" title="' . __( 'Cycle','ktz_theme_textdomain') . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on googleplus','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-google-plus"></span></a></li>';
			} if (get_the_author_meta('url') != '' ) {
			echo '<li class="rss"><a href="';
			echo the_author_meta('url');
			echo '" target="_blank" rel="nofollow" title="';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'site','ktz_theme_textdomain') . '"><span class="fontawesome ktzfo-rss"></span></a></li>';
			} 
		}
		echo '</ul>';
		echo '</div>';
		echo '</div>';

	} 	
}