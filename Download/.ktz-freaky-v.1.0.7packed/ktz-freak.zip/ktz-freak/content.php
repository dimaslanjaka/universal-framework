<?php
/**
 * KENTOOZ DEFAULD POST TEMPLATE
**/
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('box-post ktz-archive'); ?>>
	<div class="inner-box">
	<h2 class="entry-title"><a href="<?php the_permalink() ?>" rel="bookmark"><?php the_title() ?></a></h2>
	<div class="meta-post">
		<?php hook_ktz_content_meta(); ?>
	</div>
	<div class="entry-body media">
		<?php echo ktz_featured_img( 250,170 ); // New kentooz image croping just call ktz_featured_img( width, height )  ?>
	<div class="media-body ktz-post">
		<?php hook_ktz_content(); ?>
	</div>
	</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->