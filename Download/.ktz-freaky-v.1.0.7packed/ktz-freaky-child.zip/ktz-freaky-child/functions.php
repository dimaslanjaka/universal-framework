<?php
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK
/* Version :1.01
/* You can add your own function here! 
/* But don't change anything in this file!
/*-----------------------------------------------*/

remove_action( 'init', 'ktz_register_css');
function ktz_register_css_child() {
	if( !is_admin() ) {
		/*
		 * default_theme_fonts from includes/admin/googlefont/functions.php
		 */
		global $default_theme_fonts;
		
		$getheadinggfont = ot_get_option( 'ktz_heading_font' );	
		$getbodygfont = ot_get_option( 'ktz_body_font' );		
		
		$getheadinggfont_arr = '';
		if( isset($getheadinggfont['font-family']) ){
			$getheadinggfont_arr = $getheadinggfont['font-family'];
			$getheadinggfont_arr = str_replace(' ', '+', $getheadinggfont_arr);
		}
		$getbodygfont_arr = '';
		if( isset($getbodygfont['font-family'])  ){
			$getbodygfont_arr = $getbodygfont['font-family'];
			$getbodygfont_arr = str_replace(' ', '+', $getbodygfont_arr);
		}
		
		if (! empty ( $getheadinggfont['font-family'] ) && ! empty ( $getbodygfont['font-family'] ) ) {
			$gofontfamily = $getheadinggfont_arr . '|' . $getbodygfont_arr;
		} elseif (! empty ( $getheadinggfont['font-family'] ) ) {
			$gofontfamily = $getheadinggfont_arr . '|Open+Sans:light,lightitalic,regular,regularitalic,600,600italic,bold,bolditalic,800,800italic';
		} elseif (! empty ( $getbodygfont['font-family'] ) ) {
			$gofontfamily = 'Bree+Serif|' . $getbodygfont_arr;
		} else {
			$gofontfamily = 'Bree+Serif|Open+Sans:light,lightitalic,regular,regularitalic,600,600italic,bold,bolditalic,800,800italic';
		}
		
		$query_args = array(
			'family' => $gofontfamily
		);
		wp_register_style( 'ktz_google_font_link', add_query_arg( $query_args, "//fonts.googleapis.com/css" ), array(), '1.0', 'all' );
		wp_register_style( 'ktz-bootstrap-min',ktz_url . 'includes/assets/css/bootstrap.min.css', array(), '1.0', 'screen, projection' );
		wp_register_style( 'ktz-video-min',ktz_url . 'includes/assets/video-js/video-js.min.css', array(), '1.0', 'all' );
		wp_register_style( 'ktz-main-css',get_stylesheet_directory_uri() . '/style.css',array(), '1.0', 'all' );
		if( ot_get_option( 'ktz_styledefault' ) != '' ) { 
			$styledefault = '';
			if( ot_get_option('ktz_styledefault') ){
			$styledefault = ot_get_option('ktz_styledefault');
			}
		wp_register_style( 'ktz-default-css',ktz_url . 'includes/assets/css/' . $styledefault,array(), '1.0', 'screen' ); 
		}
	}
}
add_action( 'init', 'ktz_register_css_child' );