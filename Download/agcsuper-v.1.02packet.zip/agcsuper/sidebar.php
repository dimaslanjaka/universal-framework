<div class="span4 widget-area sbar wrapwidget" role="complementary">
<?php 	
if ( is_page() ) {
	$post_mt = get_post_meta( $posts[0]->ID, 'page_meta', true );
	$sidebar_rgt = (isset($post_mt['sidebar_rgt'])) ? $post_mt['sidebar_rgt'] : 'sidebar_default';
}
elseif ( is_singular('product') ) {
	$product_mt = get_post_meta( $posts[0]->ID, 'product_meta', true );
	$sidebar_rgt = (isset($product_mt['sidebar_rgt'])) ? $product_mt['sidebar_rgt'] : 'sidebar_default';
} 
elseif ( is_singular() ) {
	$page_mt = get_post_meta( $posts[0]->ID, 'post_meta', true );
	$sidebar_rgt = (isset($page_mt['sidebar_rgt'])) ? $page_mt['sidebar_rgt'] : 'sidebar_default';
} 
	if ( is_page() || is_single() ) {	
		if ( is_active_sidebar($sidebar_rgt)) : dynamic_sidebar($sidebar_rgt); endif;
    } else {
		if ( is_active_sidebar('sidebar_default')) : dynamic_sidebar('sidebar_default'); endif;
	}
?>
</div>
