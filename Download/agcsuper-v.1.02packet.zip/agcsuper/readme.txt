<strong>INSTALL</strong>
1. Upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress dashboard and select Appearance.
3. Be sure to activate the kasep theme
4. Inside your WordPress dashboard, go to kasep options to setting your website.

<strong>Kapro Changelog</strong>
02/05/2013 - Version 1.01
* Fixed little bugs in css
* Module 1 magazine page can be unlimited box
* Fixed little in admin panel and attachment page
01/24/2013 - Version 1.0
* Theme release

<strong>Author link</strong>
<a href="http://www.kentooz.com/">http://kentooz.com</a>
