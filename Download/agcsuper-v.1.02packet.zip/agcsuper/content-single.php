<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?>>
	<?php ktz_setPostViews(get_the_ID()); //get view for single post ?>
		<div class="title-box">	
			<?php echo ktz_posted_title_nonlink_h('h1','single-title'); ?>
		</div>
	<div class="bgstripes-meta">
		<span class="bgstripe color1"><?php echo ktz_author_by(); ?></span>
		<span class="bgstripe color4"><?php echo ktz_posted_on(); ?></span>
		<span class="bgstripe color2"><?php echo ktz_socialshare_fb(); ?></span>
		<span class="bgstripe color11"><?php echo ktz_socialshare_twit(); ?></span>
		<span class="bgstripe color10"><?php echo ktz_socialshare_gplus(); ?></span>
	</div>
			<div class="post-box-single">
			
			<?php hook_ktz_singletitban(); //banner ?>
			
			<?php echo ktz_ban336_topsingle_right(); //content ?>
			<?php if ( get_theme_option('ktz_ban336_topsingle_right_set') != '' ) : ?>
			<div class="content-inbanner">
			<?php endif; ?>
			<?php echo ktz_content(); //content ?>
			<?php if ( get_theme_option('ktz_ban336_topsingle_right_set') != '' ) : ?>
			</div>
			<?php endif; ?>
			<?php echo ktz_ban46860_singlefoot(); ?>
			
			<?php echo ktz_author_box(); ?>
			
			<?php echo ktz_relpost(); ?>
			<?php if (get_theme_option('ktz_agc_activated') !="") : ?>
			<?php echo ktz_agc_bing_single(); ?>
			<?php endif; ?>
			
			<div class="meta-post-single clearfix">	
				<?php echo ktz_default_nav(); ?>
			</div>
			<ul class="nav nav-tabs" id="kentooz-comment">
				<?php if ( get_theme_option('ktz_facebook_com_activated') != '' ) : ?>
				<li><a href="#comfacebook" data-toggle="tab" title="Facebook comment"><?php _e( 'FB Comments', ktz_theme_textdomain ); ?></a></li>
				<?php endif; ?>
				<?php if ( get_theme_option('ktz_google_com_activated') != '' ) : ?>
				<li><a href="#comgoogle" data-toggle="tab" title="Google comment"><?php _e( 'Google+ Comments', ktz_theme_textdomain ); ?></a></li>
				<?php endif; ?>
			</ul>
			<div class="tab-content">
			<?php if ( get_theme_option('ktz_facebook_com_activated') != '' ) : ?>
			<div class="tab-pane" id="comfacebook">
				<div class="wrapcomment">
				<?php echo ktz_comments_facebook(); ?>
				</div>
			</div>
			<?php endif; ?>
			<?php if ( get_theme_option('ktz_google_com_activated') != '' ) : ?>
			<div class="tab-pane" id="comgoogle">
				<div class="wrapcomment">
					<div style="width: 100%">
					<?php echo ktz_comments_google(); ?>
					</div>
				</div>
			</div>
			<?php endif; ?>
			</div>

		</div>
</article><!-- #post-<?php the_ID(); ?> -->