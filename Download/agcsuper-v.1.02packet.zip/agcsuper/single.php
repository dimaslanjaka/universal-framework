<?php 
/**
 * KENTOOZ SINGLE PAGE TEMPLATE
**/
get_header(); ?>
	<section class="span12">
	<div class="row">
	<?php if ( get_theme_option('ktz_sb_layout') == 'left' ) : get_sidebar(); endif; ?>
	<div role="main" class="span8">
		<section class="new-content">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'content', 'single' ); ?>
		<?php endwhile; // end of the loop. ?>
		</section>
	</div>
	<?php if ( get_theme_option('ktz_sb_layout') == 'right' ) : get_sidebar(); endif; ?>
	</div>
	</section>
<?php get_footer(); ?>