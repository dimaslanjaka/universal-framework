<?php 
/**
 * KENTOOZ INDEX TEMPLATE
**/
get_header(); ?>
	<section class="span12">
	<div class="row">
	<?php if ( get_theme_option('ktz_sb_layout') == 'left' ) : get_sidebar(); endif; ?>
		<div role="main" class="span8">
		<section class="new-content">

			<!-- Conditional Statements for .page-heading -->
			<?php /* If this is a tag archive */ if( is_tag() ) { ?>
			<h1 class="widget-title page-title"><span><?php _e('Posts tagged with', ktz_theme_textdomain); ?> &#8216;<?php single_tag_title(); ?>&#8217;</span></h1>
			<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
			<h1 class="widget-title page-title"><span><?php _e('Archive for', ktz_theme_textdomain); ?> <?php the_time('F jS, Y'); ?></span></h1>
			<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
			<h1 class="widget-title page-title"><span><?php _e('Archive for', ktz_theme_textdomain); ?> <?php the_time('F, Y'); ?></span></h1>
			<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
			<h1 class="widget-title page-title"><span><?php _e('Archive for', ktz_theme_textdomain); ?> <?php the_time('Y'); ?></span></h1>
			<?php /* If this is an author archive */ } elseif (is_author()) { ?>
			<?php $author = get_userdata( get_query_var('author') );?>
			<h1 class="widget-title page-title"><span><?php _e('Author archive for', ktz_theme_textdomain); ?> <?php echo $author->display_name;?></h1>
			<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
			<h1 class="widget-title page-title"><span><?php _e('Blog Archives', ktz_theme_textdomain); ?></span></h1>
			<?php /* If this is an category archive */ } elseif (is_category()) { ?>
			<h1 class="widget-title page-title"><span><?php single_cat_title(); ?></span></h1>
			<?php } else { ?>
			<h1 class="widget-title page-title"><span><?php wp_title( '|', true, 'right' ); ?></span></h1>
			<?php } ?>
		
		<?php if ( have_posts() ) : ?>
		<?php while ( have_posts() ) : the_post();
			get_template_part( 'content', get_post_format() );
		endwhile; ?>
		<nav id="nav-index">
			<?php ktz_navigation(); ?>
		</nav>
		<?php else : ktz_post_notfound(); endif; ?>
		</section>
		</div>
	<?php if ( get_theme_option('ktz_sb_layout') == 'right' ) : get_sidebar(); endif; ?>
	</div>
	</section>
<?php get_footer(); ?>
