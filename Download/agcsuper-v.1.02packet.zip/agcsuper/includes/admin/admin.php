<?php

// Call admin functions
	require_once(ktz_inc . 'admin/functions/optionselect.php');
	require_once(ktz_inc . 'admin/functions/theme.php');
	require_once(ktz_inc . 'admin/functions/googlefontarray.php');
	require_once(ktz_inc . 'admin/functions/core.php');
	require_once(ktz_inc . 'admin/functions/setting.php');

// Add admin menu and name for admin menu
function mytheme_add_admin() {
	global $themename, $shortname, $options;
		if ( isset($_GET['page']) && ($_GET['page'] == basename(__FILE__)) ) {
			adminktz_save_data();
		}
	$admin_page = add_theme_page($themename . " options", "".$themename . " options", 'edit_theme_options', 'theme_options', 'mytheme_admin');
	add_action("admin_print_scripts-{$admin_page}", 'my_admin_scripts');
	add_action("admin_print_styles-{$admin_page}", 'my_admin_styles');
}
add_action('admin_menu', 'mytheme_add_admin');

function ktz_add_admin_redirect() {
    global $pagenow;
    if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' )
    {
    wp_redirect( admin_url( 'themes.php?page=theme_options' ) );
    exit;
    }
}
add_action( 'after_setup_theme', 'ktz_add_admin_redirect' );	

?>