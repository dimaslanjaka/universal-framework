<?php
/*** Kentooz function select framework for admin ***/

function fontsize_select()
{
	$fontsize_array[] = array('value'=>'10px','title'=>'10px');
	$fontsize_array[] = array('value'=>'11px','title'=>'11px');
	$fontsize_array[] = array('value'=>'12px','title'=>'12px');
	$fontsize_array[] = array('value'=>'13px','title'=>'13px');
	$fontsize_array[] = array('value'=>'14px','title'=>'14px');
	$fontsize_array[] = array('value'=>'15px','title'=>'15px');
	$fontsize_array[] = array('value'=>'16px','title'=>'16px');
	$fontsize_array[] = array('value'=>'17px','title'=>'17px');
	$fontsize_array[] = array('value'=>'18px','title'=>'18px');
	$fontsize_array[] = array('value'=>'19px','title'=>'19px');
	$fontsize_array[] = array('value'=>'20px','title'=>'20px');
	$fontsize_array[] = array('value'=>'21px','title'=>'21px');
	$fontsize_array[] = array('value'=>'22px','title'=>'22px');
	$fontsize_array[] = array('value'=>'23px','title'=>'23px');
	$fontsize_array[] = array('value'=>'24px','title'=>'24px');
	return $fontsize_array;
}

function layout_select()
{
	$layout_select[] = array('value'=>'full','title'=>'Full');
	$layout_select[] = array('value'=>'half_half','title'=>'1/2 : 1/2');
	$layout_select[] = array('value'=>'onethird_onethird_onethird','title'=>'1/3 : 1/3 : 1/3');
	$layout_select[] = array('value'=>'twothird_onethird','title'=>'2/3 : 1/3');
	$layout_select[] = array('value'=>'onethird_twothird','title'=>'1/3 : 2/3');
	$layout_select[] = array('value'=>'onefourth_onefourth_onefourth_onefourth','title'=>'1/4 : 1/4 : 1/4 : 1/4');
	$layout_select[] = array('value'=>'threefourth_onefourth','title'=>'3/4 : 1/4');
	$layout_select[] = array('value'=>'onefourth_threefourth','title'=>'1/4 : 3/4');
	$layout_select[] = array('value'=>'onesixth_onesixth_onesixth_onesixth_onesixth_onesixth','title'=>'1/6 : 1/6 : 1/6 : 1/6 : 1/6 : 1/6');
	$layout_select[] = array('value'=>'fivesixth_onesixth','title'=>'5/6 : 1/6');
	$layout_select[] = array('value'=>'onesixth_fivesixth','title'=>'1/6 : 5/6');
	return $layout_select;
}

function bloglayout_select()
{
	$bloglayout_select[] = array('value'=>'bloglayout_1','title'=>'blog layout 1');
	$bloglayout_select[] = array('value'=>'bloglayout_2','title'=>'blog layout 2');
	return $bloglayout_select;
}

function agc_select()
{
	$agc_select[] = array('value'=>'agc_draft','title'=>'Save as draft');
	$agc_select[] = array('value'=>'agc_publish','title'=>'Publish');
	return $agc_select;
}

function ratting_select()
{
	$ratting_select[] = array('value'=>'0','title'=>'0');
	$ratting_select[] = array('value'=>'0.5','title'=>'0.5');
	$ratting_select[] = array('value'=>'1','title'=>'1');
	$ratting_select[] = array('value'=>'1.5','title'=>'1.5');
	$ratting_select[] = array('value'=>'2','title'=>'2');
	$ratting_select[] = array('value'=>'2.5','title'=>'2.5');
	$ratting_select[] = array('value'=>'3','title'=>'3');
	$ratting_select[] = array('value'=>'3.5','title'=>'3.5');
	$ratting_select[] = array('value'=>'4','title'=>'4');
	$ratting_select[] = array('value'=>'4.5','title'=>'4.5');
	$ratting_select[] = array('value'=>'5','title'=>'5');
	return $ratting_select;
}

function autostylish_select() {
	$alt_stylesheet_path = ktz_dir . 'css/style/';
	$autostylish_select = array();
	$autostylish_select[] = array('value'=> '' ,'title'=> 'Default');
	if ( is_dir($alt_stylesheet_path) ) {
    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) {
        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
            if(stristr($alt_stylesheet_file, '.css') !== false) {
                $autostylish_select[] = array('value'=> $alt_stylesheet_file ,'title'=> $alt_stylesheet_file);
            }
        }
		}
	return $autostylish_select;
	}
}

function fontdefault_select()
{
	$fontdefault_array[] = array("value"=>"Arial, Helvetica, sans-serif","title" => "Arial, Helvetica, sans-serif");
	$fontdefault_array[] = array("value"=>"'Arial Black', Gadget, sans-serif","title" => "'Arial Black', Gadget, sans-serif");
	$fontdefault_array[] = array("value"=>"'Bookman Old Style', serif","title" => "'Bookman Old Style', serif");
	$fontdefault_array[] = array("value"=>"'Comic Sans MS', cursive","title" => "'Comic Sans MS', cursive");
	$fontdefault_array[] = array("value"=>"Courier, monospace","title" => "Courier, monospace");
	$fontdefault_array[] = array("value"=>"Garamond, serif","title" => "Garamond, serif");
	$fontdefault_array[] = array("value"=>"Georgia, serif","title" => "Georgia, serif");
	$fontdefault_array[] = array("value"=>"Impact, Charcoal, sans-serif","title" => "Impact, Charcoal, sans-serif");
	$fontdefault_array[] = array("value"=>"'Lucida Console', Monaco, monospace","title" => "'Lucida Console', Monaco, monospace");
	$fontdefault_array[] = array("value"=>"'Lucida Sans Unicode', 'Lucida Grande', sans-serif","title" => "'Lucida Sans Unicode', 'Lucida Grande', sans-serif");
	$fontdefault_array[] = array("value"=>"'MS Sans Serif', Geneva, sans-serif","title" => "'MS Sans Serif', Geneva, sans-serif");
	$fontdefault_array[] = array("value"=>"'MS Serif', 'New York', sans-serif","title" => "'MS Serif', 'New York', sans-serif");
	$fontdefault_array[] = array("value"=>"'Palatino Linotype', 'Book Antiqua', Palatino, serif","title" => "'Palatino Linotype', 'Book Antiqua', Palatino, serif");
	$fontdefault_array[] = array("value"=>"Tahoma, Geneva, sans-serif","title" => "Tahoma, Geneva, sans-serif");
	$fontdefault_array[] = array("value"=>"'Times New Roman', Times, serif","title" => "'Times New Roman', Times, serif");
	$fontdefault_array[] = array("value"=>"'Trebuchet MS', Helvetica, sans-serif","title" => "'Trebuchet MS', Helvetica, sans-serif");
	$fontdefault_array[] = array("value"=>"Verdana, Geneva, sans-serif","title" => "Verdana, Geneva, sans-serif");
	$fontdefault_array[] = array("value"=>"Webdings, sans-serif","title" => "Webdings, sans-serif");
	$fontdefault_array[] = array("value"=>"Wingdings, 'Zapf Dingbats', sans-serif","title" => "Wingdings, 'Zapf Dingbats', sans-serif");
	return $fontdefault_array;
}


function cats_to_select()
{
	$categories = get_categories('hide_empty=0'); 
	$categories_array[] = array('value'=>'0', 'title'=>'Select');
	foreach ($categories as $cat) {
		if($cat->category_count == '0') {
			$posts_title = 'No posts!';
		} elseif($cat->category_count == '1') {
			$posts_title = '1 post';
		} else {
			$posts_title = $cat->category_count . ' posts';
		}
		$categories_array[] = array('value'=> $cat->cat_ID, 'title'=> $cat->cat_name . ' ( ' . $posts_title . ' )');
	  }
	return $categories_array;
}

function orderby_to_select()
{
	$orderby_array[] = array('value'=>'date','title'=>'Date');
	$orderby_array[] = array('value'=>'comment_count','title'=>'Comment count');
	$orderby_array[] = array('value'=>'author','title'=>'Author');
	$orderby_array[] = array('value'=>'title','title'=>'Title');
	return $orderby_array;
}

function numberten_select()
{
	$numberten_select[] = array('value'=>'1','title'=>'1');
	$numberten_select[] = array('value'=>'2','title'=>'2');
	$numberten_select[] = array('value'=>'3','title'=>'3');
	$numberten_select[] = array('value'=>'4','title'=>'4');
	$numberten_select[] = array('value'=>'5','title'=>'5');
	$numberten_select[] = array('value'=>'6','title'=>'6');
	$numberten_select[] = array('value'=>'7','title'=>'7');
	$numberten_select[] = array('value'=>'8','title'=>'8');
	$numberten_select[] = array('value'=>'9','title'=>'9');
	$numberten_select[] = array('value'=>'10','title'=>'10');
	return $numberten_select;
}

function nav_select()
{
	$nav_array[] = array('value'=>'default','title'=>'Default navigation');
	$nav_array[] = array('value'=>'number','title'=>'Number navigation');
	return $nav_array;
}

function menudepth_select()
{
	$menudepth_array[] = array('value'=>'1','title'=>'1');
	$menudepth_array[] = array('value'=>'2','title'=>'2');
	$menudepth_array[] = array('value'=>'3','title'=>'3');
	return $menudepth_array;
}

function truefalse_select()
{
	$truefalse_array[] = array('value'=>'true','title'=>'True');
	$truefalse_array[] = array('value'=>'false','title'=>'False');
	return $truefalse_array;
}

function float_select()
{
	$float_array[] = array('value'=>'left','title'=>'Left');
	$float_array[] = array('value'=>'right','title'=>'Right');
	return $float_array;
}

function repeatimg_select()
{
	$repeatimg_array[] = array('value'=>'','title'=>'select');
	$repeatimg_array[] = array('value'=>'repeat','title'=>'Repeat');
	$repeatimg_array[] = array('value'=>'repeat-x','title'=>'Repeat x');
	$repeatimg_array[] = array('value'=>'repeat-y','title'=>'Repeat Y');
	$repeatimg_array[] = array('value'=>'no-repeat','title'=>'No Repeat');
	return $repeatimg_array;
}

function attachimg_select()
{
	$attachimg_array[] = array('value'=>'','title'=>'select');
	$attachimg_array[] = array('value'=>'fixed','title'=>'Fixed');
	$attachimg_array[] = array('value'=>'scroll','title'=>'Scroll');
	$attachimg_array[] = array('value'=>'inherit','title'=>'Inherit');
	return $attachimg_array;
}

function positionimg_select()
{
	$positionimg_array[] = array('value'=>'','title'=>'select');
	$positionimg_array[] = array('value'=>'left top','title'=>'Left Top');
	$positionimg_array[] = array('value'=>'left center','title'=>'Left Center');
	$positionimg_array[] = array('value'=>'left bottom','title'=>'Left Bottom');
	$positionimg_array[] = array('value'=>'right top','title'=>'Right Top');
	$positionimg_array[] = array('value'=>'right center','title'=>'Right Center');
	$positionimg_array[] = array('value'=>'right bottom','title'=>'Right Bottom');
	$positionimg_array[] = array('value'=>'center top','title'=>'Center Top');
	$positionimg_array[] = array('value'=>'center center','title'=>'Center Center');
	$positionimg_array[] = array('value'=>'center bottom','title'=>'Center Bottom');
	return $positionimg_array;
}

function fullfloat_select()
{
	$fullfloat_array[] = array('value'=>'full','title'=>'Full');
	$fullfloat_array[] = array('value'=>'left','title'=>'Left');
	$fullfloat_array[] = array('value'=>'right','title'=>'Right');
	return $fullfloat_array;
}

function taxonomy_select()
{
	$taxonomy_array[] = array('value'=>'category','title'=>'Category');
	$taxonomy_array[] = array('value'=>'tags','title'=>'Tags');
	return $taxonomy_array;
}

?>