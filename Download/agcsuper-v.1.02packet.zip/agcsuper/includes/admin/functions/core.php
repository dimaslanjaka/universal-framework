<?php
/* Kentooz framework for call functions admin */

// Get theme options
if ( !function_exists( 'get_theme_option' ) ) {
function get_theme_option($option) {
	global $shortname;
	return stripslashes_deep(get_option($shortname . '_' . $option));
	}
}

// Get theme settings
if ( !function_exists( 'get_theme_settings' ) ) {
function get_theme_settings($option) {
	return stripslashes_deep(get_option($option));
	}
}

// Get theme settings
function mytheme_admin_init() {
    global $themename, $shortname, $pagenow, $options;
    $get_theme_options = get_option($shortname . '_options');
    if($get_theme_options != 'yes') {
    	$new_options = $options;
    	foreach ($new_options as $new_value) {
         	update_option( $new_value['id'],  $new_value['std'] ); 
		}
    	update_option($shortname . '_options', 'yes');
    }
}

// Ajax callback for kentooz framework admin
function my_action_callback() {
    check_ajax_referer("adminktz_nonce");
	adminktz_save_data();
	die();
}
add_action('wp_ajax_save_ktz', 'my_action_callback');

// Save data for admin
function adminktz_save_data(){
	global $options;
	ktz_get_standard();
	$valuesArray = array();
	if ( isset($_REQUEST['action']) ) {
		 if ( 'save_ktz' == $_REQUEST['action'] )  {
			foreach ($options as $value) {
				if( isset( $value['id'] ) ) { 
					if( isset( $_REQUEST[ $value['id'] ] ) ) {
						if ($value['type'] == 'textarea' || $value['type'] == 'text' || $value['type'] == 'textlimit' || $value['type'] == 'upload') update_option( $value['id'], stripslashes($_REQUEST[$value['id']]) );
						elseif ($value['type'] == 'select') update_option( $value['id'], htmlspecialchars($_POST[$value['id']]) );
						else update_option( $value['id'], $_POST[$value['id']] );
					}
					else {
						if ($value['type'] == 'checkbox') update_option( $value['id'] , $_POST[$value['id']] );
						else delete_option( $value['id'] );
					}
				}
				
				$valuesArray[$value['id']] = $_POST[$value['id']];
			}
                header("Location: themes.php?page=theme_options&saved=true");
                die;
        } else if( 'reset_ktz' == $_REQUEST['action'] ) {
			foreach ($options as $value) {
				if (isset($value['id'])) {
					delete_option( $value['id'] );
					if (isset($value['std'])) $value['id'] = $value['std'];
				};
			}
            header("Location: themes.php?page=theme_options&reset=true");
            die;
        }
	}
}

function ktz_get_standard(){
	global $options, $value, $shortname;
	$options = ktz_options_framework();
	if(is_array($options)){
	foreach ($options as $value) {
	if (isset($value['id'])) {
		if ( get_option( $value['id'] ) === FALSE) {
			if (array_key_exists('std', $value)) { 
				update_option( $value['id'], $value['std'] );
				$$value['id'] = $value['std'];
			}
		} else {
			$$value['id'] = get_option( $value['id'] ); 
		}
	} 
	}
	}
}

	
?>