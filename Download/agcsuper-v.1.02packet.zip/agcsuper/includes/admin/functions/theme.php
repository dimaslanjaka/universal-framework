<?php
/* Kentooz theme interface framework V.1.0 */

// Add javascripts for admin
function my_admin_scripts() {
	wp_enqueue_script('media-upload');
	wp_enqueue_script('thickbox');
	wp_enqueue_script('jquery-form');
	wp_enqueue_script('jquery-ui-tabs');
	wp_enqueue_script('rm_script', ktz_styleinc . 'admin/jscss/kentoozadmin.js', false, '1.0');
	wp_enqueue_script('colorpick', ktz_styleinc . 'admin/jscss/colorpicker.js', false, '1.0');
	wp_enqueue_script('checkbox', ktz_styleinc . 'admin/jscss/checkbox.js', false, '1.0');
	wp_enqueue_script('admincp_functions_init', ktz_styleinc . 'admin/jscss/ajax-init.js');
	wp_localize_script('admincp_functions_init', 'admincpSettings', array('clearpath' => ktz_styleinc . 'admin/jscss/images/empty.png','adminktz_nonce' => wp_create_nonce('adminktz_nonce')));
}
add_action('admin_enqueue_scripts-themes.php?page=theme_options', 'my_admin_scripts');

// Add CSS for admin
function my_admin_styles() {
	wp_enqueue_style('thickbox');
	wp_enqueue_style('functions', ktz_styleinc . 'admin/jscss/functions.css', false, '1.0', 'all');
	wp_enqueue_style('colorpictcss', ktz_styleinc . 'admin/jscss/colorpicker.css', false, '1.0', 'all');
}
add_action('admin_enqueue_styles-themes.php?page=theme_options', 'my_admin_scripts');

// Get latest themes
function ktz_latest_theme($interval) {
	$notifier_file_url = 'http://www.kentooz.com/latest-themes.xml';
	$db_cache_field = 'contempo-notifier-cache';
	$db_cache_field_last_updated = 'contempo-notifier-last-updated';
	$last = get_option( $db_cache_field_last_updated );
	$now = time();
	if ( !$last || (( $now - $last ) > $interval) ) {
		if( function_exists('curl_init') ) { 
			$ch = curl_init($notifier_file_url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_TIMEOUT, 10);
			$cache = curl_exec($ch);
			curl_close($ch);
		} else {
			$cache = file_get_contents($notifier_file_url);
		}
		if ($cache) {			
			update_option( $db_cache_field, $cache );
			update_option( $db_cache_field_last_updated, time() );			
		}
		$notifier_data = get_option( $db_cache_field );
	}
	else {
		$notifier_data = get_option( $db_cache_field );
	}
	$xml = simplexml_load_string($notifier_data); 
	return $xml;
}

function ktz_themes_info() { 
	$xml = ktz_latest_theme(11600); // This tells the function to cache the remote call for 21600 seconds (6 hours)
	$kentooz_theme = wp_get_theme();
		echo '<div class="ktztitle"><strong>Theme Information</strong></div>';
		echo '<div class="ktz_systemstatus">';
		echo '<div class="list_systemstatus"><ul>';		
		echo '<li><strong>Theme Name:</strong> ' . $kentooz_theme->Name . '</li>';
	    echo '<li><strong>Theme Version:</strong> ' . $kentooz_theme->Version . '</li>';
		echo '<li><strong>Author:</strong> ' . $kentooz_theme->get( 'ThemeURI' ) . '</li>';
		echo '</ul></div>';
		echo '</div><div class="clear"></div>';	
	    echo '<div class="ktztitle"><strong>Latest release themes from kentooz</strong></div>';
		echo '<div class="ktz_systemstatus">';
		echo '<div class="list_systemstatus">';
	    echo $xml->ktzlatestthemes;
		echo '</div>';
		echo '</div>';
} 

// Jquery for head admin
if ( !function_exists('ktz_admin_customscript') ) {
function ktz_admin_customscript() {
global $options;
if (isset($_GET['page'])) { 
    if ($_GET['page'] == "theme_options") {
	echo '<script type="text/javascript" language="javascript">';
	echo 'jQuery(document).ready(function(){';
	$options = ktz_options_framework();
	if(is_array($options)){
		foreach($options as $option){ 
		if($option['type'] == 'color' || $option['type'] == "minicolor"){
		$option_id = $option['id'];
		$color = get_option($option_id);	
	echo 'jQuery(\'#' . $option_id . '_picker\').children(\'div\').css(\'backgroundColor\', \'' . $color . '\');';    
	echo 'jQuery(\'#' . $option_id . '_picker\').ColorPicker({';
	echo 'color: \'' . $color . '\',';
	echo 'onShow: function (colpkr) { jQuery(colpkr).fadeIn(500); return false; },';
	echo 'onHide: function (colpkr) { jQuery(colpkr).fadeOut(500); return false;},';
	echo 'onChange: function (hsb, hex, rgb) { ';
	echo 'jQuery(\'#' . $option_id . '_picker\').children(\'div\').css(\'backgroundColor\', \'#\' + hex);';
	echo 'jQuery(\'#' . $option_id . '_picker\').next(\'input\').attr(\'value\',\'#\' + hex);';
	echo '}});';
	} } }
	// Jquery Checkbox
	echo 'jQuery(\'input.checkbox\').checkbox({';
		echo 'empty: \'' . ktz_styleinc . 'admin/jscss/images/empty.png\'});';
	//Live preview
		foreach($options as $option){ 
		if($option['type'] == 'preview'){
		$option_id = $option['id'];              
		echo 'jQuery(\'#' . $option_id . '\').click( function(){';
        echo 'var font = jQuery(\'#' . $option_id . ' option:selected\').val();';
		echo 'jQuery(\'body\').append("<link rel=\'stylesheet\' href=\'http://fonts.googleapis.com/css?family=" + escape(jQuery(this).val()) + "\' type=\'text/css\' media=\'all\' />");';
        echo 'jQuery(\'.' . $option_id . '_live_preview\').css(\'font-family\',font)';
        echo '});';
	} }
	// Jquery radio with image
	foreach($options as $option){ 
	if($option['type'] == 'images'){
		$option_id = $option['id'];
		$color = get_option($option_id);
	echo 'jQuery(\'.of-radio-img-img_' . $option_id . '\').click(function(){';
	echo 'jQuery(this).parent().parent().find(\'.of-radio-img-img_' . $option_id . '\').removeClass(\'of-radio-img-selected\');';
	echo 'jQuery(this).addClass(\'of-radio-img-selected\');';			
	echo '});';
	echo 'jQuery(\'.of-radio-img-label\').hide();';
	echo 'jQuery(\'.of-radio-img-img\').show();';
	echo 'jQuery(\'.of-radio-img-radio\').hide();';
	} } 
	echo '})';
	echo '</script>';
	}
}
}
}
add_action( 'admin_head', 'ktz_admin_customscript' );

function ktz_let_to_num( $size ) {
    $let = substr( $size, -1 );
	$ret = substr( $size, 0, -1 );
        switch( strtoupper( $let ) ) {
     	case 'P':
     	    $ret *= 1024;
     	case 'T':
     	    $ret *= 1024;
     	case 'G':
     	    $ret *= 1024;
     	case 'M':
     	    $ret *= 1024;
     	case 'K':
     	    $ret *= 1024;
        }
    return $ret;
}

// Field admin
function ktz_admin_fields() {
	global $options, $themename,$themeversion;
	ktz_get_standard();
	foreach ($options as $value) {  
	switch ( $value['type'] ) {	
		case "wrap_start" : 
			echo '<div class="ss_wrap">';
			break;
		case "wrap_end" :
			echo '</div>';
			break;
		case "open" : 
			echo '<div class="item_row">';
			break;
		case "close" :
			echo '</div>';
			break;
		case "title" :
			echo '<div class="ktztitle"><h3>' . esc_attr ( $value['name'] ) . '</h3></div>';
			break;
		case "optiontitle" :
			echo '<div class="ktztitle"><strong>' . esc_attr ( $value['name'] ) . '</strong>';
			echo '<img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" />';
			echo '<div class="ktzdesc">' . esc_attr ( $value['desc'] ) . '</div>';
			echo '</div>';
			break;
		case "credits" :
			echo '<div class="ktzcredit"><strong>kentooz admin version 2</strong></div>';
			break;
		case 'text' :
			echo '<div class="ktztitle"><strong>' . esc_attr ( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr ( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktzinput"><input style="width:100%;" name="' . esc_attr ( $value['id'] ) . '" id="' . esc_attr ( $value['id'] ) . '" type="' . esc_attr ( $value['type'] ) . '" value="' . get_theme_settings( esc_attr ( $value['id'] ) ) . '" /></div>';
			break;
		case 'color' :
			echo '<div class="ktztitle"><strong>' . esc_attr ( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr ( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktzinput"><div id="' . esc_attr ( $value['id'] ) .'_picker" class="colorSelector"><div></div></div><input class="of-color" style="width:25%;" name="' . esc_attr ( $value['id'] ) . '" id="' . esc_attr ( $value['id'] ) . '" type="' . esc_attr ( $value['type'] ) .'" value="' . get_theme_settings( esc_attr ( $value['id'] ) ) .'" /></div>';
			break;
		case 'upload' :
			echo '<div class="ktztitle"><strong>' . esc_attr ( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr ( $value['desc'] ) . '</div></div>';	
			$current_image = get_theme_settings( esc_attr ( $value['id'] ) );
			echo '<div id="' . esc_attr ( $value['id'] ) .'_preview" style="';
			if(!$current_image) { echo 'display: none;'; }
			echo '" class="image-preview" >';
			if($current_image) { echo '<a href="' . $current_image . '" target="_blank"><img src="' . $current_image . '" title="The image might be resized, click for full preview!" alt=""  /></a><br />'; }
			echo '</div>';
			echo '<div class="ktzinput"><input id="' . esc_attr ( $value['id'] ) . '" class="upload_field " style="width:100%;" type="text" size="90" name="' . esc_attr ( $value['id'] ) . '" value="' . (get_option( esc_attr ( $value['id'] ))) . '" /><input class="upload_image_button button-secondary" type="button" value="Upload Image" /></div>';
			break;
		case 'textarea' :
			echo '<div class="ktztitle"><strong>' . esc_attr ( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr ( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktzinput"><textarea name="' . esc_attr ( $value['id'] ) . '" style="width:100%; height:140px;" type="' . esc_attr ( $value['type'] ) .'" cols="" rows="">' . get_theme_settings( esc_textarea ( $value['id'] ) ) . '</textarea></div>';
			break;
		case 'select' :
			echo '<div class="ktztitle"><strong>' . esc_attr ( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr ( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktzinput select_wrapper">';
			echo '<select style="width:100%;" name="' . esc_attr( $value['id'] ) . '" id="' . esc_attr( $value['id'] ) . '" class="select">';
					foreach ($value['options'] as $option) { 
						echo '<option value="' . esc_attr( $option['value'] ) . '"';
					if ( get_theme_settings( $value['id'] ) == $option['value']) { 
						echo ' selected="selected" '; } 
						echo '>' . esc_html( $option['title'] ) . '</option>';
						}
			echo '</select></div><div class="clear"></div>';
			break;
		case 'multiselect' :
			echo '<div class="ktztitle"><strong>' . esc_attr ( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr ( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktzinput multiselect_wrapper">';
			echo '<select style="width:100%;" name="' . esc_attr( $value['id'] ) . '[]" id="' . esc_attr( $value['id'] ) . '" class="widefat" size="5" multiple>';
					foreach ($value['options'] as $option) { 
						echo '<option value="' . esc_attr( $option['value'] ) . '"';
						if (!empty($value['id']) && in_array($option['value'], (array) get_theme_settings( $value['id'] ))) { // use array for fixed if not select
						echo ' selected="selected" '; } 
						echo '>' . esc_html( $option['title'] ) . '</option>';
						}
			echo '</select></div><div class="clear"></div>';
			break;
		case 'preview' :
            echo '<div class="' . esc_attr( $value['id'] ) . '_live_preview ktz_preview">';
			echo __('This is example google font preview. Lorem ipsum dolor sit amet...', ktz_theme_textdomain) . '</div><div class="clear"></div>';
			break;
		case 'images' :
			echo '<div class="ktztitle"><strong>' . esc_attr( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktzinput">';
			foreach ($value['options'] as $option) {
			echo '<input type="radio" id="' . esc_attr( $value['id'] ) . '_' . esc_attr( $option['value'] ) . '" class="of-radio-img-radio" value="' . esc_attr( $option['value'] ) . '" name="' . esc_attr( $value['id'] ) . '"';
			if ( get_theme_settings( $value['id'] ) == $option['value']) { 
			echo ' checked="checked" '; } 
			echo '/>';
			echo '<img src="' . ktz_styleinc . 'admin/images/' . esc_attr( $option['value'] ) . '.png" alt="' . $option['value'] . '" class="of-radio-img-img of-radio-img-img_' . $value['id'];
			if ( get_theme_settings( $value['id'] ) == $option['value']) { 
			echo ' of-radio-img-selected '; }
			echo '" onclick="document.getElementById(\'' . esc_attr( $value['id'] ) . '_' . esc_attr( $option['value'] ) . '\').checked=true;" />';
			}
			echo '</div><div class="clear"></div>';
			break;
		case "checkbox" :
			echo '<div class="ktztitle"><strong>' . esc_attr( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktzinput">';
			if(get_theme_settings($value['id'])){ $checked = 'checked="checked"'; }
				else{ $checked = ''; }
            echo '<input type="checkbox" class="checkbox" name="' . esc_attr( $value['id'] ) . '" id="' . esc_attr( $value['id'] ) . '" value="true" ' . $checked . ' />';
			echo '</div>';
			break;
		case 'minitext' :
			echo '<div class="ktztextmini">';
			echo '<input style="width:40px;" name="' . esc_attr( $value['id'] ) . '" id="' . esc_attr( $value['id'] ) . '" type="' . esc_attr( $value['type'] ) . '" value="' . get_theme_settings( esc_attr( $value['id'] ) ) .'" />';
			echo '<br /><small><span style="font-weight:bold;">' . esc_attr( $value['desc'] ) . '</span></small></div>';
			break;
		case 'miniselect' :
			echo '<div class="ktzinputmini">';
			echo '<div class="select_wrapper_mini">';
			echo '<select style="width:100%;" name="' . esc_attr( $value['id'] ) . '" id="' . esc_attr( $value['id'] ) . '" class="select">';
			foreach ($value['options'] as $option) {
				echo '<option value="' . esc_attr( $option['value'] ) . '"'; 
				if ( get_theme_settings( $value['id'] ) == $option['value']) { 
				echo ' selected="selected" '; } echo '>';
				echo $option['title'] .'</option>';
				}
			echo '</select>';
			echo '</div><br /><small><span style="font-weight:bold;">' . esc_attr( $value['desc'] ) . '</span></small></div>';
			break;
		case 'minicolor' :
			echo '<div class="ktzcolormini">';
			echo '<div id="' . esc_attr( $value['id'] ) . '_picker" class="colorSelector"><div></div></div><input class="of-color" style="width:100px;" name="' . esc_attr( $value['id'] ) . '" id="' . esc_attr( $value['id'] ) . '" type="' . esc_attr( $value['type'] ) . '" value="' . get_theme_settings( esc_attr( $value['id'] ) ) . '" />';
			echo '<br /><small><span style="font-weight:bold;">' . esc_attr( $value['desc'] ) . '</span></small></div>';
			break;
		case 'clear' :
			echo '<div class="clear"></div>';
			break;
		case "innertabs_start" :
			echo '<ul id="innertabs">';
			break;
		case "innertabs_end" :
			echo '</ul>';	
			break;
		case "innerheading" :
			echo '<li><a href="#' . esc_attr( $value['id'] ) . '"><span class="' . esc_attr( $value['id'] ) . ' dashicons ktz-' . esc_attr( $value['name'] ) . '"></span> ' . esc_attr( $value['name'] ) . '</a></li>';
			break;
		case "inneropen" :
			echo '<div class="ktz_innertab" id="' . $value['id'] . '">';
			break;
		case "innerclose" :
			echo '</div>';	
			break;  
		case 'system_status' :
			echo '<div class="ktztitle"><strong>' . esc_attr( $value['name'] ) . '</strong><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . esc_attr( $value['desc'] ) . '</div></div>';	
			echo '<div class="ktz_systemstatus">';
			echo '<div class="list_systemstatus"><ul>';	
			echo '<li><strong>Home URL:</strong>' . home_url() . '</li>';
			echo '<li><strong>Site URL:</strong>' . site_url() . '</li>';
			echo '<li><strong>Theme Name:</strong>' . $themename . '</li>';
			echo '<li><strong>Theme Version:</strong>' . $themeversion . '</li>';
			if ( is_multisite() ) {
				echo '<li><strong>WordPress Version:</strong>' . 'WPMU ' . get_bloginfo('version') . '</li>';
			} else {
				echo '<li><strong>WordPress Version:</strong>'. 'WP ' . get_bloginfo('version') . '</li>';	
			}   	
			echo '<li><strong>Information server:</strong>' . esc_html( $_SERVER['SERVER_SOFTWARE'] ) . '</li>';
			if ( function_exists( 'phpversion' ) ) {
				echo '<li><strong>PHP Version:</strong>' . esc_html( phpversion() ) . '</li>';
			}
			if (function_exists( 'size_format' )) {
				echo '<li><strong>Memory Limit:</strong>';
				$mem_limit = ktz_let_to_num( WP_MEMORY_LIMIT );
				if ( $mem_limit < 67108864 ) {
				echo '<mark class="error">' . size_format( $mem_limit ) .' - Recommended memory to at least 64MB. Please see: <a href="http://codex.wordpress.org/Editing_wp-config.php#Increasing_memory_allocated_to_PHP">Increasing memory allocated to PHP</a></mark>';
				} else {
				echo '<mark class="yes">' . size_format( $mem_limit ) . '</mark>';
				}
				echo '</li>';
				echo '<li><strong>WP Max Upload Size:</strong>'. size_format( wp_max_upload_size() ) .'</li>';
			}
			if ( function_exists( 'ini_get' ) ) {
				echo '<li><strong>PHP Time Limit:</strong>'. ini_get('max_execution_time') .'</li>';
			}
			if ( defined('WP_DEBUG') && WP_DEBUG ) {
				echo '<li><strong>WP Debug Mode:</strong><mark class="yes"><b>Yes</b> - If life website please turn off WP debug mode. Please see: <a href="http://codex.wordpress.org/Debugging_in_WordPress">Debugging in WordPress</a></mark></mark></li>';
				} else {
				echo '<li><strong>WP Debug Mode:</strong><mark class="no">No</mark></li>';    
			}			
			echo '</ul></div>';
			echo '</div>';	
			break;
		case 'theme_information' :
			echo ktz_themes_info();
			break;
		} 
	} 
}

// Form admin
function mytheme_admin() {
    global $themename, $shortname, $options, $themeversion, $documentation;
    if ( isset($_REQUEST['saved']) && $_REQUEST['saved'] ) echo __('<div id="message" class="updated fade"><p>Settings saved.</p></div>',ktz_theme_textdomain);
    if ( isset($_REQUEST['reset']) && $_REQUEST['reset'] ) echo __('<div id="message" class="updated fade"><p>Settings reset.</p></div>',ktz_theme_textdomain);

	echo '<div class="wrap"><h2 class="headtitle">' . $themename;
	echo ' ' . $themeversion . ' ';
	echo __('options', ktz_theme_textdomain) .'</h2><p class="documentation">' . $documentation . '</p>';
	echo '<form method="post" id="ktz_form" enctype="multipart/form-data">';
	echo ktz_admin_fields();
	echo '<p class="submit ss_wrap">'; 
	echo '<input name="save" type="submit" value="Save changes" id="adminktz-save" class="button button-primary button-large" />';
	echo '<input type="hidden" name="action" value="save_ktz" />';
	echo '<div id="adminktz-ajax-saving">';
	echo '<div class="ajaxloader"></div>';
	echo '</div>';
	echo '</p>';
	echo '<div class="clear"></div></form>';  
	echo '<form method="post">';
	echo '<p class="submit">';  
	echo '<input name="reset" type="submit" value="Reset" id="ktz_reset" class="button button-primary button-large" /> '; 
	echo '<input type="hidden" name="action" value="reset_ktz" />'; 
	echo '</p>'; 
	echo '</form>';
	echo '</div>';
}

?>