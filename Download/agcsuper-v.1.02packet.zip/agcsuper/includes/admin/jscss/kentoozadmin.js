jQuery(document).ready(function(){
	jQuery('.ss_wrap').tabs();
	jQuery('input:checkbox:not([safari])').checkbox();
	jQuery('input[safari]:checkbox').checkbox({cls:'jquery-safari-checkbox'});

	jQuery('.select_wrapper').each(function () {
	jQuery(this).prepend('<span>' + jQuery(this).find('.select option:selected').text() + '</span>');
    });
		jQuery('.select').live('change', function () {
        jQuery(this).prev('span').replaceWith('<span>' + jQuery(this).find('option:selected').text() + '</span>');
    });
		jQuery('.select').bind(jQuery.browser.msie ? 'click' : 'change', function(event) {
        jQuery(this).prev('span').replaceWith('<span>' + jQuery(this).find('option:selected').text() + '</span>');
    }); 

    jQuery('.select_wrapper_mini').each(function () {
        jQuery(this).prepend('<span>' + jQuery(this).find('.select option:selected').text() + '</span>');
    });
    jQuery('.select').live('change', function () {
        jQuery(this).prev('span').replaceWith('<span>' + jQuery(this).find('option:selected').text() + '</span>');
    });
      jQuery('.select').bind(jQuery.browser.msie ? 'click' : 'change', function(event) {
        jQuery(this).prev('span').replaceWith('<span>' + jQuery(this).find('option:selected').text() + '</span>');
    }); 
	
	jQuery(".img-description").click(function(){
	var descheading = jQuery(this).prev(".ktztitle strong").html();
	var desctext = jQuery(this).next(".ktzdesc").html();
	jQuery('body').append("<div id='custom-lbox'><div class='shadow'></div><div class='box-desc'><div class='box-desc-top'></div><div class='box-desc-content'><h3>"+descheading+"</h3>"+desctext+"<div class='lightboxclose'></div> </div> <div class='box-desc-bottom'></div>	</div></div>");
	jQuery(".shadow").animate({ opacity: "show" }, "fast").fadeTo("fast", 0.75);
	jQuery('.lightboxclose').click(function(){
	jQuery(".shadow").animate({ opacity: "hide" }, "fast", function(){jQuery("#custom-lbox").remove();});	
	});
	});
	
	window.formfield = '';
	jQuery('.upload_image_button').live('click', function() {
		window.formfield = jQuery('.upload_field',jQuery(this).parent());
		tb_show('', 'media-upload.php?post_id=0&type=image&TB_iframe=true');
		return false;
	});
	window.original_send_to_editor = window.send_to_editor;
	window.send_to_editor = function(html) {
	if (window.formfield) {
		imgurl = jQuery('img',html).attr('src');
		window.formfield.val(imgurl);
		tb_remove();
	}
	else {
		window.original_send_to_editor(html);
	}
	window.formfield = '';
	window.imagefield = false;
}
});


