/* <![CDATA[ */
	var clearpath = admincpSettings.clearpath;
	jQuery(document).ready(function(){
		var $save_message = jQuery("#adminktz-ajax-saving");
		jQuery("input#adminktz-save").click(function($){
			var options_fromform = jQuery("#ktz_form").formSerialize(),
				add_nonce = '&_ajax_nonce='+admincpSettings.adminktz_nonce;
			options_fromform += add_nonce;
			var save_button=jQuery(this);
			jQuery.ajax({
				responseTime: 2000,
				type: "POST",
				url: ajaxurl,
				data: options_fromform,
			});
			return false;
		});
		$save_message.ajaxStart(function(){
			timeOut = setTimeout(function () {
				jQuery('.ajaxloader').fadeIn();
				}, 500); // Waits for half a second before fading .modal in
		}).ajaxStop(function(){ 
			clearTimeout(timeOut); // Cancels if request finished < .5 seconds
			jQuery('.ajaxloader').fadeOut();
		});
	});
/* ]]> */