<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ JAVASCRIPTS FRAMEWORK
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*******************************************
# Register javascript on hook system ~ header
*******************************************/
function ktz_register_jascripts() {
	if( !is_admin() ) {
		wp_deregister_script('fbsdk');
		wp_register_script( 'modernizr-respon',ktz_url . 'js/modernizr-2.6.1-respond-1.1.0.min.js', array(), false, false );
		wp_register_script( 'ktzscript',ktz_url . 'js/script.min.js',array('jquery'), false, true );
		wp_register_script( 'ktzrate',ktz_url . 'js/rating.js',array('jquery'), false, true );
		wp_register_script( 'kentoozMain',ktz_url . 'js/custom.main.js',array('jquery'), false, true );	
	}
}

/*******************************************
# Enqueue javascript on hook system ~ header
*******************************************/
function ktz_jsscripts() {
	global $is_IE;
	if( !is_admin() ) {
		wp_enqueue_script('modernizr-respon'); // top before all script for IE
		wp_enqueue_script('jquery');	
		if ( is_singular() ) { /* only in single */
			wp_enqueue_script( 'comment-reply' ); 
		}
		wp_enqueue_script('ktzscript');
		wp_enqueue_script('ktzrate');
		wp_enqueue_script('kentoozMain');
		wp_localize_script('ktzrate', 'ktz_ajax_data', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'codes' => array(
				'SUCCESS' => 1,
				'PREVIOUSLY_VOTED' => 0,
				'REQUEST_ERROR' => 2,
				'UNKNOWN' => -1
			),
			'messages' => array(
				'success' => __('You\'ve voted correctly', ktz_theme_textdomain),
				'previously_voted' => __('You had previously voted', ktz_theme_textdomain),
				'request_error' => __('The request was malformed, try again', ktz_theme_textdomain),
				'unknown' => __('An unknown error has occurred, try to vote again', ktz_theme_textdomain)
			)
		));
	}
}

/*
 * Social javascript in footer.
 */
function ktz_lockscript() {
	global $post;
	echo '<script>
		(function(w, d, s) {
		function go(){
			var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
			if (d.getElementById(id)) {return;}
			js = d.createElement(s); js.src = url; js.id = id;
			fjs.parentNode.insertBefore(js, fjs);
		};
		load(\'https://connect.facebook.net/en_US/all.js#xfbml=1\', \'fbjssdk\');
		load(\'https://apis.google.com/js/plusone.js\', \'gplus1js\');
		load(\'https://platform.twitter.com/widgets.js\', \'tweetjs\');
		}
		if (w.addEventListener) { w.addEventListener("load", go, false); }
		else if (w.attachEvent) { w.attachEvent("onload",go); }
		}(window, document, \'script\'));
		</script>
	';
}

/*******************************************
# Add Elastis Slider in magazine homepage
*******************************************/
if ( !function_exists('ktz_feature_slider') ) {
function ktz_feature_slider() { 
	if ( is_home() || is_front_page() ) {
	if ( get_theme_option('ktz_featuredslider_activated') != '' ) :
		$args = array(
		'post_type'=> 'post',
		'post_status'=> 'publish',
		'ignore_sticky_posts'=>1,
		'showposts' => 5,
		'cat' => get_theme_option('ktz_cat_featuredslider'),
		);
		$ktz_sliderquery = new WP_Query($args); 
		if ($ktz_sliderquery -> have_posts()) :
        echo '<div class="row mainfeatured"><div class="span8"><div id="ei-slider" class="ei-slider"><ul class="ei-slider-large">';
		while ($ktz_sliderquery -> have_posts()) : $ktz_sliderquery -> the_post(); 
		global $post;
		$permalink = get_permalink();
		$title = get_the_title();
		$postid = get_the_ID();
		echo '<li>';
		echo ktz_feature_img( 620, 238 );
		echo '<div class="ei-title">';
        echo ktz_posted_title_h('h2','slider-title');
		echo '</div>';
		echo '</li>';
		endwhile;
        echo '</ul>';
        echo '<ul class="ei-slider-thumbs">';
		echo '<li class="ei-slider-element">Current</li>';
		while ($ktz_sliderquery -> have_posts()) : $ktz_sliderquery -> the_post(); 
		global $post;
        echo '<li><a href="#">&nbsp;</a>';
		echo ktz_feature_justimg( 124, 80 );
		echo '</li>';
		endwhile;
		echo '</ul></div></div>'; 
		echo '<div class="span4">';
		if ( get_theme_option('ktz_ban300250_slider') != '' ) :
			echo '<div class="banner-slider">';
				echo get_theme_option('ktz_ban300250_slider');
			echo '</div>';
		endif;
		echo '</div></div>';
		endif;
	endif;
		}	
	}
}

/*
 * Change default wordpress gallery.
 */
function ktz_post_gallery($output, $attr) {
    global $post;
    if (isset($attr['orderby'])) {
        $attr['orderby'] = sanitize_sql_orderby($attr['orderby']);
        if (!$attr['orderby'])
            unset($attr['orderby']);
    }
    extract(shortcode_atts(array(
        'order' => 'ASC',
        'orderby' => 'menu_order ID',
        'id' => $post->ID,
        'itemtag' => 'dl',
        'icontag' => 'dt',
        'captiontag' => 'dd',
        'columns' => 3,
        'size' => 'thumbnail',
        'include' => '',
        'exclude' => ''
    ), $attr));
    $id = intval($id);
    if ('RAND' == $order) $orderby = 'none';
    if (!empty($include)) {
        $include = preg_replace('/[^0-9,]+/', '', $include);
        $_attachments = get_posts(array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby));

        $attachments = array();
        foreach ($_attachments as $key => $val) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    }
    if (empty($attachments)) return '';
    // Here's your actual output, you may customize it to your need
    $output .= "<div class=\"list_carousel-single\"><div class=\"ktzcarousel-single owl-carousel owl-theme owl-single\">\n";
    // Now you loop through each attachment
    foreach ($attachments as $id => $attachment) {
        // Fetch the thumbnail (or full image, it's up to you)
        $img = wp_get_attachment_image_src($id, 'full');
		$url_attachment = get_attachment_link($attachment->ID);
		$title = apply_filters( 'the_title', $attachment->post_title );
        $output .= "<div class=\"item\">\n";
		$output .= "<a href=\"" . $url_attachment . "\">";
        $output .= "<img src=\"{$img[0]}\" width=\"{$img[1]}\" height=\"{$img[2]}\" alt=\"\" />\n";
		$output .="</a>\n";
		$output .= "<div class=\"title-carousel\">\n";
		$output .= $title;
		$output .="</div>\n";
        $output .= "</div>\n";
    }

    $output .= "</div></div>\n";

    return $output;
}

/* 
Function parsing FBML in footer
*/
function ktz_parseFBML(){
	if ( get_theme_option('ktz_active_socialdl') != '' ) {
	if (is_singular('post')) {
	echo'<script type="text/javascript">FB.XFBML.parse();</script>';
	}
	}
}

?>