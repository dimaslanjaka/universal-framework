<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK FOR FREE THEME
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*******************************************
# Main footer on hook system ~ post
*******************************************/
if ( !function_exists( 'ktz_mainfooter' ) ) :
function ktz_mainfooter() {
	$footer_column = get_theme_option('ktz_footer_columns');
	echo '<div class="row">';
		switch($footer_column) :
			case 'full':
				echo '<div class="span12 widget-area" role="complementary">';
				dynamic_sidebar('widget_fot1');
				echo '</div>';
				break;
			case 'half_half':
				echo '<div class="span6 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span6 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				break;
			case 'onethird_onethird_onethird':					
				echo '<div class="span4 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span4 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				echo '<div class="span4 widget-area sbar">';
				dynamic_sidebar( 'widget_fot3' );
				echo '</div>';
				break;
			case 'twothird_onethird':
				echo '<div class="span8 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span4 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				break;
			case 'onethird_twothird':
				echo '<div class="span4 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span8 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				break;
			case 'onefourth_onefourth_onefourth_onefourth':
				echo '<div class="span3 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span3 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				echo '<div class="span3 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot3' );
				echo '</div>';
				echo '<div class="span3 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot4' );
				echo '</div>';
				break;
			case 'threefourth_onefourth':
				echo '<div class="span9 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span3 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				break;
			case 'onefourth_threefourth':
				echo '<div class="span3 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span9 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				break;
			case 'onesixth_onesixth_onesixth_onesixth_onesixth_onesixth':
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot3' );
				echo '</div>';
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot4' );
				echo '</div>';
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot5' );
				echo '</div>';
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot6' );
				echo '</div>';
				break;
			case 'fivesixth_onesixth':
				echo '<div class="span10 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				break;
			case 'onesixth_fivesixth':
				echo '<div class="span2 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot1' );
				echo '</div>';
				echo '<div class="span10 widget-area sbar" role="complementary">';
				dynamic_sidebar( 'widget_fot2' );
				echo '</div>';
				break;
		endswitch;
	echo '</div>';
	}
endif;

/*******************************************
# Sub footer on hook system ~ post
*******************************************/
if ( !function_exists( 'ktz_subfooter' ) ) :
function ktz_subfooter() {
	echo '<p class="footercredits">' . get_theme_option('ktz_footcredits') . '</p>';
	}
endif;
if ( !function_exists( 'ktz_subfooter_squeeze' ) ) :
function ktz_subfooter_squeeze() {
	echo '<p class="footercredits-squeeze">' . get_theme_option('ktz_footcredits') . '<br />';
	echo '</p>';
	}
endif;

?>