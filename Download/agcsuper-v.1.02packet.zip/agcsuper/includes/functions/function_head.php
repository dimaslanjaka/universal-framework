<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK FOR FREE THEME
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*******************************************
# Register CSS on hook system ~ header
# Add googlefont and custom css @ kasep theme v.1.01
*******************************************/
function ktz_register_css() {
	if( !is_admin() ) {
		if (get_theme_option('ktz_ffh') != '') {
		$getheadinggfont = '';
		if( get_theme_option('ktz_ffh') ){
			$getheadinggfont = get_theme_option('ktz_ffh');
			$getheadinggfont = str_replace(' ', '+', $getheadinggfont);
		}
		wp_register_style( 'googlefont-css', 'http://fonts.googleapis.com/css?family='. $getheadinggfont);
		} 
		if (get_theme_option('ktz_ffb') != '') {
			$getbodygfont = '';
			if( get_theme_option('ktz_ffb') ){
				$getbodygfont = get_theme_option('ktz_ffb');
				$getbodygfont = str_replace(' ', '+', $getbodygfont);
			}
		wp_register_style( 'googlefontbody-css', 'http://fonts.googleapis.com/css?family='. $getbodygfont);
		}	
		wp_register_style( 'main-css',ktz_url . 'style.css',array(), '1.0', 'all' );
		if( get_theme_option('ktz_styledefault') != '' ) { 
			$styledefault = '';
			if( get_theme_option('ktz_styledefault') ){
			$styledefault = get_theme_option('ktz_styledefault');
			}
		wp_register_style( 'defaultstyle-css',ktz_url . 'css/style/' . $styledefault,array(), '1.0', 'screen' ); 
		}
	}
}

/*******************************************
# Enqueue CSS on hook system ~ header
*******************************************/
function ktz_enqueue_css()  { 
	if( !is_admin() ) { 
        wp_enqueue_style( 'googlefont-css' ); 
        wp_enqueue_style( 'googlefontbody-css' ); 
        wp_enqueue_style( 'main-css' );  
        wp_enqueue_style( 'defaultstyle-css' );  
	}
}  

/* 
Must have for open graph like button. 
*/
function ktz_ogHEAD(){
	global $page, $paged, $post;
		$default_keywords = get_theme_option('ktz_keyword');
		if ( !is_search() && !is_404() ) {
			$thumb = get_post_thumbnail_id();
			$img_url = wp_get_attachment_url( $thumb,'full' ); 
			$img_default = get_template_directory_uri() . '/img/no-image/no-thumb.jpg'; 
			$firstimage_url = get_first_image_src(); 
			$params = array( 'width' => 500, 'height' => 500, 'crop' => true );
			if ( $img_url ) {  
				$image_thumb = bfi_thumb( $img_url, $params ); //resize & crop the image
			} elseif ( $firstimage_url ) {
				$image_thumb = bfi_thumb( $firstimage_url, $params ); 
			} else { 
				$image_thumb = $img_default;
			} 
			if ( is_single() ) {  
				setup_postdata( $post );
				$content_desc = substr(get_the_excerpt(),0,160);
			} else {
					if ( $paged >= 2 || $page >= 2 ) {
					$content_desc = strip_tags($post->post_excerpt) . ' ' . sprintf( __( 'in page %s', ktz_theme_textdomain ), max( $paged, $page ) );
					} else {
					$content_desc = strip_tags($post->post_excerpt); 					
					}
			} 
			$cats = get_the_category();
			$tags = get_the_tags();
			if (!empty($post)) :
				$keys = get_post_meta($post->ID, 'ktz_seo_keywords', true);
				else :
				$keys = 'No post';
			endif;
			if (empty($keys)) {
				if (!empty($cats)) foreach($cats as $cat) $keys .= $cat->name . ', ';
				if (!empty($tags)) foreach($tags as $tag) $keys .= $tag->name . ', ';
				$keys .= $default_keywords;
			}
		}
			if ( $paged >= 2 || $page >= 2 ) {
				$content_desc_other = get_bloginfo('description') . ' ' . sprintf( __( 'in page %s', ktz_theme_textdomain ), max( $paged, $page ) );
			} else {
				$content_desc_other = get_bloginfo('description'); 					
			} 
		echo '<!-- BEGIN opengraph added by kentooz themes -->'."\n";
		$ktz_metadata_arg[] = '<meta property="fb:app_id" content="' . get_theme_option('ktz_facebook_app_id') . '" />';
		if ( is_single() || is_page() ) {
			$ktz_metadata_arg[] = '<meta property="og:url" content="' . get_permalink() . '"/>';  
			$ktz_metadata_arg[] = '<meta property="og:title" content="' . get_the_title() . '" />';
			$ktz_metadata_arg[] = '<meta property="og:description" content="' . $content_desc . '" />';
			$ktz_metadata_arg[] = '<meta property="og:type" content="article" />';  
			$ktz_metadata_arg[] = '<meta property="og:image" content="' . $image_thumb . '" />';  
		} elseif ( is_search() && get_theme_option('ktz_agc_activated') !="" ) {			
			echo '<meta property="og:url" content="' . str_replace('search', get_theme_option('ktz_search_permalink'), get_search_link()) . '" />'."\n";  
			echo '<meta property="og:title" content="';
			$change = array('.html','-');
			echo str_replace($change, ' ', get_search_query());
			echo '" />'."\n";
			echo '<meta property="og:description" content="';
			echo ktz_agc_bing_desc();
			echo '" />'."\n";
			echo '<meta property="og:type" content="article" />'."\n";
			echo '<meta property="og:image" content="';
			ktz_agc_google();
			echo '" />'."\n";
		} else {   
			$ktz_metadata_arg[] = '<meta property="og:site_name" content="' . get_bloginfo('name') . '" />';
			$ktz_metadata_arg[] = '<meta property="og:description" content="' . $content_desc_other . '" />';  
			$ktz_metadata_arg[] = '<meta property="og:type" content="website" />';
			$ktz_metadata_arg[] = '<meta property="og:image" content="' . get_theme_option('ktz_image_default') . '" />';
		}  
		if (get_theme_option('ktz_active_autoseo') != '') :
			$ktz_metadata_arg[] = '<!-- BEGIN Auto Meta SEO added by kentooz themes -->';
			if ( is_single() || is_page() ) {
				$ktz_metadata_arg[] = '<meta name="description" content="' . $content_desc . '"/>';
				$ktz_metadata_arg[] = '<meta name="keywords" content="' . esc_attr($keys) . '">';
			} elseif ( is_search() && get_theme_option('ktz_agc_activated') !="" ) {
				echo '<meta name="description" content="';
				echo ktz_agc_bing_desc();
				echo '"/>'."\n";
				echo '<meta name="keywords" content="';
				$change = array('.html','-');
				echo str_replace($change, ' ', get_search_query());				
				echo '">'."\n";
			} else {   
				$ktz_metadata_arg[] = '<meta name="description" content="' . $content_desc_other . '"/>';  
				$ktz_metadata_arg[] = '<meta name="keywords" content="' . $default_keywords . '">';
			}  
			$ktz_metadata_arg[] = '<!-- END opengraph added by kentooz themes -->';
		endif;
	echo implode("\n", $ktz_metadata_arg);
}

/*******************************************
# Dynamic background on hook system ~ header
*******************************************/
if ( !function_exists('ktz_dynamicbg') ) {
function ktz_dynamicbg(){
if(is_page()) {
global $wp_query;
$postid = $wp_query->post->ID;
	$page_mt = get_post_meta( $postid, 'page_meta', true );
	$bgactivated = empty($page_mt['bgactivated']) ? '' : $page_mt['bgactivated'];
	$bgcolor = empty($page_mt['bgcolor']) ? '' : $page_mt['bgcolor'];
	$bgimage = empty($page_mt['bgimage']) ? '' : $page_mt['bgimage'];
	$bgrepeat = empty($page_mt['bgrepeat']) ? '' : $page_mt['bgrepeat'];
	$bgposition = empty($page_mt['bgposition']) ? '' : $page_mt['bgposition'];
	$bgattach = empty($page_mt['bgattach']) ? '' : $page_mt['bgattach'];
	$page_id = get_the_ID();
	if ($bgactivated != '' ) { echo '<style type="text/css">body.page-id-'.$page_id.'{';
	if ($bgcolor) {	echo 'background-color:'.$bgcolor.';';}
	if ($bgimage) { echo 'background-attachment:fixed;background-image:url('.$bgimage.');';}
	if ($bgrepeat) { echo 'background-repeat:'.$bgrepeat.';';}
	if ($bgposition) { echo 'background-position:'.$bgposition.';';}
	if ($bgattach) { echo 'background-attachment:'.$bgattach.';';}
	echo '}</style>';}
	}	
if(is_single()) { 
global $wp_query;
$postid = $wp_query->post->ID;
	$post_mt = get_post_meta( $postid, 'post_meta', true );
	$bgactivated = empty($post_mt['bgactivated']) ? '' : $post_mt['bgactivated'];
	$bgcolor = empty($post_mt['bgcolor']) ? '' : $post_mt['bgcolor'];
	$bgimage = empty($post_mt['bgimage']) ? '' : $post_mt['bgimage'];
	$bgrepeat = empty($post_mt['bgrepeat']) ? '' : $post_mt['bgrepeat'];
	$bgposition = empty($post_mt['bgposition']) ? '' : $post_mt['bgposition'];
	$bgattach = empty($post_mt['bgattach']) ? '' : $post_mt['bgattach'];
	$post_id = get_the_ID();
	if ($bgactivated != '' ) { echo '<style type="text/css">body.postid-'.$post_id.'{';
	if ($bgcolor) {	echo 'background-color:'.$bgcolor.';';}
	if ($bgimage) { echo 'background-attachment:fixed;background-image:url('.$bgimage.');';}
	if ($bgrepeat) { echo 'background-repeat:'.$bgrepeat.';';}
	if ($bgposition) { echo 'background-position:'.$bgposition.';';}
	if ($bgattach) { echo 'background-attachment:'.$bgattach.';';}
	echo '}</style>';}
	}	
	}  
}  

if ( !function_exists('ktz_custom_css') ) {
function ktz_custom_css() {
	global $post;
	$getheadinggfont = '';
	$getbodygfont = '';
	if (get_theme_option('ktz_ffh') != ' ') { 
	$getheadinggfont = preg_split( '/:/',  get_theme_option('ktz_ffh') );
	$getheadinggfont = '"' . $getheadinggfont[0] . '",';
	}
	$getheadingdeffont = get_theme_option('ktz_headfontdefault');
	if( get_theme_option('ktz_ffb') ){
	$getbodygfont = preg_split( '/:/',  get_theme_option('ktz_ffb') );
	$getbodygfont = '"' . $getbodygfont[0] . '",';
	}
	$getbodydeffont = get_theme_option('ktz_fontdefault');
?>
<style type="text/css">
body {
	font-family:<?php echo $getbodygfont; ?><?php echo $getbodydeffont; ?>;
	color:<?php echo get_theme_option('ktz_ffbcolor'); ?>;
	font-size:<?php echo get_theme_option('ktz_ffbsize'); ?>;
	<?php if ( get_theme_option('ktz_bodybg') != '' ) { ?>
	background-color:<?php echo get_theme_option('ktz_bodybg'); ?>;
	<?php } ?><?php if ( get_theme_option('ktz_bodyimgbg') != '' ) { ?>
	background-image:url(<?php echo get_theme_option('ktz_bodyimgbg'); ?>);
	<?php } ?><?php if ( get_theme_option('ktz_bodyimgbgrepeat') != '' ) { ?>
	background-repeat:<?php echo get_theme_option('ktz_bodyimgbgrepeat'); ?>;
	<?php } ?><?php if ( get_theme_option('ktz_bodyimgbgattach') != '' ) { ?>
	background-attachment:<?php echo get_theme_option('ktz_bodyimgbgattach'); ?>;
	<?php } ?><?php if ( get_theme_option('ktz_bodyimgbgposition') != '' ) { ?>
	background-position:<?php echo get_theme_option('ktz_bodyimgbgposition'); ?>;
	<?php } ?>
}
h1,
h2,
h3,
h4,
h5,
h6,
#mainmenu a,
.singleblogtit,
.title-carousel a,
#searchform input[type="submit"],
#feedburnerform input[type="submit"],
.button-prev a,
.button-next a{
	font-family: <?php echo $getheadinggfont; ?> <?php echo $getheadingdeffont; ?>;
}
<?php /* HEADER */ ?>
.allwrap.head {
	<?php if ( get_theme_option('ktz_headbg') != '' ) { ?>
	background-color:<?php echo get_theme_option('ktz_headbg'); ?>;
	<?php } ?><?php if ( get_theme_option('ktz_headimgbg') != '' ) { ?>
	background-image:url(<?php echo get_theme_option('ktz_headimgbg'); ?>);
	<?php } ?><?php if ( get_theme_option('ktz_headimgbgrepeat') != '' ) { ?>
	background-repeat:<?php echo get_theme_option('ktz_headimgbgrepeat'); ?>;
	<?php } ?><?php if ( get_theme_option('ktz_headimgbgattach') != '' ) { ?>
	background-attachment:<?php echo get_theme_option('ktz_headimgbgattach'); ?>;
	<?php } ?><?php if ( get_theme_option('ktz_headimgbgposition') != '' ) { ?>
	background-position:<?php echo get_theme_option('ktz_headimgbgposition'); ?>;
	<?php } ?>
}
<?php if (get_theme_option('ktz_colorscheme') != '') { ?>
a:hover, a:focus, a:active,
#breadcrumbs-wrap a:hover, 
#breadcrumbs-wrap a:focus,
#secondmenu ul > li a:hover {
	color:<?php echo get_theme_option('ktz_colorscheme'); ?>;
}
#back-top,
#wp-calendar tbody td:hover,
#wp-calendar tbody td:hover a,
.widget .tagcloud a,
.read-more a,
.bgstripes-meta,
.copyright{
	background:<?php echo get_theme_option('ktz_colorscheme'); ?>;
}
#search input[type="submit"],
#feedburner input[type="submit"],
.button-prev a,
.button-next a,
.pagination ul>.active>a,
.pagination ul>.active>span,
.pagination ul>li>a:hover,
.pagination ul>li>a:focus{
	background-color:<?php echo get_theme_option('ktz_colorscheme'); ?>;
}
.widget-title,
#breadcrumbs-wrap {
	border-color:<?php echo get_theme_option('ktz_colorscheme'); ?>;
}
<?php } ?>
</style>
<?php 
	}
}

/*******************************************
# Add favicon on hook system ~ header
*******************************************/
if ( !function_exists('ktz_head_favicon') ) {
function ktz_head_favicon() {
	if(get_theme_option('ktz_favicon') != '') {
		echo '<link rel="shortcut icon" href="'. get_theme_option('ktz_favicon') .' " />';
		} 
	}
}

/*******************************************
# Add element on head on hook system ~ header
*******************************************/
if ( !function_exists('ktz_headelement') ) {
function ktz_headelement() { ?>
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php if (get_theme_option('ktz_gplus_sn') != '') { echo '<link href="' . get_theme_option('ktz_gplus_sn') . '" rel="publisher" />'; } ?>
<?php } 
} 

/*******************************************
# Dynamic background on hook system ~ header
*******************************************/
if ( !function_exists('ktz_headlogo') ) :
function ktz_headlogo() { 
	$get_logo_image = get_theme_option('ktz_logo');
	if (get_theme_option('ktz_logo_actived') != '') { 
		echo '<div id="logo">';
		echo '<a href="' . home_url() . '" title="permalink to ' . get_bloginfo('name') . '">';
		echo '<img src="' . $get_logo_image . '" alt="' . get_bloginfo('name') . '" title="' . get_bloginfo('name') . '" />';
		echo '</a>';
		if( (is_single() || is_page() || is_archive() || is_search()) and !(is_front_page()) ) :
		echo '<div class="singleblogtit-hide"><a href="'. home_url() . '">' . get_bloginfo('name'). '</a></div>';
		echo '<div class="desc-hide">' . get_bloginfo ( 'description' ) . '</div>';
		else : 
		echo '<h1 class="homeblogtit-hide"><a href="'. home_url() . '">' . get_bloginfo('name') . '</a></h1>';
		echo '<div class="desc-hide">' . get_bloginfo ( 'description' ) . '</div>';
		endif;
		echo '</div>';
		} else { 		
		echo '<div id="logo" class="pull-left">';
		if( (is_single() || is_page() || is_archive() || is_search()) and !(is_front_page()) ) :
		echo '<div class="singleblogtit"><a href="'. home_url() . '">' . get_bloginfo('name') . '</a></div>';
		echo '<div class="desc">' . get_bloginfo ( 'description' ) . '</div>';
		else : 
		echo '<h1 class="homeblogtit"><a href="'. home_url() . '">' . get_bloginfo('name') . '</a></h1>';
		echo '<div class="desc">' . get_bloginfo ( 'description' ) . '</div>';
		endif;
		echo '</div>';
		}	
	} 
endif;

/*******************************************
# Top menu on hook system ~ header
*******************************************/
if( !function_exists('ktz_topmenu')) {
	function ktz_topmenu() {
	wp_nav_menu( array(
	'container' =>false,
	'theme_location' =>'ktzmenu_1',
	'echo' => true,
	'depth' =>  3,
	'fallback_cb' => 'ktzmenu_1_default',
	'items_wrap' => '<ul id="topmenu" class="categories">%3$s</ul>',
	));
	}
}

/*******************************************
# Add default top menu on hook system ~ header
*******************************************/
if ( !function_exists('ktzmenu_1_default') ) {
function ktzmenu_1_default(){  ?>
	<ul id="topmenu" class="categories">
        <?php wp_list_categories('depth=1&sort_column=menu_order&title_li=' ); ?>
    </ul>
	<?php }
}

/*******************************************
# Add default fixed menu on hook system ~ footer
*******************************************/
if ( !function_exists('ktzmenu_2_default') ) {
	function ktzmenu_2_default() {  
	?>
		<div id="secondmenu"><ul id="menu-secondmenu" class="categories"><?php wp_list_pages('depth=1&exclude=1&hide_empty=0&orderby=name&show_count=0&use_desc_for_title=1&title_li='); ?></ul></div>
	<?php }
}

/*******************************************
# Sub footer on hook system ~ post
*******************************************/
if ( !function_exists( 'ktz_secondmenu' ) ) :
function ktz_secondmenu() {
	if(function_exists('wp_nav_menu')) { 
	$defaults = array(
		'theme_location' => 'ktzmenu_2',
		'depth' => 1,
		'menu_class' => 'categories',
		'fallback_cb' => 'ktzmenu_2_default',
		'items_wrap'      => '<div id="secondmenu"><ul id="menu-secondmenu" class="%2$s">%3$s</ul></div>'
	);
		wp_nav_menu( $defaults ); 
	} else { 
		ktzmenu_2_default();  
	}
	}
endif;

/*******************************************
# Register menu on hook system ~ header
*******************************************/
if ( function_exists( 'register_nav_menus' ) ) {
	register_nav_menus(
	array(
      'ktzmenu_1' => 'Top Menu',
      'ktzmenu_2' => 'Second Menu',
    ) );
}

/*******************************************
# Search hook in header |||||||||||||||||||
*******************************************/
if( !function_exists('ktz_topsearch')) {
	function ktz_topsearch() {
	$search_text = empty($_GET['s']) ? "Search" : get_search_query();
	echo '<div id="search" class="topsearch">';
    echo '<form method="get" id="searchform" action="' . esc_url( home_url( '' ) ) . '/">'; 
    echo '<input type="text" name="s" id="s" class="steel" placeholder="Search" />';
    echo '<input type="submit" value="Search">';
    echo '</form>';
	echo '</div>';
	}
}

/*******************************************
# Header social network on hook system ~ footer
*******************************************/
if ( !function_exists('ktz_sn') ) {
function ktz_sn() {
	if ((get_theme_option('ktz_tweet_sn') != '') || (get_theme_option('ktz_fb_sn') != '') || (get_theme_option('ktz_gplus_sn') != '') || (get_theme_option('ktz_in_sn') != '') || (get_theme_option('ktz_dribble_sn') != '') || (get_theme_option('ktz_flickr_sn') != '') || (get_theme_option('ktz_deviant_sn') != '') || (get_theme_option('ktz_blogger_sn') != '') || (get_theme_option('ktz_vimeo_sn') != '') || (get_theme_option('ktz_youtube_sn') != '') || (get_theme_option('ktz_rss_sn') != '')) :
	echo '<div class="header-sn"><ul class="icon24px">';
			if (get_theme_option('ktz_tweet_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_tweet_sn') . '" data-placement="bottom" class="twitter" title="Twitter"></a></li>';
			if (get_theme_option('ktz_fb_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_fb_sn') . '" data-placement="bottom" class="facebook" title="Facebook"></a></li>';
			if (get_theme_option('ktz_gplus_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_gplus_sn') . '" data-placement="bottom" class="gplus" title="GPlus"></a></li>';
			if (get_theme_option('ktz_in_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_in_sn') . '" data-placement="bottom" class="in" title="LinkedIn"></a></li>';
			if (get_theme_option('ktz_dribble_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_dribble_sn') . '" data-placement="bottom" class="dribble" title="Dribble"></a></li>';
			if (get_theme_option('ktz_flickr_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_flickr_sn') . '" data-placement="bottom" class="flickr" title="Flickr"></a></li>';
			if (get_theme_option('ktz_deviant_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_deviant_sn') . '" data-placement="bottom" class="deviant" title="DeviantArt"></a></li>';
			if (get_theme_option('ktz_blogger_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_blogger_sn') . '" data-placement="bottom" class="blogger" title="Blogger"></a></li>';
			if (get_theme_option('ktz_vimeo_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_vimeo_sn') . '" data-placement="bottom" class="vimeo" title="Vimeo"></a></li>';
			if (get_theme_option('ktz_youtube_sn') != '')
				echo '<li><a href="' . get_theme_option('ktz_youtube_sn') . '" data-placement="bottom" class="youtube" title="YouTube"></a></li>';
			if (get_theme_option('ktz_rss_sn') != '')
				echo '<li><a href="' . get_bloginfo('rss2_url') . '" data-placement="bottom" class="rss" title="RSS"></a></li>';
	echo '</ul></div>';
	endif;
	} 
} 

/*******************************************
# Breadcrumbs on hook system with rich snipped
*******************************************/
if ( !function_exists('ktz_crumbs') ) {
function ktz_crumbs() {
	if( is_front_page() )
		return;
		if ( get_theme_option('ktz_breadcrumbs') != '' ) :
		echo '<div id="breadcrumbs-wrap"><div class="breadcrumbs" xmlns:v="http://rdf.data-vocabulary.org/#">';
		echo '<span typeof="v:Breadcrumb"><a rel="v:url" property="v:title" href="';
        echo home_url();
        echo '">';
        echo __('Home',ktz_theme_textdomain);
        echo "</a></span>";
        if (is_category() || is_single()) {
		$category = get_the_category();
		foreach($category as $category) {
		echo '<span typeof="v:Breadcrumb"><a href="';
			echo get_category_link($category->term_id);
		echo '" rel="v:url" property="v:title">' . $category->name . '</a></span>';
			}
			if (is_single()) {
                echo '<span property="v:title">' . get_the_title() . '</span>';
			}	
        } 	
		elseif (is_page()) {
                echo '<span property="v:title">' . get_the_title() . '</span>';
        }
		elseif (is_tag()) {
                echo '<span property="v:title">';
					echo single_tag_title();
				echo '</span>';
				}
		elseif (is_day()) {echo '<span property="v:title">' . __("Archive for ",ktz_theme_textdomain); get_the_time('F jS, Y') . '</span>';}
		elseif (is_month()) {echo '<span property="v:title">' . __("Archive for ",ktz_theme_textdomain); get_the_time('F, Y') . '</span>';}
		elseif (is_year()) {echo '<span property="v:title">' . __("Archive for ",ktz_theme_textdomain); get_the_time('Y') . '</span>';}
		elseif (is_author()) {echo '<span property="v:title">' . __("Author Archive",ktz_theme_textdomain) . '</span>';}
		elseif (isset($_GET['paged']) && !empty($_GET['paged'])) {echo '<span property="v:title">' . __("Blog Archives",ktz_theme_textdomain) . '</span>';}
		elseif (is_search()) {echo '<span property="v:title">' . __("Search Results",ktz_theme_textdomain) . '</span>';}
		elseif (is_404()) {echo '<span property="v:title">' . __("Page not found",ktz_theme_textdomain) . '</span>';}
		echo '</div></div>';
		endif;
	}
}

?>