<?php 
/*
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK FOR FREE THEME
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*
* Add post title on hook system
* How to use it for example
* ktz_posted_title_nonlink_h($hfont,$classes) use it
* ktz_posted_title_nonlink_h(h2,class-title) it's for <h2 class="entry-title class-title">
*/
if ( !function_exists('ktz_posted_title_a') ) :
function ktz_posted_title_a() {
	printf( __( '<a href="%1$s" title="Permalink to %2$s" rel="bookmark">%3$s</a>', ktz_theme_textdomain ),
		esc_url(get_permalink()),
		esc_attr(get_the_title()),
		esc_attr(get_the_title())
	);
	}
endif;
if ( !function_exists('ktz_posted_title_nonlink_h') ) :
function ktz_posted_title_nonlink_h($hfont,$classes) {
	printf( __( '<%4$s class="entry-title %5$s">%3$s</%4$s>', ktz_theme_textdomain ),
		esc_url(get_permalink()),
		esc_attr(get_the_title()),
		esc_attr(get_the_title()),
		$hfont,
		$classes
	);
	}
endif;

if ( !function_exists('ktz_posted_title_h') ) :
function ktz_posted_title_h($hfont,$classes) {
	printf( __( '<%4$s class="entry-title %5$s"><a href="%1$s" title="Permalink to %2$s" rel="bookmark">%3$s</a></%4$s>', ktz_theme_textdomain ),
		esc_url(get_permalink()),
		esc_attr(get_the_title()),
		esc_attr(get_the_title()),
		$hfont,
		$classes
	);
	}
endif;

/*******************************************
# Add rich snippet star rating ~ post
*******************************************/
if ( !function_exists('ktz_posted_ratting') ) :
function ktz_posted_ratting() {
	global $post,$wp_query;
	$postid = $wp_query->post->ID;
	$post_mt = get_post_meta( $postid, 'post_meta', true );
	$ratedisplay = empty($post_mt['ratedisplay']) ? '' : $post_mt['ratedisplay'];
	$ratevalue = empty($post_mt['ratevalue']) ? '' : $post_mt['ratevalue'];
	$ratenumb = array('0' => '', '0.5' => '05', '1' =>'1', '1.5' => '15','2' => '2','2.5' => '25','3' => '3','3.5' => '35','4' => '4','4.5' => '45','5' => '5');
	echo '<div xmlns:v="http://rdf.data-vocabulary.org/#" typeof="v:Review" class="rating-box"';
	if ($ratedisplay == '' ) { echo ' style="display:none;"'; }
	echo '>';
    echo '<span property="v:itemreviewed" class="rating-title">' . get_the_title() . '</span>';
    echo '<span class="rating-author">' . __('Reviewed by',ktz_theme_textdomain) . ' <span property="v:reviewer">' . get_the_author() . '</span></span>';
	echo '<span class="rating-date">' . __('on',ktz_theme_textdomain) . '<time property="v:dtreviewed" datetime="' . get_the_date('F j, Y') . '">' . get_the_time('l, F jS, Y') . '</time>.</span>';
    echo '<span property="v:summary" class="rating-summery">' . __('This Is Article About',ktz_theme_textdomain);
	echo the_title();
	echo '</span>';
    echo '<span property="v:description" class="rating-desc">' . get_the_excerpt() . '</span>';
    echo '<span class="rating"><span class="rating';
	if (@!empty($ratenumb[$ratevalue])) { echo $ratenumb[$ratevalue];}
	echo '" property="v:rating" content="'.$ratevalue.'" /></span>';
	echo '</div>';
	}
endif;

/*******************************************
# Add date on hook system ~ post
*******************************************/

if ( !function_exists('ktz_posted_on') ) :
function ktz_posted_on() {
	printf( __( '<a href="%1$s" title="%2$s" rel="bookmark"><time class="entry-date updated" datetime="%3$s" pubdate>%4$s</time></a>', ktz_theme_textdomain ),
		esc_url( get_permalink() ),
		esc_attr( get_the_time() ),
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() )
	);
}
endif;

/*******************************************
# Add author on hook system ~ post
*******************************************/
if ( !function_exists('ktz_author_by') ) :
function ktz_author_by() {
	printf( __( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s" rel="author">%3$s</a></span>', ktz_theme_textdomain ),
		esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
		esc_attr( sprintf( __( 'View all posts by %s', ktz_theme_textdomain ), get_the_author() ) ),
		get_the_author()
	);
}
endif;

/*******************************************
# Add categories on hook system ~ post
*******************************************/
if ( !function_exists('ktz_categories') ) :
function ktz_categories() { 
	$categories_list = get_the_category_list( __( ', ',ktz_theme_textdomain ) );
	if ( $categories_list ):
	printf( __( '<li><b>Category:</b> %2$s</li>',ktz_theme_textdomain ), 'entry-utility-prep entry-utility-prep-cat-links', $categories_list );
	endif; 
}
endif;

/*******************************************
# Add tags on hook system ~ post
*******************************************/
if ( !function_exists('ktz_tagged') ) :
function ktz_tagged() { 
	$tags_list = get_the_tag_list( '', __( ', ', ktz_theme_textdomain ) );
	if ( $tags_list ):
	printf( __('%2$s',ktz_theme_textdomain ), 'entry-utility-prep entry-utility-prep-tag-links', $tags_list );
	endif;
}
endif;

/*******************************************
# Add tags on hook system ~ post
*******************************************/
if ( !function_exists('ktz_single_tagged') ) :
function ktz_single_tagged() { 
	$tags_list = get_the_tag_list( '<ul class="wp-tag-cloud"><li>','</li><li>','</li></ul>' );
	if ( $tags_list ):
	printf( __('<span class="wraptags">%2$s</span>',ktz_theme_textdomain ), 'entry-utility-prep entry-utility-prep-tag-links', $tags_list );
	endif;
}
endif;

/*******************************************
# Add comment number on hook system ~ post
*******************************************/
if ( !function_exists('ktz_comment_num') ) :
function ktz_comment_num() {
	if ( comments_open() && ! post_password_required() ) :
	echo '<span class="comments-link">';
	comments_popup_link( __( '0', ktz_theme_textdomain ), _x( '1', 'comments number', ktz_theme_textdomain ), _x( '%', 'comments number', ktz_theme_textdomain ) );
	echo '</span>';
	endif;
}
endif;

if ( !function_exists('ktz_comment_num2') ) :
function ktz_comment_num2() {
	if ( comments_open() && ! post_password_required() ) :
	echo '<span class="leave-reply pull-right">';
	comments_popup_link( __( 'No comments', ktz_theme_textdomain ), _x( '1 comments', 'comments number', ktz_theme_textdomain ), _x( '% comments', 'comments number', ktz_theme_textdomain ) );
	echo '</span>';
	endif;
}
endif;

/*******************************************
# Add auto read more @ kasep theme v.1.01
*******************************************/
function ktz_get_excerpt($limit){
	global $post;
  $permalink = get_permalink($post->ID);
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).' <span class="read-more pull-right"><a href="'. $permalink . '">' . __( 'Read More', ktz_theme_textdomain ) . '</a></span>';
  } else {
    $excerpt = implode(" ",$excerpt);
  }	
  $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
  return $excerpt;
}

/*******************************************
# Add content on hook system ~ post 
# Call autoread @ kasep theme v.1.01
*******************************************/
if ( !function_exists('ktz_content') ) :
function ktz_content() {
	if ( is_search() ) :
	the_excerpt(); 
	else :
		if ( get_theme_option('ktz_active_automore') != '' && !(is_single()) ) // Set active/deactive via admin
			{ 
				$readmore_count = get_theme_option('ktz_automore_count');
				echo ktz_get_excerpt($readmore_count); 
			} // call function auto readmore
		else
			{ 
				the_content( __( '<strong>...</strong>', ktz_theme_textdomain ) ); 
			}
	endif;
}
endif;

/*******************************************
# Add link pages on hook system ~ post
*******************************************/
if ( !function_exists('ktz_link_pages') ) :
function ktz_link_pages() {	
	wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', ktz_theme_textdomain ) . '</span>', 'after' => '</div>' ) );
	}
endif;

/*******************************************
# Add auto featured image from post attach
# If has_thumb elseif firstimage else no image
*******************************************/
function ktz_autoset_featured( $new_status ) {
	if ( ! isset( $GLOBALS['post']->ID ) )
		return NULL;
	if ( has_post_thumbnail( get_the_ID() ) )
		return NULL;
	$args = array(
		'numberposts'    => 1,
		'order'          => 'ASC', // DESC for the last image
		'post_mime_type' => 'image',
		'post_parent'    => get_the_ID(),
		'post_status'    => NULL,
		'post_type'      => 'attachment'
	);
	$attached_image = get_children( $args );
	if ( $attached_image ) {
		foreach ( $attached_image as $attachment_id => $attachment )
		set_post_thumbnail( get_the_ID(), $attachment_id );
	}
}

/*******************************************
# Get first image post functions
*******************************************/
function get_first_image_src() {
    $content = get_the_content();
    $image_regex = "/<img [^>]*src=[\"']([^\"^']*)[\"']/";
    preg_match($image_regex, $content, $match);
    if (empty($match))
        return "";
    return $match[1];
}
function get_first_image_src_height() {
    $content = get_the_content();
    $imageheight_regex = "/<img [^>]*height=[\"']([^\"^']*)[\"']/";
    preg_match($imageheight_regex, $content, $match);
    if (empty($match))
        return "";
    return $match[1];
}
function get_first_image_src_width() {
    $content = get_the_content();
    $imagewidth_regex = "/<img [^>]*width=[\"']([^\"^']*)[\"']/";
    preg_match($imagewidth_regex, $content, $match);
    if (empty($match))
        return "";
    return $match[1];
}

if ( !function_exists('ktz_feature_img') ) :
function ktz_feature_img($width, $height) { 
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$params = array( 'width' => $width, 'height' => $height, 'crop' => true );
	$image = bfi_thumb( $img_url, $params );
	$first_image = bfi_thumb( $fisrtimg_url, $params  ); 
	if ( $img_url ) { 
		echo '<a class="linkimage" href="' . $permalink . '">';
		echo '<img src="' . $image . '" class="thumbnail btn-box ktz-thumb" alt="' . $title . '" title="' . $title . '" width="' . $width . '" height="' . $height . '" />';
		echo '</a>';
	} elseif ( $first_image ) {
		echo '<a class="linkimage" href="' . $permalink . '">';
		echo '<img src="' . $first_image . '" class="thumbnail btn-box ktz-thumb" alt="' . $title . '" title="' . $title . '" width="' . $width . '" height="' . $height . '" />';
		echo '</a>';	
	} else { 
		echo ''; 
	} 
}
endif;
if ( !function_exists('ktz_feature_justimg') ) :
function ktz_feature_justimg($width, $height) { 
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$params = array( 'width' => $width, 'height' => $height, 'crop' => true );
	$image = bfi_thumb( $img_url, $params );
	$first_image = bfi_thumb( $fisrtimg_url, $params ); 
	if ( $img_url ) { 
		echo '<img src="' . $image . '" class="thumbnail btn-box" alt="' . $title . '" title="' . $title . '" width="' . $width . '" height="' . $height . '" />';
	} elseif ( $fisrtimg_url ) {
		echo '<img src="' . $first_image . '" class="thumbnail btn-box" alt="' . $title . '" title="' . $title . '" width="' . $width . '" height="' . $height . '" />';
	} else { 
		echo ''; 
	} 
}
endif;

if ( !function_exists('ktz_feature_justlink') ) :
function ktz_feature_justlink($width) { 
	global $post;
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$params = array( 'width' => $width );
	$image = bfi_thumb( $img_url, $params );
	$first_image = bfi_thumb( $fisrtimg_url, $params ); 
	$default_image = ktz_url . 'img/no-image/no-thumb.jpg';
	if ( $img_url ) { 
		echo $image;
	} elseif ( $fisrtimg_url ) {
		echo $first_image;
	} else { 
		echo $default_image; 
	} 
}
endif;

?>