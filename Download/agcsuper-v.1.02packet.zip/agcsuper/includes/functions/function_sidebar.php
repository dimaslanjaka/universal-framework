<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ SIDEBAR FRAMEWORK
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*******************************************
# Register sidebar on hook system ~ post
*******************************************/
function sidebar_widget_init() {
	register_sidebar(array('name' => __( 'Default Sidebar', ktz_admin_textdomain ),'id' => 'sidebar_default','description' => 'sidebar','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
	register_sidebar(array('name' => __( 'Top home module', ktz_admin_textdomain ),'id' => 'widget_tophome','description' => 'Top home module','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
	register_sidebar(array('name' => __( 'Left home module', ktz_admin_textdomain ),'id' => 'widget_leftmodule','description' => 'Left home module','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>'));
	register_sidebar(array('name' => __( 'Right home module', ktz_admin_textdomain ),'id' => 'widget_rightmodule','description' => 'Right home module','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>'));
	register_sidebar(array('name' => __( 'Footer home module 1', ktz_theme_textdomain ),'id' => 'widget_footermodule_1','description' => 'Footer home module 1','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>'));
	register_sidebar(array('name' => __( 'Footer home module 2', ktz_theme_textdomain ),'id' => 'widget_footermodule_2','description' => 'Footer home module 2','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>'));
	register_sidebar(array('name' => __( 'Footer home module 3', ktz_theme_textdomain ),'id' => 'widget_footermodule_3','description' => 'Footer home module 3','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>'));
    register_sidebar(array('name' => __( 'Footer 1', ktz_admin_textdomain ),'id' => 'widget_fot1','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
    register_sidebar(array('name' => __( 'Footer 2', ktz_admin_textdomain ),'id' => 'widget_fot2','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
    register_sidebar(array('name' => __( 'Footer 3', ktz_admin_textdomain ),'id' => 'widget_fot3','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
    register_sidebar(array('name' => __( 'Footer 4', ktz_admin_textdomain ),'id' => 'widget_fot4','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
    register_sidebar(array('name' => __( 'Footer 5', ktz_admin_textdomain ),'id' => 'widget_fot5','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
    register_sidebar(array('name' => __( 'Footer 6', ktz_admin_textdomain ),'id' => 'widget_fot6','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>', ));
	$getpages = get_pages();
	foreach($getpages as $ktzpost) {
		$page_mt = get_post_meta( $ktzpost->ID, 'page_meta', true );
		$sb = isset($page_mt['sidebar']) ? $page_mt['sidebar'] : '';
		if ( $sb == 'true' ){
		register_sidebar( array('name' => $ktzpost->post_title.__( ' sidebar ', ktz_admin_textdomain ),'id' => $ktzpost->ID.'-sidebar','description' => 'sidebar','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>','before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>') );
		}
	}
	$args_post = array('post_type' => 'post', 'terms' => array ( 'post-format-gallery' ));
	$getpost = get_posts($args_post);
	foreach($getpost as $ktzpost) {
		$page_mt = get_post_meta( $ktzpost->ID, 'post_meta', true );
		$sb = isset($page_mt['sidebar']) ? $page_mt['sidebar'] : '';
		if ( $sb == 'true' ){
		register_sidebar( array('name' => $ktzpost->post_title.__( ' sidebar', ktz_admin_textdomain ),'id' => $ktzpost->ID.'-sidebar','description' => 'sidebar','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>', 'before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>') );
		}
	}
	$args = array('post_type' => 'product');
	$getproduct = get_posts($args);
	foreach($getproduct as $ktzpost) {
		$page_mt = get_post_meta( $ktzpost->ID, 'product_meta', true );
		$sb = isset($page_mt['sidebar']) ? $page_mt['sidebar'] : '';
		if ( $sb == 'true' ){
		register_sidebar( array('name' => $ktzpost->post_title.__( ' sidebar', ktz_admin_textdomain ),'id' => $ktzpost->ID.'-sidebar','description' => 'sidebar','before_widget' => '<aside id="%1$s" class="widget %2$s">','after_widget' => '</aside>', 'before_title' => '<h4 class="widget-title"><span>','after_title' => '</span></h4>') );
		}
	}
}

?>