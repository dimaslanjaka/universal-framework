<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK FOR FREE THEME
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*******************************************
# Default navigation on hook system ~ post
*******************************************/
if ( ! function_exists( 'ktz_default_nav' ) ) {
function ktz_default_nav() {
	global $wp_query;
	if ( is_single() ) :
	echo '<div class="pull-left">';
	echo previous_post_link( '<div class="button-prev">%link</div>', __( 'Prev', 'Previous post link', ktz_theme_textdomain ) );
	echo '</div>';
	echo '<div class="pull-right">';
	echo next_post_link( '<div class="button-next">%link</div>', __( 'Next', 'Next post link', ktz_theme_textdomain ) );
	echo '</div>';
	echo '<center>';
	echo ktz_ajaxstar_SEO_single();
	echo '</center>';
	elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) :
	echo '<ul class="pager">';
		if ( get_next_posts_link() ) :
		echo '<li>';
		echo next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', ktz_theme_textdomain ) );
		echo '</li>';
		endif;
		if ( get_previous_posts_link() ) :
		echo '<li>';
		echo previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', ktz_theme_textdomain ) );
		echo '</li>';
		endif;
	echo '</ul>';
	endif; 
	}
}


/*******************************************
# Number navigation on hook system ~ post
*******************************************/
function round_num($num, $to_nearest) {
   return floor($num/$to_nearest)*$to_nearest;
}
if ( ! function_exists( 'ktz_pagenavi' ) ):
function ktz_pagenavi($before = '', $after = '') {
    global $wpdb, $wp_query;
    $pagenavi_options = array();
    $pagenavi_options['pages_text'] = __('Page %CURRENT_PAGE% of %TOTAL_PAGES%:',ktz_theme_textdomain);
    $pagenavi_options['current_text'] = __('%PAGE_NUMBER%',ktz_theme_textdomain);
    $pagenavi_options['page_text'] = __('%PAGE_NUMBER%',ktz_theme_textdomain);
    $pagenavi_options['first_text'] = __('First Page',ktz_theme_textdomain);
    $pagenavi_options['last_text'] = __('Last Page',ktz_theme_textdomain);
    $pagenavi_options['next_text'] = __('Next &raquo;',ktz_theme_textdomain);
    $pagenavi_options['prev_text'] = __('&laquo; Previous',ktz_theme_textdomain);
    $pagenavi_options['dotright_text'] = '...';
    $pagenavi_options['dotleft_text'] = '...';
    $pagenavi_options['num_pages'] = 5;
    $pagenavi_options['always_show'] = 0;
    $pagenavi_options['num_larger_page_numbers'] = 0;
    $pagenavi_options['larger_page_numbers_multiple'] = 5;
 
    if (!is_single()) {
        $request = $wp_query->request;
        $posts_per_page = intval(get_query_var('posts_per_page'));
        $paged = intval(get_query_var('paged'));
        $numposts = $wp_query->found_posts;
        $max_page = $wp_query->max_num_pages;
 
        if(empty($paged) || $paged == 0) { $paged = 1; }
 
        $pages_to_show = intval($pagenavi_options['num_pages']);
        $larger_page_to_show = intval($pagenavi_options['num_larger_page_numbers']);
        $larger_page_multiple = intval($pagenavi_options['larger_page_numbers_multiple']);
        $pages_to_show_minus_1 = $pages_to_show - 1;
        $half_page_start = floor($pages_to_show_minus_1/2);
        $half_page_end = ceil($pages_to_show_minus_1/2);
        $start_page = $paged - $half_page_start;
 
        if($start_page <= 0) { $start_page = 1; }
 
        $end_page = $paged + $half_page_end;
        if(($end_page - $start_page) != $pages_to_show_minus_1) { $end_page = $start_page + $pages_to_show_minus_1; }
        if($end_page > $max_page) { $start_page = $max_page - $pages_to_show_minus_1; $end_page = $max_page; }
        if($start_page <= 0) { $start_page = 1; }
 
        $larger_per_page = $larger_page_to_show*$larger_page_multiple;
        $larger_start_page_start = (round_num($start_page, 10) + $larger_page_multiple) - $larger_per_page;
        $larger_start_page_end = round_num($start_page, 10) + $larger_page_multiple;
        $larger_end_page_start = round_num($end_page, 10) + $larger_page_multiple;
        $larger_end_page_end = round_num($end_page, 10) + ($larger_per_page);
 
        if($larger_start_page_end - $larger_page_multiple == $start_page) {
            $larger_start_page_start = $larger_start_page_start - $larger_page_multiple;
            $larger_start_page_end = $larger_start_page_end - $larger_page_multiple;
        }
        if($larger_start_page_start <= 0) { $larger_start_page_start = $larger_page_multiple; }
        if($larger_start_page_end > $max_page) { $larger_start_page_end = $max_page; }
        if($larger_end_page_end > $max_page) { $larger_end_page_end = $max_page; }
        if($max_page > 1 || intval($pagenavi_options['always_show']) == 1) {
			echo $before.'<div class="pagination pagination-large pagination-centered"><ul>'."\n";
            $pages_text = str_replace("%CURRENT_PAGE%", number_format_i18n($paged), $pagenavi_options['pages_text']);
            $pages_text = str_replace("%TOTAL_PAGES%", number_format_i18n($max_page), $pages_text);
            if(!empty($pages_text)) {
				echo '<li class="disabled">';
                echo '<span>'.$pages_text.'</span>';
				echo '</li>';
            }
			if ( get_previous_posts_link() ) :
				echo '<li>';
				previous_posts_link($pagenavi_options['prev_text']);
				echo '</li>';
			endif;
            if ($start_page >= 2 && $pages_to_show < $max_page) {
                $first_page_text = str_replace("%TOTAL_PAGES%", number_format_i18n($max_page), $pagenavi_options['first_text']);
                echo '<li><a href="'.esc_url(get_pagenum_link()).'" class="first" title="'.$first_page_text.'">1</a></li>';
                if(!empty($pagenavi_options['dotleft_text'])) {
                    echo '<li class="disabled"><span>'.$pagenavi_options['dotleft_text'].'</span></li>';
                }
            }
 
            if($larger_page_to_show > 0 && $larger_start_page_start > 0 && $larger_start_page_end <= $max_page) {
                for($i = $larger_start_page_start; $i < $larger_start_page_end; $i+=$larger_page_multiple) {
                    $page_text = str_replace("%PAGE_NUMBER%", number_format_i18n($i), $pagenavi_options['page_text']);
                    echo '<li><a href="'.esc_url(get_pagenum_link($i)).'" title="'.$page_text.'">'.$page_text.'</a></li>';
                }
            }
 
            for($i = $start_page; $i  <= $end_page; $i++) {
                if($i == $paged) {
                    $current_page_text = str_replace("%PAGE_NUMBER%", number_format_i18n($i), $pagenavi_options['current_text']);
					$page_text = str_replace("%PAGE_NUMBER%", number_format_i18n($i), $pagenavi_options['page_text']);
                    echo '<li class="active"><a href="'.esc_url(get_pagenum_link($i)).'" title="'.$page_text.'">'.$current_page_text.'</a></li>';
                } else {
                    $page_text = str_replace("%PAGE_NUMBER%", number_format_i18n($i), $pagenavi_options['page_text']);
                    echo '<li><a href="'.esc_url(get_pagenum_link($i)).'" title="'.$page_text.'">'.$page_text.'</a></li>';
                }
            }
 
            if ($end_page < $max_page) {
                if(!empty($pagenavi_options['dotright_text'])) {
                    echo '<li class="disabled"><span>'.$pagenavi_options['dotright_text'].'</span></li>';
                }
                $last_page_text = str_replace("%TOTAL_PAGES%", number_format_i18n($max_page), $pagenavi_options['last_text']);
                echo '<li><a href="'.esc_url(get_pagenum_link($max_page)).'" title="'.$last_page_text.'">'.$max_page.'</a></li>';
            }
 
            if($larger_page_to_show > 0 && $larger_end_page_start < $max_page) {
                for($i = $larger_end_page_start; $i <= $larger_end_page_end; $i+=$larger_page_multiple) {
                    $page_text = str_replace("%PAGE_NUMBER%", number_format_i18n($i), $pagenavi_options['page_text']);
                    echo '<li><a href="'.esc_url(get_pagenum_link($i)).'" title="'.$page_text.'">'.$page_text.'</a></li>';
                }
            }
			if ( get_next_posts_link() ) :
				echo '<li class="next-post-ajax">';
				next_posts_link($pagenavi_options['next_text'], $max_page);
				echo '</li>';
			endif;
            echo '</ul></div>'.$after."\n";
        }
    }
}
endif; 

/*******************************************
# Add navigation on hook system ~ post
*******************************************/
if ( !function_exists('ktz_navigation') ) {
function ktz_navigation() { 
if (get_theme_option('ktz_nav_select') == 'number') { 
		ktz_pagenavi(); 
	} 
elseif (get_theme_option('ktz_nav_select') == 'default') { 
		ktz_default_nav();
	}
  }
}

/* 
* Add author box in single page
* Add add_action( 'do_ktz_singlecontent', 'ktz_author_box' ); in init.php 
*/
if ( !function_exists('ktz_author_box') ) {
function ktz_author_box() { 
	if ( get_theme_option('ktz_active_autbox') != '' ) :
	if (is_single()) {
		echo '<div class="authorbox">';
		echo '<div class="row-fluid">';
		echo '<div class="span2"><div class="author-thumb">';
		echo get_avatar( get_the_author_meta( 'user_email' ), $size='120', '', $alt='author' );
		echo '</div></div>';
		echo '<div class="span10">';
		if (get_the_author_meta('twitter') != '' || get_the_author_meta('facebook') != '' || get_the_author_meta('googleplus') != '' || get_the_author_meta('url') != '' ) {
		echo '<div class="clearfix icony-author">';
		echo '<h4 class="entry-title pull-left">' . __( 'Author:',ktz_theme_textdomain) . '&nbsp;';
		echo the_author_posts_link();
		echo '</h4>';
		echo '<ul class="icon24px pull-right">';
		if (get_the_author_meta('twitter') != '' ) {
			echo '<li><a href="http://twitter.com/';
			echo the_author_meta('twitter');
			echo '" class="twitter" target="_blank" title="' . __( 'Follow',ktz_theme_textdomain) . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on Twitter',ktz_theme_textdomain) . '"><span class="fontawesome ktzfo-twitter"></span></a></li>';
			} if (get_the_author_meta('facebook') != '' ) {
			echo '<li><a href="';
			echo the_author_meta('facebook');
			echo '" class="facebook" target="_blank" title="' . __( 'Add',ktz_theme_textdomain) . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on facebook',ktz_theme_textdomain) . '"><span class="fontawesome ktzfo-facebook"></span></a></li>';
			} if (get_the_author_meta('googleplus') != '' ) {
			echo '<li><a href="';
			echo the_author_meta('googleplus');
			echo '" class="gplus" target="_blank" title="' . __( 'Cycle',ktz_theme_textdomain) . ' ';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'on googleplus',ktz_theme_textdomain) . '"><span class="fontawesome ktzfo-google-plus"></span></a></li>';
			} if (get_the_author_meta('url') != '' ) {
			echo '<li><a href="';
			echo the_author_meta('url');
			echo '" class="rss" target="_blank" title="';
			echo the_author_meta( 'display_name' );
			echo ' ' . __( 'site',ktz_theme_textdomain) . '"><span class="fontawesome ktzfo-rss"></span></a></li>';
			} 
			echo '</ul></div>';
		}		
		echo '<p>';
		echo the_author_meta( 'description' );
		echo '</p>';
		echo '</div></div>';
		echo '</div>';
		}
	endif;
	} 	
}

/*******************************************
# Add related post on hook system ~ post
*******************************************/
if ( !function_exists('ktz_relpost') ) {
function ktz_relpost() {
	if ( get_theme_option('ktz_active_related') != '' ) :
	global $post;
	$orig_post = $post;
	if (get_theme_option('ktz_taxonomy_relpost') == 'tags')
	{
		$tags = wp_get_post_tags($post->ID);
		if ($tags) {
			$tag_ids = array();
			foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
			$args=array(
				'tag__in' => $tag_ids,
				'post__not_in' => array($post->ID),
				'posts_per_page'=> 4,
				'ignore_sticky_posts'=>1
			);
		}
	} 
	else
	{
		$categories = get_the_category($post->ID);
		if ($categories) {
			$category_ids = array();
			foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
			$args=array(
			'category__in' => $category_ids,
			'post__not_in' => array($post->ID),
			'posts_per_page'=> 4,
			'ignore_sticky_posts'=>1
			);
		} 
	} 
	if (!isset($args)) $args = '';
	$ktz_query = new WP_Query($args);
	if( $ktz_query->have_posts() ) { 
		echo '<h2 class="related-title"><span>' . __( 'Related post for',ktz_theme_textdomain) . ' ' . get_the_title() . '</span></h2>';
		echo '<ul class="related-post clearfix">';
		while ($ktz_query -> have_posts()) : $ktz_query -> the_post(); 
		echo'<li>';
		echo ktz_feature_img( 140, 140 );
		echo '<div class="title-related">';
		echo ktz_posted_title_a();
		echo '</div>';
		echo'</li>';
		endwhile;
		echo'</ul>';
	} // if have posts
	$post = $orig_post; 
	wp_reset_query();
	endif;
	}
}

/*******************************************
# Add share article in single post ~ Post
*******************************************/
function ktz_socialshare_fb() {
    global $post;
	$href = get_permalink();
	echo '<div id="fb-root"></div><fb:like href="'.$href.'" layout="button_count" action="like" show_faces="false" share="false"></fb:like>';
}

function ktz_socialshare_twit() {
    global $post;
	$href = get_permalink();
	echo '<a href="http://twitter.com/share" class="twitter-share-button" data-url="'.$href.'" data-size="medium" data-count="horizontal" data-lang="en">Tweet</a>';
}

function ktz_socialshare_gplus() {
    global $post;
	$href = get_permalink();
	echo '<g:plusone size="medium" annotation="bubble" callback="ktz_gplus" href="'.$href.'"></g:plusone>';
}
function ktz_socialshare_fb_search() {
    global $post;
	$changethis = array('search');
	$withthis = get_theme_option('ktz_search_permalink');
	echo '<div id="fb-root"></div><fb:like href="';
	echo str_replace($changethis, $withthis ,get_search_link());
	echo '" layout="button_count" action="like" show_faces="false" share="false"></fb:like>';
}

function ktz_socialshare_twit_search() {
    global $post;
	$changethis = array('search');
	$withthis = get_theme_option('ktz_search_permalink');
	echo '<a href="http://twitter.com/share" class="twitter-share-button" data-url="';
	echo str_replace($changethis, $withthis ,get_search_link());
	echo '" data-size="medium" data-count="horizontal" data-lang="en">Tweet</a>';
}

function ktz_socialshare_gplus_search() {
    global $post;
	$changethis = array('search');
	$withthis = get_theme_option('ktz_search_permalink');
	echo '<g:plusone size="medium" annotation="bubble" callback="ktz_gplus" href="';
	echo str_replace($changethis, $withthis ,get_search_link());
	echo '"></g:plusone>';
}

/*******************************************
# All banner function ######################
*******************************************/
if ( !function_exists('ktz_headbanner') ) {
function ktz_headbanner() { 
	if (!is_search()) {
	if ( get_theme_option('ktz_ban72890_top') != '' ) :
	echo '<div id="headbanner">';
	echo get_theme_option('ktz_ban72890_top');
	echo '</div>';
	endif;
	}
  }
}

if ( !function_exists('ktz_ban72890_mainhead') ) {
function ktz_ban72890_mainhead() { 
	if (!is_search()) {
	if ( get_theme_option('ktz_ban72890_head') != '' ) :
	echo '<div class="bannermain_head">';
		echo get_theme_option('ktz_ban72890_head');
	echo '</div>';
	endif;
	}
  }
}

if ( !function_exists('ktz_ban72890_mainfooter') ) {
function ktz_ban72890_mainfooter() { 
	if (!is_search()) {
	if ( get_theme_option('ktz_ban72890_footer') != '' ) :
	echo '<div class="bannermain_footer">';
		echo get_theme_option('ktz_ban72890_footer');
	echo '</div>';
	endif;
	}
  }
}

if ( !function_exists('ktz_ban46860_singlehead') ) {
function ktz_ban46860_singlehead() { 
	if ( get_theme_option('ktz_ban46860_shead') != '' ) :
	echo '<div class="bannersinglefot">';
		echo get_theme_option('ktz_ban46860_shead');
	echo '</div>';
	endif;
  }
}

if ( !function_exists('ktz_ban46860_singletit') ) {
function ktz_ban46860_singletit() { 
	if ( get_theme_option('ktz_ban46860_stit') != '' ) :
	echo '<div class="bannersinglefot">';
		echo get_theme_option('ktz_ban46860_stit');
	echo '</div>';
	endif;
  }
}

if ( !function_exists('ktz_ban46860_singlefoot') ) {
function ktz_ban46860_singlefoot() { 
	if ( get_theme_option('ktz_ban46860_sfot') != '' ) :
	echo '<div class="bannersinglefot">';
		echo get_theme_option('ktz_ban46860_sfot');
	echo '</div>';
	endif;
  }
}

if ( !function_exists('ktz_ban336_topsingle_right') ) {
function ktz_ban336_topsingle_right() { 
	if ( get_theme_option('ktz_ban336_topsingle_right_set') != '' ) :
	echo '<div class="bannersingle_righthead clearfix">';
		echo get_theme_option('ktz_ban336_topsingle_right_set');
	echo '</div>';
	endif;
  }
}

if ( !function_exists('ktz_ban336_botsingle_right') ) {
function ktz_ban336_botsingle_right() { 
	if ( get_theme_option('ktz_ban336_botsingle_right_set') != '' ) :
	echo '<div class="bannersingle_rightfooter">';
		echo get_theme_option('ktz_ban336_botsingle_right_set');
	echo '</div>';
	endif;
  }
}

/*******************************************
# Function Comment Facebook ########
*******************************************/
if ( !function_exists('ktz_comments_facebook') ) {
function ktz_comments_facebook() { 
	if ( get_theme_option('ktz_facebook_com_activated') != '' ) : 
    echo '<div id="fb-root"></div><fb:comments href="' . get_permalink() . '" width="510"></fb:comments>';  
	endif;
	} 	
}

/* 
* Default google comment form wordpress
*/
if ( !function_exists('ktz_comments_google') ) {
function ktz_comments_google() { 
	if ( get_theme_option('ktz_google_com_activated') != '' ) : 
	echo '<div class="g-comments" data-href="' . get_permalink() . '" data-width="590" data-first_party_property="BLOGGER" data-view_type="FILTERED_POSTMOD"></div>';
	endif;
	} 	
}

/*******************************************
# Function add error page ##################
*******************************************/
function ktz_error_page() { ?>
	<img src="<?php echo get_theme_option('ktz_404'); ?>" alt="<?php bloginfo('name'); ?>" title="<?php bloginfo('name'); ?>" />
	<hr class="single" />
	<h3><?php _e( 'The page you are looking for doesn\'t seem to exist.', ktz_theme_textdomain ); ?></h3>
	<hr class="double" />
	<?php 
}

/*******************************************
# Add post not found on hook system ~ post
*******************************************/
if ( ! function_exists( 'ktz_post_notfound' ) ) :
function ktz_post_notfound() { ?>
	<article id="post-0" class="post no-results not-found" style="text-align:center;">
		<header class="entry-header">
			<h2><?php _e( 'Nothing Found', ktz_theme_textdomain ); ?></h2>
		</header>
			<div class="entry-content-notfound">
			<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', ktz_theme_textdomain ); ?></p>
			<?php get_search_form(); ?>
			</div>
	</article>
	<?php } 	
endif;

?>