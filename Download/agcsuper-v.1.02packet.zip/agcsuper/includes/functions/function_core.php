<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ FRAMEWORK FOR FREE THEME
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*
 * This is Required from wordpress
 */
if ( ! isset( $content_width ) ) $content_width = 620;

/*
 * Change avatar CSS on hook system ~ post
 */
function change_avatar_css($class) {
	$class = str_replace("class='avatar", "class='thumbnail btn-box", $class) ;
	return $class;
}

/*
 * Remove auto p on hook system ~ post
 */
if( !function_exists('ktz_remove_wpautop') ) {
function ktz_remove_wpautop( $content ) { 
	$content = trim( do_shortcode( shortcode_unautop ( $content ) ) ); 
	$content = preg_replace('#^<\/p>|^<br />|<p>$|</p><p>\s*( )?\s*<\/p>#', '', $content);
	return $content;
	}
}

/*
 * WP texturize on hook system ~ post
 */
function ktz_texturize_SC($content) {
	$content = preg_replace('/\]\[/im', "]\n[", $content);
	return $content;
}

/*
 * Disabling auto format on hook system ~ post
 */
function ktz_formatter($content) {
	$new_content = '';
	$pattern_full = '{(\[raw\].*?\[/raw\])}is';
	$pattern_contents = '{\[raw\](.*?)\[/raw\]}is';
	$pieces = preg_split($pattern_full, $content, -1, PREG_SPLIT_DELIM_CAPTURE);
	foreach ($pieces as $piece) {
		if (preg_match($pattern_contents, $piece, $matches)) {
			$new_content .= $matches[1];
		} else {
			$pattern_full_intl = '{(\<!--start_raw-->.*?\<!--end_raw-->)}is';
			$pattern_contents_intl = '{<!--start_raw-->(.*?)\<!--end_raw-->}is';
			$pieces_intl = preg_split($pattern_full_intl, $piece, -1, PREG_SPLIT_DELIM_CAPTURE);
			
			foreach ($pieces_intl as $piece_intl) {
				if (preg_match($pattern_contents_intl, $piece_intl, $matches_intl)) {
					$new_content .= $matches_intl[1];
				} else {
					$new_content .= wptexturize(wpautop($piece_intl));
				}
			}
		}
	}
	return $new_content;
}

/*
 * Add theme support on hook system ~ post
 */
if( !function_exists('ktz_setup') ) {
function ktz_setup() {
    add_theme_support('post-thumbnails');
	add_theme_support('automatic-feed-links');
	add_theme_support('custom-background');
	add_theme_support('custom-header'); // Just required for WP standart API
	}
}

/*
 * Filter tag cloud
 */
function ktz_tag_cloud($args) {
	$args = array('smallest' => 10, 'largest' => 10, 'number' => 30, 'orderby' => 'count');
	return $args;
}

/*
 * Get template
 */
if ( !function_exists('ktz_get_template') ) {
	function ktz_get_template( $template_name, $part_name = null ) {
		ob_start();
		get_template_part( $template_name, $part_name );
		$output = ob_get_contents();
		ob_end_clean();
		return $output;
	}
}

/*
 * Add editor style on hook system ~ post
 */
if(function_exists('add_editor_style')) {
	add_editor_style();
}

/*
 * Get limit in the excerpt - use <?php echo ktz_excerpt(number); ?>
 */
function ktz_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  }	
  $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
  return $excerpt;
}

/*
 * Get transient on hook system ~ post
 */
if( !function_exists('request_url') ) {
	function ktz_get_transient($request_url) {  
        $raw_response = wp_remote_get( $request_url, array( 'timeout' => 1 ) );  
        if ( is_wp_error( $raw_response ) )  
            return $raw_response;  
        $code = (int) wp_remote_retrieve_response_code($raw_response);  
        $response = json_decode( wp_remote_retrieve_body($raw_response) );  
        switch( $code ):  
            case 200:  
                return $response;  
            case 304:  
            case 400:  
            case 401:  
            case 403:  
            case 404:  
            case 406:  
            case 420:  
            case 500:  
            case 502:  
            case 503:  
            case 504:  
                return new WP_Error($code, $response->error);  
            default:  
                return new WP_Error($code, __('Invalid response','twitter'));  
        endswitch;  
    }  
}

/*
 * Set transient on hook system ~ post
 */
if( !function_exists('ktz_set_transient') ) {
	function ktz_set_transient($key, $data, $expiration) {  
        // Time when transient expires  
        $expire = time() + $expiration;  
        set_transient( $key, array( $expire, $data ) );  
    }  
} 	

/*
 * Setup meta for view post
 */
function ktz_getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return '<span class="viewpost">0 View</span>';
    }
    return '<span class="viewpost">' . $count . ' Views</span>';
}
function ktz_getPostViews_single($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return '<li><b>Display:</b> 0 View</li>';
    }
    return '<li><b>Display:</b> ' . $count . ' Views</li>';
}
function ktz_setPostViews($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

/*
 * Add extra user field in admin panel
 */
function my_show_extra_profile_fields( $user ) {
	echo '<h3>Social network:</h3>';
	echo '<table class="form-table"><tr><th><label for="twitter">' . __('Twitter', ktz_theme_textdomain) . '</label></th>';
	echo '<td><input type="text" name="twitter" id="twitter" value="';
	echo esc_attr( get_the_author_meta( 'twitter', $user->ID ) ); 
	echo '" class="regular-text" /><br /><span class="description">' . __('Please enter your Twitter username without the @.', ktz_theme_textdomain) . '</span>';
	echo '</td></tr></table><table class="form-table"><tr>';
	echo '<th><label for="facebook">' . __('Facebook', ktz_theme_textdomain) . '</label></th>';
	echo '<td><input type="text" name="facebook" id="facebook" value="';
	echo esc_attr( get_the_author_meta( 'facebook', $user->ID ) );
	echo '" class="regular-text" /><br /><span class="description">' . __('Please enter your facebook full url example http://www.facebook.com/kentoozdotcom.', ktz_theme_textdomain) . '</span>';
	echo '</td></tr></table><table class="form-table"><tr><th><label for="googleplus">' . __('Google plus', ktz_theme_textdomain) . '</label></th>';
	echo '<td><input type="text" name="googleplus" id="googleplus" value="';
	echo esc_attr( get_the_author_meta( 'googleplus', $user->ID ) );
	echo '" class="regular-text" /><br /><span class="description">' . __('Please enter your google plus full url example http://plus.google.com/100237202599723142598.', ktz_theme_textdomain) . '</span>';
	echo '</td></tr></table>';
}
function my_save_extra_profile_fields( $user_id ) {
	if ( !current_user_can( 'edit_user', $user_id ) )
		return false;
	update_user_meta( $user_id, 'twitter', $_POST['twitter'] );
	update_user_meta( $user_id, 'facebook', $_POST['facebook'] );
	update_user_meta( $user_id, 'googleplus', $_POST['googleplus'] );
}

/*******************************************
 * ALL AGC FUNGTIONS BING ******************
 *******************************************/
/*
 * Rewrite serach with other text
 */
function ktz_ChangeSearchString( $search_rewrite ) {
	if( !is_array( $search_rewrite ) )
		return $search_rewrite;
	$new_array = array();
	$searchpermalink = get_theme_option('ktz_search_permalink') . '/';
	foreach( $search_rewrite as $pattern => $_s_query_string )
		$new_array[ str_replace( 'search/', $searchpermalink, $pattern ) ] = $_s_query_string;
	$search_rewrite = $new_array;
	unset( $new_array );
	return $search_rewrite;
}

/*
 * Redirect default search link in to pretty permalink
 */
function ktz_parse_query()
{
  global $wp_query;
 
  // redirect
  if(is_search() && isset($_GET['s']))
  {
    ob_end_clean();  
    $change = array('+',' ','%20');
	$searchpermalink = '/' . get_theme_option('ktz_search_permalink') . '/';
	$html_option = get_theme_option('ktz_active_htmlsearch') != '' ? '.html' : '';
    $redirect = home_url($searchpermalink) . '' . str_replace($change, '-' ,$_GET['s']). ''.$html_option;
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: $redirect");
    die;
  }
}
/*
 * Filter wp title and perfect work for search result
 */
function ktz_filter_pagetitle($title) {
    //check if its a blog post
    if (is_search())
		$title = str_replace('-', ' ', $title); 
		$title = str_replace('.html', '', $title); 
		$title = ucwords($title);
        return $title;

    //if wordpress can't find the title return the default
    return $title;
}
function ktz_clean_character($result) { 
	/*
	 * Replace +, _ with ' ' blank
	 * http://codex.wordpress.org/Function_Reference/remove_accents
	 */
	$result = strip_tags(htmlspecialchars_decode($result));
	$result = html_entity_decode($result, ENT_QUOTES);
	$result = str_replace('+', ' ', $result);
	$result = str_replace('_', ' ', $result);
	$result = preg_replace( '/[^a-zA-Z0-9\s]/', '', $result );
	$result = preg_replace('/\s[\s]+/','-',$result);
	$result = preg_replace('/[\s\W]+/','-',$result);
	/*
	 * Converts all accent characters to ASCII characters. 
	 * http://codex.wordpress.org/Function_Reference/remove_accents
	 */
	$result = remove_accents($result);
	/*
	 * Function sanitize from
	 * http://codex.wordpress.org/Function_Reference/sanitize_title
	 */
	$result = sanitize_title($result);
	
	/*
	 * Replace - with ' ' blank
	 * http://codex.wordpress.org/Function_Reference/remove_accents
	 */
	$result = str_replace('-', ' ', $result);
	/*
	 * Convert the first character of each word to uppercase: 
	 * http://www.w3schools.com/php/func_string_ucwords.asp
	 */
	$result = ucwords($result);
	return $result;
}
function ktz_clean_description($result) { 
	/*
	 * Replace +, _ with ' ' blank
	 * http://codex.wordpress.org/Function_Reference/remove_accents
	 */
	$result = strip_tags(htmlspecialchars_decode($result));
	$result = html_entity_decode($result, ENT_QUOTES);
	$result = str_replace('+', ' ', $result);
	$result = str_replace('_', ' ', $result);
	$result = preg_replace( '/[^a-zA-Z0-9\s]/', ' ', $result );
	$result = preg_replace('/\s[\s]+/','-',$result);
	$result = preg_replace('/[\s\W]+/','-',$result);
	/*
	 * Converts all accent characters to ASCII characters. 
	 * http://codex.wordpress.org/Function_Reference/remove_accents
	 */
	$result = remove_accents($result);
	/*
	 * Function sanitize from
	 * http://codex.wordpress.org/Function_Reference/sanitize_title
	 */
	$result = sanitize_title($result);
	
	/*
	 * Replace - with ' ' blank
	 * http://codex.wordpress.org/Function_Reference/remove_accents
	 */
	$result = str_replace('-', ' ', $result);
	/*
	 * Convert the first character of each word to uppercase: 
	 * http://www.w3schools.com/php/func_string_ucwords.asp
	 */
	$result = ucfirst($result);
	return $result;
}
function ktz_filter_badkeyword() {
	/*
	 * Get from kentooz option
	 * ktz_badkeyword
	 */
	$badkeyword_option = get_theme_option('ktz_badkeyword');
	/*
	 * Split a string by string
	 * http://www.php.net/manual/en/function.explode.php
	 */
	$filterword = explode(',', $badkeyword_option);
	/*
	 * Termstring
	 */
	$termstring = get_search_query();
	$termstring = str_replace('-', ' ', $termstring);
	$termstring = str_replace('.html', '', $termstring);
	if (in_array($termstring, $filterword)) {
		return true;
	} else {
		return false;
	}
}
/*
 * This function unique identifier for check post
 * Inspirated By WP Robot
 */
function ktz_if_unique_post($checkit) {
	global $wpdb;
	$checkit = esc_sql($checkit);
	$check = $wpdb->get_var("SELECT post_title FROM $wpdb->posts WHERE post_title = '$checkit' LIMIT 1");

	if($check != false) {
		return $check;
	} else {
		$checkit_2 = sanitize_title($checkit);
		$check_2 = $wpdb->get_var("SELECT post_name FROM $wpdb->posts WHERE post_name = '$checkit_2' LIMIT 1");	

		if($check_2 == false) {
			return false;		
		} else {
			return $check_2;
		}	
	}
}
/*
 * Get unique title for AGC...
 */
function ktz_unique_title($unique) {
	/*
	 * First let's limit the title grabber
	 */
    $word_number_agc = get_theme_option('ktz_title_number');
	$ktz_title_format_limit = wp_trim_words($unique,$word_number_agc, ' ');
	/*
	 * Second let's unique that title.
	 */
    $title_format = get_theme_option('ktz_wall_title');
    $ktz_title_format = str_replace( '%ktztitle%', $ktz_title_format_limit , $title_format );
	return $ktz_title_format;
}

/*
 * Cache Feed URL image
 */
function ktz_cache_feed( $seconds )
{
  // change the default feed cache recreation period to 1 days
  return 86400;
}
function ktz_get_feed($url){
  $data = false;
  if ($url) {
    $response = wp_remote_get($url, array('timeout' => 15));
    if (!is_wp_error($response)) {
      $data = wp_remote_retrieve_body($response);
    }
  }
  return $data ? $data : false;
}
function ktz_agc_bing() {
	if (ktz_filter_badkeyword() === false) {
		/*
		 * Require for the function wp_generate_attachment_metadata() to work
		 */
		include_once( ABSPATH . WPINC . '/feed.php' );
		$change = array('-');
		$termstring_clean = str_replace($change, ' ', get_search_query());
		$termstring = urlencode($termstring_clean);
		/*
		 * Number for bing result, will be display in search page
		 * Maximal 30 post
		 */
		$number_result = get_theme_option('ktz_number_result');
		/*
		 * This is BING XML where the picture come from. :D
		 */
		$xmlbing = array('http://www.bing.com/search?q='.$termstring.'&go=&form=QBLH&filt=all&format=rss');
		if ($xmlbing) {
		foreach ($xmlbing as $xmlbing) {
		$rss = fetch_feed($xmlbing);
		if ( ! is_wp_error( $rss ) ) : // Checks that the object is created correctly
		
		// Figure out how many total items there are, but limit it to 5. 
		$maxitems = $rss->get_item_quantity( 5 ); 
		
		// Build an array of all the items, starting with element 0 (first element).
		$bing_result = $rss->get_items( 0, $maxitems );

		endif;
		if ( ! is_wp_error( $rss ) ) :
		echo '<p>';
		if ( $maxitems != 0  ) {	
			foreach ($bing_result as $bing_results) {
				/*
				 * Image result, this auto save in your server
				 */
				$save_and_getcontent = ktz_clean_description($bing_results->get_description());
					echo $save_and_getcontent . '. ';		
				}
			}
		echo '</p>';
		endif;
		}
		} else { echo 'No internet connection!'; } // if not internet connection
	} else { echo 'Keyword is block from our system, please use other keyword.'; } // if bad keyword
}

function ktz_agc_bing_desc() {
	if (ktz_filter_badkeyword() === false) {
		/*
		 * Require for the function wp_generate_attachment_metadata() to work
		 */
		include_once( ABSPATH . WPINC . '/feed.php' );
		$change = array('-');
		$termstring_clean = str_replace($change, ' ', get_search_query());
		$termstring = urlencode($termstring_clean);
		/*
		 * This is BING XML where the picture come from. :D
		 */
		$xmlbing = array('http://www.bing.com/search?q='.$termstring.'&go=&form=QBLH&filt=all&format=rss');
		if ($xmlbing) {
		foreach ($xmlbing as $xmlbing) {
		$rss = fetch_feed($xmlbing);
		if ( ! is_wp_error( $rss ) ) : // Checks that the object is created correctly
		
		// Figure out how many total items there are, but limit it to 1. 
		$maxitems = $rss->get_item_quantity( 1 ); 
		
		// Build an array of all the items, starting with element 0 (first element).
		$bing_result = $rss->get_items( 0, $maxitems );

		endif;
		if ( ! is_wp_error( $rss ) ) :
		if ( $maxitems != 0  ) {	
			foreach ($bing_result as $bing_results) {
				/*
				 * Image result, this auto save in your server
				 */
				$save_and_getcontent = ktz_clean_description($bing_results->get_description());
				$save_and_getcontent = substr($save_and_getcontent,0,160);
				echo $save_and_getcontent;
				}
			}
		endif;
		}
		} else { echo 'No internet connection!'; } // if not internet connection
	} else { echo 'Keyword is block from our system, please use other keyword.'; } // if bad keyword
}

function ktz_agc_bing_related() {
	if (ktz_filter_badkeyword() === false) {
		/*
		 * Require for the function wp_generate_attachment_metadata() to work
		 */
		include_once( ABSPATH . WPINC . '/feed.php' );
		$change = array('-');
		$termstring_clean = str_replace($change, ' ', get_search_query());
		$termstring = urlencode($termstring_clean);
		/*
		 * Number for bing result, will be display in search page
		 * Maximal 30 post
		 */
		$number_result = get_theme_option('ktz_number_result');
		/*
		 * This is BING XML where the picture come from. :D
		 */
		$xmlbing = array('http://www.bing.com/search?q='.$termstring.'&go=&form=QBLH&filt=all&format=rss');
		if ($xmlbing) {
		foreach ($xmlbing as $xmlbing) {
		$rss = fetch_feed($xmlbing);
		if ( ! is_wp_error( $rss ) ) : // Checks that the object is created correctly
		
		// Figure out how many total items there are, but limit it to 5. 
		$maxitems = $rss->get_item_quantity( 5 ); 
		
		// Build an array of all the items, starting with element 0 (first element).
		$bing_result = $rss->get_items( 0, $maxitems );

		endif;
		if ( ! is_wp_error( $rss ) ) :
		if ( $maxitems != 0  ) {	
			foreach ($bing_result as $bing_results) {
				/*
				 * Clean and unique title
				 */
				$title_format = ktz_unique_title(ktz_clean_character($bing_results->get_title()));
				/*
				 * Image result, this auto save in your server
				 */
				$save_and_getcontent = $bing_results->get_description();
					echo '<div class="box-post"><div class="inner-box">';
					echo '<div class="entry-search">';
					$change = array('+',' ','--');
					$searchpermalink = '/' . get_theme_option('ktz_search_permalink') . '/';
					$html_option = get_theme_option('ktz_active_htmlsearch') != '' ? '.html' : '';
					echo '<h3><a href="'.home_url($searchpermalink).'' . strtolower((str_replace($change, '-', $title_format))).''.$html_option.'">'.ucwords($title_format).'</a></h3>';
					echo '<p>'.$save_and_getcontent.'</p>';
					echo $bing_results->get_permalink();
					echo '</div>';
					echo '</div></div>';			
				}
			}
		endif;
		}
		} else { echo 'No internet connection!'; } // if not internet connection
	} else { echo 'Keyword is block from our system, please use other keyword.'; } // if bad keyword
}

function ktz_agc_google() {
	if (ktz_filter_badkeyword() === false) {
		/*
		 * Require for the function wp_generate_attachment_metadata() to work
		 */
		include_once( ABSPATH . WPINC . '/feed.php' );
		$change = array('-');
		$termstring_clean = str_replace($change, ' ', get_search_query());
		$termstring = urlencode($termstring_clean);
		/*
		 * This is BING XML where the picture come from. :D
		 */
		$xmlbing = array('http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.$termstring.'&lr=&ie=utf-8&num=10&output=rss');
		if ($xmlbing) {
		foreach ($xmlbing as $xmlbing) {
		$rss = fetch_feed($xmlbing);
		if ( ! is_wp_error( $rss ) ) : // Checks that the object is created correctly
		
		// Figure out how many total items there are, but limit it to 5. 
		$maxitems = $rss->get_item_quantity( 5 ); 
		
		// Build an array of all the items, starting with element 0 (first element).
		$bing_result = $rss->get_items( 0, $maxitems );

		endif;
		if ( ! is_wp_error( $rss ) ) :
		echo '<p>';
		if ( $maxitems != 0  ) {	
			foreach ($bing_result as $bing_results) {
				/*
				 * Image result, this auto save in your server
				 */
				$save_and_getcontent = ktz_clean_description($bing_results->get_description());
					echo $save_and_getcontent . '. ';		
				}
			}
		echo '</p>';
		endif;
		}
		} else { echo 'No internet connection!'; } // if not internet connection
	} else { echo 'Keyword is block from our system, please use other keyword.'; } // if bad keyword
}

function ktz_agc_bing_single() {
	if (ktz_filter_badkeyword() === false) {
		/*
		 * Require for the function wp_generate_attachment_metadata() to work
		 */
		include_once( ABSPATH . WPINC . '/feed.php' );
		$termstring = urlencode(get_the_title());
		/*
		 * This is BING XML where the picture come from. :D
		 */
		$xmlbing = array('http://www.bing.com/search?q='.$termstring.'&go=&form=QBLH&filt=all&format=rss',
						'http://blogsearch.google.com/blogsearch_feeds?hl=en&q='.$termstring.'&lr=&ie=utf-8&num=10&output=rss',
						'http://api.search.yahoo.com/WebSearchService/rss/webSearch.xml?appid=yahoosearchwebrss&query='.$termstring.'&adult_ok=1');
		if ($xmlbing) {
		echo '<h3 class="related-title"><span>' . __( 'Other source for',ktz_theme_textdomain) . ' ' . get_the_title() . '</span></h3>';
		foreach ($xmlbing as $xmlbing) {
		$rss = fetch_feed($xmlbing);
		if ( ! is_wp_error( $rss ) ) : // Checks that the object is created correctly
		
		// Figure out how many total items there are, but limit it to 5. 
		$maxitems = $rss->get_item_quantity( 5 ); 
		
		// Build an array of all the items, starting with element 0 (first element).
		$bing_result = $rss->get_items( 0, $maxitems );

		endif;
		if ( ! is_wp_error( $rss ) ) :
		if ( $maxitems != 0 ) {	
			foreach ($bing_result as $bing_results) {
				/*
				 * Clean and unique title
				 */
				$title_format = ktz_unique_title(ktz_clean_character($bing_results->get_title()));
				/*
				 * Image result, this auto save in your server
				 */
				$save_and_getcontent = ktz_clean_character($bing_results->get_description());
				/*
				 * For auto post, you can set draft or publish.
				 */
					echo '<div class="box-post"><div class="inner-box">';
					echo '<div class="entry-search">';
					$change = array('+',' ','--');
					$searchpermalink = '/' . get_theme_option('ktz_search_permalink') . '/';
					$html_option = get_theme_option('ktz_active_htmlsearch') != '' ? '.html' : '';
					echo '<div class="single-agc-title"><a href="'.home_url($searchpermalink).'' . strtolower((str_replace($change, '-', $title_format))).''.$html_option.'">'.ucwords($title_format).'</a></div>';
					echo '</div>';
					echo '</div></div>';				
				}
			}
		endif;
		}
		} else { echo 'No internet connection!'; } // if not internet connection
	} else { echo 'Keyword is block from our system, please use other keyword.'; } // if bad keyword
}
/*
 * Back to use google API
 */
function pete_curl_get($url, $params){
	$post_params = array();
	foreach ($params as $key => &$val) {
		if (is_array($val)) $val = implode(',', $val);
		$post_params[] = $key.'='.urlencode($val);
	}
	$post_string = implode('&', $post_params);
	$fullurl = $url."?".$post_string;
	$ch = curl_init();curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);curl_setopt($ch, CURLOPT_URL, $fullurl);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7) Gecko/20040608');
	$result = curl_exec($ch);curl_close($ch);
	return $result;
}

function perform_google_web_search($termstring){
	$start = 0;
	$get_google_API = get_theme_option('ktz_googleapi_key');
	$result = array();
	while($start<3)
	{
		$searchurl = 'http://ajax.googleapis.com/ajax/services/search/images?v=1.0'; 
		$searchurl .= '&key='.$get_google_API;
		$searchurl .= '&start='.$start;
		$searchurl .= '&rsz=large';
		$searchurl .= '&filter=0';
		$searchurl .= '&q='.urlencode($termstring);
		$response = pete_curl_get($searchurl, array());
		$responseobject = json_decode($response, true);
	if (count(isset($responseobject['responseData']['results'])) == 0 )
	break;
	$allresponseresults = $responseobject['responseData']['results'];
	if (is_array($allresponseresults))
	{
	foreach ($allresponseresults as $responseresult)
	{
		$result[] = array(
		'url' => $responseresult['url'],
		'title' => $responseresult['title'],
		'thumbnail' => $responseresult['tbUrl'],
		'height' => $responseresult['tbHeight'],
		'width' => $responseresult['tbWidth'],
		'Oriurl' => $responseresult['url'],);
		}
	} else {
		echo 'No internet connection ';
	}
	$start += 2;
	}
	return $result;
}

function ktz_get_googleimageAGC() {
if (ktz_filter_badkeyword() === false) {
		$change = array('-');
		$termstring_clean = str_replace($change, ' ', get_search_query());
		$termstring = urlencode($termstring_clean);
if ($termstring!='') {
	$googleresults = perform_google_web_search($termstring);
	if (is_array($googleresults))
	{
	$i = 0;
	foreach ($googleresults as $result) {
		$link = $result['Oriurl'];
		$i++;
		if($i < 2){
			echo '<img src="'.$link.'" class="aligncenter"  />';
			}
		}
	}
	}
	} else { die('Keyword is block from our system, please use other keyword.'); } // if bad keyword
}

?>