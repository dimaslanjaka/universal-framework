<?php
/**
 * Init kentooz framework
 * Since 11/11/2012
 */

/*
* Add other script
*/
require_once(TEMPLATEPATH . '/includes/functions/BFI_Thumb.php');
// Change the upload subdirectory to wp-content/uploads/other_dir
@define( BFITHUMB_UPLOAD_DIR, 'ktz' );

class KENTOOZ {
	public static function init() {
		self::ktz_definitions();
		self::ktz_functions();
		self::ktz_add_actions();
		self::ktz_filters();
		self::locale();
	}

	// Define URL
	public static function ktz_definitions() {
		define( 'theme_slug', get_template() );
		define( 'ktz_dir', get_template_directory() . '/' );
		define( 'ktz_inc', get_template_directory() . '/includes/' );
		define( 'ktz_url', get_template_directory_uri() . '/' );
		define( 'ktz_styleinc', get_template_directory_uri() . '/includes/' );
		define( 'ktz_theme_textdomain', theme_slug );
		define( 'ktz_admin_textdomain', theme_slug . '_admin' );
	}
		
	// Load function data
	public static function ktz_functions() {
		require_once(ktz_inc . 'admin/admin.php');
		require_once(ktz_inc . 'widget/widget.php');
		require_once(ktz_inc . 'functions/function_core.php');
		require_once(ktz_inc . 'functions/function_ajaxrate.php');
		require_once(ktz_inc . 'functions/function_js.php');
		require_once(ktz_inc . 'functions/function_head.php');
		require_once(ktz_inc . 'functions/function_footer.php');
		require_once(ktz_inc . 'functions/function_sidebar.php');
		require_once(ktz_inc . 'functions/function_content.php');
		require_once(ktz_inc . 'functions/function_loop.php');
		require_once(ktz_inc . 'metaboxes/meta-options.php');
		require_once(ktz_inc . 'metaboxes/meta-theme.php');
	}	
	
	public static function ktz_add_actions() {
		add_action('wp_ajax_ktz_stars_rating','ktz_handle_vote');
		add_action('wp_ajax_nopriv_ktz_stars_rating','ktz_handle_vote');
		add_action('wp_ajax_ktz_setcookie', 'ktz_setcookie');
		add_action('wp_ajax_nopriv_ktz_setcookie', 'ktz_setcookie');
		/**
		* add action for modified user profile
		*/
		add_action( 'show_user_profile', 'my_show_extra_profile_fields' );
		add_action( 'edit_user_profile', 'my_show_extra_profile_fields' );
		add_action( 'personal_options_update', 'my_save_extra_profile_fields' );
		add_action( 'edit_user_profile_update', 'my_save_extra_profile_fields' );
		//WP hook action
		add_action(	'after_setup_theme', 'ktz_setup' );
		add_action( 'wp_head', 'ktz_ogHEAD' );
		add_action( 'wp_head', 'ktz_headelement' );
		add_action( 'wp_head', 'ktz_dynamicbg' );
		add_action( 'wp_head', 'ktz_custom_css' );
		add_action( 'wp_footer', 'ktz_lockscript' );
		add_action( 'init', 'ktz_register_css');
		add_action( 'wp_enqueue_scripts', 'ktz_enqueue_css' );  
		add_action( 'init', 'ktz_register_jascripts' );
		add_action( 'wp_enqueue_scripts','ktz_jsscripts' );
		add_action( 'widgets_init', 'sidebar_widget_init' );
		add_action( 'widgets_init', 'ktz_widget_init' );
		// HEADER hook action
		add_action( 'do_ktz_topheader', 'ktz_topheader' );
		add_action( 'do_ktz_header', 'ktz_headlogo' );
		add_action( 'do_ktz_head', 'ktz_head_favicon' );
		add_action( 'do_ktz_logo_squeeze', 'ktz_headlogo_squeeze' );
		// FOOTER hook action
		add_action( 'do_ktz_squeezemenu', 'ktz_squeezemenu' );
		add_action( 'do_ktz_mainfooter', 'ktz_mainfooter' );
		add_action( 'do_ktz_subfooter', 'ktz_subfooter',10 );
		add_action( 'do_ktz_footer_squeeze', 'ktz_subfooter_squeeze');
		// BANNER hook action
		add_action( 'do_ktz_centerbanner', 'ktz_centerbanner' );
		add_action( 'do_ktz_centerbanner', 'ktz_centerbanner2' );
		add_action( 'do_ktz_footbanner', 'ktz_ban72890_foot' );
		add_action( 'do_ktz_archivebanner', 'ktz_archivebanner' );
		add_action( 'do_ktz_headbanner', 'ktz_headbanner' );
		// OTHER hook action
		add_action( 'do_ktz_title', 'ktz_title' );
		add_action( 'do_ktz_topsearch', 'ktz_topsearch' );
		add_action( 'do_ktz_topticker_feat', 'ktz_topticker_feat' );
		add_action( 'do_ktz_header_sn', 'ktz_sn' );
		add_action( 'do_ktz_secondmenu', 'ktz_secondmenu' );
		add_action( 'do_ktz_topmenu', 'ktz_topmenu' );
		add_action( 'do_ktz_nivo', 'ktz_feat_nivoslider' );
		add_action( 'do_ktz_after_header', 'ktz_crumbs' );
		add_action( 'do_ktz_meta_content', 'ktz_share_post' );
		add_action( 'do_ktz_content_title', 'ktz_posted_title' );
		add_action( 'do_ktz_content_title_h3', 'ktz_posted_title_h3' );
		add_action( 'do_ktz_content_meta', 'ktz_author_by' );
		add_action( 'do_ktz_content_meta', 'ktz_categories' );
		add_action( 'do_ktz_content_meta_rate', 'ktz_ajaxstar_SEO' );
		add_action( 'do_ktz_content_meta_rate_single', 'ktz_ajaxstar_SEO' );
		add_action( 'do_ktz_post_left', 'ktz_posted_on' );	
		add_action( 'do_ktz_post_left', 'ktz_comment_num' );
		add_action( 'do_ktz_content', 'ktz_content' );	
		add_action( 'do_ktz_content', 'ktz_link_pages' );
		add_action( 'do_ktz_singleheadban', 'ktz_ban46860_singlehead' );
		add_action( 'do_ktz_singletitban', 'ktz_ban46860_singletit' );
		add_action( 'do_ktz_feedburner', 'ktz_feedburner' );
		add_action( 'do_ktz_navigation', 'ktz_navigation' );
		add_filter( 'widget_tag_cloud_args', 'ktz_tag_cloud' );
		/* Create table hook */
		add_action( 'after_switch_theme', 'ktzcreate_table' );
		add_action( 'save_post', 'ktz_autoset_featured' );
		add_action( 'wp_footer', 'ktz_parseFBML' );
		add_action( 'parse_query', 'ktz_parse_query');
	}
	public static function ktz_filters() {	
		add_filter( 'get_avatar', 'change_avatar_css' );
		add_filter( 'comment_form_default_fields','ktz_com_fields' );
		add_filter( 'comment_form_field_comment','ktz_com_fields_textarea' );
		add_filter( 'the_content', 'ktz_texturize_SC' );
		add_filter( 'the_content', 'ktz_formatter', 99 );
		add_filter( 'widget_text', 'ktz_formatter', 99 );
		add_filter( 'post_gallery', 'ktz_post_gallery', 10, 2);
		add_filter( 'search_rewrite_rules', 'ktz_ChangeSearchString');
		add_filter( 'wp_feed_cache_transient_lifetime' , 'ktz_cache_feed' );
		add_filter( 'wp_title', 'ktz_filter_pagetitle' );
		remove_filter( 'the_content', 'wptexturize' );
		remove_filter( 'the_content', 'wpautop' );
	}
	public static function locale() {
	// Get locale languange in both front end and back end
		$locale = get_locale();
		if( is_admin() ) {
			load_theme_textdomain( ktz_admin_textdomain, ktz_inc . 'languages' );
			$locale_file = ktz_inc . "languages/$locale.php";
		} else {
			load_theme_textdomain( ktz_theme_textdomain, ktz_dir . 'languages' );
			$locale_file = ktz_dir . "languages/$locale.php";
		}
		if ( is_readable( $locale_file ) )
			require_once( $locale_file );
	}
}

// Hook system
function hook_ktz_head() {
	 do_action('do_ktz_head');
}
function hook_ktz_logo_squeeze() {
	do_action( 'do_ktz_logo_squeeze' );
}
function hook_ktz_title() {
	 do_action('do_ktz_title');
}
function hook_ktz_secondmenu() {
	 do_action('do_ktz_secondmenu');
}
function hook_do_ktz_topsearch() {
	 do_action('do_ktz_topsearch');
}
function hook_ktz_topticker_feat() {
	 do_action('do_ktz_topticker_feat');
}
function hook_do_ktz_header_sn() {
	 do_action('do_ktz_header_sn');
}
function hook_ktz_header() {
	do_action( 'do_ktz_header' );
}
function hook_ktz_headbanner() {
	do_action( 'do_ktz_headbanner' );
}
function hook_ktz_squeezemenu() {
	 do_action('do_ktz_squeezemenu');
}
function hook_ktz_menu_header() {
	do_action( 'do_ktz_topmenu' );
}
function hook_ktz_after_header() {
	 do_action(	'do_ktz_after_header' );
}
function hook_ktz_title_content() {
	 do_action('do_ktz_title_content');
}
function hook_ktz_footbanner() {
	 do_action('do_ktz_footbanner');
}
function hook_ktz_centerbanner() {
	 do_action('do_ktz_centerbanner');
}
function hook_ktz_archivebanner() {
	 do_action('do_ktz_archivebanner');
}
function hook_ktz_before_content() {
	 do_action('do_ktz_before_content');
}
function hook_ktz_before_firstcontent() {
	 do_action('do_ktz_before_firstcontent');
}
function hook_ktz_meta_content() {
	 do_action('do_ktz_meta_content');
}
function hook_ktz_post_left() {
	 do_action('do_ktz_post_left');
}
// Hook for loop content
function hook_ktz_content_title() {
	 do_action('do_ktz_content_title');
}

function hook_ktz_content_title_h3() {
	 do_action('do_ktz_content_title_h3');
}

function hook_ktz_content_meta() {
	 do_action('do_ktz_content_meta');
}

function hook_ktz_content_meta_rate() {
	 do_action('do_ktz_content_meta_rate');
}

function hook_ktz_content_meta_rate_single() {
	 do_action('do_ktz_content_meta_rate_single');
}

function hook_ktz_content() {
	 do_action('do_ktz_content');
}

function hook_ktz_singleproduct() {
	 do_action('do_ktz_singleproduct');
}
function hook_ktz_singleheadban() {
	 do_action('do_ktz_singleheadban');
}
function hook_ktz_botmenuban() {
	 do_action('do_ktz_botmenuban');
}
function hook_ktz_singletitban() {
	 do_action('do_ktz_singletitban');
}
function hook_ktz_feat_single() {
	 do_action('do_ktz_feat_single');
}
function hook_ktz_feedburner() {
	 do_action('do_ktz_feedburner');
}
function hook_ktz_navigation() {
	 do_action('do_ktz_navigation');
}

function hook_ktz_footer() {
	do_action( 'do_ktz_mainfooter' ); 
}

function hook_ktz_after_footer() {
	 do_action('do_ktz_subfooter');
}

function hook_ktz_footer_squeeze() {
	 do_action('do_ktz_footer_squeeze');
}

?>