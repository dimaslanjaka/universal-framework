<?php

/************************************************************************
		You should not edit the code below or things might explode!
*************************************************************************/
$page_meta = array();
$page_meta = apply_filters ( 'ktz_metaboxes' , $page_meta );
foreach ( $page_meta as $meta_box ) {
	$my_box = new ktz_MetaBox( $meta_box );
}

/**
 * Validate value of meta fields
 * Define ALL validation methods inside this class and use the names of these 
 * methods in the definition of meta boxes (key 'validate_func' of each field)
 */
class ktz_MetaBox_Validate {
	function check_text( $text ) {
		if ($text != 'hello') {
			return false;
		}
		return true;
	}
}

/**
 * Create meta boxes
 */
class ktz_MetaBox {
	protected $_meta_box;
	function __construct( $meta_box ) {
		if ( !is_admin() ) return;
		$this->_meta_box = $meta_box;
		
		$upload = false;
		foreach ( $meta_box['fields'] as $field ) {
			if ( $field['type'] == 'upload' ) {
				$upload = true;
				break;
			}
		}
		
		global $pagenow;		
		if ( $upload && in_array( $pagenow, array( 'page.php', 'page-new.php', 'post.php', 'post-new.php' ) ) ) {
			add_action( 'admin_head', array( &$this, 'add_post_enctype' ) );
		}

		add_action( 'admin_menu', array( &$this, 'add' ) );
		add_action( 'save_post', array( &$this, 'save' ) );

	}

	function add_post_enctype() {
		echo '
		<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery("#post").attr("enctype", "multipart/form-data");
			jQuery("#post").attr("encoding", "multipart/form-data");
		});
		</script>';
	}

	// Add metaboxes
	function add() {
		$this->_meta_box['context'] = empty($this->_meta_box['context']) ? 'normal' : $this->_meta_box['context'];
		$this->_meta_box['priority'] = empty($this->_meta_box['priority']) ? 'high' : $this->_meta_box['priority'];
		$this->_meta_box['show_on'] = empty( $this->_meta_box['show_on'] ) ? array('key' => false, 'value' => false) : $this->_meta_box['show_on'];
		foreach ( $this->_meta_box['pages'] as $page ) {
				add_meta_box( $this->_meta_box['id'], $this->_meta_box['title'], array(&$this, 'display_page_meta'), $page, $this->_meta_box['context'], $this->_meta_box['priority']) ;
		}
	}

	function display_page_meta() {
	global $post, $page_meta;
	echo '<div class="form-wrap">';
	wp_nonce_field( plugin_basename( __FILE__ ), $this->_meta_box['pagemeta_key'] . '_wpnonce', false, true );
        foreach ( $this->_meta_box['fields'] as $meta_box ) {
            $data = get_post_meta($post->ID, $this->_meta_box['pagemeta_key'], true);
			switch ( $meta_box['type'] ) {
            case 'heading' :
				echo '<li><a href="#' . $meta_box['id'] . '">'; if(isset($meta_box[ 'description' ])) echo $meta_box[ 'description' ] . '</a></li>';
				break;
            case 'open' :
				echo '<div class="ktz_tabmb">';
				break;
            case 'close' :
				echo '</div>';
				break;
			case 'innertabs_start' :
				echo '<ul id="innertabs">';
				break;
            case 'innertabs_end' :
				echo '</ul>';
				break;
            case 'inneropen' :
				echo '<div class="clear"></div><div class="ktz_innertab" id="' .  $meta_box['id'] . '">';
				break;
            case 'innerclose' :
				echo '</div>';
				break;
            case 'custom_sidebar' :
				echo '<div class="ktztitle"><span>' . $meta_box[ 'title' ] . '</span><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . $meta_box[ 'description' ] . '</div></div>';
				echo '<div class="ktzinput select_wrapper">';
				echo '<select style="width:100%" name="' . $meta_box['id'] . '" id="' . $meta_box['id'] . '" class="select">';
                    global $wp_registered_sidebars;
                    $current_sidebars = $wp_registered_sidebars;
                    if(is_array($current_sidebars) && !empty($current_sidebars)){
                        foreach($current_sidebars as $sidebar){
                            if( $sidebar['description'] == "sidebar"  ) {
                            echo '<option ';
							if ( isset($data[ $meta_box[ 'id' ] ]) && ( $data[ $meta_box[ 'id' ] ] == $sidebar['id'] ) ) { echo ' selected="selected"'; }
							echo ' value="' . $sidebar['id'] . '">' . $sidebar['name'] . '</option>'; } 
                        }
                    }
                echo '</select></div><div class="clear"></div>';
				break;
            case 'select' :
				echo '<div class="ktztitle"><span>' . $meta_box[ 'title' ] . '</span><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . $meta_box[ 'description' ] . '</div></div>';
				echo '<div class="ktzinput select_wrapper"><select style="width:100%" name="' . $meta_box['id'] . '" id="' . $meta_box['id'] . '" class="select">';
                    foreach ($meta_box['options'] as $option) {
                    echo '<option '; 
					if ( isset($data[$meta_box[ 'id' ] ]) && ( $data[ $meta_box[ 'id' ] ] == $option['value'] ) ) { echo ' selected="selected"'; } 
					elseif (empty($data[$meta_box[ 'id' ] ]) && $meta_box['std'] == $option['value']) { echo ' selected="selected"'; } 
					echo ' value="' . $option['value'] . '">' . $option['title'] . '</option>';
                    }
				echo '</select></div><div class="clear"></div>';
				break;
			case 'checkbox' :
				if( isset($data[ $meta_box[ 'id' ] ]) && ( $data[$meta_box['id']] )){ $checked = 'checked="checked"'; }else{ $checked = ''; }
                echo '<input style="float:left; width:20px" type="checkbox" name="' . $meta_box['id'] . '" id="' . $meta_box['id'] . '" value="true" ' . $checked .' />';
                echo '<label for="' . $meta_box[ 'id' ] . '">' . $meta_box[ 'title' ] . '</label>';
                echo '<p>'; 
				if(isset($meta_box[ 'description' ])) echo $meta_box[ 'description' ] . '</p>';
				break;
            case 'text' :
				echo '<div class="ktztitle"><span>' . $meta_box[ 'title' ] . '</span><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . $meta_box[ 'description' ] . '</div></div>';
				echo '<div class="ktzinput"><input style="width:35%" type="text" name="';
				if( isset($meta_box['id']) ) echo $meta_box[ 'id' ] . '" id="';
				if( isset($meta_box['id']) ) echo $meta_box['id'] . '" value="';
				if( isset($data[ $meta_box[ 'id' ] ]) ) echo htmlspecialchars( $data[ $meta_box[ 'id' ] ] ); else { if(isset($meta_box[ 'std' ])) echo htmlspecialchars( $meta_box[ 'std' ] ); } 
				echo '" class="text" /></div><div class="clear"></div>';
				break;
            case 'color' :
				echo '<div class="ktztitle"><span>' . $meta_box[ 'title' ] . '</span><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . $meta_box[ 'description' ] . '</div></div>';
				echo '<div class="ktzinput"><div id="';
				if( isset($meta_box['id']) ) echo $meta_box[ 'id' ] . '" class="colorSelector"><div style="background-color:';
				if( isset($data[ $meta_box[ 'id' ] ]) ) echo htmlspecialchars( $data[ $meta_box[ 'id' ] ] ); else { if(isset($meta_box[ 'std' ])) echo htmlspecialchars( $meta_box[ 'std' ] ); }
				echo '"></div></div><input style="width:25%" type="text" name="';
				if( isset($meta_box['id']) ) echo $meta_box[ 'id' ] . '" id="';
				if( isset($meta_box['id']) ) echo $meta_box['id'] . '" value="';
				if( isset($data[ $meta_box[ 'id' ] ]) ) echo htmlspecialchars( $data[ $meta_box[ 'id' ] ] ); else { if(isset($meta_box[ 'std' ])) echo htmlspecialchars( $meta_box[ 'std' ] ); }
				echo '" class="text" /></div><div class="clear"></div>';
				break;
			case 'images' :
				echo '<div class="ktztitle"><span>' . $meta_box[ 'title' ] . '</span><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . $meta_box[ 'description' ] . '</div></div>';
				echo '<div class="ktzinput">';
				foreach ($meta_box['options'] as $option) {
				echo '<input type="radio" id="' . $meta_box['id'] . '_' . $option['value'] . '" class="of-radio-img-radio" value="' . $option['value'] . '" name="' . $meta_box['id'] . '"';
				if ( isset($data[$meta_box[ 'id' ] ]) && ( $data[ $meta_box[ 'id' ] ] == $option['value'] ) ) { 
				echo ' checked="checked" '; } 
				echo '/>';
				echo '<img src="' . ktz_styleinc . 'admin/images/' . $option['value'] . '.png" alt="' . $option['value'] . '" class="of-radio-img-img of-radio-img-img_' . $meta_box['id'];
				if ( isset($data[$meta_box[ 'id' ] ]) && ( $data[ $meta_box[ 'id' ] ] == $option['value'] ) ) { 
				echo ' of-radio-img-selected '; }
				echo '" onclick="document.getElementById(\'' . $meta_box['id'] . '_' . $option['value'] . '\').checked=true;" />';
				}
				echo '</div><div class="clear"></div>';
				echo '<script type="text/javascript" language="javascript">';
				echo 'jQuery(document).ready(function(){';
				foreach ($meta_box['options'] as $option) {
				echo 'jQuery(\'.of-radio-img-img_' . $meta_box['id'] . '\').click(function(){';
				echo 'jQuery(this).parent().parent().find(\'.of-radio-img-img_' . $meta_box['id'] . '\').removeClass(\'of-radio-img-selected\');';
				echo 'jQuery(this).addClass(\'of-radio-img-selected\');';			
				echo '});';
				echo 'jQuery(\'.of-radio-img-label\').hide();';
				echo 'jQuery(\'.of-radio-img-img\').show();';
				echo 'jQuery(\'.of-radio-img-radio\').hide();';
				}
				echo '})';
				echo '</script>';
				break;
            case 'upload' :
				echo '<div class="ktztitle"><span>' . $meta_box[ 'title' ] . '</span><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . $meta_box[ 'description' ] . '</div></div>';
				echo '<div class="ktzinput"><input id="';
				if( isset($meta_box['id']) ) echo $meta_box[ 'id' ] . '" class="upload_field" style="width:35%;" type="text" size="90" name="' . $meta_box['id'] . '" value="';
				if( isset($data[ $meta_box[ 'id' ] ]) ) echo htmlspecialchars( $data[ $meta_box[ 'id' ] ] ); else { if(isset($meta_box[ 'http://yoursite.com/path/image.jpg' ])) echo htmlspecialchars( $meta_box[ 'http://yoursite.com/path/image.jpg' ] ); } 
				echo '" /><br /><input class="upload_image_button button-secondary" type="button" value="Upload Image" /></div><div class="clear"></div>';
				break;
            case 'textarea' :
				echo '<div class="ktztitle"><span>' . $meta_box[ 'title' ] . '</span><img src="' . ktz_styleinc . 'admin/jscss/images/help.png" alt="description" class="img-description" /><div class="ktzdesc">' . $meta_box[ 'description' ] . '</div></div>';
				echo '<div class="ktzinput"><textarea name="';
				if( isset($meta_box['id']) ) echo $meta_box[ 'id' ] . '" class="textarea" style="width:60%; height:120px;" type="textarea">';
				if( isset($data[ $meta_box[ 'id' ] ]) ) echo htmlspecialchars( $data[ $meta_box[ 'id' ] ] ); else { if(isset($meta_box[ 'http://yoursite.com/path/image.jpg' ])) echo htmlspecialchars( $meta_box[ 'http://yoursite.com/path/image.jpg' ] ); } 
				echo '</textarea></div><div class="clear"></div>';
				break;
			} 
		}
	echo '</div>';
	}
	
	function save( $post_id ) {
	global $post;
	
	if (!isset($_POST[ $this->_meta_box['pagemeta_key'] . '_wpnonce' ]) || ( !wp_verify_nonce( $_POST[ $this->_meta_box['pagemeta_key'] . '_wpnonce' ], plugin_basename(__FILE__) ) )) {
			return $post_id;
	}
			
	foreach( $this->_meta_box['fields'] as $meta_box ) {
		if(isset ($meta_box['id']) && isset($_POST[ $meta_box['id'] ]))
		$data[ $meta_box[ 'id' ] ] = $_POST[ $meta_box[ 'id' ] ];
	}

	if ( !current_user_can( 'edit_post', $post_id ))
		return $post_id;

	if(isset($data))
		update_post_meta( $post_id, $this->_meta_box['pagemeta_key'], $data );
	}
}

function ktz_metaboxes_jscss() {
	global $pagenow;
  	if ( $pagenow == 'post.php' || $pagenow == 'post-new.php' || $pagenow == 'page-new.php' || $pagenow == 'page.php' ) {
		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		wp_enqueue_script('jquery-form');
		wp_enqueue_script('jquery-ui-tabs');
		wp_enqueue_script("mb_script", ktz_url."includes/metaboxes/jscss/metaboxes.js", false, "1.0");
		wp_enqueue_script("colorpick", ktz_url."includes/admin/jscss/colorpicker.js", false, "1.0");
		wp_enqueue_script("shortcode_js", ktz_url."includes/shortcodes/js/scripts.js", false, "1.0");
		wp_enqueue_style("functions", ktz_url."includes/metaboxes/jscss/functions.css", false, "1.0", "all");
		wp_enqueue_style("colorpictcss", ktz_url."includes/admin/jscss/colorpicker.css", false, "1.0", "all");
	}
}
add_action( 'admin_enqueue_scripts', 'ktz_metaboxes_jscss' );

function ktz_metaboxes_upload() {
	global $post, $pagenow;
  	if ( $pagenow == 'post.php' || $pagenow == 'post-new.php' || $pagenow == 'page-new.php' || $pagenow == 'page.php' ) {
	echo '<script type="text/javascript" language="javascript">';
	echo 'jQuery(document).ready(function() {';
	echo 'window.formfield = \'\';';
	echo 'jQuery(\'.upload_image_button\').live(\'click\', function() {';
	echo 'window.formfield = jQuery(\'.upload_field\',jQuery(this).parent());';
	echo 'tb_show(\'\', \'media-upload.php?post_id=' . $post->ID . '&type=image&TB_iframe=true\');';
	echo 'return false;});';
	echo 'window.original_send_to_editor = window.send_to_editor;';
	echo 'window.send_to_editor = function(html) {';
	echo 'if (window.formfield) {imgurl = jQuery(\'img\',html).attr(\'src\');';
	echo 'window.formfield.val(imgurl);	tb_remove();}';
	echo 'else {window.original_send_to_editor(html);}';
	echo 'window.formfield = \'\';window.imagefield = false;}});';
	echo '</script>';
	}
}
add_action( 'admin_head', 'ktz_metaboxes_upload' );

?>