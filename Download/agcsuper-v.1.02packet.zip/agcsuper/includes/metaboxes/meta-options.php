<?php
function ktz_metaboxes_options( array $page_meta ) {
	$page_meta[] = array( 
	"id" => "page-options", "title" => "Page options", "pagemeta_key" => "page_meta", "pages" => array("page"), "context" => "normal", "priority" => "high", "fields" => array(
	"open" => array("type" => "open" ),	
	"tabber" => array("type" => "innertabs_start" ),
	"title_sb" => array( "type" => "heading", "id" => "sidebar", "description" => __( 'Sidebar and widget option',ktz_admin_textdomain) ),
	"title_stylepages" => array( "type" => "heading", "id" => "bgsetting", "description" => __( 'Background setting',ktz_admin_textdomain) ),
	"tabberend" => array("type" => "innertabs_end" ),

	"tabwrap_sb" => array("type" => "inneropen", "id" => "sidebar"), 
	"sidebar_rgt" => array(	"id" => "sidebar_rgt","title" => __( 'Available Sidebar',ktz_admin_textdomain),	"type" => "custom_sidebar",	"description" => __( 'You can add new sidebar with check below. Select available sidebar if you want use another sidebar for this page (dynamic sidebar)',ktz_admin_textdomain) ),
	"sidebar" => array("id" => "sidebar","title" => __( 'Create an new sidebar for this page.',ktz_admin_textdomain), "type" => "checkbox",	"description" => __( 'Check to create new sidebar for this page. If this activated default sidebar will remove',ktz_admin_textdomain) ), 
	"tabwrapclose_sb" => array("type" => "innerclose"), 
	
	"tabwrap_bg" => array("type" => "inneropen", "id" => "bgsetting"), 	
	"bgactivated" => array("id" => "bgactivated","title" => __( 'Activated dynamic background for this page.',ktz_admin_textdomain), "type" => "checkbox",	"description" => __( 'Check for Activated dynamic background, default background will be replaced with new background',ktz_admin_textdomain) ), 
	"bgcolor" => array("id" => "bgcolor","title" => __( 'Background color',ktz_admin_textdomain ),	"type" => "color","description" => __( 'Fill with color for background this page.',ktz_admin_textdomain),"std" => "#ffffff" ),
	"bgimage" => array("id" => "bgimage","title" => __( 'Background Image',ktz_admin_textdomain ),	"type" => "upload","description" => __( 'Fill with full path image url for background. Or upload your image.',ktz_admin_textdomain) ),
	"bgrepeat" => array("id" => "bgrepeat","title" => __( 'Background Repeat',ktz_admin_textdomain ),	"type" => "select","std" => "","options" => repeatimg_select(),"description" => __( 'Select with repeat, repeat-x, repeat-y and no-repeat.',ktz_admin_textdomain) ),
	"bgposition" => array("id" => "bgposition","title" => __( 'Background Position',ktz_admin_textdomain ),	"type" => "select","std" => "","options" => positionimg_select(),"description" => __( 'Fill position like top left, bottom left, or etc.',ktz_admin_textdomain) ),
	"bgattach" => array("id" => "bgattach","title" => __( 'Background Attachment',ktz_admin_textdomain ),	"type" => "select","std" => "","options" => attachimg_select(),"description" => __( 'Fill with background attachment.',ktz_admin_textdomain) ),
	"tabwrapclose_bg" => array("type" => "innerclose"), 
	));

	$page_meta[] = array( 
	"id" => "post-options", "title" => "Post options", "pagemeta_key" => "post_meta", "pages" => array("post"), "context" => "normal", "priority" => "high", "fields" => array(
	"open" => array("type" => "open" ),	
	"tabber" => array("type" => "innertabs_start" ),
	"title_sb" => array( "type" => "heading", "id" => "sidebar", "description" => __( 'Sidebar and widget option',ktz_admin_textdomain) ),
	"title_stylepages" => array( "type" => "heading", "id" => "bgsetting", "description" => __( 'Background setting',ktz_admin_textdomain) ),
	"tabberend" => array("type" => "innertabs_end" ),

	"tabwrap_sb" => array("type" => "inneropen", "id" => "sidebar"), 
	"sidebar_rgt" => array(	"id" => "sidebar_rgt","title" => __( 'Available Sidebar for widget you can add other sidebar',ktz_admin_textdomain),	"type" => "custom_sidebar",	"description" => __( 'You can add new sidebar with check below..',ktz_admin_textdomain) ),
	"sidebar" => array("id" => "sidebar","title" => __( 'Create an new sidebar for this page.',ktz_admin_textdomain), "type" => "checkbox",	"description" => __( 'Check to create new sidebar for this posting. If this activated default sidebar will remove',ktz_admin_textdomain) ), 
	"tabwrapclose_sb" => array("type" => "innerclose"), 

	"tabwrap_bg" => array("type" => "inneropen", "id" => "bgsetting"), 	
	"bgactivated" => array("id" => "bgactivated","title" => __( 'Activated dynamic background for this posting.',ktz_admin_textdomain), "type" => "checkbox",	"description" => __( 'Check for Activated dynamic background, default background will be replaced with new background',ktz_admin_textdomain) ), 
	"bgcolor" => array("id" => "bgcolor","title" => __( 'Background color',ktz_admin_textdomain ),	"type" => "color","description" => __( 'Fill with color for background this page.',ktz_admin_textdomain) ),
	"bgimage" => array("id" => "bgimage","title" => __( 'Background Image',ktz_admin_textdomain ),	"type" => "upload","description" => __( 'Fill with full path image url for background. Or upload your image.',ktz_admin_textdomain) ),
	"bgrepeat" => array("id" => "bgrepeat","title" => __( 'Background Repeat',ktz_admin_textdomain ),	"type" => "select","std" => "","options" => repeatimg_select(),"description" => __( 'Select with repeat, repeat-x, repeat-y and no-repeat.',ktz_admin_textdomain) ),
	"bgposition" => array("id" => "bgposition","title" => __( 'Background Position',ktz_admin_textdomain ),	"type" => "select","std" => "","options" => positionimg_select(),"description" => __( 'Fill position like top left, bottom left, or etc.',ktz_admin_textdomain) ),
	"bgattach" => array("id" => "bgattach","title" => __( 'Background Attachment',ktz_admin_textdomain ),	"type" => "select","std" => "","options" => attachimg_select(),"description" => __( 'Fill with background attachment.',ktz_admin_textdomain) ),

	"close" => array("type" => "close" ),	
	));
	return $page_meta;
}
add_filter( 'ktz_metaboxes', 'ktz_metaboxes_options' );

function ktz_meta_boxes_initialize() {
	if ( ! class_exists( 'ktz_MetaBox' ) )
		require_once 'testing.php';
}
add_action( 'init', 'ktz_meta_boxes_initialize', 9999 );

?>