/******
* Kentooz Framework Add JS function for metabox
******/

// Add Popup description
jQuery(document).ready(function () {  
jQuery(".img-description").click(function(){
	var descheading = jQuery(this).prev(".ktztitle span").html();
	var desctext = jQuery(this).next(".ktzdesc").html();
	jQuery('body').append("<div id='custom-lbox'><div class='shadow'></div><div class='box-desc'><div class='box-desc-top'></div><div class='box-desc-content'><h3>"+descheading+"</h3>"+desctext+"<div class='lightboxclose'></div> </div> <div class='box-desc-bottom'></div>	</div></div>");
	jQuery(".shadow").animate({ opacity: "show" }, "fast").fadeTo("fast", 0.75);
	jQuery('.lightboxclose').click(function(){
	jQuery(".shadow").animate({ opacity: "hide" }, "fast", function(){jQuery("#custom-lbox").remove();});	
	});
});
});

// Add Select UI
jQuery(document).ready(function () {
      jQuery('.select_wrapper').each(function () {
        jQuery(this).prepend('<span>' + jQuery(this).find('.select option:selected').text() + '</span>');
      });
      jQuery('.select').live('change', function () {
        jQuery(this).prev('span').replaceWith('<span>' + jQuery(this).find('option:selected').text() + '</span>');
      });
      jQuery('.select').bind(jQuery.browser.msie ? 'click' : 'change', function(event) {
        jQuery(this).prev('span').replaceWith('<span>' + jQuery(this).find('option:selected').text() + '</span>');
      }); 
  });
  
// Add Tabs
jQuery(document).ready(function(){
		jQuery('.ktz_tabmb,.ktz_tabmb > div').tabs({selected: 0 });
})

// Add color picker
jQuery(document).ready(function(){
			jQuery("#post").attr("enctype", "multipart/form-data");
			jQuery("#post").attr("encoding", "multipart/form-data");
			
			jQuery(".colorSelector").each(function(){
				var Othis = this;
				var initialColor = jQuery(Othis).next("input").attr("value");
				jQuery(this).ColorPicker({
					color: initialColor,
					onShow: function (colpkr) {
						jQuery(colpkr).fadeIn(500);
						return false;
					},
					onHide: function (colpkr) {
						jQuery(colpkr).fadeOut(500);
						return false;
					},
					onChange: function (hsb, hex, rgb) {
						jQuery(Othis).children("div").css("backgroundColor", "#" + hex);
						jQuery(Othis).next("input").attr("value","#" + hex);
					}
				});
			});
			
});

