<?php
/* Kentooz Framework widget for recent posts carousel. */

class ktz_recent_posts_carousel extends WP_Widget {
	function ktz_recent_posts_carousel() {
		$widget_ops = array( 'classname' => 'ktz_recent_post_carosuel clearfix', 'description' => __( 'Recent posts with carousel. (This widget only work in BIG MODULE)',ktz_theme_textdomain ) );
		$this->WP_Widget('ktz-recent-posts-carousel', __( 'KTZ Recent Carousel',ktz_theme_textdomain ), $widget_ops);
		$this->alt_option_name = 'ktz_recent_carousel';
		add_action( 'save_post', array(&$this, 'flush_widget_cache') );
		add_action( 'deleted_post', array(&$this, 'flush_widget_cache') );
		add_action( 'switch_theme', array(&$this, 'flush_widget_cache') );
	}
	function widget($args, $instance) {
		$cache = wp_cache_get('widget_recent_posts_carousel', 'widget');
		if ( !is_array($cache) )
			$cache = array();
		if ( isset($cache[$args['widget_id']]) ) {
			echo $cache[$args['widget_id']];
			return;
		}
		ob_start();
		extract($args);
		$cats = empty( $instance['cats'] ) ? '' : $instance['cats'];
		$title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title']);
		if ( !$number = (int) $instance['number'] )
			$number = 10;
		else if ( $number < 1 )
			$number = 1;
		else if ( $number > 15 )
			$number = 15;
		$ktzrecentcar = new WP_Query(array('showposts' => $number, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'cat' => $cats));
		if ($ktzrecentcar->have_posts()) : 
		echo $before_widget; 
        if ( $title ) :
			if ( $title != '' ) {
				echo '<h4 class="widget-title">';
				echo '<span>' . $title . '</span>';
				echo '</h4>';
			} else { 
				echo '';
			}
		endif;
		global $post;
		echo '<div class="widget_carousel"><div class="list_carousel">';
		echo '<div class="owl-carousel owl-theme ktzcarousel">';
		while ($ktzrecentcar -> have_posts()) : $ktzrecentcar -> the_post(); 
		global $post;
		$permalink = get_permalink();
		$title = get_the_title();
		$postid = get_the_ID();
		echo '<div class="item">';
        echo ktz_feature_img( 147, 147 );
		echo '<div class="title-carousel">';
		echo ktz_posted_title_a();
		echo '</div>';
		echo '</div>';
		endwhile;
        echo '</div>';
		echo '</div></div>';
		wp_reset_query();  
		endif;
		echo $after_widget;
		$cache[$args['widget_id']] = ob_get_flush();
		wp_cache_add('widget_recent_posts_carousel', $cache, 'widget');
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = (int) $new_instance['number'];
		$instance['cats'] = (int) $new_instance['cats'];
		$this->flush_widget_cache();
		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['ktz_recent_carousel']) )
		delete_option('ktz_recent_carousel');
		return $instance;
	}

	function flush_widget_cache() {
		wp_cache_delete('widget_recent_posts_carousel', 'widget');
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '','cats' => '') );
		$title = esc_attr( $instance['title'] );
		$cats = esc_attr( $instance['cats'] );
		if ( !isset($instance['number']) || !$number = (int) $instance['number'] )
			$number = 5; ?>
		<p><small><?php _e('This widget only work 1 carousel every page', ktz_theme_textdomain); ?></small><br /><label for="<?php echo $this->get_field_id('title',ktz_theme_textdomain ); ?>"><?php _e( 'Title:',ktz_theme_textdomain ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
		<p><label for="<?php echo $this->get_field_id('number',ktz_theme_textdomain ); ?>"><?php _e( 'Number of posts to show:'); ?></label>
		<input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" /><br />
		<small><?php _e( '(at most 15)',ktz_theme_textdomain ); ?></small>
        </p>
		<p><label for="<?php echo $this->get_field_id('cats'); ?>"><?php _e( 'Fill with Category ID:',ktz_theme_textdomain); ?></label>
		<select id="<?php echo $this->get_field_id('cats'); ?>" name="<?php echo $this->get_field_name('cats'); ?>" class="widefat">
		<option value="" <?php selected( $instance['cats'], '' ); ?>><?php _e('All', ktz_theme_textdomain); ?></option>
		<?php $blog_categories = get_categories( array('orderby' => 'id') ); foreach( $blog_categories as $category ): ?>
		<option value="<?php echo $category->term_id; ?>" <?php selected( $instance['cats'], $category->term_id ); ?>><?php echo $category->name; ?></option>
		<?php endforeach; ?>
		</select>
		<br />
		<small><?php _e('Please select category for display in your widget', ktz_theme_textdomain); ?></small>
		</p>
	<?php }
}?>