<?php
/* Kentooz Framework widget for flickr photo stream. */

class ktz_flickr extends WP_Widget {
	function ktz_flickr() {
		$widget_ops = array( 'classname' => 'ktz_flickr', 'description' => __( 'Widget for display photostream with flickr.',ktz_admin_textdomain) );
		$this->WP_Widget( 'ktz_flickr', __( 'KTZ Flickr Photostream',ktz_admin_textdomain), $widget_ops );
	}

	function ktz_flickrgraph( $user_ID, $number ) {
		$noerror = false;
		$images = get_transient('ktz_flickrgraph');
		if ( $images === false ) {
			$xml_load = wp_remote_get("http://api.flickr.com/services/feeds/photos_public.gne?id=$user_ID&format=rss");
			$rss_feed = @simplexml_load_string( $xml_load['body'] );
			if( is_wp_error( $rss_feed ) || empty( $rss_feed ) ) {
				$images = "<div id=\"flickr_badge_wrapper\">". __('Image not available', ktz_admin_textdomain) ."</div>";
			} else {
				$image = $rss_feed->channel->item;
				if( count( $image ) ) {
					$noerror = true;
					for( $i = 0; $i < $number; $i++ ) {
						preg_match( '/<img[^>]*>/i', $image[$i]->description, $image_tag );
						preg_match( '/(?<=src=[\'|"])[^\'|"]*?(?=[\'|"])/i', $image_tag[0], $image_src );
						if ( preg_match( '/(_m.jpg)$/',$image_src[0] ) ){
							$thumb = preg_replace('/(_m.jpg)$/', '_s.jpg', $image_src[0] );
						} elseif( preg_match( '/(_m.png)$/',$image_src[0] ) ){
							$thumb = preg_replace('/(_m.png)$/', '_s.png', $image_src[0] );
						} elseif( preg_match( '/(_m.gif)$/',$image_src[0] ) ){
							$thumb = preg_replace( '/(_m.gif)$/', '_s.gif', $image_src[0] );
						}
						$image_link = $image[$i]->link;
						$image_title = $image[$i]->title;
						$images .= "<div class=\"flickr_badge_image pull-left thumbnail clearfix\"><a href='$image_link' title='$image_title'><img src='$thumb' alt='$image_title' /></a></div>\n";
					}
					set_transient('ktz_flickrgraph', $images, 60*60);
				}
			}
		}
		return $images;
	}

	function widget( $args, $instance ) {
		extract( $args );
		$title = apply_filters('widget_title', empty( $instance['title'] ) ? __( 'Flickr Widget',ktz_admin_textdomain ) : $instance['title'], $instance, $this->id_base);
		$user_ID = $instance['user_ID'];
		if ( !$number = (int) $instance['number'] )
			$number = 10;
		else if ( $number < 1 )
			$number = 1;
		else if ( $number > 10 )
			$number = 10;
		$text = $instance['text'];

		echo $before_widget;
		if ( $title )
			echo $before_title . $title . $after_title;

		?>
        <div id="flickr_badge_wrapper" class="clearfix">
		<?php echo $text; ?>
		<?php echo $this->ktz_flickrgraph($user_ID, $number); ?>
        </div><!-- END FLICKR BADGE WRAPPER -->

	<?php	/* End output */
		echo $after_widget;
	}

	/* Update the widget settings. */
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags( $new_instance['title'] );
		if ( in_array( $new_instance['source'], array( 'user', 'user_tag', 'user_set', 'all', 'all_tag' ) ) ) {
			$instance['source'] = $new_instance['source'];
		} else {
			$instance['source'] = 'user';
		}
		// Refresh Cache
		delete_transient('ktz_flickrgraph');
		$instance['user_ID'] = strip_tags( $new_instance['user_ID'] );
		$instance['user_set_ID'] = strip_tags( $new_instance['user_set_ID'] );
		$instance['tag'] = strip_tags( $new_instance['tag'] );
		$instance['number'] = (int) $new_instance['number'];
		$instance['display_random'] = isset($new_instance['display_random']) ? true : false;
		if ( current_user_can('unfiltered_html') )
			$instance['text'] =  $new_instance['text'];
		else
			$instance['text'] = stripslashes( $new_instance['text'] );
		return $instance;
	}


	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'source' => 'user', 'title' => '', 'user_ID' => '83779042%40N07', 'user_set_ID' => '72157630808825766', 'tag' => '', 'display_random' => false, 'text' => '' ) );
		if ( !isset($instance['number']) || !$number = (int) $instance['number'] )
		$number = 9;
		$title = esc_attr( $instance['title'] );
		$user_ID = esc_attr( $instance['user_ID'] );
		$user_set_ID = esc_attr( $instance['user_set_ID'] );
		$tag = esc_attr( $instance['tag'] );
		$text = format_to_edit($instance['text']);
		?>

        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title:',ktz_admin_textdomain ); ?></label> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('user_ID'); ?>"><?php _e( 'User ID:',ktz_admin_textdomain ); ?></label> <input type="text" value="<?php echo $user_ID; ?>" name="<?php echo $this->get_field_name('user_ID'); ?>" id="<?php echo $this->get_field_id('user_ID'); ?>" class="widefat" />
            <br />
            <small><?php _e( 'Flickr photostream ID. Eg: 83779042%40N07, http://www.flickr.com/photos/83779042@N07/7671148482/ where %40 is replaced for @',ktz_admin_textdomain ); ?>
            </small>
        </p>
		<p><label for="<?php echo $this->get_field_id('number'); ?>"><?php _e( 'Number img to show:',ktz_admin_textdomain ); ?></label>
		<input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" /><br />
		<small><?php _e( '(at most 10)',ktz_admin_textdomain ); ?></small>
        </p>
		<p><label for="<?php echo $this->get_field_id('text'); ?>"><?php _e( 'Text before gallery:',ktz_admin_textdomain ); ?></label>
        <textarea class="widefat" rows="5" cols="20" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>"><?php echo $text; ?></textarea><br />
		<small><?php _e( 'Fill with text, you can use HTML code.',ktz_admin_textdomain ); ?></small></p>
		</p>
	<?php
	}
}
?>