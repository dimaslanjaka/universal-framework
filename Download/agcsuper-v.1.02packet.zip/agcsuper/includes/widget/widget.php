<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ WIDGET FRAMEWORK
/* Website: kentooz.com
/* The Author: Gian Mokhammad Ramadhan 
/* Social network :twitter.com/g14nnakal facebook.com/gianmr
/* Version :1.0
/*-----------------------------------------------*/

/*******************************************
# Register widget on hook system ~ sidebar
*******************************************/
function ktz_widget_init() {
	// Add facebook widget in kentooz framework
	include_once(ktz_dir . '/includes/widget/facebook_widget.php');
	register_widget('ktz_facebook');
	// Add banner widget in kentooz framework
	include_once(ktz_dir . '/includes/widget/banner_widget.php');
	register_widget('ktz_banner');
	// Add recent widget in kentooz framework
	include_once(ktz_dir . '/includes/widget/recent_posts_widget.php');
	register_widget('ktz_recent_posts');
	// Add recent widget in kentooz framework
	include_once(ktz_dir . '/includes/widget/popular_posts_widget.php');
	register_widget('ktz_popular_posts');
	// Add social feed widget in kentooz framework
	include_once(ktz_dir . '/includes/widget/feedburner_widget.php');
	register_widget('ktz_feedburner');
	// Add recent widget carousel in kentooz framework
	include_once(ktz_dir . '/includes/widget/recent_posts_carousel_widget.php');
	register_widget('ktz_recent_posts_carousel');
	// Add social flickr widget in kentooz framework
	include_once(ktz_dir . '/includes/widget/flickr_widget.php');
	register_widget('ktz_flickr');
	// Add recent widget in kentooz framework
	include_once(ktz_dir . '/includes/widget/recent_posts_big_widget.php');
	register_widget('ktz_recent_posts_big');
}

?>