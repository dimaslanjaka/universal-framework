<?php
/* Kentooz Framework widget for recent posts. */

class ktz_recent_posts_big extends WP_Widget {
	function ktz_recent_posts_big() {
		$widget_ops = array( 'classname' => 'ktz_recent_post_big clearfix', 'description' => __( 'Recent posts with category selection [This widget just used in Top Module].',ktz_theme_textdomain ) );
		$this->WP_Widget('ktz-recent-posts-big', __( 'KTZ BIG Recent Posts',ktz_theme_textdomain ), $widget_ops);
		$this->alt_option_name = 'ktz_recent_big';
		add_action( 'save_post', array(&$this, 'flush_widget_cache') );
		add_action( 'deleted_post', array(&$this, 'flush_widget_cache') );
		add_action( 'switch_theme', array(&$this, 'flush_widget_cache') );
	}
	function widget($args, $instance) {
		$cache = wp_cache_get('widget_recent_posts_big', 'widget');
		if ( !is_array($cache) )
			$cache = array();
		if ( isset($cache[$args['widget_id']]) ) {
			echo $cache[$args['widget_id']];
			return;
		}
		ob_start();
		extract($args);
		$style_latest = empty( $instance['style_latest'] ) ? 'list' : $instance['style_latest'];
		$cats = empty( $instance['cats'] ) ? '' : $instance['cats'];
		$title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title']);
		$number = empty( $instance['number'] ) ? '5' : $instance['number'];
		$ktzrecent = new WP_Query(array('showposts' => $number , 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'cat' => $cats));
		if ($ktzrecent->have_posts()) : 
		global $post;
		echo $before_widget; 
        if ( $title ) :
			if ( $cats != '' ) { echo '<h4 class="widget-title"><span><a href="' . get_category_link( $cats ) . '" title="' . get_cat_name( $cats ) . '">' . get_cat_name( $cats ) . '</a></span></h4>'; }
			else { echo '<h4 class="widget-title"><span>' . __('Latest post', ktz_theme_textdomain) . '</span></h4>';}
		endif;
		if ( $style_latest == "list" ) {
			$count = 0; 
			echo '<div class="row-fluid">';
			while ($ktzrecent -> have_posts()) : $ktzrecent -> the_post(); 
			$count++; 
			if ( $count <= 1 ) {
			echo '<div class="span6">';
			echo '<div class="image-bigmodule">';
			echo ktz_feature_img( 290, 160 );
			echo '</div>';
			echo ktz_posted_title_h('h4', 'bigmodule-title');
			echo ktz_get_excerpt(15);
			echo '</div>';
			echo '<div class="span6">';
			} else {
			echo '<div class="bigmodule-list clearfix">';	
			echo '<div class="pull-left">';
			echo ktz_feature_img( 70, 50 );
			echo '</div>';
			echo ktz_posted_title_a();
			echo '</div>';
			} 
			endwhile;
			echo '</div></div>';
		} else {
			$count = 0; 
			echo '<div class="row-fluid">';
			while ($ktzrecent -> have_posts()) : $ktzrecent -> the_post(); 
			$count++; 
			if ( $count <= 1 ) {
			echo '<div class="span6">';
			echo '<div class="image-bigmodule">';
			echo ktz_feature_img( 290, 160 );
			echo '</div>';
			echo ktz_posted_title_h('h4', 'bigmodule-title');
			echo ktz_get_excerpt(15);
			echo '</div>';
			echo '<div class="span6">';
			echo '<ul class="widget-list-box clearfix">';
			} else {
			echo '<li>';
			echo '<div class="list-box pull-left">';
			echo ktz_feature_img(140,140);
			echo '<div class="mask">';
			echo ktz_posted_title_a();
			echo '</div></div>';
			echo '</li>';
			} 
			endwhile;
			echo '</ul>';
			echo '</div></div>';
		} 
		wp_reset_query();  
		endif;
		echo $after_widget;
		$cache[$args['widget_id']] = ob_get_flush();
		wp_cache_add('widget_recent_posts_big', $cache, 'widget');
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['style_latest'] = strip_tags( $new_instance['style_latest'] );
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['cats'] = (int) $new_instance['cats'];
		$instance['number'] = (int) $new_instance['number'];
		$this->flush_widget_cache();
		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['ktz_recent_big']) )
		delete_option('ktz_recent_big');
		return $instance;
	}

	function flush_widget_cache() {
		wp_cache_delete('widget_recent_posts_big', 'widget');
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'cats' => '', 'style_latest' => 'list') );
		$title = esc_attr( $instance['title'] );
		$cats = esc_attr( $instance['cats'] );
		if ( !isset($instance['number']) || !$number = (int) $instance['number'] )
			$number = 5;  ?>
		<p><label for="<?php echo $this->get_field_id('title',ktz_theme_textdomain ); ?>"><?php _e( 'Title:',ktz_theme_textdomain ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
            <br/>
            <small><?php _e( 'This title will not show in widget.',ktz_theme_textdomain ); ?></small>
        </p>
		<p><label for="<?php echo $this->get_field_id('number',ktz_theme_textdomain ); ?>"><?php _e( 'Number of posts to show:'); ?></label>
		<input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" /><br />
		<small><?php _e( '(at most 15)',ktz_theme_textdomain ); ?></small>
        </p>
        <p><label for="<?php echo $this->get_field_id('style_latest'); ?>"><?php _e( 'Style big module:',ktz_theme_textdomain ); ?></label>
            <select name="<?php echo $this->get_field_name('style_latest'); ?>" id="<?php echo $this->get_field_id('style_latest',ktz_theme_textdomain); ?>" class="widefat">
            <option value="list" <?php selected( $instance['style_latest'], 'list' ); ?>><?php _e( 'List',ktz_theme_textdomain ); ?></option>
            <option value="box" <?php selected( $instance['style_latest'], 'box' ); ?>><?php _e( 'Box',ktz_theme_textdomain ); ?></option>
            </select>
            <br/>
            <small><?php _e( 'Select style for recent post widget.',ktz_theme_textdomain ); ?></small>
		</p>
		<p><label for="<?php echo $this->get_field_id('cats'); ?>"><?php _e( 'Fill with Category ID:',ktz_theme_textdomain); ?></label>
		<select id="<?php echo $this->get_field_id('cats'); ?>" name="<?php echo $this->get_field_name('cats'); ?>" class="widefat">
		<option value="" <?php selected( $instance['cats'], '' ); ?>><?php _e('All', ktz_theme_textdomain); ?></option>
		<?php $blog_categories = get_categories( array('orderby' => 'id') ); foreach( $blog_categories as $category ): ?>
		<option value="<?php echo $category->term_id; ?>" <?php selected( $instance['cats'], $category->term_id ); ?>><?php echo $category->name; ?></option>
		<?php endforeach; ?>
		</select>
		<br />
		<small><?php _e('Please select category for display in your widget', ktz_theme_textdomain); ?></small>
		</p>
	<?php }
}?>