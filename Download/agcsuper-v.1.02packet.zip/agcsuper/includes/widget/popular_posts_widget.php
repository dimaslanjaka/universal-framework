<?php
/* Kentooz Framework widget for popular posts. */

class ktz_popular_posts extends WP_Widget {
	function ktz_popular_posts() {
		$widget_ops = array( 'classname' => 'ktz_popular_post clearfix', 'description' => __( 'Popular posts with thumbnail.',ktz_admin_textdomain ) );
		$this->WP_Widget('ktz-popular-posts', __( 'KTZ popular Posts',ktz_admin_textdomain ), $widget_ops);
		$this->alt_option_name = 'ktz_popular';
		add_action( 'save_post', array(&$this, 'flush_widget_cache') );
		add_action( 'deleted_post', array(&$this, 'flush_widget_cache') );
		add_action( 'switch_theme', array(&$this, 'flush_widget_cache') );
	}
	function widget($args, $instance) {
		$cache = wp_cache_get('widget_popular_posts', 'widget');
		if ( !is_array($cache) )
			$cache = array();
		if ( isset($cache[$args['widget_id']]) ) {
			echo $cache[$args['widget_id']];
			return;
		}
		ob_start();
		extract($args);
		$style_popular = empty( $instance['style_popular'] ) ? 'list' : $instance['style_popular'];
		$popular_by = empty( $instance['popular_by'] ) ? 'comment' : $instance['popular_by'];
		$cats = empty( $instance['cats'] ) ? '' : $instance['cats'];
		if ( !$number = (int) $instance['number'] )
			$number = 10;
		else if ( $number < 1 )
			$number = 1;
		else if ( $number > 15 )
			$number = 15;
		$title = apply_filters('widget_title', empty($instance['title']) ? __( 'Popular posts',ktz_admin_textdomain) : $instance['title']);
		if ( $popular_by == "comment" ) {
		$ktzpopular = new WP_Query(array('showposts' => $number,  'cat' => $cats, 'nopaging' => 0, 'post_status' => 'publish', 'ignore_sticky_posts' => 1, 'orderby' => 'comment_count', 'order' => 'DESC'));
		} elseif ( $popular_by == "view" ) {
		$ktzpopular = new WP_Query(array('post_type' => 'post', 'cat' => $cats, 'meta_key' => 'post_views_count','orderby' => 'meta_value_num','order' => 'desc','showposts' => $number,'post_status' => 'publish','ignore_sticky_posts' => 1));
		} elseif ( $popular_by == "rate" ) {
		$ktzpopular = new WP_Query(array('post_type' => 'post', 'cat' => $cats, 'meta_key' => 'ktz_stars_rating','orderby' => 'meta_value_num','order' => 'desc','showposts' => $number,'post_status' => 'publish','ignore_sticky_posts' => 1));
		} 
		if ($ktzpopular->have_posts()) : 
		echo $before_widget; 
        if ( $title ) :
			echo '<h4 class="widget-title"><span>';
			echo $title;
			echo '</span></h4>';
		endif;
		global $post;
		if ( $style_popular == "list" ) {
			echo '<ul class="widget-list">';
			while ($ktzpopular -> have_posts()) : $ktzpopular -> the_post(); 
			echo '<li class="clearfix">';
				$thumb = get_post_thumbnail_id();
				$img_url = wp_get_attachment_url( $thumb,'full' ); 
				$fisrtimg_url = get_first_image_src(); 
				if ( $img_url ) { 
					echo '<div class="pull-left">';
				} elseif ( $fisrtimg_url ) {
					echo '<div class="pull-left">';
				} else { echo ''; }
				echo ktz_feature_img(70,50);
				if ( $img_url ) { 
					echo '</div>';
				} elseif ( $fisrtimg_url ) {
					echo '</div>';
				} else { echo ''; }
				if ( $img_url ) { 
					echo '<div class="widget-list-body">';
				} elseif ( $fisrtimg_url ) {
					echo '<div class="widget-list-body">';
				} else { echo ''; }
				echo ktz_posted_title_a();
				if ( $img_url ) { 
					echo '</div>';
				} elseif ( $fisrtimg_url ) {
					echo '</div>';
				} else { echo ''; }
			echo '</li>';
			endwhile;
			echo '</ul>';
		} else {
			echo '<ul>';
			while ($ktzpopular -> have_posts()) : $ktzpopular -> the_post(); 
			global $post;
			echo '<li>';
			echo ktz_posted_title_a();
			echo '</li>';
			endwhile;
			echo '</ul>';
		}
		wp_reset_query();  
		endif;
		echo $after_widget;
		$cache[$args['widget_id']] = ob_get_flush();
		wp_cache_add('widget_popular_posts', $cache, 'widget');
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['popular_by'] = strip_tags($new_instance['popular_by']);
		$instance['style_popular'] = strip_tags( $new_instance['style_popular'] );
		$instance['number'] = (int) $new_instance['number'];
		$instance['cats'] = strip_tags($new_instance['cats'] );
		$this->flush_widget_cache();
		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['ktz_popular']) )
		delete_option('ktz_popular');
		return $instance;
	}

	function flush_widget_cache() {
		wp_cache_delete('widget_popular_posts', 'widget');
	}

	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'popular_by' => 'comment', 'cats' => '', 'style_popular' => 'list') );
		$title = esc_attr( $instance['title'] );
		$cats = esc_attr( $instance['cats'] );
		if ( !isset($instance['number']) || !$number = (int) $instance['number'] )
			$number = 5; ?>
		<p><label for="<?php echo $this->get_field_id('title',ktz_admin_textdomain ); ?>"><?php _e( 'Title:',ktz_admin_textdomain ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p><label for="<?php echo $this->get_field_id('number',ktz_admin_textdomain ); ?>"><?php _e( 'Number of posts to show:'); ?></label>
		<input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" /><br />
		<small><?php _e( '(at most 15)',ktz_admin_textdomain ); ?></small>
        </p>
        <p><label for="<?php echo $this->get_field_id('popular_by'); ?>"><?php _e( 'Popular by:',ktz_admin_textdomain ); ?></label>
            <select name="<?php echo $this->get_field_name('popular_by'); ?>" id="<?php echo $this->get_field_id('popular_by',ktz_admin_textdomain); ?>" class="widefat">
            <option value="comment" <?php selected( $instance['popular_by'], 'comment' ); ?>><?php _e( 'Comment',ktz_admin_textdomain ); ?></option>
            <option value="view" <?php selected( $instance['popular_by'], 'view' ); ?>><?php _e( 'View',ktz_admin_textdomain ); ?></option>
            <option value="rate" <?php selected( $instance['popular_by'], 'rate' ); ?>><?php _e( 'Rating',ktz_admin_textdomain ); ?></option>
            </select>
            <br/>
            <small><?php _e( 'Select popular by comment, view, rating.',ktz_admin_textdomain ); ?></small>
		</p>
        <p><label for="<?php echo $this->get_field_id('style_popular'); ?>"><?php _e( 'Style box:',ktz_admin_textdomain ); ?></label>
            <select name="<?php echo $this->get_field_name('style_popular'); ?>" id="<?php echo $this->get_field_id('style_popular',ktz_admin_textdomain); ?>" class="widefat">
            <option value="list"<?php selected( $instance['style_popular'], 'list' ); ?>><?php _e( 'list',ktz_admin_textdomain ); ?></option>
            <option value="box"<?php selected( $instance['style_popular'], 'box' ); ?>><?php _e( 'Just title',ktz_admin_textdomain ); ?></option>
            </select>
            <br/>
            <small><?php _e( 'Select style for latest widget.',ktz_admin_textdomain ); ?></small>
		</p>
		<p><label for="<?php echo $this->get_field_id('cats'); ?>"><?php _e( 'Select category:',ktz_admin_textdomain); ?></label>
		<select id="<?php echo $this->get_field_id('cats'); ?>" name="<?php echo $this->get_field_name('cats'); ?>" class="widefat">
		<option value="" <?php selected( $instance['cats'], '' ); ?>><?php _e('All', ktz_admin_textdomain); ?></option>
		<?php $blog_categories = get_categories( array('orderby' => 'id') ); foreach( $blog_categories as $category ): ?>
		<option value="<?php echo $category->term_id; ?>" <?php selected( $instance['cats'], $category->term_id ); ?>><?php echo $category->name; ?></option>
		<?php endforeach; ?>
		</select>
		<br />
		<small><?php _e('Please select category for display in your widget', ktz_admin_textdomain); ?></small>
		</p>
	<?php }
}?>