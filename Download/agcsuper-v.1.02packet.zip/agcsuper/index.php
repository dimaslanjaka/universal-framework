<?php 
/**
 * KENTOOZ INDEX TEMPLATE
**/
get_header(); ?>
	<section class="span12">
	<?php echo ktz_feature_slider(); ?>
	<div class="row">
	<?php if ( get_theme_option('ktz_sb_layout') == 'left' ) : get_sidebar(); endif; ?>
		<div role="main" class="span8">
		<section class="new-content">
		<?php if ( is_active_sidebar('widget_tophome')) : dynamic_sidebar('widget_tophome'); endif; ?>
		<div class="row">
		<div role="main" class="span4">
			<?php if ( is_active_sidebar('widget_leftmodule')) : dynamic_sidebar('widget_leftmodule'); endif; ?>
		</div>
		<div role="main" class="span4">
			<?php if ( is_active_sidebar('widget_rightmodule')) : dynamic_sidebar('widget_rightmodule'); endif; ?>
		</div>
		</div>
		</section>
		</div>
	<?php if ( get_theme_option('ktz_sb_layout') == 'right' ) : get_sidebar(); endif; ?>
	</div>
	<div class="row">
		<div role="main" class="span4">
			<?php if ( is_active_sidebar('widget_footermodule_1')) : dynamic_sidebar('widget_footermodule_1'); endif; ?>
		</div>
		<div role="main" class="span4">
			<?php if ( is_active_sidebar('widget_footermodule_2')) : dynamic_sidebar('widget_footermodule_2'); endif; ?>
		</div>
		<div role="main" class="span4">
			<?php if ( is_active_sidebar('widget_footermodule_3')) : dynamic_sidebar('widget_footermodule_3'); endif; ?>
		</div>
	</div>
	</section>
<?php get_footer(); ?>