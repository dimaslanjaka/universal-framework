<?php
/**
 * KENTOOZ DEFAULD POST TEMPLATE
**/
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('ktz-wallpaperitem boxer'); ?>>
			<?php echo ktz_feature_img(147, 90); ?>
	<div class="wallpaper-box">
		<div class="image-wallpaper position-rel">	
			<div class="title-wallpaper">
				<div>
				<?php echo ktz_posted_title_a(); ?>	
				</div>
			</div>
		</div>
		<div class="meta-wallpaper">
				<?php echo ktz_ajaxstar_SEO(); ?><div style="display:none;"><?php echo ktz_posted_on(); ?><?php echo ktz_author_by(); ?></div>
		</div>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
