<?php $search_text = empty($_GET['s']) ? "Search" : get_search_query(); ?> 
<div id="search" class="clearfix">
    <form method="get" id="searchform" action="<?php echo esc_url( home_url( '' ) ); ?>"> 
        <input type="text" name="s" id="s" placeholder="Search"/>
        <input type="submit" value="Search">
    </form>
</div>
