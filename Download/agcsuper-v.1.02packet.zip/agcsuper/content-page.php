<?php
/**
 * KENTOOZ PAGE LOOP TEMPLATE
**/
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="post-box-single">
			<?php the_content(); ?>
			<?php wp_link_pages( array( 'before' => '<div class="page-link"><span>' . __( 'Pages:', ktz_theme_textdomain ) . '</span>', 'after' => '</div>' ) ); ?>
		</div>
</article><!-- #post-<?php the_ID(); ?> -->
