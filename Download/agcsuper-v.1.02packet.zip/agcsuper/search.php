<?php 
/**
 * KENTOOZ SEARCH PAGE TEMPLATE
**/
get_header();
		$s = str_replace('-', ' ', $s); 
		$termstring = $s;
 ?>
	<section class="span12">
	<div class="row">
	<?php if ( get_theme_option('ktz_sb_layout') == 'left' ) : get_sidebar(); endif; ?>
		<div role="main" class="span8 clearfix">
		<section class="new-content">
		<div class="title-box clearfix"><?php 
		$s = str_replace('-', ' ', $s); 
		$s = str_replace('.html', '', $s); 
		echo '<h1 class="entry-title single-title"><span>';
		if (get_theme_option('ktz_agc_activated') !="") {
			echo '';
		} else {
			echo __( 'Search Results for: ', ktz_theme_textdomain );
		}
		if (ktz_filter_badkeyword() === false) : 
		echo ucwords($s); 
		else : 
		echo 'Keyword is block'; 
		endif; ?></span></h1></div>
		<?php if (get_theme_option('ktz_agc_activated') !="") : ?>
	<div class="bgstripes-meta">
		<span class="bgstripe color2"><?php echo ktz_socialshare_fb_search(); ?></span>
		<span class="bgstripe color11"><?php echo ktz_socialshare_twit_search(); ?></span>
		<span class="bgstripe color10"><?php echo ktz_socialshare_gplus_search(); ?></span>
	</div>
		<?php endif; ?>
		<?php $s = str_replace('-', ' ', $s);
			  $s = str_replace('.html', '', $s);
			$query = new WP_Query( 's='.$s ); if ( $query->have_posts() ) : ?>
		<div class="clearfix" id="box-content">
		<?php 
		if (get_theme_option('ktz_agc_activated') !="") {
			if ( !empty ($termstring) ) {
				echo '<div class="post-box clearfix">';
				ktz_get_googleimageAGC();
				ktz_agc_bing();
				ktz_agc_google();
				echo '<h2 class="related-title"><span>' . __('Related post for',ktz_theme_textdomain) . ' '.$termstring.'</span></h2>';
				ktz_agc_bing_related();
				echo '</div>';
			}
		}		
		while ( $query->have_posts() ) : $query->the_post();
			get_template_part( 'content', get_post_format() );
		endwhile;
		?>
		</div>
		<nav id="nav-index">
			<?php ktz_navigation(); ?>
		</nav>
		<?php else : 
		$s = str_replace('-', ' ', $s); 
		$termstring = $s;
		if (get_theme_option('ktz_agc_activated') !="") {
			if ( !empty ($termstring) ) {
				echo '<div class="post-box clearfix">';
				ktz_get_googleimageAGC();
				ktz_agc_bing();
				ktz_agc_google();
				echo '<h2 class="related-title"><span>' . __('Related post for',ktz_theme_textdomain) . ' '.$termstring.'</span></h2>';
				ktz_agc_bing_related();
				echo '</div>';
			} 
		} else {
				ktz_post_notfound();
	} 
	endif; ?>
		</section>
		</div>
	<?php if ( get_theme_option('ktz_sb_layout') == 'right' ) : get_sidebar(); endif; ?>
	</div>
	</section>
<?php get_footer(); ?>
