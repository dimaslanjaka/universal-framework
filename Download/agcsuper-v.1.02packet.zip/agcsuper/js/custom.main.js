/*
 * Copyright (c) 2013 kentooz
 * Kentooz Theme Custom Javascript
 */
jQuery(document).ready(function() {
// JS TOOLTIPS
	jQuery('ul.icon24px a').tooltip()
	jQuery('a[rel=tooltip]').tooltip()
// JS SCROLL TOP	
	jQuery(window).scroll(function(){
		if (jQuery(this).scrollTop() > 100) {
			jQuery('#back-top').fadeIn();
		} else {
			jQuery('#back-top').fadeOut();
		}
    });
    jQuery('#back-top').click(function(){
        jQuery("html, body").animate({ scrollTop: 0 }, 600);
		return false;
		});
// NEWS JQUERY CAROUSEL
	jQuery(".ktzcarousel").owlCarousel({
	navigation: true,
	navigationText: [
		"<span class='carousel-next'></span>",
		"<span class='carousel-prev'></span>"
	],
	pagination : false,
	items : 4,
    responsive: true,
    responsiveRefreshRate : 200,
	});
	jQuery(".ktzcarousel-single").owlCarousel({
		navigation : true, // Show next and prev buttons
		navigationText: [
			"<span class='carousel-next'></span>",
			"<span class='carousel-prev'></span>"
		],
		slideSpeed : 300,
		paginationSpeed : 400,
		singleItem:true
	});
// EISLIDER
	jQuery('#ei-slider').eislideshow({
		animation			: 'center',
		autoplay			: true,
		slideshow_interval	: 3000,
		titlesFactor		: 0
    });
// JS Tab
jQuery('#kentooz-comment a:first').tab('show');
// JS SELECT NAV FOR SMALL SCREEN
	selectnav('topmenu', {
		label: '-- SELECT MENU --',
		nested: true,
		indent: '-'
	});
// SUPERFIST
	jQuery('ul#topmenu').superfish({
			delay:       500,                            // one second delay on mouseout
			animation:   {opacity:'show',height:'show'},  // fade-in and slide-down animation
			speed:       'fast',                          // faster animation speed
			autoArrows:  true                            // disable generation of arrow mark-up	
	});
}); 