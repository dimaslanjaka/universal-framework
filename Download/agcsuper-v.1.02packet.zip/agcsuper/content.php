<?php
/**
 * KENTOOZ DEFAULD POST TEMPLATE
**/
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(''); ?>>
		<div class="title-box">	
			<?php echo ktz_posted_title_h('h2','title-content'); ?>	
		</div>
	<div class="bgstripes-meta">
		<span class="bgstripe color1"><?php echo ktz_author_by(); ?></span>
		<span class="bgstripe color4"><?php echo ktz_posted_on(); ?></span>
		<span class="bgstripe color2"><?php echo ktz_socialshare_fb(); ?></span>
		<span class="bgstripe color11"><?php echo ktz_socialshare_twit(); ?></span>
		<span class="bgstripe color10"><?php echo ktz_socialshare_gplus(); ?></span>
	</div>
		<div class="post-box clearfix">	
		<div class="pull-left">	
			<?php echo ktz_feature_img(120, 120); ?>
		</div>
		<?php
		$thumb = get_post_thumbnail_id();
		$img_url = wp_get_attachment_url( $thumb,'full' ); 
		$fisrtimg_url = get_first_image_src(); 
		if ( $img_url ) { 
			echo '<div class="post-box-content clearfix">';
		} elseif ( $fisrtimg_url ) {
			echo '<div class="post-box-content clearfix">';
		} else { echo ''; }
			echo ktz_content();
		if ( $img_url ) { 
			echo '</div>';
		} elseif ( $fisrtimg_url ) {
			echo '</div>';
		} else { echo ''; }
		?>
		</div>
</article><!-- #post-<?php the_ID(); ?> -->
