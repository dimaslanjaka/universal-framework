<?php 
/**
 * KENTOOZ ATTACMENT TEMPLATE
**/
get_header(); ?>
	<div role="main" class="span12">
		<section class="new-content">
		<?php while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<?php ktz_setPostViews(get_the_ID()); //get view for single post ?>
		<div class="title-box">	
			<?php echo ktz_posted_title_nonlink_h('h1','single-title'); ?>
		</div>
	<div class="bgstripes-meta">
		<span class="bgstripe color1"><?php echo ktz_author_by(); ?></span>
		<span class="bgstripe color4"><?php echo ktz_posted_on(); ?></span>
		<span class="bgstripe color2"><?php echo ktz_socialshare_fb(); ?></span>
		<span class="bgstripe color11"><?php echo ktz_socialshare_twit(); ?></span>
		<span class="bgstripe color10"><?php echo ktz_socialshare_gplus(); ?></span>
	</div>
			<div class="post-box-single">
				<?php $attachments = array_values( get_children( array( 'post_parent' => $post->post_parent, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => 'ASC', 'orderby' => 'menu_order ID' ) ) );
				foreach ( $attachments as $k => $attachment ) {
					if ( $attachment->ID == $post->ID )
						break;
				}
				$k++;
				if ( count( $attachments ) > 1 ) {
					if ( isset( $attachments[ $k ] ) ) {
						$caption = $attachment->post_excerpt;
						$next_attachment_url = get_attachment_link( $attachments[ $k ]->ID );
					} else {
						$caption = $attachment->post_excerpt;
						$next_attachment_url = get_attachment_link( $attachments[ 0 ]->ID );
					}
				}
				else {
					$next_attachment_url = wp_get_attachment_url();
				}
				?>
				<div class="entry-body-attachment clearfix">
					<p class="attachment"><?php echo wp_get_attachment_image( $post->ID, 'full' ); // filterable image width with, essentially, no limit for image height. ?></p>
				</div>
			<h2 class="info-title"><?php echo __('Description attachment for', ktz_theme_textdomain ) .' ' . get_the_title(); ?></h2>
			<?php
					$attachment_meta = wp_get_attachment_metadata($post->ID, 'full');
					$image_attributes = wp_get_attachment_image_src( $post->ID, 'full' ); // returns an array
				echo '<ul class="attachment-desc">';
					echo '<li class="dark">
						<span class="title-info">Title:</span>
						<span class="desc">';
						echo get_the_title();
						echo '</span>
					</li>
					<li>
					<span class="title-info">Author:</span>
						<span class="desc">';
						echo ktz_author_by();
						echo '</span>
					</li>
					<li class="dark">
						<span class="title-info">Upload:</span>
						<span class="desc">';
						echo ktz_posted_on();
						echo '</span>
					</li>
					<li>
						<span class="title-info">Link:</span>
						<span class="desc">';
						$thumb = get_post_thumbnail_id();
						$img_url = wp_get_attachment_url( $thumb,'full' ); 
						$firstimage_url = get_first_image_src(); 
						if ( $img_url ) {  
							echo $img_url;
						} elseif ( $firstimage_url ) {
							echo $firstimage_url; 
						} else { 
							echo 'No Image';
						} 
						echo '</span>
					</li>
					<li class="dark">
						<span class="title-info">Location:</span>
						<span class="desc">';
						echo $attachment_meta['file'];
						echo '</span>
					</li>
					<li>
						<span class="title-info">Dimention:</span>
						<span class="desc">';
						echo $attachment_meta['width'] . 'px X ' . $attachment_meta['height'] . 'px';
						echo '</span>
					</li>
					<li class="dark">
						<span class="title-info">Content:</span>
						<span class="desc">';
						echo get_the_content();
						echo '</span>
						</li>';	
				echo '</ul>';
			?>
			</div>
			</article><!-- #post-<?php the_ID(); ?> -->
			<?php endwhile; // end of the loop. ?>
		</section>
	</div>
	<?php $ktzrandom = new WP_Query(array( // Use query_post for add pagination in post page
			'orderby' => 'rand',
			'order' => 'desc',
			'paged' => $paged,
			'posts_per_page' => 6,
			'ignore_sticky_posts' => 1
	)); ?>
	<div role="main" class="span12">
	<section class="new-content">
		<div class="entry-body-attachment post-box-single">
			<?php $args = array(
			'orderby'           => 'rand',
			'post_type'         => 'attachment',
			'post_status'       => 'inherit',
			'posts_per_page'    => 4
			);
			$query = new WP_Query($args);
			echo '<h3 class="widget-title page-attachment"><span>' . __('Random attachment for', ktz_theme_textdomain) . ' ' . get_the_title() . '</span></h3>';
			echo '<div class="row-fluid">';
			if($query->have_posts()) : 
			while($query->have_posts()) : $query->the_post();
			echo '<div class="span3">';
			echo ktz_feature_img( 220, 150 );
			echo '</div>';
			endwhile;
			wp_reset_postdata();
			endif; 		?>
		</div>
	</section>
	</div>
<?php get_footer(); ?>
