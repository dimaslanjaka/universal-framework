<?php 
/**
 * KENTOOZ Silent is gold
**/

?>
