<?php 
/**
 * KENTOOZ 404 ERROR TEMPLATE
**/
get_header(); ?>	
<section class="span12">
	<div class="error-img">
			<?php ktz_error_page(); ?>
	</div>
</section>
<?php get_footer(); ?>