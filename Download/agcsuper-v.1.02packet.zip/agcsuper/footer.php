	</div> <!-- .row on head -->
	<?php echo ktz_ban72890_mainfooter(); ?>
	</div> <!-- .head -->
	</div> <!-- .on head -->
	<footer class="footer">
	<div class="bgstripes">
		<span class="bgstripe color1"></span>
		<span class="bgstripe color2"></span>
		<span class="bgstripe color3"></span>
		<span class="bgstripe color4"></span>
		<span class="bgstripe color5"></span>
		<span class="bgstripe color6"></span>
		<span class="bgstripe color7"></span>
		<span class="bgstripe color8"></span>
		<span class="bgstripe color9"></span>
		<span class="bgstripe color10"></span>
		<span class="bgstripe color11"></span>
		<span class="bgstripe color12"></span>
		<span class="bgstripe color13"></span>
		<span class="bgstripe color14"></span>
		<span class="bgstripe color15"></span>
		<span class="bgstripe color16"></span>
		<span class="bgstripe color17"></span>
		<span class="bgstripe color18"></span>
		<span class="bgstripe color19"></span>
		<span class="bgstripe color20"></span>
	</div>
	<?php if ( is_active_sidebar('widget_fot1') ): ?>
	<div class="wrapfootwidget">
		<div class="container">
			<?php hook_ktz_footer(); ?>
		</div>
	</div>
	<?php endif; ?>
	<div class="copyright">
		<div class="container">
			<div class="row">
			<?php hook_ktz_after_footer(); ?>
			</div>
		</div>
	</div>
	</footer>
	</div> <!-- .all-wrapper on head -->
	<p id="back-top">
		<a href="#top"><span></span></a>
	</p> <!-- End #back-top -->
	<?php wp_footer();echo get_theme_option("ktz_footer")  . "\n"; ?>
</body>
</html>
<?php if (is_search()) : ob_flush(); endif ?>