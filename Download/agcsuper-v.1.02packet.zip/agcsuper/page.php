<?php 
/**
 * KENTOOZ PAGE TEMPLATE
**/
get_header(); ?>
	<section class="span12">
	<div class="row">
	<?php if ( get_theme_option('ktz_sb_layout') == 'left' ) : get_sidebar(); endif; ?>
	<div role="main" class="span8">
		<section class="new-content">
		<?php if (is_home() || is_front_page()) { ?>
		<?php } else { ?>
		<h1 class="widget-title page-title-2"><span><?php echo wp_title('',true); ?></span></h1>
		<?php } ?>
		<?php while ( have_posts() ) : the_post(); 
		get_template_part( 'content', 'page' ); 
		endwhile; ?>
		</section>
	</div>
	<?php if ( get_theme_option('ktz_sb_layout') == 'right' ) : get_sidebar(); endif; ?>
	</div>
	</section>
<?php get_footer(); ?>
