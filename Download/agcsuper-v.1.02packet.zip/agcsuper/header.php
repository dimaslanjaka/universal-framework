<?php if (is_search()) : ob_start(); endif ?>
<!DOCTYPE html>
<!--[if IE 7]><html class="ie7 no-js" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml" <?php language_attributes(); ?><![endif]-->
<!--[if lte IE 8]><html class="ie8 no-js" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml" <?php language_attributes(); ?><![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="not-ie no-js" xmlns:og="http://opengraphprotocol.org/schema/" xmlns:fb="http://www.facebook.com/2008/fbml" <?php language_attributes(); ?>><!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width" />
<title><?php 	
	global $page, $paged;
	wp_title( '|', true, 'right' );
	bloginfo( 'name' );
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', ktz_theme_textdomain ), max( $paged, $page ) );
	?></title>	
<?php hook_ktz_head();	echo get_theme_option("ktz_head") . "\n";  wp_head(); ?>
</head>
<body <?php body_class(); ?> id="top">
	<div class="allwrap head">
	<div class="inner-responsive">
	<header class="mainheader">
		<div class="container">
			<div class="row rowhead clearfix">
			<div class="span4 pull-left">
			<?php hook_ktz_header(); //Kentooz_hook_system ?>
			</div>
			<div class="span8 clearfix">
				<div class="clearfix">
					<?php hook_do_ktz_header_sn();  //Kentooz_hook_system ?>
				</div>
				<div class="pull-right">
					<?php hook_do_ktz_topsearch();  //Kentooz_hook_system ?>
				</div>
			</div>
			</div>
		</div>	
	</header>
	<nav class="mainmenu">
		<div class="container">
			<?php hook_ktz_menu_header(); //Kentooz_hook_system ?>
		</div>	
	</nav>
	</div>
	<div class="bgstripes">
		<span class="bgstripe color1"></span>
		<span class="bgstripe color2"></span>
		<span class="bgstripe color3"></span>
		<span class="bgstripe color4"></span>
		<span class="bgstripe color5"></span>
		<span class="bgstripe color6"></span>
		<span class="bgstripe color7"></span>
		<span class="bgstripe color8"></span>
		<span class="bgstripe color9"></span>
		<span class="bgstripe color10"></span>
		<span class="bgstripe color11"></span>
		<span class="bgstripe color12"></span>
		<span class="bgstripe color13"></span>
		<span class="bgstripe color14"></span>
		<span class="bgstripe color15"></span>
		<span class="bgstripe color16"></span>
		<span class="bgstripe color17"></span>
		<span class="bgstripe color18"></span>
		<span class="bgstripe color19"></span>
		<span class="bgstripe color20"></span>
	</div>
	</div>
	
	<div class="allwrap body">
	<div class="inner-responsive">
	<div id="main">
		<div class="container">
		<?php echo ktz_ban72890_mainhead(); ?>
		<?php if (is_home() || is_front_page()) { ?>
			<?php echo '' ?>
		<?php } else { ?>
			<?php hook_ktz_after_header(); //Kentooz_hook_system ?>
		<?php } ?>
		</div>	
	</div>
		<div class="container">
			<div class="row">