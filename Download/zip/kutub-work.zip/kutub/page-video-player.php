<?php /**
 * Template Name: Player Page
 * Description: Halaman / Page video player
 *
 * @package kutub themes
 * @oleh Kang Iwan, Majalengka
 */
?>
<?php
$video_id	= ( isset( $_GET['vid'] ) ) ? $_GET['vid'] : 'EIsauUFIguE';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://www.googleapis.com/youtube/v3/videos?id='.$video_id.'&key='.$api_key.'&part=snippet,contentDetails,statistics,status');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: application/json"));
$response = curl_exec($ch);
curl_close($ch);
$datane     = json_decode($response, true);

error_reporting(E_ERROR | E_PARSE);
foreach ($datane['items'] as $data_vid) {

$idvideo    = $data_vid['id'];

$titley     = $data_vid['snippet']['title'];
$titlenp    = besarkan(hilangkeun(kecilkan_bsc($titley)));
$titlena    = preg_replace("/[[:blank:]]+/"," ",$titlenp);

$vpub       = $data_vid['snippet']['publishedAt'];
$vpubc      = date('j F Y', strtotime($vpub));

$vdesc      = $data_vid['snippet']['description'];
$vchan      = $data_vid['snippet']['channelTitle'];
$vdura      = $data_vid['contentDetails']['duration'];
$vview      = $data_vid['statistics']['viewCount'];
$vviewn     = number_format($vview);
$vlike      = $data_vid['statistics']['likeCount'];
$vliken     = number_format($vlike);
$vdlike     = $data_vid['statistics']['dislikeCount'];
$vdliken    = number_format($vdlike);

$vthumm     = $data_vid['snippet']['thumbnails']['medium']['url'];
$vthumh     = $data_vid['snippet']['thumbnails']['high']['url'];
$vthums     = $data_vid['snippet']['thumbnails']['standard']['url'];
$vthumx     = $data_vid['snippet']['thumbnails']['maxres']['url'];
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Streaming <?php echo $titlena;?></title>
<meta name="robots" content="NOINDEX,NOFOLLOW,NOARCHIVE,NOODP,NOYDIR">
<link href="<?php bloginfo('template_directory'); ?>/player/css/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/player/jwplayer.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/player/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/player/js/jquery.1.4.2.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/player/js/jquery.lint.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/player/js/Myriad_Pro_400-Myriad_Pro_700-Myriad_Pro_italic_400-Myriad_Pro_italic_700.font.js"></script>
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/favicon.ico" type="image/x-icon" />
<?php wp_head(); ?>
</head>
<body>
<!-- Wrapper -->
<div id="wrapper_sec">
    <!-- Banner -->
    <div id="banner">
    	<div id="slider2" class="leftsecbanner">
            <div class="contentdiv">
            <div style="width:721px;height:20px;margin:0px; padding:0px;overflow: hidden;"><div style="width:20px;float:left;margin:0px; padding-top:1px;"><img src="<?php bloginfo('template_directory'); ?>/player/images/loader.gif" width="14"></div><div style="width:680px;float:left;margin:0px; padding:0px;"><font size="3"><?php echo $titlena;?></font></div></div>
	<div id="player">
	<div id="video">Loading the player ...</div>
<script type="text/javascript">
  jwplayer('video').setup({
    'flashplayer': '<?php bloginfo('template_directory'); ?>/player/player.swf',
    'width': '728',
    'height': '400',
    'file': 'http://www.youtube.com/watch?v=<?php echo $idvideo;?>',
    'skin': '<?php bloginfo('template_directory'); ?>/player/lightrv5.zip',
    'autoplay':'true',
    'repeat':'always'
  });
</script>
</div>
	</div><!-- player -->

            </div>

        </div>

    <div class="clear"></div>
	
	    <!-- Content Section -->
    <div id="content_sec">
  	<center>     <!-- Banner ads below -->

    </center>

	<!-- Column 1 -->
        <div class="col1">
        	<!-- Featured Playlist -->
        	<div class="featured_playlist">
            	<h3 class="heading">You are watching <?php echo $titlena;?></h3>
                <p>This video has been watched up to <?php echo $vviewn; ?> times since its uploaded on <?php echo $vpubc; ?> by <?php echo $vchan; ?>. Thanks for watching <?php echo $titlena;?><p>

            </div>
         </div>
</div>
<div id="copyrights">
	<div class="inner">
    	<p>Copyright &copy; <?php echo date('Y'); ?> <a href="<?php echo get_option('home'); ?>/" alt="<?php bloginfo('name'); ?>" ><?php bloginfo('name'); ?></a>. All rights reserved.</p>
        <div class="designdby">
        	<p></p>
        </div>
    </div>
	</div>
<!-- wrapper -->
</div>
<div class="clear"></div>
<!-- Footer -->
</div>
<?php wp_footer(); ?> 
</body>
</html>