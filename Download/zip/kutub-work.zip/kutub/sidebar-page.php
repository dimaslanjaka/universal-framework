<div class="sidebar" data-iceapc="59" data-iceapw="57">

<div class="menu-box" data-iceapw="20" data-iceapc="21">
<h4>Random Posts</h4>
<ul data-iceapw="20" data-iceapc="20">
<?php
 $rand_posts = get_posts('numberposts=10&orderby=rand'); //angka 10 = jumlah postingan yang mau ditampilkan
 foreach( $rand_posts as $post ) :
 setup_postdata($post);
 ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>
</div>
</ul>
</div>

</div>