<?php
$keywod 	= besarwal(hilangkeun(kecilkan_bsc(get_search_query())));
if($_GET['s']!=''){
$ganti = array('+',' '); //tanda plus dan spasi
$urlredirect = get_settings('home') .'/'."$nama".''."$tanda".''. str_replace($ganti, '-' ,$_GET['s']). ''."$akhir".''; //tanda plus dan spasi jadi minus
header("HTTP/1.1 301 Moved Permanently");
header( "Location: $urlredirect" );
}

$fulltitle  = $keywod;
$pdektitle 	= wp_trim_words(cleankw(hilangkeun(kecilkan_bsc($fulltitle))), $num_words = 4, $more = '' );

// Json Parsing
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://www.googleapis.com/youtube/v3/search?q='.urlencode($pdektitle).'&key='.$api_key.'&part=snippet&maxResults='.$vidcount.'&order=relevance&videoDuration=any&type=video');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: application/json"));
$response = curl_exec($ch);
curl_close($ch);
$datane		= json_decode($response, true);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<head profile="http://gmpg.org/xfn/11">
<title><?php echo $keywod; ?></title>
<meta name="description" content="Here are <?php echo $keywod; ?> videos streaming online" />
<meta name="keywords" content="<?php echo $keywod; ?>" />
<link href="<?php bloginfo('template_directory'); ?>/style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/favicon.ico" type="image/x-icon" />
<?php wp_head(); ?>
</head>

<body>
<div id="all">
<div class="header">
<table width="839" cellpadding="5" cellspacing="0" data-iceapc="10"><tbody data-iceapc="9"><tr data-iceapc="8"><td width="190">
<a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>"><img border="0" src="<?php bloginfo('template_directory'); ?>/images/brand.png" width="190px" height="60px"></a></td>
<td align="right" data-iceapc="6">
<?php include('searchform.php'); ?></td></tr>
</tbody></table>
</div>

<div id="menu">
	<ul class="navbar">
		<?php include('link-head.php'); ?>
	</ul>
</div>

<div id="container">
<div class="post">
<h1 style="margin:5px 5px 5px 1px;"><?php echo $keywod; ?></h1>
<div class="entry">

<div style="margin:0 0 10px 15px;">
<p>Below are videos of <strong><?php echo $keywod; ?></strong>, you are able to watch the video by hitting "Play Video" button. Streaming <i><?php echo $keywod; ?></i> online here. </p>
</div>

<?php
error_reporting(E_ERROR | E_PARSE);
foreach ($datane['items'] as $datayt) {

$video_kode		= $datayt['id']['videoId'];
$titley			= $datayt['snippet']['title'];
$titlena		= besarkan(hilangkeun(kecilkan_bsc($titley)));

$data_ytpub		= $datayt['snippet']['publishedAt'];
$data_ytpubb	= date('Y-m-d', strtotime($data_ytpub));
$data_ytpubc	= date('F j, Y', strtotime($data_ytpub));
$data_ytdesc	= $datayt['snippet']['description']; 
$data_ytthumm	= $datayt['snippet']['thumbnails']['medium']['url'];
$data_ytthumh	= $datayt['snippet']['thumbnails']['high']['url'];
$data_ytchan	= $datayt['snippet']['channelTitle'];
$gbr2 			= 'http://i.ytimg.com/vi/'.$video_kode.'/2.jpg';
?>

<div class="coloma left">
<div class="colomb left"><a id="titlecolo" title="<?php echo $titlena;?>" href="<?php echo get_settings('home'); ?>/<?php echo $nama ?><?php echo $tanda ?><?php echo ganti_url(wp_trim_words(kecilkan($titlena), $num_words = 12, $more = '' )); ?><?php echo $akhir ?>"><?php echo wp_trim_words($titley, $num_words = 10, $more = '' );?></a></div>

<div class="colomc">
<img src="<?php echo $gbr2;?>" alt="<?php echo wp_trim_words($titlena, $num_words = 10, $more = '' );?>" title="<?php echo wp_trim_words($titlena, $num_words = 10, $more = '' );?>" width="107px" height="77px"/>
</div>

<div class="colomd right">This video of <?php echo $titlena; ?> was uploaded by <?php echo $data_ytchan; ?> on <?php echo $data_ytpubc; ?>.</div>

<div style="float:right; text-align:left; padding: 0 3px; width:370px;margin-bottom: 3px; ">
<a id="sbutton" target="_blank" rel="nofollow" href="<?php echo bloginfo('home') ?>/<?php echo $page_player;?>?vid=<?php echo yt_url($video_kode); ?>" title="<?php echo $titlena;?>">Play Video</a>
</div>

</div>

<?php
}
?>
<div style="clear:both"></div>
</div>
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>