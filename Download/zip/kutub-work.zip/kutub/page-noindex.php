<?php /**
 * Template Name: Page NoIndex
 * Description: Halaman / Page yang dibuat no index
 *
 * @package kutub themes
 * @oleh Kang Iwan, Majalengka
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' - '; } ?><?php bloginfo('name'); ?></title>
<meta name="robots" content="NOINDEX,NOFOLLOW,NOARCHIVE,NOODP,NOYDIR"/>
<link href="<?php bloginfo('template_directory'); ?>/style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/favicon.ico" type="image/x-icon" />
<?php wp_head(); ?>
</head>

<body>
<div id="all">
<div class="header">
<table width="839" cellpadding="5" cellspacing="0" data-iceapc="10"><tbody data-iceapc="9"><tr data-iceapc="8"><td width="190">
<a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>"><img border="0" src="<?php bloginfo('template_directory'); ?>/images/brand.png" width="190px" height="60px"></a></td>
<td align="right" data-iceapc="6">
<?php include('searchform.php'); ?></td></tr>
</tbody></table>
</div>

<div id="menu">
	<ul class="navbar">
		<?php include('link-head.php'); ?>
	</ul>
</div>

<div id="container">
<div class="post">

<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>

<h1 style="margin:5px 5px 5px 1px;"><?php the_title(); ?></h1>
<div class="entry">
	<?php the_content(''); ?>
</div>			
	<?php endwhile; ?>

	<?php endif; ?>
<div style="clear:both"></div>
</div>
</div>
<?php include (TEMPLATEPATH . '/sidebar-page.php'); ?>
<?php get_footer(); ?>