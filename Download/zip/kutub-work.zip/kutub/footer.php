<div style="clear:both"></div>

<div id="footer">
<h5 class="lighter"> Copyright &copy; <?php _e(date('Y')); ?> <a href="<?php echo get_option('home'); ?>/" alt="<?php bloginfo('name'); ?>" ><?php bloginfo('name'); ?></a><br>
Disclaimer : All contents are copyrighted and owned by their respected owners. <?php echo get_option('home'); ?> does not upload or host any video files on our server. <?php echo get_option('home'); ?> only links to user submitted websites and is not responsible for third party website content. It is illegal for you to distribute copyrighted files without permission.<br>
All content posted by our users is <a rel="license" href="http://creativecommons.org/publicdomain/zero/1.0/" target="_blank" style="font-weight: normal;">dedicated to the public domain</a>.</h5>
</div>

<?php wp_footer(); ?> 

</body>
</html>