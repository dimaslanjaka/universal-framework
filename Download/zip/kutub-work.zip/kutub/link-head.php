<li><a href="<?php echo get_option('home'); ?>/" title="<?php bloginfo('name'); ?>" >Home</a></li>
<li><a href="<?php echo get_option('home'); ?>/#">About</a></li>
<li><a href="<?php echo get_option('home'); ?>/#">Contact Us</a></li>