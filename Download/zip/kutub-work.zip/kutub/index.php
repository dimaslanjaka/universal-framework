<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<head profile="http://gmpg.org/xfn/11">
<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' - '; } ?><?php bloginfo('name'); ?></title>
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="Revisit-After" content="1 day"/>
<meta name="page-type" content="Search Engine"/>
<meta name="audience" content="global"/>
<meta name="publisher" content="<?php echo bloginfo( 'name' ); ?>"/>
<meta name="language" content="en"/>
<meta name="expires" content="never"/>
<link href="<?php bloginfo('template_directory'); ?>/style.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/favicon.ico" type="image/x-icon" />
<?php wp_head(); ?>
</head>

<body>
<div id="all">
<div class="header">
<center><a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>"><img border="0" src="<?php bloginfo('template_directory'); ?>/images/brand.png" width="190px" height="60px"></a></center>
</div>

<div id="menu">
	<ul class="navbar">
		<?php include('link-head.php'); ?>
	</ul>
</div>

<center>
<div style="display:block;height:15px;"></div>
<table cellpadding="0" cellspacing="4" bgcolor="#3b3b3d" data-iceapc="5"><tbody data-iceapc="4"><tr data-iceapc="3"><form method="get" action="<?php bloginfo('url'); ?>/"><td data-iceapc="1">
<input type="text" name="s" value="" size="34" style="font:normal 19px tahoma;color:#333;border:1px solid #68686b;background-color:#ddd;width:520px;" onkeypress="return disableEnterKey(event)">
</td><td><input type="submit" name="search" id="submit" value="SEARCH" style="border:1px solid #68686b;height:34px;width:115px;background-color:#6dc444;font-weight:bold;color:#fff;" onmousedown="disableElements()">
</td></form></tr></tbody></table>

</center>

<div style="clear:both"></div>

<div style="text-align:center;display:block;margin: 10px 0 10px 25px; ">

<?php

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,'https://www.googleapis.com/youtube/v3/search?q='.urlencode($keywordhome).'&key='.$api_key.'&part=snippet&maxResults='.$vidcounthome.'&order=relevance&videoDuration=any&type=video');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Accept: application/json"));
$response = curl_exec($ch);
curl_close($ch);
$datane		= json_decode($response, true);

error_reporting(E_ERROR | E_PARSE);

foreach ($datane['items'] as $datayt) {

$video_kode		= $datayt['id']['videoId'];
$titley			= $datayt['snippet']['title'];
$titlena		= besarkan(hilangkeun(kecilkan_bsc($titley)));
$title			= preg_replace("/[[:blank:]]+/"," ",kecilkan($titlena));
$image 			= 'http://i.ytimg.com/vi/'.$video_kode.'/2.jpg';
?>
<div style="float:left; width:165px; height: 170px; overflow:hidden;margin-top: 5px; padding-right:5px;">
<div style="float:left;"><a href="<?php echo bloginfo('home') ?>/<?php echo $nama ?><?php echo $tanda ?><?php echo ganti_url(wp_trim_words($title, $num_words = 12, $more = '' )); ?><?php echo $akhir ?>" target="_blank"><img src="<?php echo $image; ?>" width="165px" height="135px"/></a></div>
<div style="float:left; text-align:left; font-weight:bold;"><a href="<?php echo bloginfo('home') ?>/<?php echo $nama ?><?php echo $tanda ?><?php echo ganti_url(wp_trim_words($title, $num_words = 12, $more = '' )); ?><?php echo $akhir ?>" target="_blank"><?php echo wp_trim_words($titlena, $num_words = 7, $more = '' ); ?></a></div>
</div>

<?php
}
?>
<div style="clear:both"></div>
</div>

<div id="footer">
<h5 class="lighter"> Copyright &copy; <?php _e(date('Y')); ?> <a href="<?php echo get_option('home'); ?>/" alt="<?php bloginfo('name'); ?>" ><?php bloginfo('name'); ?></a><br>
Disclaimer : All contents are copyrighted and owned by their respected owners. <?php echo get_option('home'); ?> does not upload or host any video files on our server. <?php echo get_option('home'); ?> only links to user submitted websites and is not responsible for third party website content. It is illegal for you to distribute copyrighted files without permission.<br>
All content posted by our users is <a rel="license" href="http://creativecommons.org/publicdomain/zero/1.0/" target="_blank" style="font-weight: normal;">dedicated to the public domain</a>.</h5>
</div>

<?php wp_footer(); ?> 
</body>
</html> 