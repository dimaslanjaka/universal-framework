<table cellpadding="0" cellspacing="4" bgcolor="#3b3b3d" data-iceapc="5"><tbody data-iceapc="4"><tr data-iceapc="3">
<form method="get" action="<?php bloginfo('url'); ?>/">
<td data-iceapc="1"><input type="text" name="s" value="" size="34" style="font:normal 19px tahoma;color:#333;border:1px solid #68686b;background-color:#ddd;width:480px;"></td>
<td><input type="submit" name="search" id="submit" value="SEARCH" style="border:1px solid #68686b;height:34px;width:115px;background-color:#6dc444;font-weight:bold;color:#fff;"></td>
</form>
</tr></tbody></table>