<?php 
/**
 * Template untuk Page.php normal, misal untuk privacy, dll.
 *
 * @ dibuat oleh Kang Iwan, Majalengka
 */
 get_header(); ?>

<div id="container" data-iceapc="399" data-iceapw="290">
<div class="post" data-iceapc="397" data-iceapw="290">

<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>

<h1 style="margin:5px 5px 5px 15px;"><?php the_title(); ?></h1>
<div class="entry" data-iceapc="396" data-iceapw="290">

	<?php the_content(''); ?>
</div>			
	<?php endwhile; ?>

	<?php endif; ?>
<div style="clear:both"></div>
</div>
</div>
<?php include (TEMPLATEPATH . '/sidebar-page.php'); ?>
<?php get_footer(); ?>