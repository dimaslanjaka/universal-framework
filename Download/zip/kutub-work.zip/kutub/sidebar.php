<div class="sidebar" data-iceapc="59" data-iceapw="57">

<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar") ) : ?>
<?php endif; ?>

<div class="menu-box" data-iceapw="20" data-iceapc="21">
<h4>Random Posts</h4>
<ul data-iceapw="20" data-iceapc="20">
<?php
 $rand_posts = get_posts('numberposts=10&orderby=rand'); //angka 10 = jumlah postingan yang mau ditampilkan
 foreach( $rand_posts as $post ) :
 setup_postdata($post);
 ?>
<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
<?php endforeach; ?>
</ul>
</div>

</div>