<?php
$homepage = file_get_contents('$url');
preg_match('/(About )?([\d,]+) result/si', $homepage, $p) ;
echo $p[0];
?>