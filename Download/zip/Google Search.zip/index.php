<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Audiowide' rel='stylesheet'>
<style>
html, body {
    margin: 0;
    height: 100%;
}
body {
    font-family: 'Audiowide';font-size: 14px;
}
</style>
<title>Google Search Parser | By L3n4r0x</title>
</head>
 
<!-- body style="margin-left:100px;" -->
<body>
<center>
<label>L3n4r0x Google Search:</label><br/><small color="green">input keywords or dork for hacking</small>
<form method="get" action="">
<input name="results" />
<input type="submit" />
</form>

 <?php
error_reporting(0);
$search = $_GET['results'];
if(isset($_GET['results']) && $_GET['results'] != "")

$url  = "http://www.google.com/search?hl=en&safe=active&tbo=d&site=&source=hp&"
		. "q=".str_replace(' ', '+', $_GET['results']);

require_once('simple_html_dom.php');

$html = file_get_html($url);

$linkObjs = $html->find('h3.r a');
foreach ($linkObjs as $linkObj) {
    $title = trim($linkObj->plaintext);
    $link  = trim($linkObj->href);
    
    // if it is not a direct link but url reference found inside it, then extract
    if (!preg_match('/^https?/', $link) && preg_match('/q=(.+)&amp;sa=/U', $link, $matches) && preg_match('/^https?/', $matches[1])) {
        $link = $matches[1];
    } else if (!preg_match('/^https?/', $link)) { // skip if it is not a valid link
        continue;    
    }
    
    echo '<p>Title: ' . $title . '<br />';
    echo 'Link: ' . $link . '</p>';
}
?>
 

</body>
</html>