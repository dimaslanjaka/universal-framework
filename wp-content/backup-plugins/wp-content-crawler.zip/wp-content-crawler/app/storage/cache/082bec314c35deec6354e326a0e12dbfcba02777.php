<div class="wrap container-general-settings">

    <?php if(isset($_GET["success"])): ?>
        <?php echo $__env->make('partials/alert', [
            'type'      =>  $_GET["success"] == 'true' ? 'success' : 'error',
            'message'   =>  $_GET["success"] == 'true' ?
                            _wpcc("Settings updated.") :
                            (isset($_GET["message"]) && $_GET["message"] ? $_GET["message"] : _wpcc("An error occurred."))
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php endif; ?>

    <h1><?php echo e(_wpcc('General Settings')); ?></h1>
    <form action="admin-post.php" method="post" id="post">
        
        

        

        
        <?php echo $__env->make('partials.form-nonce-and-action', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo $__env->make('general-settings/button-container', ['class' => 'top right'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        
        <div class="details">
            <div class="inside">
                <div class="panel-wrap wcc-settings-meta-box">

                    <?php echo $__env->make('partials/form-error-alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo $__env->make('general-settings/settings', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div>
            </div>
        </div>

        <?php echo $__env->make('general-settings/button-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </form>
</div>