

<?php if(!isset($noNonceAndAction) || !$noNonceAndAction): ?>
    <?php echo wp_nonce_field($pageActionKey, \WPCCrawler\Constants::$NONCE_NAME); ?>


    <input type="hidden" name="action" value="<?php echo e($pageActionKey); ?>" id="hiddenaction">
<?php endif; ?>