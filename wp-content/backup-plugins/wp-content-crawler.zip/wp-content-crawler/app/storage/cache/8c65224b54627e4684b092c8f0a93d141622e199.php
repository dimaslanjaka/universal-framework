<?php $__env->startSection('content-class'); ?> whats-happening <?php $__env->stopSection(true); ?>
<?php $__env->startSection('header'); ?> <?php $__env->stopSection(true); ?>

<?php $__env->startSection('title'); ?>
    <?php echo e(_wpcc("What's happening")); ?>

<?php $__env->stopSection(true); ?>

<?php $__env->startSection('content'); ?>
    <?php $now = strtotime(current_time('mysql')); ?>

    
    <h3><?php echo e(_wpcc("CRON Events")); ?> <span>(<?php echo e(sprintf(_wpcc('Now: %1$s'), \WPCCrawler\Utils::getDateFormatted(current_time('mysql')))); ?>)</span></h3>
    <table class="detail-card orange">
        <thead>
            <tr>
                <?php
                    $tableHeadValues = [
                        _wpcc("URL Collection") => \WPCCrawler\Factory::schedulingService()->eventCollectUrls,
                        _wpcc("Post Crawl")     => \WPCCrawler\Factory::schedulingService()->eventCrawlPost,
                        _wpcc("Post Recrawl")   => \WPCCrawler\Factory::schedulingService()->eventRecrawlPost,
                        _wpcc("Post Delete")    => \WPCCrawler\Factory::schedulingService()->eventDeletePosts,
                    ];
                ?>
                <th></th>
                <?php $__currentLoopData = $tableHeadValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $eventKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th>
                        <?php echo e($name); ?>

                        <div class="interval-description"><?php echo e($dashboard->getCronEventIntervalDescription($eventKey)); ?></div>
                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <tr>
                <?php
                    $nextEventDates = [
                        [$dashboard->getNextUrlCollectionDate(),    $dashboard->getNextUrlCollectionSite()],
                        [$dashboard->getNextPostCrawlDate(),        $dashboard->getNextPostCrawlSite()],
                        [$dashboard->getNextPostRecrawlDate(),      $dashboard->getNextPostRecrawlSite()],
                        [$dashboard->getNextPostDeleteDate(),       $dashboard->getNextPostDeleteSite()],
                    ];
                ?>
                <td><?php echo e(_wpcc("Next")); ?></td>

                <?php $__currentLoopData = $nextEventDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $timestamp = strtotime($v[0]); ?>
                    <td>
                        <div class="diff-for-humans">
                            <?php echo e(\WPCCrawler\Utils::getDiffForHumans(strtotime($v[0]))); ?>

                            <?php echo e($timestamp > $now ? _wpcc("later") : _wpcc("ago")); ?>

                        </div>
                        <span class="date">(<?php echo e(\WPCCrawler\Utils::getDateFormatted($v[0])); ?>)</span>
                        <?php if($v[1]): ?>
                            <div class="next-site">
                                <?php echo $__env->make('dashboard.partials.site-link', ['site' => $v[1]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        <?php endif; ?>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <td><?php echo e(_wpcc("Last")); ?></td>
                <?php
                    $lastEventDates = [
                        $dashboard->getLastUrlCollectionDate(),
                        $dashboard->getLastPostCrawlDate(),
                        $dashboard->getLastPostRecrawlDate(),
                        $dashboard->getLastPostDeleteDate(),
                    ];
                ?>
                <?php $__currentLoopData = $lastEventDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><div class="diff-for-humans"><?php echo sprintf(_wpcc("%s ago"), \WPCCrawler\Utils::getDiffForHumans(strtotime($d))); ?></div> <span class="date">(<?php echo e(\WPCCrawler\Utils::getDateFormatted($d)); ?>)</span> </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </tbody>
    </table>

    
    <h3><?php echo e(_wpcc("Counts")); ?></h3>
    <table class="detail-card counts teal">
        <thead>
            <tr>
                <th></th>
                <th><?php echo e(_wpcc("URLs in Queue")); ?></th>
                <th><?php echo e(_wpcc("Saved Posts")); ?></th>
                <th><?php echo e(_wpcc("Updated Posts")); ?></th>
                <th><?php echo e(_wpcc("Deleted Posts")); ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e(_wpcc("Today")); ?></td>
                <td><?php echo e($dashboard->getTotalUrlsInQueueAddedToday()); ?></td>
                <td><?php echo e($dashboard->getTotalSavedPostsToday()); ?></td>
                <td><?php echo e($dashboard->getTotalRecrawledPostsToday()); ?></td>
                <td><?php echo e($dashboard->getTotalDeletedPostsToday()); ?></td>
            </tr>
            <tr>
                <td><?php echo e(_wpcc("All")); ?></td>
                <td><?php echo e($dashboard->getTotalUrlsInQueue()); ?></td>
                <td><?php echo e($dashboard->getTotalSavedPosts()); ?></td>
                <td><?php echo e($dashboard->getTotalRecrawledPosts()); ?></td>
                <td><?php echo e($dashboard->getTotalDeletedPosts()); ?></td>
            </tr>
        </tbody>
    </table>

    
    <?php if($dashboard->getUrlsCurrentlyBeingCrawled()): ?>
        <h3><?php echo e(_wpcc("URLs being crawled right now")); ?></h3>
        <?php echo $__env->make('dashboard.partials.table-urls', [
            'urls'          => $dashboard->getUrlsCurrentlyBeingCrawled(),
            'tableClass'    => 'detail-card green',
            'dateColumnName' => _wpcc('Created'),
            'fieldName' => 'created_at',
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php endif; ?>

    
    <?php if($dashboard->getPostsCurrentlyBeingSaved()): ?>
        <h3><?php echo e(_wpcc("Posts being saved right now")); ?></h3>
        <?php echo $__env->make('dashboard.partials.table-posts', [
            'posts'         => $dashboard->getPostsCurrentlyBeingSaved(),
            'tableClass'    => 'detail-card green'
        ], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php endif; ?>

<?php $__env->stopSection(true); ?>
<?php echo $__env->make('dashboard.partials.section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>