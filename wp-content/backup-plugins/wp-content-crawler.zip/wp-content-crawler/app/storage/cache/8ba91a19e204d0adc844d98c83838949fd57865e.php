<div class="input-group">
    <div class="input-container input-container-passwords">
        <input type="password" name="<?php echo e($name . '_old'); ?>" id="<?php echo e($name . '_old'); ?>" placeholder="<?php echo e(_wpcc('Old password')); ?>">
        <input type="password" name="<?php echo e($name); ?>" id="<?php echo e($name); ?>" placeholder="<?php echo e(_wpcc('New password')); ?>">
        <input type="password" name="<?php echo e($name . '_validation'); ?>" id="<?php echo e($name . '_validation'); ?>" placeholder="<?php echo e(_wpcc('New password again')); ?>">
    </div>
</div>