<div id="wcc-alert" class="notice notice-error hidden">
    <p><?php echo e(_wpcc('Please fix the errors.')); ?></p>
</div>