<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 10/01/17
 * Time: 13:28
 */

namespace WPCCrawler\objects\crawling;


class DummyBot extends AbstractBot {

}