<div class="button-container {{ isset($class) ? $class : '' }}">
    <button class="button button-primary button-large" id="submit">{{ _wpcc('Save Changes') }}</button>
</div>