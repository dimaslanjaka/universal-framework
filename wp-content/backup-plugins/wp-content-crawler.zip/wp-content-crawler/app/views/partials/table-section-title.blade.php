<tr>
    <td colspan="2">
        <h4 class="section-title">{!! $title !!}</h4>
    </td>
</tr>