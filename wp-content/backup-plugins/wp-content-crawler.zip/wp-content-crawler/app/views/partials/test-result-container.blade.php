<div class="test-results hidden">
    <button class="button hide-test-results">{{ _wpcc('Hide') }}</button>
    <div class="content"></div>
    <button class="button hide-test-results">{{ _wpcc('Hide') }}</button>
</div>