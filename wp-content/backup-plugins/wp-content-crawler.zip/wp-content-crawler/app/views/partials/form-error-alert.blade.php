<div id="wcc-alert" class="notice notice-error hidden">
    <p>{{ _wpcc('Please fix the errors.') }}</p>
</div>