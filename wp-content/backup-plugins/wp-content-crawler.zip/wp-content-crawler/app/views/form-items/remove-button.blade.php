<button class="button wcc-remove"><span class="dashicons dashicons-trash"></span></button>

@if(!isset($disableSort) || !$disableSort)
    <div class="wcc-sort"><span class="dashicons dashicons-move"></span></div>
@endif