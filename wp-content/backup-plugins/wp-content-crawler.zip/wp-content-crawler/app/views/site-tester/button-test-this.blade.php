<button class="button test-this"
        data-url="{{ $url }}"
        data-type="{{ $type }}"
        title="{{ _wpcc('Test this URL') }}">
    <span class="dashicons dashicons-search"></span>
</button>