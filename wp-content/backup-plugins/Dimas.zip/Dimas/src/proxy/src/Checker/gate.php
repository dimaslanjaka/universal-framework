<?php
/**
 * PHPProxyChecker gate.
 * @author Stanislav Afanasiev <stas.progger[at]gmail.com>
 * @created 15.12.2010
 * @version 1.0
 */
    echo(serialize($_SERVER)).'<br>';
    echo(serialize($_GET)).'<br>';
    echo(serialize($_POST)).'<br>';
