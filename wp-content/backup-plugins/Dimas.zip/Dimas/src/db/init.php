<?php

include plugin_dir_path(__FILE__) . 'agc.php';
