# __unset

```php
__unset ( string $name )
```

Removes the attribute with name `$name` from the current node if it exists.