<?php

class dimas_google extends dimas_user
{
  function __construct($O = null)
  {
    parent::__construct($O);
  }
}
