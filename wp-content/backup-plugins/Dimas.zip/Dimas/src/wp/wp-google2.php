<?php

class wpgoogle extends dimas_google
{
  public $token;
  public $token_file;
  public $callback;
  public $redirect;
  public $auth_code;
  public $user;
  public $gtoken;
  public static $email;
  public $client;
  public $tokenfile;
  public static $sclient;
  public $scopes;
  public $auth_state;
  public $auth_request;

  public function __construct($conf = [])
  {
    $this->auth_state = isset($_GET['state']) ? trim($_GET['state']) : (isset($_GET['session_state']) ? trim($_GET['session_state']) : false);
    $this->auth_request = isset($_GET['code']) && $this->auth_state && isses('tokenState');
    if (class_exists('Google_Client')) {
      $gClient = new Google_Client();
      $gClient->setApplicationName('Login to ' . WP_HOST);
      $gClient->setDeveloperKey(GOOGLE_CLIENT_KEY);
      $gClient->setClientId(GOOGLE_CLIENT_ID);
      $gClient->setClientSecret(GOOGLE_CLIENT_SECRET);
      $scope = $this->google_scopes('default');
      $gClient->setScopes($scope);
      $gClient->setApprovalPrompt('force');
      $gClient->setAccessType('offline');
      $gClient->logged_in = false;
      $dr = [];
      if (isset($conf['redirect_uri'])) {
        $redirect = $conf['redirect_uri'];
        $dr[__LINE__] = $redirect;
      } elseif (isses('redirect_uri')) {
        $redirect = isses('redirect_uri');
        $dr[__LINE__] = $redirect;
      } else {
        $redirect = GOOGLE_REDIRECT_URL;
        $dr[__LINE__] = $redirect;
      }

      $this->client = $gClient;
      $this->google_redir($redirect);
      $this->setTokenFile();
      $this->google_process_token();
      if (($this->islogin() || isset($_REQUEST['logout'])) && !iscookie('savedToken')) {
        $this->deleteFile($this->defaultToken(false));
        $this->deleteFile(ROOT . '/assets/config/token/' . md5($_SERVER['HTTP_USER_AGENT']) . '.json');
        $this->deleteFile(ROOT . '/assets/config/token/' . iscookie('ip') . '.json');
        if (isses('token')) {
          _file_($this->token_file, $this->token, true);
        }
        cook('savedToken', 1, 3600);
      }
    }
    parent::__construct($conf);
  }
  /**
   * Delete file if exists
   */
  public function deleteFile($path)
  {
    if (file_exists($path)) {
      unlink($path);
    }
  }

  public function properties()
  {
    return $this->getMethodClass(__CLASS__);
  }

  public function google_redir($redirect)
  {
    $gClient = $this->client;
    $redirect = str_replace([ROOT, '/views'], '', $redirect);
    $redirect = $this->fix_slash($redirect);
    $this->redirect = $redirect;
    $gClient->setRedirectUri($redirect);
  }

  public function google_process_token()
  {
    /**
     * @var Google_Client $gClient
     */
    $gClient = $this->google_auth();

    if (!$gClient->getAccessToken()) {
      $accessToken = $this->get_token($gClient);
      if (!$accessToken && !$this->auth_request) {
        if (file_exists($this->token_file)) {
          $accessToken = json_decode(file_get_contents($this->token_file));
        }
      }

      if (!empty($accessToken)) {
        $gClient->setAccessToken((array) $accessToken);
      }
    }

    if ($gClient->getAccessToken()) {
      unses('tokenState');
      $gClient->logged_in = true;
      /*
       * if token is expired
       */
      if ($gClient->isAccessTokenExpired()) {
        $gClient->fetchAccessTokenWithRefreshToken($gClient->getRefreshToken());
        $_SESSION['token'] = $gClient->getAccessToken();
      }
      /*
       * if token is valid
       */
      if (!$gClient->isAccessTokenExpired()) {
        if (!$this->isSubsribed()) {
          check_subscriber($gClient);
        }
        if (!is_user_logged_in() || isreq('re-login')) {
          $this->wp_login();
        }
      }
      /*
       * update token when auth request initiated
       */
      if ($this->auth_request) {
        $this->update_token($gClient);
      }

      if (isset($_SESSION['token']) && !empty($_SESSION['token']) && !headers_sent()) {
        if (!headers_sent()) {
          setcookie('token', json_encode($_SESSION['token']), time() + 60 * 60 * 24 * 1);
        }
      }

      if (is_user_logged_in() && $this->client->getAccessToken()) {
        $this->fetch_google_user();
        $this->setBlogger();
        $this->token = $this->client->getAccessToken();
      }
    }
  }

  public function google_scopes(...$type)
  {
    $scope = [
      'https://www.googleapis.com/auth/youtube.readonly',
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/userinfo.profile',
    ];

    foreach ($type as $sc) {
      switch ($sc) {
        case 'drive':
          $scope[] = 'https://www.googleapis.com/auth/drive';
          break;
        case 'blogger':
          $scope[] = 'https://www.googleapis.com/auth/blogger';
          $scope[] = 'https://www.googleapis.com/auth/blogger.readonly';
          break;
        case 'analystic':
          $scope[] = 'https://www.googleapis.com/auth/analytics.readonly';
          break;

        default:
          if ((isLocalhost() || $this->isAdmin()) && 'default' == $type[0]) {
            $scope[] = 'https://www.googleapis.com/auth/drive';
            $scope[] = 'https://www.googleapis.com/auth/youtube';
            $scope[] = 'https://www.googleapis.com/auth/youtube.force-ssl';
          }
          break;
      }
    }
    $scope = array_values(array_unique($scope));
    $this->scopes = $scope;

    return $scope;
  }

  public function google_auth()
  {
    $gClient = $this->client;
    if ($this->auth_request) {
      $gClient->authenticate($_GET['code']);
      $gClient->fetchAccessTokenWithAuthCode($_GET['code']);
      if ($gClient->getAccessToken()) {
        $gClient->setAccessToken($gClient->getAccessToken());
        $this->update_token($gClient);
      }
      unses('tokenState');
    } else {
      $_SESSION['tokenState'] = md5(date('dmy'));
    }

    return $gClient;
  }

  public function wp_login()
  {
    $gClient = $this->google_auth();
    if ($gClient->getAccessToken()) {
      $service = new Google_Service_Oauth2($gClient);
      $gu = $service->userinfo->get();
      if (isset($gu->email)) {
        if (filter_var($gu->email, FILTER_VALIDATE_EMAIL)) {
          if (!email_exists($gu->email)) {
            $username = strtok($gu->email, '@');
            $password = md5($gu->email);
            $email = $gu->email;
            wp_create_user($username, $password, $email);
            $user = get_user_by('email', $gu->email);
            if (!is_wp_error($user)) {
              wp_clear_auth_cookie();
              wp_set_current_user($user->ID);
              wp_set_auth_cookie($user->ID);
              $this->update_token($gClient);
            }
          } elseif (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            if ($current_user->user_email != $gu->email) {
              $this->delete_token($gClient);
              $user = get_user_by('email', $gu->email);
              if (!is_wp_error($user)) {
                wp_clear_auth_cookie();
                wp_set_current_user($user->ID);
                wp_set_auth_cookie($user->ID);
                $this->update_token($gClient);
              }
            }
          } else {
            $user = get_user_by('email', $gu->email);
            if (!is_wp_error($user)) {
              wp_clear_auth_cookie();
              wp_set_current_user($user->ID);
              wp_set_auth_cookie($user->ID);
              $this->update_token($gClient);
            }
          }
        }
      }
      $_SESSION['google_user'] = $gu;
    }
  }

  public function update_token($gClient)
  {
    $_SESSION['token'] = $gClient->getAccessToken();
    $tokenstring = base64_encode(json_encode($gClient->getAccessToken()));
    if (is_user_logged_in()) {
      update_user_meta(get_current_user_id(), 'google_token', $tokenstring);
    }
    _file_($this->token_file, json_encode($gClient->getAccessToken()), true);
  }

  public function get_token($gClient)
  {
    $accessToken = false;
    if (isses('token') && !$this->auth_request) {
      return isses('token');
    } elseif (is_user_logged_in() && !$this->auth_request) {
      $accessToken = base64_decode(get_user_meta(get_current_user_id(), 'google_token', true));
      if ($accessToken && !empty($accessToken)) {
        $accessToken = json_decode($accessToken);
        if (is_string($accessToken)) {
          $accessToken = json_decode($accessToken);
        }
      }
    }

    return $accessToken;
  }

  public function delete_token($gClient)
  {
    if (is_user_logged_in()) {
      delete_user_meta(get_current_user_id(), 'google_token');
    }
    if (file_exists($this->token_file)) {
      @unlink($this->token_file);
    }
  }

  /**
   * Check user is admin.
   *
   * @return boolean
   */
  public function isAdmin()
  {
    return is_user_logged_in() && current_user_can('administrator');
  }

  /**
   * Check instance of google have an valid token or not.
   *
   * @return boolean
   */
  public function isValid()
  {
    $gClient = $this->client;

    return $gClient->getAccessToken() && !$gClient->isAccessTokenExpired();
  }

  /**
   * Check user is subscribed or not.
   *
   * @return boolean
   */
  public function isSubsribed()
  {
    if (!$this->subCek()) {
      $this->check_subscriber($this->client);
    }
    return $this->subCek();
  }

  function subCek()
  {
    return isset($_SESSION['subscribed']) && 1 == $_SESSION['subscribed'];
  }

  public function setRedirect($url)
  {
    if (isset($this)) {
      $this->client->setRedirectUri($url);
      if (!headers_sent()) {
        setcookie('redirect_uri', $url, time() + 3600);
      }

      return $this;
    }
  }

  /**
   * set file token google.
   *
   * @param string $prefix prefix filename
   *                       * directory end with /
   *                       * prefix name any
   * @param string $suffix suffix filename
   *                       * directory not allowed
   *
   * @return string
   */
  public function setTokenFile($prefix = '', $suffix = '')
  {
    $dir = ROOT . '/assets/config/token/';
    $ext = '.json';
    if (is_user_logged_in()) {
      $filename = $this->user()->user_email;
    } else {
      $filename = $this->tokenfile_gen();
    }
    if (empty(trim($filename))) {
      $filename = $this->defaultToken(true);
    }
    $filename = _file_($dir . $prefix . $filename . $suffix . $ext);
    $this->token_file = $filename;

    return $filename;
  }

  /**
   * Get default token path.
   */
  public function defaultToken($onlyFilename)
  {
    $dir = ROOT . '/assets/config/token/';
    if (!isses('tokenDefault')) {
      sess('tokenDefault', md5($_SERVER['HTTP_USER_AGENT']));
    }
    $f = isses('tokenDefault');
    if (iscookie('ip')) {
      $f = iscookie('ip');
    }
    if ($onlyFilename) {
      return $f;
    } else {
      return $dir . $f;
    }
  }

  public function setBlogger()
  {
    if (!isset($_SESSION['for'])) {
      if (is_user_logged_in()) {
        $for = get_user_meta(get_current_user_id(), 'blogger_email', true);
      } elseif (isset($_POST['blogger_email']) && !empty($_POST['blogger_email'])) {
        $e = trim($_POST['blogger_email']);
        if (strpos($e, '@blogger.com') && filter_var($e, FILTER_VALIDATE_EMAIL)) {
          $for = $e;
        }
      }
      if (isset($for) && !isses('for')) {
        $_SESSION['for'] = $for;
      }
    }

    return $this;
  }

  public static function i()
  {
    return new self();
  }

  public function user()
  {
    $response = null;
    if (is_user_logged_in()) {
      $user = wp_get_current_user();
      $user->data->email = $user->data->user_email;
      $this->fetch_google_user();

      $response = $user->data;
    } elseif (isset($this) && $this->fetch_google_user_email()) {
      $response = $this->fetch_google_user_email();
    } else {
      $response = $this->get_client_ip();
    }
    if (empty($response)) {
      return date('dmyhis');
    } else {
      return $response;
    }
  }

  public function fetch_google_user_email()
  {
    $get = $this->fetch_google_user();
    if (isset($get->email)) {
      return $get->email;
    }
  }

  public function fetch_google_user()
  {
    if (isset($this->client->logged_in) && $this->client->logged_in && !isses('google_user')) {
      if ($this->client->getAccessToken()) {
        if (!$this->client->isAccessTokenExpired()) {
          if (!$this->isSubsribed()) {
            check_subscriber($this->client);
          }
          $service = new Google_Service_Oauth2($this->client);
          $user = $service->userinfo->get();
          if (!isset($_SESSION['google_user']) || !isset($_COOKIE['google_user'])) {
            _file_($this->token_file, json_encode($this->client->getAccessToken()), true);
            $_SESSION['google_user'] = $_COOKIE['google_user'] = $user;
          }
        }

        return $user;
      }
    }
  }

  public function tokenfile_gen()
  {
    $user = $this->user();
    if (isset($user->user_email)) {
      return $user->user_email;
    } elseif (isset($user->email)) {
      return $user->email;
    }

    return $this->defaultToken(true);
  }

  public function auth_url()
  {
    return filter_var($this->client->createAuthUrl(), FILTER_SANITIZE_URL);
    if (is_user_logged_in()) {
      return wp_logout_url(filter_var($this->client->createAuthUrl(), FILTER_SANITIZE_URL));
    } else {
      return filter_var($this->client->createAuthUrl(), FILTER_SANITIZE_URL);
    }
  }

  public function check_subscriber($client)
  {
    $output = [];
    try {
      $service = new Google_Service_YouTube($client);
      $cid = 'UCGNaoefvJRfd15fo-LQ0zvg';
      $filter = array_filter(['forChannelId' => $cid, 'mine' => true]);
      $response = $service->subscriptions->listSubscriptions('snippet,contentDetails', $filter);
      $result = count($response['items']);
      if ($result > 0) {
        $output['success'] = true;
        $output['data'] = $response['items'];
        $_SESSION['subscribed'] = 1;
      } else {
        $output['error'] = true;
        $output['data'] = 'Belum Subscribe';
        $output['msg'] = 'Belum Subscribe';
        $_SESSION['subscribed'] = 0;
      }
    } catch (Google_Exception $th) {
      $output = $th->getMessage();
    }

    return $output;
  }

  public function get_client_ip()
  {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
      $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
      $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
      $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    } elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
      $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    } elseif (isset($_SERVER['HTTP_FORWARDED'])) {
      $ipaddress = $_SERVER['HTTP_FORWARDED'];
    } elseif (isset($_SERVER['REMOTE_ADDR'])) {
      $ipaddress = $_SERVER['REMOTE_ADDR'];
    } else {
      $ipaddress = 'UNKNOWN';
    }

    return $ipaddress;
  }
}

function log_func($filename = __FILE__, $function = __FUNCTION__)
{
  $dump = debug_backtrace();
  $caller = array_shift($dump);
  _file_(ROOT . '/log/' . $filename . '/' . $function . '.log', json_encode($dump));
  _file_(ROOT . '/log/' . $filename . '/' . $function . '.array_shift.log', json_encode($caller));
}

if (isURL(isreq('redirect_callback'))) {
  $u = urldecode(isreq('redirect_callback'));
  if (!headers_sent()) {
    header("refresh:5; url=$u");
  } else {
    wp_redirect($u);
  }
}
