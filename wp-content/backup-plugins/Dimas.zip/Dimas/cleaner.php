<?php
if (!isset($core)) {
  $core = do_shortcode('DimasClass');
}
if (!iscookie('cleanup') && isreq('cleanup')) {
  $files = glob(ROOT . '/tmp/post_*', GLOB_BRACE);
  foreach ($files as $post_log) {
    if (file_exists($post_log)) {
      unlink($post_log);
    }
  }
  $files = glob(ROOT . '/tmp/*.{json}', GLOB_BRACE);
  for ($i = 0; $i < count($files); ++$i) {
    $json = json_decode(file_get_contents($files[$i]));
    if (isset($json->title)) {
      if (file_exists(dirname($files[$i]) . '/' . $json->title . '.info.json') && !file_exists(dirname($files[$i]) . '/' . $json->title . '.mp3') && (isset($json->url) && !empty($json->url))) {
        unlink(dirname($files[$i]) . '/' . $json->title . '.info.json');
      }
    }
  }
  $folder = ROOT . '/tmp/www*';
  foreach (glob($folder) as $subfolder) {
    if (is_dir($subfolder)) {
      deleteDirectory(realpath($subfolder));
    }
  }
  $folder = ROOT . '/views/AGC/saved';
  $jsoncfg = [];
  if (is_dir($folder)) {
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($folder)) as $entry) {
      //var_dump($entry->getPathname());
      if ($entry->isFile() && $entry->isWritable() && !preg_match('/^index\.json$/m', $entry)) {
        delfile(smartFilePath($entry->getPathname()));
      }
    }
  }
  cook('cleanup', true, 86400);
}

function rsearch($folder, $pattern)
{
  $dir = new RecursiveDirectoryIterator($folder);
  $ite = new RecursiveIteratorIterator($dir);
  $files = new RegexIterator($ite, $pattern, RegexIterator::GET_MATCH);
  $fileList = array();
  foreach ($files as $file) {
    $fileList = array_merge($fileList, $file);
  }
  return $fileList;
}

function deleteDirectory($dir)
{
  if (!file_exists($dir)) {
    return;
  }

  if (!is_dir($dir)) {
    return unlink($dir);
  }

  foreach (scandir($dir) as $item) {
    if ($item == '.' || $item == '..') {
      continue;
    }

    if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
      return false;
    }
  }

  return rmdir($dir);
}
