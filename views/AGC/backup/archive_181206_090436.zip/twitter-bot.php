<?php
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
header('Access-Control-Allow-Origin: *');
header('Origins: https://www.twitter.com');
header('Origin: https://www.twitter.com');
header('Referer: https://www.twitter.com/login');
require "vendor/autoload.php";
include "twitter-html.php";

//$access_token = "1021081604-rVIhvkX5GrkgVYbC70ZyV0XzuU87vxWz7FNCzCw";
//$access_token_secret = "0KiujvzDUCDg8GSy4a6uK91tZtB1RNZMqhUKUEKU9f5GW";

$api_key = "DAduu5On0ndm1W7sa3GdpTIai";
$api_secret = "zploajODV7prNtQHQsw7LUeoFezVXQETCAhlzJj7scFfIV5Nr7";
$callback = "http://dimaslanjaka.000webhostapp.com/instagram/twitter-bot.php?callback";

//bootsraping
$twData = array(
    'consumer_key' => $api_key,
    'consumer_secret' => $api_secret,
    'callback_url' => $callback,
    'callback' => $callback
);
define('CONSUMER_KEY', $twData["consumer_key"]); 
define('CONSUMER_SECRET', $twData["consumer_secret"]); 
define('OAUTH_CALLBACK', $twData["callback_url"]); 

use Abraham\TwitterOAuth\TwitterOAuth;

function getToken(){
  global $twData;
$request_token = [];
$request_token['oauth_token'] = $_SESSION['oauth_token'];
$request_token['oauth_token_secret'] = $_SESSION['oauth_token_secret'];

if (isset($_REQUEST['oauth_token']) && $request_token['oauth_token'] !== $_REQUEST['oauth_token']) {
    die("Something Wrong");
}
if (isset($_REQUEST['oauth_verifier'])){
  $connection = new TwitterOAuth($twData['consumer_key'], $twData['consumer_secret'], $request_token['oauth_token'], $request_token['oauth_token_secret']);
$access_token = $connection->oauth("oauth/access_token", ["oauth_verifier" => $_REQUEST['oauth_verifier']]);
$_SESSION['access_token'] = $access_token;
save();
}
}

function save(){
$access_token = $_SESSION["access_token"] or die("access token required");
$dta = $_SESSION["dta"] = "twitter-tokens/".$_SESSION["data_twitter"];
if (file_exists($dta)){
  $dtx = json_decode(file_get_contents($dta), true);
  if (isset($dtx["bot_status"])){
    $access_token["bot_status"] = $dtx["bot_status"];
  }
}
file_put_contents($dta, json_encode($access_token, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
return header("Location: twitter-bot.php?user");
}

function getUser(){
  global $twData;
//$access_token = $_SESSION['access_token'];
if (!isset($_SESSION["dta"]) || empty($_SESSION["dta"])){
  header("Location: twitter-bot.php?oauth"); die();
}
$access_token = json_decode(file_get_contents($_SESSION["dta"]), true);

if (isset($_GET["activate"])){
  $access_token["bot_status"] = 1;
  file_put_contents($_SESSION["dta"], json_encode($access_token, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
  header("Location: twitter-bot.php?user"); die();
} else if (isset($_GET["deactivate"])){
  $access_token["bot_status"] = 0;
  file_put_contents($_SESSION["dta"], json_encode($access_token, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
  header("Location: twitter-bot.php?user"); die();
}

if (!isset($access_token["bot_status"])){
  $access_token["bot_status"] = 0;
  $stats="inactive";
  file_put_contents($_SESSION["dta"], json_encode($access_token, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
} else if (isset($access_token["bot_status"]) && $access_token["bot_status"] === 0){
  $stats="inactive";
} else if (isset($access_token["bot_status"]) && $access_token["bot_status"] === 1){
  $stats="active";
}
if ($stats === "inactive"){
  $color = "bg-danger";
  $do = "<a class='btn btn-default bg-success text-white' href='twitter-bot.php?user&activate'>Activate Now</a>";
} else if ($stats === "active"){
  $color = "bg-success";
  $do = "<a class='btn btn-default bg-danger text-white' href='twitter-bot.php?user&deactivate'>Deactivate</a>";
}
$connection = new TwitterOAuth($twData['consumer_key'], $twData['consumer_secret'], $access_token['oauth_token'], $access_token['oauth_token_secret']);

try {
  $user = $connection->get('account/verify_credentials', ['tweet_mode' => 'extended', 'include_entities' => 'true']);
} catch(Exception $e){
  $user = $connection->get("account/verify_credentials", ['include_email' => 'true']);
}
$css = file_get_contents("https://codepen.io/dimaslanjaka/pen/MzOMyZ.css");
$userhtml = <<<EOF
<div class='card card-profile'>
  <img alt='' class='card-img-top' src='{$user->profile_image_url_https}' />
  <div class='card-block'>
    <div class='text-center'>
    <img alt='{$user->screen_name}' class='card-img-profile' title='{$user->screen_name}' src='{$user->profile_image_url}'>
    </div>
    <div class='card-body'>
    <h4 class='card-title text-center'>
      {$user->name}
    </h4>
    <p class='card-text'>
      <small>
      <b>Username:</b> {$user->screen_name}<br/>
      <b>Account Created At:</b> {$user->created_at}<br/>
      <b>User Location Address:</b> {$user->location}
      </small>
    </p>
    <div class="container">
    <span class='text-left'>Status Bot <b class='shadow {$color}'>{$stats}</b></span> <span class='text-right'>{$do}</span>
    </div>
    </div>
    <div class='card-links text-center'>
      <!--a class='fa fa-dribbble' href='#'></a-->
      <a class='fa fa-twitter' href='{$user->url}'></a>
      <button id="homepage" class='btn btn-default' >Show Homepage</button>
    </div>
  </div>
</div>
<script>
function xconsole(string){
  var str = JSON.stringify(string);
  str = JSON.stringify(string, null, 4);
  return str;
}
    $('#homepage').on('click', function () {
        $.ajax({
            url: 'twitter-bot.php?home_timeline',
            type: 'POST',
            /*
            success: function(data){
              $("div#home").append(xconsole(data));
            },
            error: function(data){
              $("div#home").append(xconsole(data));
            },
            */
            complete: function(data){
              $("div#home").html(data.responseText);
            }
        });
    });
</script>
<div id="home"></div>
EOF;
    $ux = headhtml("Dashboard ".$user->screen_name, "Dashboard ". $user->screen_name, false);
    $ux .= "<style>$css</style>";
    $ux = closehead($ux);
    $ux .= closebody($userhtml, false);
    $ux .= <<<EOF
    
EOF;

    echo fixhtml($ux);
    /*
    echo "<pre>";
    print_r($user);
    echo "<pre>";	*/
}

function getAccess(){
  global $twData;
$tw = new TwitterOAuth($twData['consumer_key'], $twData['consumer_secret']);
//$content = $tw->get("account/verify_credentials");

$request_token = $tw->oauth("oauth/request_token", array("oauth_callback" => $twData['callback']));
$_SESSION['oauth_token'] = $request_token['oauth_token'];
$_SESSION['oauth_token_secret'] = $request_token['oauth_token_secret'];

$url = $tw->url('oauth/authorize', array('oauth_token' => $request_token['oauth_token']));
echo oauthbutton($url);
}

if (isset($_GET["logout"])){
if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
        //setcookie($name, '', time()-1000);
        //setcookie($name, '', time()-1000, '/');
        unset($_COOKIE[$name]);
        setcookie($name, null, -1, '/');
    }
    
}  session_destroy();
}
//var_dump($_SESSION); die();

if (!isset($_SESSION["userlogin"]) || $_SESSION["userlogin"] === false){
  echo loginform();
  die();
} /*else if (isset($_SESSION["userlogin"]) && !empty($_SESSION["userlogin"]) && !isset($_GET["panel"])){
  header("Location: twitter-bot.php?panel");
}*/

if (isset($_GET["oauth"])){
  getAccess(); die();
} else if (isset($_GET["callback"])){
  getToken(); die();
} else if (isset($_GET["user"])){
  getUser(); die();
} else if (isset($_GET["home_timeline"])){
  $access_token = json_decode(file_get_contents($_SESSION["dta"]), true);
  $connection = new TwitterOAuth($twData['consumer_key'], $twData['consumer_secret'], $access_token['oauth_token'], $access_token['oauth_token_secret']);
  $home = $connection->get('statuses/home_timeline', array("count" => 5));
  header("Content-type: application/json; charset=utf-8");
  //echo json_encode($home, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
  $xp = "";
  var_dump($home);die();
  foreach ($home as $feed){
    $id = $feed->id;
    $text = $feed->text;
    $favorited = $feed->favorited;
    if ($favorited === false){
      $favorited = "No";
    } else {
      $favorited = "Yes";
    }
    $retweeted = $feed->retweeted;
    if ($retweeted === false){
      $retweeted = "No";
    } else {
      $retweeted = "Yes";
    }
    $from = $feed->user->id;
    $from_name = $feed->user->name;
    $from_username = $feed->user->screen_name;
    $from_image = $feed->user->profile_image_url_https;
    $xp .= <<<EOF
    <div class="col-12 col-sm-6 col-md-6 col-lg-4 col-xl-2 mb-3">
				<img class="img-thumbnail" src="{$from_image}" title="{$from_name}" alt="{$from_name}" width="auto" />
				<div class="container mt-2">
				<b>ID</b>: {$id};<br/>
				<b>From</b>: {$from_name}<br/>
				<b>Username</b>: {$from_username}<br/>
				<b>Text</b>: $text;<br/>
				<b>Liked</b>: {$favorited}<br/>
				<b>Retweeted</b>: {$retweeted}<br/>		
				</div>
			</div>
EOF;
  }
  $phtml = <<<EOF
<section>
  <div class="container">
		<div class="row py-5">
		{$xp}
		</div>
		</div>
</section>
EOF;
  echo $phtml;
}