<?php
require_once 'twitter.php';
include "dom.php";

$username = $_POST["username"];
$password = $_POST["password"];
$data = base64_encode("$username~$password");
$_SESSION["data_twitter"] = $_SESSION["data_twiter"] = $data;
$cookie = "twitter-cookie/$data";
$_SESSION["cookiefile"] = $cookie;
global $twid;
$twid = '/^(?=.*twid)(?=.*u\=([0-9]{1,20}))/m';

if (file_exists($cookie) && preg_match($twid, file_get_contents($cookie), $user)){
  $hc = new hhb_curl();
  $cO = array(
    CURLOPT_COOKIEFILE => $cookie,
    CURLOPT_COOKIEJAR => $cookie,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTPHEADER => array(
    "Cookie" => "app_shell_visited=1"
    ),
    CURLOPT_URL => "https://abs.twimg.com/k/en/init.en.c5a67fc1f42cedcdbbcd.js"
  );
  $html = $hc->setopt_array( $cO )->exec()->getResponseBody();
  $header = $hc->setopt_array( $cO )->exec()->getResponseHeaders();
  preg_match ( '/i\s*\=\s*\"([^\"]{114})\"\s*\;/iu', $html, $matches );
  $_SESSION["api_auth_key"]=$matches[1];
  echo "Generated Site Auth Token: ".$matches[1]."\n";
  $_SESSION["userlogin"] = $user[1];
  die("Was Logged-in as: ".$user[1]);
}

$hc = new hhb_curl ( 'https://twitter.com/login', true );
$hc->exec();

# parse authenticity_token out of html response
   $html = $hc->getStdOut();
   $data = str_get_html($html);
   $nodes = $data->find("input[type=hidden]");
   $authenticity_token = $data->find("input[name=authenticity_token]",0)->attr["value"];
   
# set post data
$sPost = "session[username_or_email]=$username&session[password]=$password&return_to_ssl=true&scribe_log=&redirect_after_login=%2F&authenticity_token=$authenticity_token";
$cOpt = array (
        CURLOPT_POST => true,
        CURLOPT_COOKIEFILE => $cookie,
        CURLOPT_COOKIEJAR => $cookie,
        CURLOPT_POSTFIELDS => $sPost,
        CURLOPT_URL => 'https://twitter.com/sessions' 
);
$html = $hc->setopt_array ( $cOpt )->exec ()->getResponseBody ();
$domd = @DOMDocument::loadHTML ( $html );
$xpath = new DOMXPath ( $domd );
$infoURL = $hc->getinfo ( CURLINFO_EFFECTIVE_URL );
if (false !== stripos ( $infoURL, 'login/error' )) {
  die("Login Failed!. " . $infoURL);
} else if (false !== stripos ( $infoURL, 'account/login_challenge' )) {
  preg_match("/user\_id\=([0-9]{1,20})/m", $infoURL, $user);
  $_SESSION["userlogin"] = $user[1];
  die("Login Challenge Required! <a href='$infoURL' target='_blank' class='btn btn-info'>Click Here</a> then <button class='btn btn-info' onclick='window.location.reload(1);'>Reload This Page</button>");
} else if (false !== stripos ( $infoURL, 'account/access' )) {
  die("Login Challenge Required! ".$infoURL);
} else if (file_exists($cookie) && preg_match($twid, file_get_contents($cookie), $user)){
  $_SESSION["userlogin"] = $user[1];
  die("Was Logged-in as: ".$user[1]);
}
?>