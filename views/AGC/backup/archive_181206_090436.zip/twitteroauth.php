<?php
header("Content-type: application/json; charset=utf-8");
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
header('Access-Control-Allow-Origin: *');
header('Origins: https://www.twitter.com');
header('Origin: https://www.twitter.com');
header('Referer: https://www.twitter.com/login');

if (!isset($_GET["admin"])){
if (isset($_POST["username"])){
  define("USERNAME", $_POST["username"], true);
}
if (isset($_POST["password"])){
  define("PASSWORD", $_POST["password"], true);
}
if (!isset($_POST["password"]) || !isset($_POST["username"])){
  die("Username Or Password Required");
}
} else {
  define("USERNAME", "dimaslanjaka@gmail.com", true);
  define("PASSWORD", "Bangsadpo0l#", true);
}

$dir="twitter-cookie/";
$DATA = base64_encode(USERNAME."~".PASSWORD);
$cookiefile = $_SESSION["cookiefile"] = $dir.$DATA;

$log=array();
require_once 'twitter.php';
$hc = new hhb_curl ( 'https://twitter.com/login', true );
$hc->exec();

function getInfo($html=null){
  global $hc; global $cookiefile;
  if (null === $html){
    $inputs ['session[username_or_email]'] = USERNAME;
    $inputs ['session[password]'] = PASSWORD;
    $html = $hc->setopt_array ( array (
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query ( $inputs ),
        CURLOPT_URL => 'https://twitter.com/sessions' 
    ) )->exec ()->getResponseBody ();
  }
$domd = @DOMDocument::loadHTML ( $html );
$xpath = new DOMXPath ( $domd );
// now to get the api key
$js = $hc->exec ( 'https://abs.twimg.com/k/en/init.en.c5a67fc1f42cedcdbbcd.js' )->getResponseBody ();
// hhb_var_dump ( $hc->getStdErr (), $hc->getStdOut () ) & die ();
// fragile regex: assumes that there's only 1x i="114 characters"; , and that the api key is exactly 114 characters.
preg_match ( '/i\s*\=\s*\"([^\"]{114})\"\s*\;/iu', $js, $matches );
// hhb_var_dump ( $matches ) & die ();
if (count ( $matches ) !== 2) {
    throw new RuntimeException ( 'failed to extract the api auth key!' );
}
$api_auth_key = $matches [1];

$user_name = ltrim ( $xpath->query ( '//a[contains(@class,\'DashboardProfileCard\')]' )->item ( 0 )->getAttribute ( "href" ), '/' );
$myurl = 'https://twitter.com/' . $user_name;
//echo 'myurl: ' . $myurl . PHP_EOL;
// $myurl = 'https://twitter.com/scaleway';

if (strlen($user_name) >= 2){
  $_SESSION["userlogin"] = $user_name;
  //header("Location: twitter-bot.php?panel");
  $jsx = <<<EOF
  <script>
  window.location.href="twitter-bot.php?panel";
  </script>
EOF;
  echo $jsx;
  die("Was Logged-in as: ".$user_name);
} else {
  if (false !== REM($_SESSION["cookiefile"])){
    echo "Cookie Removed\n";
  } else {
    echo "Failed Remove Cookie\n";
  }
  die("Login Failed!");
}
}

$hcH = $hc->getResponseHeaders();
if (is_array($hcH) || ($hcH instanceof Traversable)){
  $hcH = json_encode($hcH);
}
$cfh = file_get_contents($cookiefile);
//die($cfh);
// get csrf token ct0=xxxx
$csrf_token = [ ];
//preg_match ( '/\s+ct0\s*=\s*(.*?)\;/', implode ( "\n", $hcH ), $csrf_token );
$r1='/ct0\=([a-zA-Z0-9]{1,30})/m';
$re = '/ct0.([a-zA-Z0-9]{1,50})/m';
$twid = '/^(?=.*twid)(?=.*u\=([0-9]{1,20}))/m';

if (preg_match($twid, $hcH.$cfh, $user)){
  die("Was Logged-in as: ".$user[1]);
} else if (preg_match($re, $hcH.$cfh, $csrf_token)){
if (count ( $csrf_token ) !== 2) {
    throw new Exception ( 'failed to extract the csrf token!' );
}
$csrf_token = $csrf_token [1];

// to log in...

$html = $hc->getStdOut ();
$domd = @DOMDocument::loadHTML ( $html );
$inputs = getDOMDocumentFormInputs ( $domd, true ) [0]; // << not sure why, but they have 6 seemingly duplicate login forms. the first 1 works fine.
$inputs = DOMInputsToArray ( $inputs );
$inputs ['session[username_or_email]'] = USERNAME;
$inputs ['session[password]'] = PASSWORD;
// hhb_var_dump ( $inputs ) & die ();
$html = $hc->setopt_array ( array (
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query ( $inputs ),
        CURLOPT_URL => 'https://twitter.com/sessions' 
) )->exec ()->getResponseBody ();
$domd = @DOMDocument::loadHTML ( $html );
$xpath = new DOMXPath ( $domd );
// hhb_var_dump ( $hc->getStdErr (), $hc->getStdOut () );

if (false !== stripos ( $hc->getinfo ( CURLINFO_EFFECTIVE_URL ), 'login/error' )) {
  die("Login Failed!. " . $hc->getinfo ( CURLINFO_EFFECTIVE_URL ));
    //throw new Exception ( 'failed to login!. UserName Or Password Incorrect' );
} else if (false !== stripos ( $hc->getinfo ( CURLINFO_EFFECTIVE_URL ), 'account/login_challenge' )) {
  echo challenge( $html );
  die("Login Challenge Required!");
}
 getInfo($html);
}

function challenge($c){
  include "dom.php";
  $html = str_get_html($c);
  $form = $html->find("form",0);
  $form = $form->outertext;
  $_SESSION["form_challenge"] = $form;
  if (isset($_GET["admin"])){
    die( $form );
  }
}