<?php
if (!isset($_COOKIE["sudah"])){
  setcookie("sudah", true, time()+3600);
$type = $_GET['type'];
  switch($type){
            case 1:
            $siap = "type=1"; //like
            break;
            case 2:
            $siap = "type=2"; //love
            break;
            case 3:
            $siap = "type=3"; //wow
            break;
            case 4:
            $siap = "type=4"; //haha
            break;
            case 5:
            $siap = "type=7"; //sedih
            break;
            case 6:
            $siap = "type=8"; //marah
            break;
           default:
           $siap = "type=1"; //like sebagai default
            break;
        }
$id=$_GET['id'];
if(!is_numeric($id)){
echo $id . ' invalid post ID!';
exit;
}
$op=opendir('cokisx');
while($isi=readdir($op)){ 
if($isi != '.' && $isi != '..'){ 
$cokis = $isi;
$gerr ='https://m.facebook.com/reactions/picker/?ft_id='.$id; 
$sukaa= getx($gerr,$cokis); 
$suka= cut($sukaa,'</h1>','<div id="static'); 
$ha= explode('/ufi/reaction/',$suka); 
$liha= count($ha);
for($hai=0; $hai<=$liha; $hai++){ 
$getha= cut($ha[$hai],$siap,'"'); 
 echo $getha.'<hr>'; 
 if($getha){ 
 $ok[]=1; 
 $hajarm='https://m.facebook.com/ufi/reaction/?ft_ent_identifier='.$id.'&amp;reaction_'.$siap.''.$getha; $hajar= str_replace('&amp;','&',$hajarm); getx($hajar,$cokis);
 }
 }
 } 
 }
 echo count($ok).' Sukses';
}

function getx($url,$xx=null,$cokis=null){
$me='Opera/9.80 (Series 60; Opera Mini/6.5.27309/34.1445; U; en) Presto/2.8.119 Version/11.10';
  if($cokis){
     $ch=curl_init();
        curl_setopt_array($ch,array(
         CURLOPT_URL => $xx,
         CURLOPT_RETURNTRANSFER => 1,
         CURLOPT_USERAGENT => $me,
         CURLOPT_REFERER => $xx,
         CURLOPT_POST => 1,
         CURLOPT_POSTFIELDS => $url,
         CURLOPT_SSL_VERIFYPEER => true,
         CURLOPT_ENCODING => '',
         CURLOPT_COOKIEJAR => 'cokisx/'.$cokis,
   CURLOPT_COOKIEFILE => 'cokisx/'.$cokis,
));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
       curl_close($ch);
          return ($cx);
             }else{
                $ch=curl_init();
                    curl_setopt_array($ch,array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_USERAGENT => $me,
             CURLOPT_HEADER => 1,
             CURLOPT_ENCODING => '',
             CURLOPT_COOKIEFILE => 'cokisx/'.$xx,
          ));
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      $cx=curl_exec($ch);
  curl_close($ch);
     return ($cx);
}
        }
 function cut($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];
}
return '';
}
}
?>