<?php
$lines = file('api.url');
$lines = array_unique($lines);
file_put_contents('api.url', implode($lines));

var_dump($lines);