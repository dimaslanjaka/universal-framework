<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head>
<title>Privacy Policy | Robot Reaction Facebook</title>
<link rel="shortcut icon" href="//bertena.ga/Material/img/favicon.ico">
<meta name="description" content="Robot Beranda | Tanggapi Status Teman Facebook Kamu Secara Otomatis" />
<meta charset="utf-8">
<meta name="keywords" content=" Robot Beranda, Robot Wow, Robot Super, Robot Like, Robot Sad, Robot Sedih, Robot Marah, Robot Angry, Robot Like, Robot Love, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, CST Liker, Indonesia Autolike, Autolike status, Autolike Photo, ,Autolike Fans Page ,Bot komen ,Bot Like, Bom Like,Bomer Like, Big Like, Facebook, Google, Yahoo, Mywapblog, Bot koplak, Alexa, Ping, Twitter, Indonesian Likers, Autoliker, FB Autolike, FB Autoliker, FB Status Autolike, Indonesian Liker, Autolike 2014, Autolike, Jempol, Hublaa, Like" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="//bertena.ga/Material/img/icon.png"/>
<meta name="copyright" content="Copyright © Webmanajemen.xyz">
<meta name="author" content="Dimas Lanjaka Kumala Indra">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike,hublaa,CST Liker,Yaz4rt,IndoLikerz,Hembus,auto follower,autolike page,auto komen">
</head>
<body>
<?php include 'menu.php'; ?>
<div class="w3-container w3-center w3-blue"><h1><a class="w3-text-white" href="privacy.php">Privacy Policy</a></h1></div>
<div class="container">
<h2>
  Intro
</h2>
<p>
  Halaman ini akan menghapus semua keraguan Anda tentang bagaimana kami
  melindungi privasi Anda dan mengapa kami meminta Anda untuk masuk dengan
  Facebook untuk menggunakan situs kami.
</p>
<p>
  Halaman ini diperbarui secara teratur setelah beberapa bulan mengalami
  penundaan. Halaman ini diperbarui tanpa pemberitahuan lebih lanjut, maka
  tanggung jawab Anda untuk membaca dokumentasi terbaru dari halaman ini.
</p>
<h2>
  Apa yang Kami Kumpulkan Dari Otorisasi Facebook Anda?
</h2>
<p>
  Kami menggunakan login berbasis Facebook untuk mengotentikasi pengguna di
  situs kami. Saat log in ke situs kami menggunakan Facebook, kami
  mendapatkan beberapa data tentang Anda dari data Anda, data tersebut
  tersimpan di database kami dan digunakan untuk tujuan berikut:
</p>
<ul>
  <li>
    Mendapatkan rincian profil Anda (Nama, Username, E-Mail, Hometown
    dll.).
  </li>
  <li>
    Mendapatkan posting terbaru / status / foto Anda.
  </li>
  <li>
    Mengirimkan reaksi / menyukai tulisan pengguna lain.
  </li>
  <li>
    Menjaga catatan authenctication Anda.
  </li>
</ul>
<h2>
  Apakah Account Anda Aman Setelah Menggunakan Layanan Ini?
</h2>
<p>
  Kami menjaga setiap informasi kerahasiaan pengguna kami di setiap aspek dan
  kami juga tidak menjual data Anda ke situs atau layanan lain meskipun kami
  tidak mengirimkan apapun ke timeline Anda atas nama Anda.
</p>
</div>
<div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;">
<div id="google_translate_element"></div>
<hr>
<div id="histats_counter"></div><br>
<strong>Copyright &copy; 2017 <a href="/">Robot Reaction Facebook</a> All Right Reserved. </strong></font>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.3.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://codepen.io/dimaslanjaka/pen/xLPQjG.js"></script>

<script type="text/javascript" src="gtrans.js">
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script>
var loadMultipleCss = function(){
    //load local css
    loadCss('css/bootstrap.css');        
    loadCss('css/bootstrap.min.css');
    loadCss('css/bootstrap-theme.css');
    loadCss('css/bootstrap-theme.min.css')
    //load Bootstrap from CDN
    loadCss('https://www.w3schools.com/w3css/4/w3.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
}
 
var loadCss = function(cssPath){
    var cssLink = document.createElement('link');
    cssLink.rel = 'stylesheet';
    cssLink.href = cssPath;
    var head = document.getElementsByTagName('head')[0];
    head.parentNode.insertBefore(cssLink, head);
};
 
//call function on window load
window.addEventListener('load', loadMultipleCss);
</script>
<noscript>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
<link rel="styleheet" href="css/bootstrap.css" />      
<link rel="styleheet" href="css/bootstrap.min.css" />
<link rel="styleheet" href="css/bootstrap-theme.css" />
<link rel="styleheet" href="css/bootstrap-theme.min.css" />
</noscript>
</body>
</html>