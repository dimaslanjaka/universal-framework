<?php
$load = sys_getloadavg();
$limit =50; //percent cpu
if ($load[0] >= $limit) {
  die("Oops Server Busy, this message was automate from Dimas Lanjaka For telling users, there too many processed.");
}
//$host = "localhost";
//$username = "root";
//$password = "bangsadpo0l";	
//$dbname = "test";
/*
$server = array(
"host" => "85.10.205.173:3306",
"user" => "dimaslanjaka",
"pass" => "bangsadpo0l",
"dbname" => "dimaslanjaka"
);
*/
$server = array(
"user" => "IzintQlW2e",
"pass" => "LHLLqRh8CH",
"dbname" => "IzintQlW2e",
"host" => "remotemysql.com:3306"
);
/*
$server = array(
"host" => "sql12.freemysqlhosting.net:3306",
"pass" => "c2i3w5EdMa",
"user" => "sql12263992",
"dbname" => "sql12263992"
);

$db = [$server1,$server2];
$server = $db[array_rand($db)];
*/
$dbname = $server["dbname"];
//database connect 
$con = mysqli_connect($server["host"], $server["user"], $server["pass"]) or die(mysqli_error($con));

 $selectdb = mysqli_select_db($con, $dbname) or die(mysqli_error($con));
 $encoding = mysqli_query($con, "SET NAMES utf8");
 if (false === $encoding){
   die("Encoding UTF-8 Failed\n");
 } else {
   //echo "UTF-8 Encoded\n";
$query = "SELECT ID FROM token_all";
$result = mysqli_query($con, $query);
if (false === $result){  
$result = mysqli_query($con, "CREATE TABLE IF NOT EXISTS `token_all` (
  `token` varchar(255) DEFAULT NULL,
  `id` varchar(32) NOT NULL DEFAULT '',
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

");
}
} //encoding

?>