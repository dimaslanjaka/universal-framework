<?php
require_once 'ajax/assets/facebook-sdk/facebook.php';
header('Content-Type: text/plain; charset=utf-8');
@ini_set('memory_limit', '256M'); //-1
//@ini_set('output_buffering',0);
ob_start();
$facebook    = new Facebook(array(
    'appId'  => '6628568379',
    'secret' => md5('{Your-app-secret}'),
    'cookie' => true
));

if (!isset($_GET["text"]) && !isset($_GET["load"]) && !isset($_GET["url"]) && !isset($_GET["cache"]) && !isset($_GET["exec"]) && !isset($_POST["exec"])) {
  echo "400 Bad Goblok";
  header("HTTP/1.1 400");
  exit;
}

if (isset($_POST["get"])){
  gethome();
} else if (isset($_POST["clean"])){
  unique();
} else if (isset($_GET["load"])){
    header('Content-Type: text/html; charset=utf-8');
    $facebook->setAccessToken('EAAAAAYsX7TsBAJLZBslgZAHo360pk6pKLeL9DSzWrgyBseHuZBGhfRtfa87ZCcSaZAAKcAZBQkuwTL0eodvbInJZBus5QyWJ6giNhchtrFv9h8gAaDtudpoZBMrTvZAmSmn6UXWdqzs3a8wKsom59dkMiSJBZBayrguFZBPqVsKDvcZBwJS5mggeGrJXdNegXyr9YOdjV3ljCTw9hPq2J3g0K7jZA');
    //$facebook->doLogin('dimaslanjaka1','DimasLanjaka--','cokisx/default.txt');
    echo $facebook->reload($_GET["load"], 'cokisx/default.txt');
} 
  
$items = typex('typex');

$text = $items['text'];
shuffle($text);
$random = $text[array_rand($text)];
$data = parse_data($random);

  if (isset($_GET["text"])){
    echo $facebook->reload($_GET["text"], $data["cokis"]);
  } else if (isset($_GET["cache"])){
    header('Content-Type: text/html; charset=utf-8');
    echo $facebook->reload($_GET["cache"], $data["cokis"]);
  } else if (isset($_GET["url"])){
    header('Content-Type: text/html; charset=utf-8');
    echo $facebook->curl($_GET["url"], $data["cokis"], null, '"Opera 10.00 Mobi - SymbOS" useragent="Opera/9.80 (S60; SymbOS; Opera Mobi/499; U; xx) Presto/2.4.18 Version/10.00');
  }

if (isset($_POST["exec"]) || isset($_GET["exec"])){
$files = scandir('typex/');
$filelist=array();
foreach($files as $file) {
  if (strpos($file, '.') === false){
  array_push($filelist,$file);
  }
}

$filelist = array_unique($filelist);
shuffle($filelist);
for ($i = 0; $i < count($filelist); $i++){
  try {
  REACT( parse_data( 'typex/' . $filelist[$i] ) );
  } catch(Exception $e){
    echo $e->getMessage();
  }
}

$ox = ob_get_contents();
ob_clean();
ob_start();
file_put_contents('log/facebook-exec.txt', $ox, LOCK_EX);
echo $ox;
}

function REACT($data=array()){
  global $facebook;
  if ($facebook->verifyCokis(file_get_contents($data["cokis"])) !== "success"){
    @unlink($data["config"]);
    throw new Exception($data["user"] ." Was Removed\n");
  }

echo "
\n--------------------
Log: ".$data['fbid']."
----------------------\n";
try {
$type=preg_match('!\d+!', $data["type"], $m);
$data["type"]=$m[0];
$home = fetch_home("https://m.facebook.com/home.php",$data["cokis"]);

preg_match_all('/ft_id=([0-9]{1,20})?\&/m', $home, $matches);

$ids = array_unique($matches[1]);
shuffle($ids);
if (!isset($ids[0])){
  throw new Exception($data["user"]." Data Was Changed & Removed\n");
}
for ($k = 0 ; $k < count($ids); $k++){
  echo "Trying " . $ids[$k] . "\n";
  if ( $facebook->Logger($data['log'],'check',$ids[$k]) !== false ) {
 $reaction_picker = "https://mobile.facebook.com/reactions/picker/?ft_id=";
 $t1 = $reaction_picker. $ids[$k];
 $t2 = fetch_home($t1, $data["cokis"]);
 $r = str_replace('&amp;','&',$t2);
 $postReact = '/ufi/reaction/?ft_ent_identifier='.$ids[$k].'&reaction_type='.$data["type"];
 $post_data = fetch_value($r,$postReact,'" style="display:block">');
 $postFetchs = 'https://mobile.facebook.com/ufi/reaction/?ft_ent_identifier='.$ids[$k].'&reaction_type='.$data["type"].$post_data;
 
 $field_data = parse_url($postFetchs)["query"].'&__user='.$data["fbid"];
 
 $result = send_post($postFetchs, $data["cokis"], $field_data);
 /*
 if ($data["fbid"] === '100008165670028'){
  throw new Exception($result);
 }
 */
 if (strpos($result, '>Facebook</title>') !== false){
   $facebook->Logger($data['log'],'save',$ids[$k]);
   echo $ids[$k] . " (".$data["type_text"].") Success\n";
 } else if (preg_match('/(action blocked|tindakan diblokir)/m', strtolower($result))){
   echo $data["user"] . " Like Action Was Blocked (Need Proxy For That, Contact Admin +6285655667573) \n";
 }
 } // check Log
}
} //try
catch(Exception $e){
  echo $e->getMessage();
}
}

function fetch_value($str, $find_start, $find_end)
	{
		$start = strpos($str, $find_start);
		if ($start === false) {
				return "";
		}
		$length = strlen($find_start);
		$end = strpos(substr($str, $start + $length), $find_end);
		return trim(substr($str, $start + $length, $end));
	}


/*
echo gethome($random);
*/

/*
} else {
  echo "Hello KONTOL";
}
*/

function fetch_home($url, $cokis){
  global $facebook;
  return $facebook->curl($url, $cokis, null, '"Opera 10.00 Mobi - SymbOS" useragent="Opera/9.80 (S60; SymbOS; Opera Mobi/499; U; xx) Presto/2.4.18 Version/10.00');
}

function send_post($url, $cokis, $data){
  global $facebook;
  return $facebook->curl($url, $cokis, $data, '"Opera 10.00 Mobi - SymbOS" useragent="Opera/9.80 (S60; SymbOS; Opera Mobi/499; U; xx) Presto/2.4.18 Version/10.00');
}

function parse_data($c){
  global $facebook;
  $cx = $c;
  if (strpos($c, '×') === false){
  if (file_exists($c)){
    $fp = fopen(realpath($c),'r');
    $c = fgets($fp, 2028);
  } else {
    //throw new Exception("{$c} Not Found \n");
  }
  }
 $data = explode('×', $c);
 $login = base64_decode($data[1]);
 $dlogin = explode('~', $login);
 $u = $dlogin[0];
 $p = $dlogin[1];
 $type = $data[0];
 $lv=explode('=',trim($type));
  switch($lv[1]){
            case 1:
            $siap = "type=1";
            $typenya = "LIKE";
            break;
            case 2:
            $siap = "type=2";
            $typenya = "LOVE";
            break;
            case 3:
            $siap = "type=3";
            $typenya = "HAHA";
            break;
            case 4:
            $siap = "type=4";
            $typenya = "WOW";
            break;
            case 7:
            $siap = "type=7";
            $typenya = "SEDIH";
            break;
            case 8:
            $siap = "type=8";
            $typenya = "MARAH";
            break;
           default:
 $acak = array('type=1','type=2','type=3','type=4','type=7','type=8');   $siap=$acak[rand(0,count($acak)-1)];
 $typenya = "ACAK";
       break;
 }
 $fbid = trim($data[2]);
 $token = (isset($data[4]) ? $data[4] : null);
 if ($token){
   $facebook->setAccessToken($token);
 }
 $max = (isset($data[5]) ? $data[5] : null);
 $log = 'logx/'.$fbid;
 if (!file_exists($log)){
   file_put_contents($log, "");
   throw new Exception("{$log} Not Found");
 }
 $cokis = 'cokisx/'.$data[1];
 if (!file_exists($cokis)){
   $facebook->createCookie($u, $p, $cokis);
   throw new Exception("{$cokis} Not Found");
 }
 $array["config"]=realpath($cx);
 $array["user"]=$u;
 $array["pass"]=$p;
 $array["log"]=realpath($log);
 $array["cokis"]=realpath($cokis);
 $array["cookie"]=$cokis;
 $array["token"]=$token;
 $array["max"]=$max;
 $array["fbid"]=$fbid;
 $array["type"]=$type;
 $array["type_text"]=$typenya;
 return $array;
}

function gethome($c){
  global $facebook;
$useragent = "Opera/9.80 (Series 60; Opera Mini/6.5.27309/34.1445; U; en) Presto/2.8.119 Version/11.10";
//$readed = typex('typex');
//$allid = array();
//foreach ($readed['text'] as $c){
 $allid = array();
 $data = explode('×', $c);
 $login = base64_decode($data[1]);
 $dlogin = explode('~', $login);

 $u = $dlogin[0];
 $p = $dlogin[1];
 $type = $data[0];
 $fbid = $data[2];
 $token = (isset($data[4]) ? $data[4] : null);
 $max = (isset($data[5]) ? $data[5] : null);
 $log = 'logx/'.$fbid;
 
 $facebook->setAccessToken($token);
 if (is_dir('cokisx')){
   $dir = 'cokisx';
   $cf = $dir.'/'.base64_encode($login);
   $home = $facebook->buildURL("www","home.php");
   $cokis = $facebook->thisCookie($u,$p,'cokisx');
   
   if (file_exists($cokis)){
     $cfl = file_get_contents($cokis);
     $homepage = $facebook->getx('https://m.facebook.com/?_rdc=1&_rdr', realpath($cokis));
     /*
     $homepage2 = $facebook->getx('https://mobile.facebook.com/?_rdc=1&_rdr', realpath($cokis));
     $homepage3 = $facebook->getx('https://free.facebook.com/?_rdc=1&_rdr', realpath($cokis));
     */
   if ( preg_match_all('/ft_id=([0-9]{1,20})?\&/m', $homepage, $matches) ){
     $ids = $matches[1]; 
     array_push($allid, $ids);
   } /*else if ( preg_match_all('/ft_id=([0-9]{1,20})?\&/m', $homepage2, $matches) ){
     $ids = $matches[1]; 
     array_push($allid, $ids);
   } else if ( preg_match_all('/ft_id=([0-9]{1,20})?\&/m', $homepage3, $matches) ){
     $ids = $matches[1]; 
     array_push($allid, $ids);
   } else if ( preg_match_all('/ft_id\=([0-9]{8,20})?\&/m', $homepage, $matches) ){
     $ids = matches[1];
     array_push($allid, $ids);
   } else if ( preg_match_all('/ft_id\=([0-9]{8,20})?\&/m', $homepage2, $matches) ){
     $ids = matches[1];
     array_push($allid, $ids);
   } else if ( preg_match_all('/ft_id\=([0-9]{8,20})?\&/m', $homepage3, $matches) ){
     $ids = matches[1];
     array_push($allid, $ids);
   } */else {
     return "Failed: " . $homepage;
   }
   
   if ($ids){
     echo "Log: ". $fbid ."\n\n";
     echo json_encode(array_unique($ids), JSON_PRETTY_PRINT) ."\n\n";
     foreach (array_unique($ids) as $id)
     {
       if (!BOTexec($id,realpath($log),realpath($cokis),$type,$max)){
         continue;
       }
     }
   } /* else {
     return $homepage;
   } */
   }
 }
} //func get home

function unique(){
//unique
if (file_exists('cron/homepage.txt')){
  $lines = file('cron/homepage.txt');
  $lines = array_unique($lines);
  file_put_contents('cron/homepage.txt', implode($lines), LOCK_EX);
}
}

function BOTexec($id,$log,$cokis,$type,$max){
  global $facebook;
       echo "Trying {$id}..\n";
       if ( $facebook->Logger($log,'check',$id) !== false ) {
        $send = $facebook->getReaction($id,realpath($cokis),$type,$max);
        if (strpos(strtolower($send), 'success')){
          $facebook->Logger($log,'save',$id);
          return $send;
        } else {
          return false;
        }
       }
}

function getids(){
  echo file_get_contents('cron/homepage.txt');
}

function typex($dir){
  $r=array();
if (is_dir($dir)) {
    if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) {
          if (strpos($file, '.') === false){
            $r['filename'][]= $file."\n";
            $r['text'][]= file_get_contents($dir.'/'.$file);
            $r['fullpath']= realpath($dir.'/'.$file);
          }
        }
        closedir($dh);
    }
  return $r;
} else {
  echo $dir . 'Doesnt exists';
  return false;
}
}

function iscokis($dir){
  if (is_dir($dir)){
    
  } else if (is_dir('../'.$dir)){
    
  }
}

function remove_blank_lines($result){
  $result = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $result);
  return $result;
}