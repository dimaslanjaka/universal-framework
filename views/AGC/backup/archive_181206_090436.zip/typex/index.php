<?php
header('Content-Type: application/json');

$js = array();
if ($handle = opendir('.')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
          if (strpos($entry, ".php") === false){
            $js[]= 'http://'.$_SERVER["HTTP_HOST"].'/instagram/'.basename(__DIR__)."/$entry\n";
          }
        }
    }

    closedir($handle);
}
/*
if (isset($_GET["admin"])){
echo json_encode($js);
}*/