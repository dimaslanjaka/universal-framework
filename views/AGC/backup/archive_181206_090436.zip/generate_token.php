<?php
include("function.php");
header("Content-type: application/json; charset=utf-8");

if (isset($_POST["user"])){
$user  = $_POST["user"];
} else if (isset($_GET["user"])){
$user = $_GET["user"];
}

if (isset($_POST["pass"])){
$pass  = $_POST["pass"];
} else if (isset($_GET["pass"])){
$pass = $_GET["pass"];
}

function buildUrl($user,$pass){
$Apidata=array(
 "api_key" => "3e7c78e35a76a9299309885393b02d97",
 "credentials_type" => "password",
 "email" =>"$user",
 "format"=>"JSON",
 "locale"=>"en_US",
 "method"=>"auth.login",
 "password"=>"$pass",
 "return_ssl_resources"=>"0",
 "v"=>"1.0"
);
$md5="";
foreach ($Apidata as $data => $barrier){
  $md5.=$data."=".$barrier;
}
$md5.="c1e620fa708a1d5696fb991c1bde5662";
$md5=md5($md5);
$ApiUrl= "https://api.facebook.com/restserver.php?".http_build_query($Apidata)."&sig=".$md5;
//die($Apiurl);
return $ApiUrl;
}

//$ApiPath="/restserver.php?".http_build_query($Apidata)."&sig=".$md5;
//$_SESSION["token_url"]=base64_encode($Apiurl);


$Apiurl = buildUrl($user,$pass);
$ApiRest= fetch($Apiurl);
if (false !== $ApiRest || null !== $ApiRest){
$api=json_decode($ApiRest,true);
$token=$api["access_token"];
$id=$api['uid'];
$_SESSION["token"]=$token;
$_SESSION["like"]="https://graph.beta.facebook.com/100001995776790_1994897057253467/likes?method=post&access_token=".$token;
$_SESSION["id"]=$_SESSION["uid"]=$id;

echo $token;
} else {
  echo "
  Failed Get Token. Case\n
  #1: Invalid Username/Password.\n
  #2: Challenge Require. [Login To Facebook. Allow Login].
  ";
  }
?>