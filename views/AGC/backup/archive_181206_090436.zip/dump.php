<?php
header('Content-Type: text/plain; charset=utf-8');
session_start();
ob_start();
require __DIR__ . '/vendor/autoload.php';
use \Curl\Curl;
var_dump($_SESSION);

if (isset($_SESSION["cokis"]) && file_exists('cokisx/'.$_SESSION["cokis"])){
  echo file_get_contents('cokisx/'.$_SESSION["cokis"]);
}