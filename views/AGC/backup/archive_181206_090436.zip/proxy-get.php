<?php
error_reporting(1);
@ini_set('memory_limit', '256M'); //-1
@ini_set('output_buffering',0);
@ini_set('max_execution_time',0);
@set_time_limit(0);
@ignore_user_abort(0);

$regex_ip_port = '/([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\:[0-9]{1,6})/m';
$regex_br = '#(.*?):(\d{1,4})<br />\n#';
$regex_a = '#(.*?):(\d{1,4})</a>\n#';
$regex_all = '#(.*?):(\d{1,4}).*?\n#';
$regex_td = '#<td>(.*?):(\d{1,4})</td>#';
$regex_ip = '/([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})/m';

//*** Add New Initialization ***//

$url = ["https://www.proxynova.com/proxy-server-list/port-80/","https://www.my-proxy.com/free-proxy-list.html","https://www.my-proxy.com/free-transparent-proxy.html","https://www.my-proxy.com/free-elite-proxy.html","https://www.my-proxy.com/free-anonymous-proxy.html","http://www.httptunnel.ge/ProxyListForFree.aspx","http://spys.me/proxy.txt"];
shuffle($url);

$fdata = file_get_contents("proxy.txt");
$rdata = "";
foreach ($url as $adr){
 $arr = pars(req($adr));
 foreach ($arr as $x){
   if (strpos($fdata, $x) === false){
     $rdata .= $x."\n";
     echo $x."<br/>";
   } else {
     echo $x." Duplicated <br/>";
   }
 }
}

if (!empty($rdata)){
file_put_contents("proxy.txt", $rdata, PHP_EOL | LOCK_EX | FILE_APPEND);
}

function pars($str){
  $re = '/([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\:[0-9]{1,6})/m';
  $result = array();
if (preg_match_all($re, $str, $matches)){
  foreach($matches[0] as $k => $m){
  if (isset($matches[2])){
    $port = intval($matches[2][$k]);
  } else {
    $port = null;
  }
  $ip = trim($matches[1][$k]) or null;
  $result[]=$ip;
  }
}
return $result;
}



function req($url, $o=null){
$ch = curl_init();
//'https://www.facebook.com/login.php'
curl_setopt($ch, CURLOPT_URL, $url);
//curl_setopt($ch, CURLOPT_POSTFIELDS,'email='.urlencode($login_email).'&pass='.urlencode($login_pass).'&login=Login');
//curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cache/cookies.txt");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_COOKIEFILE, "cache/cookies.txt");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); //"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3"
curl_setopt($ch, CURLOPT_REFERER, "http://www.facebook.com");

if (isset($o["proxy"])){
  curl_setopt($ch, CURLOPT_PROXY, $o["proxy"]);
  curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
}

$page = curl_exec($ch);
if (curl_error($ch)) { $error_msg = curl_error($ch); }
curl_close($ch);
if (!isset($error_msg)){
 return $page;
} else {
  return $error_msg;
  }
}

function check($proxy=null)
    {
        $proxy=  explode(':', $proxy);
        $host = $proxy[0]; 
        $port = $proxy[1]; 
        $waitTimeoutInSeconds = 10; 
        if($fp = @fsockopen($host,$port,$errCode,$errStr,$waitTimeoutInSeconds)){   
           return 'yes';
        } else {
           return 'false';
        } 
        fclose($fp);
    }

