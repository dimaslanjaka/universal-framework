/*
 * Facebook Data Barrier Generator [REST API]
 */
//#https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.min.js
function encodeQueryData(data) {
   const ret = [];
   for (let d in data)
     ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
   return ret.join('&');
}
function md5(a, b) {
        var c = "",
            d = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, a, Utilities.Charset.UTF_8);
        if (!b) {
            for (i = 0; i < d.length; i++) {
                var e = d[i];
                if (e < 0) {
                    e += 256
                };
                if (e.toString(16).length == 1) {
                    c += "0"
                };
                c += e.toString(16)
            }
        } else {
            for (j = 0; j < 16; j += 8) {
                e = (d[j] + d[j + 1] + d[j + 2] + d[j + 3]) ^ (d[j + 4] + d[j + 5] + d[j + 6] + d[j + 7]);
                if (e < 0) {
                    e += 1024
                };
                if (e.toString(36).length == 1) {
                    c += "0"
                };
                c += e.toString(36)
            }
        };
        return c.toLowerCase()
    }
var a = {
            "api_key": "3e7c78e35a76a9299309885393b02d97",
            "email": "username",
            "format": "JSON",
            "locale": "en_us",
            "method": "auth.login",
            "password": "password",
            "v": "1.0"
        };
        var b = "";
        for (var x in a) {
            b += x + "=" + a[x]
        }
        b += "c1e620fa708a1d5696fb991c1bde5662";
md5=CryptoJS.MD5(b);
/*
document.write(b + ":" + md5);
document.write("<hr>");
document.write("https://b-api.facebook.com/restserver.php?"+encodeQueryData(a)+"&sig="+md5);
*/

/*
var robot = {
    "email": "zuck@gmail.com",
    "user_password": "kasih tau gak ya",
    "type": {
        "like": false,
        "love": false,
        "haha": false,
        "wow": false,
        "sad": false,
        "angry": false,
        "random": true
    }
};

var aing = {
    sp: PropertiesService.getScriptProperties(),
    acak: function (a) {
        return a[Math.floor(Math.random() * a.length)]
    },
    aduk: function (a) {
        var b = a.length,
            c, d;
        while (0 !== b) {
            d = Math.floor(Math.random() * b);
            b -= 1;
            c = a[b];
            a[b] = a[d];
            a[d] = c
        }
        return a
    },
    getApi: function (huh) {
        var a = UrlFetchApp.fetch(huh, {
            muteHttpExceptions: true,
            method: "get",
            followRedirects: false,
            headers: {
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) Gecko/20100101 Firefox/54.0"
            }
        }),
            b = JSON.parse(a.getContentText());
        return b
    },
    setApi: function (huh, pl) {
        var a = UrlFetchApp.fetch(huh, {
            muteHttpExceptions: true,
            method: "post",
            payload: pl,
            followRedirects: false,
            headers: {
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) Gecko/20100101 Firefox/54.0"
            }
        }),
            b = JSON.parse(a.getContentText());
        return b
    },
    md5: function (a, b) {
        var c = "",
            d = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, a, Utilities.Charset.UTF_8);
        if (!b) {
            for (i = 0; i < d.length; i++) {
                var e = d[i];
                if (e < 0) {
                    e += 256
                };
                if (e.toString(16).length == 1) {
                    c += "0"
                };
                c += e.toString(16)
            }
        } else {
            for (j = 0; j < 16; j += 8) {
                e = (d[j] + d[j + 1] + d[j + 2] + d[j + 3]) ^ (d[j + 4] + d[j + 5] + d[j + 6] + d[j + 7]);
                if (e < 0) {
                    e += 1024
                };
                if (e.toString(36).length == 1) {
                    c += "0"
                };
                c += e.toString(36)
            }
        };
        return c.toLowerCase()
    },
    buildUrl: function (a, b) {
        var c = "";
        for (var d in b) {
            var e = b[d];
            c += encodeURIComponent(d) + "=" + encodeURIComponent(e) + "&"
        }
        if (c.length > 0) {
            c = c.substring(0, c.length - 1);
            a = a + "?" + c
        }
        return a
    },

    ambilToket: function () {
        var a = {
            "api_key": "3e7c78e35a76a9299309885393b02d97",
            "email": robot.email,
            "format": "JSON",
            "locale": "en_us",
            "method": "auth.login",
            "password": robot.user_password,
            "v": "1.0"
        };
        var b = "";
        for (var x in a) {
            b += x + "=" + a[x]
        }
        b += "c1e620fa708a1d5696fb991c1bde5662";
        b = aing.md5(b);
        if (b) {
            Logger.log("Getting access_token...");
            var c = aing.buildUrl("https://b-api.facebook.com/restserver.php", a);
            c += "&sig=" + b
        }
        var d = aing.getApi(c);
        if (d && d.access_token) {
            Logger.log("Get access_token success");
            aing.sp.setProperty("toket", d.access_token)
        } else {
            Logger.log(d.error_msg);
            aing.sp.setProperty("toket", "")
        }
    }
};

function reaction() {
    var toket = aing.sp.getProperty("toket");
    if (toket != null && toket !== "") {
        var a = aing.getApi("https://b-graph.facebook.com/me?access_token=" + toket);
        if (a && a.id) {
            var b = aing.getApi("https://b-graph.facebook.com/me/home?access_token=" + toket + "&fields=id&limit=5");
            if (b && b.data && b.data.length != 0) {
                for (x in b.data) {
                    var c = aing.getApi("https://b-graph.facebook.com/" + b.data[x].id + "/reactions?access_token=" + toket + "&limit=100"),
                        d = "y";
                    if (c && c.data && c.data.length != 0) {
                        for (z in c.data) {
                            if (c.data[z].id == a.id) {
                                d = "n";
                                break
                            }
                        }
                    }
                    if (robot.type.like) {
                        aing.type = "LIKE"
                    } else if (robot.type.love) {
                        aing.type = "LOVE"
                    } else if (robot.type.haha) {
                        aing.type = "HAHA"
                    } else if (robot.type.wow) {
                        aing.type = "WOW"
                    } else if (robot.type.sad) {
                        aing.type = "SAD"
                    } else if (robot.type.angry) {
                        aing.type = "ANGRY"
                    } else if (robot.type.random) {
                        var tp = ["LIKE", "LOVE", "WOW", "HAHA", "SAD", "ANGRY"];
                        aing.type = aing.acak(tp)
                    }
                    if (d == "y") {
                        var e = aing.setApi("https://b-graph.facebook.com/" + b.data[x].id + "/reactions", {
                            access_token: toket,
                            type: aing.type
                        });
                        if (e.success) {
                            Logger.log(b.data[x].id + " -> OK")
                        } else {
                            Logger.log(b.data[x].id + " -> ERROR")
                        }
                    }
                }
            }
        } else {
            Logger.log(a.error.message);
            aing.sp.setProperty("toket", "")
        }
    } else {
        aing.ambilToket()
    }
}*/