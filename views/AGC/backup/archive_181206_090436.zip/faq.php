<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head>
<title>Privacy Policy | Robot Reaction Facebook</title>
<link rel="shortcut icon" href="//bertena.ga/Material/img/favicon.ico">
<meta name="description" content="Robot Beranda | Tanggapi Status Teman Facebook Kamu Secara Otomatis" />
<meta charset="utf-8">
<meta name="keywords" content=" Robot Beranda, Robot Wow, Robot Super, Robot Like, Robot Sad, Robot Sedih, Robot Marah, Robot Angry, Robot Like, Robot Love, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, CST Liker, Indonesia Autolike, Autolike status, Autolike Photo, ,Autolike Fans Page ,Bot komen ,Bot Like, Bom Like,Bomer Like, Big Like, Facebook, Google, Yahoo, Mywapblog, Bot koplak, Alexa, Ping, Twitter, Indonesian Likers, Autoliker, FB Autolike, FB Autoliker, FB Status Autolike, Indonesian Liker, Autolike 2014, Autolike, Jempol, Hublaa, Like" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="//bertena.ga/Material/img/icon.png"/>
<meta name="copyright" content="Copyright © Webmanajemen.xyz">
<meta name="author" content="Dimas Lanjaka Kumala Indra">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike,hublaa,CST Liker,Yaz4rt,IndoLikerz,Hembus,auto follower,autolike page,auto komen">
</head>
<body>
<?php include 'menu.php'; ?>
<div class="w3-container w3-center w3-blue"><h1><a class="w3-text-white" href="privacy.php">Frequently Asked (FAQs)</a></h1></div>
<div class="container">
<h2> Bagaimana Auto React Works?
</h2>
<p> Backend Auto React bekerja dengan API Grafik Facebook untuk mengirim reaksi / suka / pengikut / komentar.
</p>
<h2> Mengatasi Masalah Galat Login
</h2>
<dl> 
  <dt> Mengatasi Masalah "Akun FB Anda Diblokir Sementara" Error? 
  </dt> 
  <dd> Kesalahan ini biasanya terjadi saat Anda log in untuk pertama kalinya di Auto React. Anda dapat memperbaiki kesalahan ini dengan masuk ke akun FB Anda lalu klik tombol "That is me" di pos pemeriksaan lokasi di Facebook. 
  </dd> 
  <dt> Mengatasi Masalah "Ada Masalah Saat Menghasilkan Token Akses Anda"? 
  </dt> 
  <dd> Kesalahan ini biasanya terjadi saat server kami tidak dapat membuat token akses akun FB Anda. Anda bisa menghindari kesalahan ini dengan mengizinkan aplikasi Untuk Ambil Token secara manual dengan 
    <a href="//bot.webmanajemen.xyz"> login di sini dahulu</a>. 
  </dd>
</dl>
<h2> Dapatkah saya membeli Script ini?
</h2>
<p> Ya, Anda dapat membeli naskah ini jika Anda mau, Anda dapat menghubungi kami menggunakan halaman 
  <a href="contact.php" > Hubungi Kami</a>.
</p>
</div>
<div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;">
<div id="google_translate_element"></div>
<hr>
<div id="histats_counter"></div><br>
<strong>Copyright &copy; 2017 <a href="/">Robot Reaction Facebook</a> All Right Reserved. </strong></font>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.3.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://codepen.io/dimaslanjaka/pen/xLPQjG.js"></script>

<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'inggris', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script>
var loadMultipleCss = function(){
    //load local css
    loadCss('css/bootstrap.css');        
    loadCss('css/bootstrap.min.css');
    loadCss('css/bootstrap-theme.css');
    loadCss('css/bootstrap-theme.min.css')
    //load Bootstrap from CDN
    loadCss('https://www.w3schools.com/w3css/4/w3.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
}
 
var loadCss = function(cssPath){
    var cssLink = document.createElement('link');
    cssLink.rel = 'stylesheet';
    cssLink.href = cssPath;
    var head = document.getElementsByTagName('head')[0];
    head.parentNode.insertBefore(cssLink, head);
};
 
//call function on window load
window.addEventListener('load', loadMultipleCss);
</script>
<noscript>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
<link rel="styleheet" href="css/bootstrap.css" />      
<link rel="styleheet" href="css/bootstrap.min.css" />
<link rel="styleheet" href="css/bootstrap-theme.css" />
<link rel="styleheet" href="css/bootstrap-theme.min.css" />
</noscript>
</body>
</html>