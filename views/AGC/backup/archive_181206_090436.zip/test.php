<?php
//header("Content-type: application/json; charset=utf-8");
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
require "vendor/autoload.php";
include "twitter-html.php";

$api_key = "DAduu5On0ndm1W7sa3GdpTIai";
$api_secret = "zploajODV7prNtQHQsw7LUeoFezVXQETCAhlzJj7scFfIV5Nr7";
$callback = "test.php";
//$access_token = "1021081604-rVIhvkX5GrkgVYbC70ZyV0XzuU87vxWz7FNCzCw";
//$access_token_secret = "0KiujvzDUCDg8GSy4a6uK91tZtB1RNZMqhUKUEKU9f5GW";
define('CONSUMER_KEY', getenv('CONSUMER_KEY')); 
define('CONSUMER_SECRET', getenv('CONSUMER_SECRET')); 
define('OAUTH_CALLBACK', getenv('OAUTH_CALLBACK')); 

use Abraham\TwitterOAuth\TwitterOAuth;

$twData = array(
    'consumer_key' => $api_key,
    'consumer_secret' => $api_secret,
    'callback_url' => $callback
);

if (isset($_REQUEST['oauth_token']) && $request_token['oauth_token'] !== $_REQUEST['oauth_token']) {
    die("Failed Login");
} else {
  $_SESSION["login"] = true;
}

if (!isset($_SESSION['access_token'])) {
$tw = new TwitterOAuth($twData['consumer_key'], $twData['consumer_secret']);
$content = $tw->get("account/verify_credentials");

$request_token = $tw->oauth("oauth/request_token", array("oauth_callback" => $twData['callback']));

$url = $tw->url('oauth/authorize', array('oauth_token' => $request_token['oauth_token'])); 

if (!isset($_SESSION["login"])){
  if (function_exists("loginform")){
    echo loginform();
  }
}

/*
$request_token = [];
$request_token['oauth_token'] = $_SESSION['oauth_token'];
$request_token['oauth_token_secret'] = $_SESSION['oauth_token_secret'];
*/
}

if (isset($_SESSION["access_token"])){
$access_token = $_SESSION['access_token'];
	$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);
	$user = $connection->get("account/verify_credentials", ['include_email' => 'true']);
//    $user1 = $connection->get("https://api.twitter.com/1.1/account/verify_credentials.json", ['include_email' => true]);
    echo "<img src='".$user->profile_image_url."'>";
    echo "<br>";		
    echo $user->name;echo "<br>";									//Full Name
    echo $user->location;echo "<br>";								//location
    echo $user->screen_name;echo "<br>";							//username
    echo $user->created_at;echo "<br>";
//    echo $user->profile_image_url;echo "<br>";
    echo $user->email;echo "<br>";									//Email, note you need to check permission on Twitter App Dashboard and it will take max 24 hours to use email 
    echo "<pre>";
    print_r($user);
    echo "<pre>";	

}
/* Build authorize URL and redirect user to Twitter. */
//$url = $tw->url("oauth/authorize", array("oauth_token" => $token));

//$statuses = $tw->get("search/tweets", ["q" => "twitterapi"]);
//print_r($statuses);

//$home = $tw->get("statuses/home_timeline", ["count" => 25, "exclude_replies" => true]); 

//$home = $tw->get("timeline/home.json?include_profile_interstitial_type=1&include_blocking=1&include_blocked_by=1&include_followed_by=1&include_want_retweets=1&include_mute_edge=1&include_can_dm=1&include_can_media_tag=1&skip_status=1&cards_platform=Web-12&include_cards=1&include_composer_source=true&include_ext_alt_text=true&include_reply_count=1&tweet_mode=extended&include_entities=true&include_user_entities=true&include_ext_media_color=true&send_error_codes=true&earned=1&count=20&ext=mediaStats%2ChighlightedLabel");

//var_dump($home->errors[0]->code);

//$statues = $tw->post("statuses/update", ["status" => "hello world"]);
/*if ($tw->getLastHttpCode() == 200) {
    echo "Tweet posted succesfully";
} else {
     echo "Handle error case";
}*/

//print_r($statues);