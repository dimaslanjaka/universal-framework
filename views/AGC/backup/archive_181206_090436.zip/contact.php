<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head title="Auto Like">
<title>Robot Reaction Facebook | Contact Us</title>
<link rel="shortcut icon" href="Material/img/favicon.ico">
<meta name="description" content="Autolike and Tools Facebook Working 2017"/>
<meta charset="utf-8">
<meta name="keywords" content="Auto Like Facebook, Autolike, Autolikes, Bot Koplak, Bot Like, Bot Comment, Auto Confir, Auto Add, Bomb Likers, Delete Status, Delete Friend, Update status, Tools Facebook, Facebook hack, Adelina.com, Hublaa.me, Official-liker.net, Alexa.com, Facebook.com, Google.com, Seo Facebook, Cara Menggunakan Autolike Facebook, Cara Agar Status Facebook banyak Liker, Mrzonk, Autolike.in, Berti.ga, Autolike India, Autolike Indonesia, Best Autolike Facebook, Autolikr Yang Masih Jalan, Autolike 2016, Lagu Herp.ga, Bot Reaction"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="/Material/img/logo.png"/>
<meta http-equiv="expires" content="0">
<meta name="copyright" content="Copyright © webmanajemen.xyz">
<meta name="author" content="Dimas Lanjaka Kumala Indra">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike facebook, Bot koplak, Bot somplak, Robot Beranda, Auto Add Friend, Confir Friend, Delete Status, Delete friend, Multy Post, Update status, motivasi, lucu, kocak, ramdhan, kutipan, Htc Sense, Nokia, Cara menggunakan autolike, Autolike Aman, Autolike 200+, bot koplak, hublaa, Zonk, ifur, Ahmad Saepur Ramdan, Autolike google, Cara agar status facebook banyak like,Autolike No Spam, Custom Like, autolike facebook, Bot koplak, Bot somplak, Robot Beranda, Auto Add Friend, Confir Friend, Delete Status, Delete friend, Multy Post, Update status, motivasi, lucu, kocak, ramdhan, kutipan, Htc Sense, Nokia">
</head>
<body>
<?php include 'menu.php'; ?>
<div class="w3-container w3-center w3-teal"><h1>Contact Information</h1><p>If You Any Question Please Contact Us</p></div>
<div class="container">
<div class="panel panel-primary">
<div class="panel-heading"><h2>Contact webmanajemen.xyz admin</h2></div><div class="panel-body">
<div class="container">
<li class="list-group-item">Author : Dimas Lanjaka
<li class="list-group-item">Email : admin@webmanajemen.xyz</li>
<li class="list-group-item">Facebook : <a href="https://www.facebook.com/dimaslanjaka1">Visit</a></li>
<li class="list-group-item">Twitter : <a href="https://twitter.com/DimasSkynetCybe">Visit</a></li>
<li class="list-group-item">Instagram : <a href="https://www.instagram.com/dimaslanjaka/">Visit</a></li></div></div></div>
<div class="panel panel-primary">
<div class="panel-heading"><h2>Contact Submissions webmanajemen.xyz admin</h2></div>
<script type="text/javascript" src="https://form.jotform.me/jsform/71051612971451"></script><noscript><iframe id="JotFormIFrame-71051612971451" allowtransparency="true" src="https://form.jotform.me/71051612971451" frameborder="0" width="100%" height="730px" scrolling="no"> </iframe></noscript>
</div></div>
<div class="progress progress-striped active">
<div class="progress-bar" style="width: 100%"></div></div>
<div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;">
<div id="google_translate_element"></div>
<hr>
<div id="histats_counter"></div><br>
<strong> Copyright &copy; 2017 webmanajemen.xyz All Right Reserved. </strong></font>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.3.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://codepen.io/dimaslanjaka/pen/xLPQjG.js"></script>
<script>
var loadMultipleCss = function(){
    //load local css
    loadCss('css/bootstrap.css');        
    loadCss('css/bootstrap.min.css');
    loadCss('css/bootstrap-theme.css');
    loadCss('css/bootstrap-theme.min.css')
    //load Bootstrap from CDN
    loadCss('https://www.w3schools.com/w3css/4/w3.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
}
 
var loadCss = function(cssPath){
    var cssLink = document.createElement('link');
    cssLink.rel = 'stylesheet';
    cssLink.href = cssPath;
    var head = document.getElementsByTagName('head')[0];
    head.parentNode.insertBefore(cssLink, head);
};
 
//call function on window load
window.addEventListener('load', loadMultipleCss);
</script>
<noscript>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
<link rel="styleheet" href="css/bootstrap.css" />      
<link rel="styleheet" href="css/bootstrap.min.css" />
<link rel="styleheet" href="css/bootstrap-theme.css" />
<link rel="styleheet" href="css/bootstrap-theme.min.css" />
</noscript>
<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'inggris', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs2.uzone.id/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582ECSaLdwqSpnCgur28FUm401VrTNseDf2JlEA6ZiOk%2ffQK22KycK5kPdVDjpnejkM9P73Pe7Y6EuuaOitYkmzmKNO8RUzaFdaIXn6R7NkvKk9cKCHQzyvNXXPs%2bsueqLp2EKbC6X0Nu38%2fmvVexzHBsuqHkiQG%2bNd%2bm8E%2f1Gq6XVEDRBd4yBsks3piKPJIEbKaNRdQVxqlbqy5Bs6h0iSFn8zyf11ihllrf6ZNmrJse7MMGOa5Bg8V4gb29r7%2bHjvRblYlXTzoDaVMg79rr8%2fNSZ6ssVfsxi0UIiVvCjFalmdmUa4D3V21bRqM4cgubmchEbbS%2bil%2bkh%2bMxt3Lc4cILEYiziKexsYIRCUr4wR%2fPBUNQ0j4IIx1jEuAgOLeRdwvvw4aFM0V1i21bvKCvX8DaMIllnngEEJ09Ev%2fVl90I1UyrYKv6AaTOlPRBinecqub0KT%2flfLk3J5BMJsGhRjFCfISXqn01lRdvFPPMPwF0W10PRF8Of4%2feqOmNt6%2f1%2bIe66Xn2XLzyo%2fXuwHgr8%2fESw2BJ%2fexkP13jBCMQ6mGWGfQ671Tl0qDCRxz3%2fSr7a%2fgD3rwBAepraDryNlMplNKwfDkn1RshIR2yOHd%2fT9f%2bWyzvKgo2q%2bBVg19biKxt2MA%2b51lkpH9op3ufeUcUr06SkECqC57ZaT0Gy%2btFzIpw7WrVWNOUR2IagZkIGRtvs8fT78yLbMJYt7QL2KA1NeaqJ1oxvPiRhbpzwbaEvCh2IpkWW4arhunYT9DWgF1jaNRjn1c6n%2fzCUZvEw8o0sgvMEHBsLP0VK4Q%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>
</html>