<?php
header('Access-Control-Allow-Origin: *');
//require_once("maintenance.php");
error_reporting(0);
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
require_once 'ajax/assets/facebook-sdk/facebook.php';
require "html.php";
  $facebook    = new Facebook(array(
   'appId'  => '6628568379',
   'secret' => md5('{Your-app-secret}'),
   'cookie' => true
  ));

      if (!is_dir("cokisx")){
        $oldmask = umask(0);
        mkdir("cokisx", 0777);
        umask($oldmask);
      }
      if (!is_dir("logx")){
        $oldmask = umask(0);
        mkdir("logx", 0777);
        umask($oldmask);
      }
      if (!is_dir("typex")){
        $oldmask = umask(0);
        mkdir("typex", 0777);
        umask($oldmask);
      }
      if (!is_dir("userid")){
        $oldmask = umask(0);
        mkdir("userid", 0777);
        umask($oldmask);
      }

if(isset($_POST["email"])){
   $a=$_SESSION["a"]=$_POST["email"];
   $b=$_SESSION["b"]=$_POST["pass"];
   $c=$_SESSION["c"]=$a.'~'.$b;
       $login=array(
       'email' => $a,
       'pass' => $b,
       'login' => 'Log in',
       );
$_SESSION["cokis"] = $_SESSION["base64"] = $cokis = base64_encode($c);
$cookie = 'cokisx/'.$cokis;

$o["cokis"] = $cookie;
$o["user"] = $a;
$o["pass"] = $b;

if (file_exists($cookie)){
  try {
  $facebook->curl( "http://free.facebook.com",$cookie );
  }
  finally {
  Check($cookie);
  }
} else {
  $facebook->createCookie($a, $b, $cookie);
  login($o);
  Check($cookie);
}
}

if (isset($_POST["token"])){
  $_SESSION["token"] = $_POST["token"];
  $facebook->setAccessToken($_POST["token"]);
  $d = $facebook->userData();
  if ($d !== false){
    $_SESSION["uid"] = $_SESSION["id"] = $d;
  }
  file_put_contents("tokens/".$_SESSION["base64"], $_POST["token"], LOCK_EX);
}

function Check($cookie){
  global $facebook;
$cokis = $_SESSION["cokis"];
$file=file_get_contents($cookie);

if ($facebook->verifyCokis($file) == "success"){
  $_SESSION["nama"]= $_SESSION["cokis"];
  header('Location: panel.php');
  die();
} else if ($facebook->verifyCokis($file) == "credentials invalid" || $facebook->verifyCokis($file) === false){
$head = "Data Facebook Salah";
head($head);
      echo '<div class="container"><div class="alert alert-info"><button type="button" class="close" data-dismiss="alert">&times;</button><b>INFO: </b>Gunakan Kode Negara (+62 Untuk Indonesia) Jika Email Menggunakan Nomer Ponsel, Saya Sarankan sih Pake Username Aja</div></div><p>'; 
$apa ='<b>INFO: </b>Email/Password Salah, Silahkan Coba Lagi..</div></div><p>';
eror($apa);
      home("login-fb.php");
      footer();
      unlink('cokisx/'.$_SESSION["cokis"]);
      die();
} else if ($facebook->verifyCokis($file) == "checkpoint"){
  unlink('cokisx/'.$_SESSION["cokis"]);
  $head = "Robot Reaction Beranda";
  $apa='<b>INFO: </b>Akun Kamu Terkunci Silahkan Buka <a target="_blank" href="https://web.facebook.com/login?email=your_email@domain.com">Facebook</a> dan Verif Akun Facebook Kamu. Setelah Akun Sudah Terbuka. Kembali Lagi <a href="/">Kesini</a>, dan Ulangi.';
  head($head); 
  eror($apa); 
  home("login-fb.php");
  footer();
  die();
}

}

if (isset($_GET["Hapus"])){
$cinta = $_SESSION['id'];
$data = $_GET["Hapus"];
if (file_exists("cokisx/".$data)){
@unlink('cokisx/'.$data);
}
if (file_exists("logx/".$cinta)){
@unlink('logx/'.$cinta);
}
if (file_exists("typex/".$cinta)){
@unlink('typex/'.$cinta);
}
session_destroy();
$head = "Penghapusan Robot Berhasil";
head($head);
$eror= 'Data Berhasil Dihapus Diserver Kami, Bot Tidak akan Berjalan Lagi';
eror($eror);
home("login-fb.php");
footer();
exit;
} else if (isset($_SESSION["nama"]) && !isset($_GET["Hapus"])){
header('Location: panel.php');
} else {
  $head = "Robot Reaction Facebook";
  head($head);
  if (!isset($_SESSION["show_info"])){
  echo $facebook->curl("https://codepen.io/dimaslanjaka/pen/MzMBNo.html","cokisx/default.txt");
  $_SESSION["show_info"]=1;
  }
  body_home("login-fb.php");
  footer();
}

function login($option){
  global $facebook;
  $user = $option["user"];
  $pass = $option["pass"];
  $cokis = $option["cokis"];
  if (!$user || !$pass){
    throw new Exception("Username Or Password Required, reload this page");
  }
 return $facebook->doLogin($user, $pass, $cokis);
}
function auto($url, $cookie){
   global $facebook;
   return $facebook->curl($url, $cookie, null, $_SERVER["HTTP_USER_AGENT"]);
}

?>