<?php
@ini_set('output_buffering',0);
if (isset($_GET["clean"])){
  file_put_contents("facebook.txt", "", LOCK_EX);
}
  $f_contents = file("proxy-alive.txt", FILE_SKIP_EMPTY_LINES); 
  //$line = $f_contents[array_rand($f_contents)]; 
  //$o["proxy"] = $line;
  $f_contents = array_values(array_filter($f_contents, "trim"));
  $arrs = "";
  for ($i = max(0, count($f_contents)-50); $i < count($f_contents); $i++) {
    $prxs = trim( $f_contents[$i] );
    $rf = FB($prxs);
    if (!empty($rf) && null !== $rf){
    $arrs .= $rf."\n";
    echo $rf."<br/>";
    }
  }
  if (!empty($arrs)){
    file_put_contents("facebook.txt", $arrs, LOCK_EX | FILE_APPEND);
  }

function Rline($file){
  if (file_exists($file)){
  file_put_contents($file, implode('', file($file, FILE_SKIP_EMPTY_LINES)));
  return "$file Success";
  } else {
    return false;
    }
}

function FB($proxy){
  $o["proxy"] = $proxy;
  $fb = "https://www.facebook.com";
  $str = req($fb, $o);  
  $re = '/\<title\>.*facebook.*\<\/title\>/m';
  if (preg_match($re, strtolower($str), $matches)){
    return $proxy;
  } else {
    return null;
  }
}

function req($url=null, $o=null){
$ch = curl_init();
//'https://www.facebook.com/login.php'
curl_setopt($ch, CURLOPT_URL, $url);
//curl_setopt($ch, CURLOPT_POSTFIELDS,'email='.urlencode($login_email).'&pass='.urlencode($login_pass).'&login=Login');
//curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cache/cookies.txt");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_COOKIEFILE, "cache/cookies.txt");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]); //"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3"
curl_setopt($ch, CURLOPT_REFERER, "http://www.facebook.com");

if (isset($o["proxy"])){
  curl_setopt($ch, CURLOPT_PROXY, $o["proxy"]);
  curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
}

$page = curl_exec($ch);
if (curl_error($ch)) { $error_msg = curl_error($ch); }
curl_close($ch);
if (!isset($error_msg)){
 return $page;
} else {
  return $error_msg;
  }
}
