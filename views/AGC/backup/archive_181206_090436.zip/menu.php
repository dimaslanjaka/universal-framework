<nav class="navbar navbar-default">
<div class="container-fluid">
<div class="navbar-header">
<h2><a class="navbar-brand" href="/">Robot Reaction Facebook</a></h2>
</div>
<div class="w3-bar w3-light-grey">
  <a href="login-fb.php" class="w3-bar-item w3-button">Home</a>
  <a href="privacy.php" class="w3-bar-item w3-button">Privacy</a>
  <a href="terms.php" class="w3-bar-item w3-button">Terms</a>
  <a href="faq.php" class="w3-bar-item w3-button">FAQs</a>
  <a href="contact.php" class="w3-bar-item w3-button">Contact</a>
  <a href="logout.php" class="w3-bar-item w3-button">Logout (<i class="text-danger">Flush Cookie</i>)</a>
    <div class="w3-dropdown-hover">
    <button class="w3-button">Tools (<i class='text-danger'>New</i>)</button>
    <div class="w3-dropdown-content w3-bar-block">
      <a href="simulator.php" title="Facebook Login Simulator" alt="Facebook Login Simulator" class="w3-bar-item w3-button">Login Simulator</a>
      <a href="https://web-manajemen.blogspot.com/translator.php" class="w3-bar-item w3-button">Website Translator</a>
      <a href="https://www.google.co.id/url?sa=t&source=web&rct=j&url=https://web-manajemen.blogspot.com/2018/11/script-php-auto-refresh-token-facebook.html%3Fm%3D1&ved=2ahUKEwiIjs7ak4rfAhUGeCsKHWJuCvwQFjAIegQIBxAB&usg=AOvVaw16arKL4rnzLuOCDgNhLpVc" class="w3-bar-item w3-button">Facebook Token Generator</a>
    </div>
  </div>
</div>
</div>
</nav>
