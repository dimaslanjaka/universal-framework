<?php
function getlist($dir="./tokens/removed"){
$thelist="";
if ($handle = opendir($dir)) { //'.'
    while (false !== ($file = readdir($handle)))
    {
        if ($file != "." && $file != ".." && strtolower(substr($file, strrpos($file, '.') + 1)) == 'txt')
        {
            //$thelist .= '<li><a href="'.$file.'">'.$file.'</a></li>';
            $thelist.=$file;
        }
    }
    closedir($handle);
}
return $thelist;
}
?>
<ul>
<?php echo getlist('.'); ?>
</ul>