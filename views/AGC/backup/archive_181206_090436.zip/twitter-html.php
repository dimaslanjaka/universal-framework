<?php

function headhtml($title="Twitter AutoLike Bot",$desc="twitter bot login to access bot autolike twitter",$style=true){
  $head = <<<EOF
  <title>{$title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="description" content="{$desc}"/>
EOF;
  if ($style === true){
  $head .= <<<EOF
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/> <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css'> <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
EOF;
}
$scripts=<<<EOF
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-7975270895217217",
          enable_page_level_ads: true
     });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
EOF;
$head .= $scripts;
if ($style === true){
$head .= "<style>".file_get_contents("https://codepen.io/dimaslanjaka/pen/GwQRJZ.css")."</style>";
}
  return $head;
}

function closehead($head=""){
  return "<head>$head</head>";
}

function closebody($body="",$style=true){
  if ($style === true){
  $body .= file_get_contents("https://codepen.io/dimaslanjaka/pen/GwQRJZ.html"); $body .="<script>".file_get_contents("https://codepen.io/dimaslanjaka/pen/GwQRJZ.js")."</script>";
  }
  return "<body>$body</body>";
}

function formChallenge($form=null){
  $head = headhtml("Twitter BOT Challenge Required","Twitter BOT Challenge");
  $head .= <<<EOF
<style class="cp-pen-styles">
  #form-oauth,#btn-oauth { display: none; }
</style>
EOF;
  $head = closehead($head);
  $frm="";
  return fixhtml($head.closebody($frm));
}

if (!function_exists("fixhtml")){
function fixhtml($html){
$domnew = new \DOMDocument('1.0', 'UTF-8');
libxml_use_internal_errors(true);
$domnew->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
$xpath = new DOMXpath($domnew); 
return $domnew->saveHTML();
}
}

function loginform(){
  $head = headhtml("Twitter BOT Login","twitter bot login to access bot autolike twitter");
  $head .= <<<EOF
<style>
#btn-oauth,#form-challenge { display: none; }
</style>  
EOF;
  $head = closehead($head);
  $body = "";
  $body = closebody($body);
 return fixhtml($head.$body);
}

function oauthbutton($url=null){
  $head = headhtml("Twitter BOT Dashboard","Twitter BOT Dashboard");
  $head .= <<<EOF
<style class="cp-pen-styles">
  #form-oauth,#form-challenge { display: none; }
</style>
EOF;
  $head = closehead($head);
  $body = <<<EOF
  <script>
  
  var btnoauth = "{$url}";
  
  </script>
EOF;
  $body = closebody($body);
  return fixhtml($head.$body);
}

?>