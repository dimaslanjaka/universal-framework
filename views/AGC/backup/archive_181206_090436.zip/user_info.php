<?php
/*
$user_ip = getenv('REMOTE_ADDR');
if (!function_exists("fetch")){
  include("function.php");
}
function geo($ip=null){
  if (null !== $ip){
    $url = "http://www.geoplugin.net/php.gp?ip=$ip";
  } else {
    $url = "http://www.geoplugin.net/php.gp";
  }
$geo = unserialize(fetch($url));
if (false !== $geo || null !== $geo){
  return $geo;
} else {
  return false;
}
}
function geo2(){
  $url = "http://extreme-ip-lookup.com/json/";
  $geo = fetch($url);
  if (false !== $geo || null !== $geo){
  return $geo;
} else {
  return false;
}
}
$geo = geo();
$geo2 = geo2();
echo "<div><pre>";
if (false !== $geo || null !== $geo){
$country = $geo["geoplugin_countryName"];
$city = $geo["geoplugin_city"];
$lat = $geo["geoplugin_latitude"];
$long = $geo["geoplugin_longitude"];
$region = $geo["geoplugin_region"];

foreach ($geo as $name => $value){
  if (!preg_match("/(credit)/m", $name)){
  echo "<red>$name</red>: <green>$value</green><br/>";
  }
}

} else if (false !== $geo2 || null !== $geo2){
  $json = json_decode($geo2,true);
foreach ($json as $name => $value){
  echo "<green>$name</green>: <red>$value</red><br/>";
}
}
echo "</pre></div>";
//echo '<div style="float:left;width: 50%;height:100%"><iframe width="100%" height="600" src="https://maps.google.com/maps?width=100%&height=300&hl=en&coord='.$long.','.$lat.'&ie=UTF8&t=&z=13&iwloc=B&output=embed&q='.$city.','.$region.','.$country.'" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div></div>';
*/
?>

<script>
function locationSuccess(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        var altitude = position.coords.altitude;
        var accuracy = position.coords.accuracy;
        var altitudeAccuracy = position.coords.altitudeAccuracy;
        var heading = position.coords.height;
        var speed = position.coords.speed;
        var timestamp = position.timestamp;

        // bekerja dengan informasi ini sesuka Anda!
    }

    function locationError(error) {
        var code = error.code;
        var message = error.message;

        // baca kode dan pesan dan putuskan bagaimana Anda ingin menangani ini!
    }
navigator.geolocation.getCurrentPosition(locationSuccess, locationError);
</script>