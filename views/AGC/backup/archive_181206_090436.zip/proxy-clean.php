<?php
//------- remove proxy if greater than 10k and 3k left
$log = 'proxy.txt';
$fp = file($log, FILE_SKIP_EMPTY_LINES);
$min = 10000;
$max = count($fp);
$x_amount_of_lines = $max-$min;
//echo ($max."/".$min."/".$x_amount_of_lines."=");
if ($x_amount_of_lines >= 3000){
  $file = file($log);
  $line = $file[0];
  $file = array_splice($file, $min, $x_amount_of_lines);
  file_put_contents($log, implode($file));
  //$file = array_splice($file, 2, $x_amount_of_lines);
  //$file = array_splice($file, 0, 0, array($line, "\n"));
  echo "proxy trimmed ✓<br/>";
}
//------- unique Proxy
UniQue('proxy.txt');
 UniQue('proxy-alive.txt');
  UniQue('facebook.txt');
  
function UniQue($f){
$lines = file($f);
$lines = array_unique($lines);
file_put_contents($f, implode($lines));
echo "$f Filtered ✓ <br/>";
}

//file_put_contents("cache/cache.php", "");
echo "Cleaned ✓";