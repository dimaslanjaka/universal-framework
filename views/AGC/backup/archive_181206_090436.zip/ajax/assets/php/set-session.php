<?php
require_once '../facebook-sdk/facebook.php';
//header('Content-Type: application/json');

$username = (isset($_POST["email"]) ? $_POST["email"] : (isset($_POST["user"]) ? $_POST["user"] : (isset($_POST["username"]) ? $_POST["username"] : (isset($_GET["user"]) ? $_GET["user"] : (isset($_GET["username"]) ? $_GET["username"] : (isset($_SESSION["a"]) ? $_SESSION["a"] : die("Username Required")))))));
$password = (isset($_POST["pass"]) ? $_POST["pass"] : (isset($_POST["password"]) ? $_POST["password"] : (isset($_SESSION["b"]) ? $_SESSION["b"] : die("Password Required"))));
$token = (isset($_GET["accessToken"]) ? $_GET["accessToken"] : (isset($_GET["token"]) ? $_GET["token"] : (isset($_POST["token"]) ? $_POST["token"] : (isset($_SESSION["access_token"]) ? $_SESSION["access_token"] : (isset($_SESSION["accessToken"]) ? $_SESSION["accessToken"] : die("Token Required"))))));
$cf = buildcokis();
$cfc = file_get_contents($cf);
var_dump($token,$username,$password);
if (!empty($token) && ctype_alnum($token)){
        $accessToken = $token;
        
        $facebook    = new Facebook(array(
                                    'appId'  => '6628568379',
                                    'secret' => md5('{Your-app-secret}'),
                                    'cookie' => true
        ));
        
        
  try {
        $userData = $facebook->api('v2.0/me'); //var_export($userData); die();
       
       
       $_SESSION['fb-user-token'] = $accessToken;
       $_SESSION['fb-user']       = $userData;
       if (isset($userData['id'])){
         $id = $userData['id'];
         $re = "/($id)/m";
         if (preg_match($re, $facebook->checkLogin(), $match) && !preg_match('/(checkpoint)/m', $cfc)){
           
           $_SESSION["cokis"] = $cf;
           var_export($match);
           echo "\nLogin Successfull\n";
           echo file_get_contents($_SESSION["cokis"]);
         } else if (preg_match($re, $dologin, $match) && !preg_match('/(checkpoint)/m', $cfc)){
           var_export($match);
           echo "\nLogin Successfull\n";
           echo file_get_contents($cf);
         } else {
           echo $cfc;
           echo "\nLogin Failed, Your account maybe locked. please verify before\n";
         }
       }
       $_SESSION["login"] = $userData['id'];
       $_SESSION["name"] = $userData["username"];
echo json_encode( array('id' => $userData['id'],
 'username' => $userData['username'],
  'first_name' => $userData['first_name'],
  'last_name' => $userData['last_name'],
  'gender' => $userData['gender']
  ), JSON_PRETTY_PRINT);
    } catch (FacebookApiException $e) {
      error_log($e);
 }
} else {
  echo "Nothing";
//header('HTTP/1.1 400');
}
function buildcokis(){
global $username; global $password;
$name = base64_encode($username."~".$password);
$dir = "cokisx/";
$inner = $dir.$name;
$outer = "../../../".$dir.$name;
if (file_exists($inner)){
    $r = $inner;
  } else if (file_exists($outer)){
    $r = $outer;
  } else if (file_exists('/instagram/'.$inner)){
    $r = '/instagram/'.$inner;
  }
  $_SESSION["cokis"] = $dir.$name;
  return $r;
}