<?php
require_once '../facebook-sdk/facebook.php';
require '../../../html.php';
//header('Content-Type: application/json');
header('Origin: https://www.facebook.com');
header('Host: www.facebook.com');
header('Origins: https://www.facebook.com');
header("Access-Control-Allow-Origin: *");
header('X-Frame-Options: DENY');

$username = (isset($_POST["user"]) ? $_POST["user"] : (isset($_GET["user"]) ? $_GET["user"] : (isset($_POST["email"]) ? $_POST["email"] : false)));

$password = (isset($_POST["pass"]) ? $_POST["pass"] : (isset($_GET["pass"]) ? $_GET["pass"] : false));

$token = (isset($_GET["accessToken"]) ? $_GET["accessToken"] : (isset($_GET["token"]) ? $_GET["token"] : (isset($_POST["token"]) ? $_POST["token"] : false)));

if (!$username){
  die("username required");
}
if (!$password){
  die("password required");
}

if (isset($_POST["check"])){
  if (preg_match('/c\_user\s+[0-9]{8,20}/m',file_get_contents($_SESSION['cf']))){
    echo '
    <script>
    window.location.href="/instagram/panel.php";
    </script>
    ';
  }
}

if (!$token){
  head("Get Access Token");
  if (isset($_POST["get_token"])){
  token_init($username,$password);
  form("create-cookie.php");
  } else {
    echo file_get_contents("https://codepen.io/dimaslanjaka/pen/jQdZPb.html");
  }
  footer();
  
} else {
  $accessToken = $token;
  
  $facebook    = new Facebook(array(
   'appId'  => '6628568379',
   'secret' => md5('{Your-app-secret}'),
   'cookie' => true
  ));
  
  $cfl = $_SESSION['cf'] = $facebook->thisCookie($username,$password,'cokisx');
  if (!file_exists($cfl)){
    file_put_contents($cfl, "");
  }
  $facebook->setAccessToken($accessToken);
  head("Cookie Created ✓ | Robot Reaction Facebook");
  if (!preg_match('/c\_user\s+[0-9]{8,20}/m',file_get_contents($cfl))){
  $crk = $facebook->createCookie($username,$password);
  $cht = "<a href='../../../simulator.php?token=$token' class='btn btn-success'>Click Here To Test Your Account</a>";
  } else {
  $crk = "Cookie Already Created ✓";
  $cht = <<<EOF
  <!--button onclick="create();" class="btn-success btn" disabled>Go To Dashboard</button>
  
  <blockquote>If You <b>Not Redirected</b> You can Use <b>button</b> Bellow</blockquote-->
  <form action="/instagram/simulator.php" method="POST" class="form-group">
  <input type="hidden" name="yes" value="yes" />
  <button type="submit" class="btn btn-success">Redirect Now</button>
  </form>
      
  <div>
  <resultx></resultx>
  </div>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <!--script>
  function create(){
    $.post('/instagram/simulator.php', {yes: true}, function(data, status){
      $("resultx").html(data);
    });
    $.post('', {check: true}, function (data, status){
      var first = document.getElementsByTagName('resultx')[0].innerHTML = data;
if (!first){
  $("resultx").html(data+' with JQUERY');
}
    }
  }
  </script-->
EOF;
$cht .= '<blockquote>
 <b class="text-info">Only For Testing Your Accounts For Cookie Matching</b><br/>
  Check Cookies !!!. (<b class="text-danger">Not Recommended</b>)
  </blockquote>
  
  <a class="btn btn-danger d-block" href="/instagram/simulator.php?token='.$token.'">Check My Login</a>';
  //var_dump($token);
  }
  $X = <<<EOF
  <div class='container'>
  <div class="panel panel-info">
  <div class="panel-heading">
  <h3>{$crk}</h3>
  </div>
  <div class="panel-body">
  <div class='text-center'>
EOF;
  $X .= $cht.'
  </div>
  </div>
  </div>';
  echo $X;
  footer();
}

?>