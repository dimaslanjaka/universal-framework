<?php
header("Content-Type: application/json");
require("db.php");/*
$server = array(
"host" => "sql12.freemysqlhosting.net:3306",
"pass" => "c2i3w5EdMa",
"user" => "sql12263992",
"dbname" => "sql12263992"
);*/
$con = mysqli_connect($server["host"], $server["user"], $server["pass"]) or die(mysqli_error($con));
$dbname = $server["dbname"];
 mysqli_select_db($con, $dbname) or die(mysqli_error($con));
 mysqli_query($con, "SET NAMES utf8");
echo "Server: ".$server["host"]."\n";
$query = "SELECT * FROM token_all";
$result = mysqli_query($con, $query);

/*
foreach ($sqln as $sql){
mysqli_query($con, $sql);
}
*/

while($row=mysqli_fetch_array($result,MYSQLI_ASSOC)){
  $id = $row["id"]; 
  $token = $row["token"];
  $user = $row["user"];
  $pass = $row["pass"];
  //file_put_contents("tokens/$id.txt", $token, LOCK_EX);
  echo "REPLACE INTO token_all (token,id,user,pass) VALUES ('$token', '$id', '$user', '$pass')\n";
}

/*
$column = mysqli_query($con, "SHOW COLUMNS FROM token_all");
$exist_us = false;
$exist_ps = false;
$c = mysqli_fetch_assoc($column);

while($c = mysqli_fetch_assoc($column)){
  if ( $c["Field"] === "user" ){
    $exist_us = true;
    //echo "Column user exist";
  }
  if ( $c["Field"] === "pass" ){
    $exist_ps = true;
    //echo "Column pass Exist";
  }
}
//var_dump($exist_us,$exist_ps);
if ($exist_us === false){
  $us = "ALTER TABLE token_all ADD `user` VARCHAR( 255 ) after `id`";
  $result = mysqli_query($con, $us);
  if (false !== $result){
    echo "Column Created";
  }
}
if ($exist_ps === false){
  $ps = "ALTER TABLE token_all ADD `pass` VARCHAR( 255 ) after `user`";
  $result = mysqli_query($con, $ps);
  if (false !== $result){
    echo "Column Created";
  }
}
mysqli_close($con);
*/
?>