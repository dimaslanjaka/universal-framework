<?php
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
@ini_set('output_buffering',0);
@ini_set('max_execution_time',0);
//header("Content-type: application/json; charset=utf-8");
header("Host: free.facebook.com");

	require_once("Instagram.php");
	$curl = new curl();
	function fetch($url, $curlopt=null){
	  global $curl;
	  return $curl->fetch($url, $curlopt);
	}

 $cookies_value = "";/*
if (!isset($_GET["token"])){
echo "Jalankan ini dengan Cronjob 5 menit 1x\n\n";
echo "URL Cronjob: " .  working_domain . strtok($_SERVER["REQUEST_URI"],'?') . "?max=5&token=" . (isset($_GET['token']) ? $_GET['token'] : 'Your_Access_Token') . "\n\n";
echo "You can specify a maximum of posts that will be liked by changing max=5\n\n";
}*/

$curlopt["cookiefile"] = "cache/cookies.txt";

function getToken($dir = 'tokens') {
  $dir=realpath($dir);
  $files = glob($dir . '/*.txt');
  //Die(var_dump($files));
  $file = array_rand($files);
  return $files[$file]; 
}

$token = (isset($_GET['token']) ? $_GET['token'] : /*exit('Please Input ?token=your_access_token_here')*/ null);

if (null === $token){
  $tokenfile = getToken();
  $ctokenfile = file($tokenfile);
  if (!empty($ctokenfile)){
  $token = $ctokenfile[0];
  }
}

global $token;
$max = (isset($_GET['max']) ? $_GET['max'] : "5");
global $max;
$random=["LIKE","LOVE","HAHA","WOW" /*,"SAD /*,"ANGRY"*/];
shuffle($random);
$random = $random[array_rand($random)];
$type = (isset($_GET['type']) ? $_GET['type'] : $random);

if (!empty($token) && !empty($max) && null !== $token){
define("max", $max, true);
define("token", $token, true);
} else { die("token null"); }

$json = fetch("https://graph.facebook.com/v3.2/me/?&access_token=".token, $curlopt);
$json = json_decode($json, true);
$myid = $my_id = $json["id"];
$my_fn = $myfn = $json["name"];
$r_log["fullname"]=$my_fn;
if(strlen(trim(token)) > 100){

//https://b-graph.facebook.com/me?access_token=

function gethome($token, $max){
  $home = "https://graph.facebook.com/v3.2/me/home?access_token=".$token."&limit=".$max."&fields=likes.limit(0).summary(1),comments.field(id,user_likes)";
//$home = "https://graph.beta.facebook.com/me/home?limit=".$max."&access_token=".$token."&fields=id,likes.limit(0).summary(1),comments.field(id,user_likes)";
// fields=id,likes,comments.field(id,user_likes)
//id,comments.summary(1),likes.limit(0).summary(1)
// fields=id,likes.limit(0).summary(1),comments.field(id,user_likes)
global $curlopt;
global $r_log;
global $tokenfile;
$gethome = fetch($home, $curlopt);
$r_log["home"]=$home;
$r_log["homeurl"]="<a href='$home' target='_blank'>Home</a>";
//var_dump($gethome);
$json = utf8_encode($gethome);
$json = json_decode($json, true);
if (null !== $gethome){
  $r_log["next"]=urldecode($json["paging"]["next"]);
  return $gethome;
 } else if (isset($json[0]["error"])){
  $r_log["errors"].="$tokenfile Token Error";
  //var_dump($json);
  return die($r_log["errors"]);
 }
}

function p_next($homepost){
$url = utf8_encode($homepost);
$json = json_decode($url, true);
return urldecode($json["paging"]["next"]);
}

//echo p_next(gethome(token, 15));

function sendlike($token, $id){
  global $r_log;
$url = "https://graph.beta.facebook.com/".$id."/likes?method=post&access_token=".$token;
global $curlopt;
$send = fetch($url, $curlopt);
if (null === $send){ $r_log["errors"].="$myid sendlike failed\n"; }
return $send;
}

function getcomments($token, $id, $max){
  global $r_log;
$url = "https://graph.beta.facebook.com/".$id."/comments?fields=id,likes&limit=".$max."&access_token=".$token;
global $curlopt;
$get = fetch($url, $curlopt);
if (null !== $get){
return $get;
} else {
  $r_log["errors"].="$id Get Comments Failed\n";
  return null;
}
}

function like_comments_replies($token="",$post_id="100015325267712_498664980654340"){
global $r_log; global $curlopt;
$url="https://graph.beta.facebook.com/v3.2/".$post_id."/comments?access_token=".$token."&fields=comments.field(likes,id,summary(1)),likes.limit(100).summary(1)";
 $post = fetch($url, $curlopt);
 $post = utf8_encode($post);
  $post=json_decode($post, true);
  foreach ($post["data"] as $cr){
    if ($cr["likes"]["summary"]["has_liked"] === false && $cr["likes"]["summary"]["can_like"] !== false){
    //var_dump($cr["likes"]["summary"],$cr["id"]);
    //$crs = $cr["likes"]["summary"]["has_liked"]; //single liked
    $cr_id = $cr["id"];
    if (null !== sendlike($token, $cr["id"])){
      $r_log[]=$cr["id"]." Comments Replies liked\n";
    } else {
      echo "Replies: " . json_encode($cr);
      die();
      }
    }
    
  }
 //#check replies likes->https://graph.facebook.com/v3.2/498664980654340_498670270653811/comments?access_token=EAAAAUaZA8jlABAAUgCpZABsk1jsXul8Xu9P7cjqpvDxIrW7nZB8MyT7A8woupnXY2QVZBNMhxKyyHM33X2REYAOxErufOVsg7wu4lIivdXTTvqupkTUMPGklk1DipfRJiAeKDpZCFgZAEVPF7xghqYGZAjnh30Jn5jZBsQWZC0t4ZA6BjgW4JNu8oa&fields=likes.limit(0).summary(1)
 return true;
}

function react($id, $access_token, $type){
  global $type;
  global $curlopt;
  
   $post_react = "https://graph.facebook.com/v2.11/".$id."/reactions?";
   $curlopt["post"] = array(
   "type"=>$type,
   "method"=>"post",
   "access_token"=>$access_token
   );
   //$check_post = $post_react . "token=" . $access_token;
   
  $send = fetch($post_react, $curlopt);
      
      return $send;
      
      //return $check_post;
 
//echo fetch('https://­graph.facebook.com/'.$id.'/­­reactions?type=LOVE&­m­ethod=post&access_­to­ken='.$token);
}

function process($homeurl=false){
global $r_log; global $myfn;
global $max; global $tokenfile;
global $token; global $my_id;
global $myid; global $my_fn;
global $curl; global $curlopt;

//_____ Get Homepage Posts
if (!$homeurl){
  $home = json_decode( gethome(token, max) , true );
} else if (strpos($homeurl, "://") !== false){
$home = fetch($homeurl, $curlopt);
$home = json_decode($home, true);
} else {
  $home = json_decode($homeurl, true);
}

    if ($home !== null && !empty($home)){
//$home["data"][0]["likes"]["data"]
foreach ($home["data"] as $data){
//var_dump($data);
//_____ Like Posts
if (/*empty($data["likes"]["data"][0]) || */isset($data["likes"]['summary']['has_liked']) && $data["likes"]['summary']['has_liked'] === false && $data["likes"]["summary"]["can_like"] === true){
if (null !== sendlike(token, $data["id"])){
 $p_liked = $data["id"] . " Post Liked\n";
 $r_log["id"].=$data["id"]."\n";
 //foreach ($data["id"] as $log){
 $url=explode("_", $data["id"], 2);
 //var_dump($url); 
//$test = explode("_", $r_log["id"], 2);
 $s = "id=".$url[0];
 $i = "story_fbid=".$url[1];
 $url = "https://facebook.com/story.php?$s&$i";
 $r_log["url"].=$url;
 $r_log["link"].= " <a target='_blank' href='$url'>$i</a> ";
 //}
 $r_log[]=$p_liked;
 //echo $p_liked;
}
} else {
  //echo "Posts: " . json_encode($data);
  //die();
  }
//_____ Like Comments
 if ( !empty( $data["comments"] )){
   like_comments_replies(token, $data["id"]);
 } // foreach $com["data"]
} // foreach $home["data"]
    } else { //Json Null //Token Error
       $global = $tokenfile;
       $json_null = "Token Error -> $token\n";
       $r_log["error_file"]=$tokenfile;
       $r_log["errors"].=$json_null;
       $tokenfilename=end(explode('/', $tokenfile));
       $tokenfilename = "tokens/removed/".$tokenfilename;
       if (file_exists($tokenfilename)){
         unlink($tokenfilename);
       }
       rename($tokenfile, $tokenfilename);
       //echo $json_null;
       }

} //If string token valid
} // process function
process();
/*
if (isset($r_log["next"])){
  $old = $r_log["next"];
  if (null !== process($r_log["next"])){
    if (isset($r_log["next"]) && $r_log["next"] != $old){
      process($r_log["next"]);
    }
  }
}
*/
//var_dump(end(explode('/', $tokenfile)));

array_unique($r_log);

//echo $r_log["link"] . "<br/>";
//echo $r_log["homeurl"] . "<br/>";
foreach ($r_log as $name => $value){
  if (!preg_match('(id|url|next|home)',$name)){
    echo " $name : $value <hr />";
  }
}
echo '<style>*{word-wrap:break-word;max-width:100%}</style>';
?>