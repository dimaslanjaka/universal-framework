<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
//session_destroy();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !preg_match("(localhost|127.0.0.1|dimaslanjaka)", $_SERVER['HTTP_REFERER']) && isset($_POST["username"]) && isset($_POST["password"]) && !empty($_POST["password"])) {
  echo "Cant Determine Your Request
  <script>
  location.replace('index.php');
  </script>
  ";
  header("Location: index.php");
  die();
}
$user = $_SESSION["username"] = $_POST["username"];
$pass = $_SESSION["password"] = $_POST["password"];
require_once("Instagram.php");
$ig=new Instagram(); $ig->logout();
global $r_log;

$recent=$ig->getRecentActivity();
$feed=$ig->timelineFeed();
$login=$ig->login();

echo '<style>
red{color:red;text-color:red}
green{color:green;text-color:green}
</style>';

if (null !== $login && $login["status"] == "ok"){
  $r_log["login"]="success";
  echo "<green>Login Successful</green>";
  $_SESSION["valid"] = 'valid';
  $ig->saveBio($login);
  echo '
  <script>location.href="index.php";</script>
  ';
} else if ($feed["status"] == "ok" && isset($feed["items"])){
  $r_log["logged_in_as"]=$user;
    echo "<green>You Has Logged In as ".$user;
    echo '<div><h2><a href="index.php">Return to homepage</a></h2></div></green>';
} else if ($feed["messages"] == "login_required"){
  $r_log["login"]="logout";
  $ig->logout();
  echo "<red>Please Re-login Again And Allow The BOT login challenge from <a href='//instagram.com' target='_blank'>Instagram</a> => <h2><a href='flush.php'>Return Homepage</a></h2></red>";
  echo '
  <script>
  setTimeout(function(){ location.href="flush.php"; }, 10000);
  </script>
  ';
}
if (isset($r_log["logged_in_as"])){
  echo '
  <script>location.href="like.php?username="'.$user.';</script>
  ';
}

 //var_dump($r_log);
?>