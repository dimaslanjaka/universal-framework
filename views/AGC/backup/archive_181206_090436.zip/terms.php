<!DOCTYPE html PUBLIC -//W3C//DTD XHTML 1.0 Strict//EN http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd>
<html lang="en">
<head>
<title>Terms Of Service | Robot Reaction Facebook</title>
<link rel="shortcut icon" href="//bertena.ga/Material/img/favicon.ico">
<meta name="description" content="Robot Beranda | Tanggapi Status Teman Facebook Kamu Secara Otomatis" />
<meta charset="utf-8">
<meta name="keywords" content=" Robot Beranda, Robot Wow, Robot Super, Robot Like, Robot Sad, Robot Sedih, Robot Marah, Robot Angry, Robot Like, Robot Love, Autolike Facebook, Increase Facebook Likes, AutoCommenter, Facebook Hack, Facebook Status Liker, CST Liker, Indonesia Autolike, Autolike status, Autolike Photo, ,Autolike Fans Page ,Bot komen ,Bot Like, Bom Like,Bomer Like, Big Like, Facebook, Google, Yahoo, Mywapblog, Bot koplak, Alexa, Ping, Twitter, Indonesian Likers, Autoliker, FB Autolike, FB Autoliker, FB Status Autolike, Indonesian Liker, Autolike 2014, Autolike, Jempol, Hublaa, Like" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:image" content="//bertena.ga/Material/img/icon.png"/>
<meta name="copyright" content="Copyright © Webmanajemen.xyz">
<meta name="author" content="Dimas Lanjaka Kumala Indra">
<meta name="charset" content="UTF-8">
<meta name="distribution" content="Global">
<meta name="rating" content="General">
<meta name="robots" content="Autolike,hublaa,CST Liker,Yaz4rt,IndoLikerz,Hembus,auto follower,autolike page,auto komen">
</head>
<body>
<?php include 'menu.php'; ?>
<div class="w3-container w3-center w3-blue"><h1><a class="w3-text-white" href="terms.php">Terms Of Service</a></h1></div>
<div class="container">
<p>
  Dengan menggunakan Auto React (<a href="/">webmanajemen.xyz</a>), Anda menyetujui
  Persyaratan Penggunaan kami, dan jika ada yang melanggar persyaratan ini,
  dia akan dilarang menggunakan layanan ini. Pada dasarnya dengan menggunakan
  layanan ini, Anda menyetujui persyaratan berikut:
</p>
<ul>
  <li>
    Anda tidak boleh menyalahgunakan situs dengan mengirimkan permintaan
    kosong / kosong.
  </li>
  <li>
    Anda tidak boleh menggunakan layanan ini untuk dijual kepada pengguna
    lain.
  </li>
  <li>
    Anda tidak boleh menggunakan sistem ini pada sebuah posting yang berisi
    pornografi / rasisme / diskriminasi dll.
  </li>
  <li>
    Anda harus menggunakan layanan ini hanya untuk mendapatkan kesukaan
    pada tulisan pribadi Anda.
  </li>
</ul>
<p>
  Dokumen ini terakhir diperbaharui pada tanggal 5 November 2016 dan tim kami
  berhak mengubah / memperbarui dokumen ini tanpa pemberitahuan sebelumnya
  kepada pengguna.
</p>
</div>
<div id="footer" class="jumbotron" style="padding: 20px;text-align: center;margin-bottom: 0px;">
<div id="google_translate_element"></div>
<hr>
<div id="histats_counter"></div><br>
<strong>Copyright &copy; 2017 <a href="/">Robot Reaction Facebook</a> All Right Reserved. </strong></font>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.3.1/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://codepen.io/dimaslanjaka/pen/xLPQjG.js"></script>

<script type="text/javascript" src="gtrans.js">
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script>
var loadMultipleCss = function(){
    //load local css
    loadCss('css/bootstrap.css');        
    loadCss('css/bootstrap.min.css');
    loadCss('css/bootstrap-theme.css');
    loadCss('css/bootstrap-theme.min.css')
    //load Bootstrap from CDN
    loadCss('https://www.w3schools.com/w3css/4/w3.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css');
    loadCss('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css');
}
 
var loadCss = function(cssPath){
    var cssLink = document.createElement('link');
    cssLink.rel = 'stylesheet';
    cssLink.href = cssPath;
    var head = document.getElementsByTagName('head')[0];
    head.parentNode.insertBefore(cssLink, head);
};
 
//call function on window load
window.addEventListener('load', loadMultipleCss);
</script>
<noscript>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
<link rel="styleheet" href="css/bootstrap.css" />      
<link rel="styleheet" href="css/bootstrap.min.css" />
<link rel="styleheet" href="css/bootstrap-theme.css" />
<link rel="styleheet" href="css/bootstrap-theme.min.css" />
</noscript>
</body>
</html>