<?php
if (!function_exists("fetch")){
include("function.php");
}
if (!isset($con) || isset($con) && false === mysqli_ping($con)) {
require("db.php");
}
global $con;

if (isset($_POST["token"])){
$token  = $_POST["token"];
} else if (isset($_GET["token"])){
$token = $_GET["token"];
}

if (!isset($token)){ die("Token Required"); }

$opt["refer"] = "https://www.facebook.com/home.php";

if(!empty($token)){
		$graph_url ="https://graph.facebook.com/v3.2/me?fields=id,name&access_token=".$token;
	 $json = fetch($graph_url, $opt);
	 $users = json_decode($json);
		$id = $users->id;
		if (null !== $id && !empty($id)){
$sql = "REPLACE INTO token_all (token,id) VALUES ('$token', '$id')";
$result = mysqli_query($con, $sql);
		} else {
		  echo "ID null";
		}
}
//var_dump($sql,$dbn,$encoding,$result,$select);
?>