<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_GET["username"])){
$user = $_SESSION["username"] = $_GET["username"];
} else {
  $user=null;
  }
if (isset($_GET["password"])){
$pass = $_SESSION["password"] = $_GET["password"];
} else {
  $pass=null;
  }
function setData($dir = 'data') {
  $files = glob($dir . '/*.json');
  $file = array_rand($files);
  return $files[$file]; 
}

  if ( $pass == null && $user == null || !$_GET ){
    $json = file_get_contents(setData());
    $json = json_decode($json, true);
    $_SESSION["password"] = $pass = $json[0]['password'];
    
    $_SESSION["username"] = $user = $json[0]['username'];
  } else if (!$pass && $user){
 $json = file_get_contents("data/".$user.".json");
 $json = json_decode($json, true);
 $_SESSION["password"] = $pass = $json[0]['password'];
}

 // var_dump($user,$pass);
require_once("Instagram.php");
$ig=new Instagram();
$user=$_SESSION["username"];
$pass=$_SESSION["password"];
//$_SESSION["proxy"] = "";
//var_dump($user,$pass);
define("user", $user, true);
define("pass", $pass, true);

echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>'.user.' &#x1F197;</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta http-equiv="Page-Enter" content="blendTrans(Duration=1.0)">
  <meta http-equiv="Page-Exit" content="blendTrans(Duration=1.0)">
  <meta http-equiv="Site-Enter" content="blendTrans(Duration=1.0)">
  <meta http-equiv="Site-Exit" content="blendTrans(Duration=1.0)">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"> <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<style>
*{word-wrap: break-word;max-width:100%;max-height:100%}
</style>

    <style type="text/css">
    	html,body{
			height: 100%;
		}
       #profile .container{
       	height: 100%;
       	align-content: center;
       	margin: auto;
       	padding: auto;
       }

       .image_outer_container{
       	margin-top: 20px;
       	margin-bottom: auto;
       	border-radius: 50%;
       	position: relative;
       }

       .image_inner_container{
       	border-radius: 50%;
       	padding: 5px;
        background: #833ab4; 
        background: -webkit-linear-gradient(to bottom, #fcb045, #fd1d1d, #833ab4); 
        background: linear-gradient(to bottom, #fcb045, #fd1d1d, #833ab4);
       }
       .image_inner_container img{
       	height: 200px;
       	width: 200px;
       	border-radius: 50%;
       	border: 5px solid white;
       }

       .image_outer_container .green_icon{
         background-color: #4cd137;
         position: absolute;
         right: 30px;
         bottom: 10px;
         height: 30px;
         width: 30px;
         border:5px solid white;
         border-radius: 50%;
       }  
       /*
       #result {
         margin-top: 20px;
       }  */
</style>

<script>
function check_refresh(url){
string = location.pathname;
substring = "run.php";
if (string.indexOf(substring) == -1){
  window.location.href=url;
}
}
</script>

</head>
<body>';

$login=$ig->login();
//var_dump($login);
  if (isset($login["invalid_credentials"]) && $login["status"] == "fail"){
    // Remove User Password Was Changed
    file_put_contents("data/igremoved.log", $user." Was REMOVED From BOT Because ".$login['message']."\n", FILE_APPEND | LOCK_EX);
    $ig->removeData();
  }
  $userbio="data/bio/".user."-bio.json";
if (!file_exists($userbio)){
  if ($login["status"] === "fail" || null === $login){
    $ig->relogin();
  }
  if ( !empty($login)){
$login=(isset($login['logged_in_user']) ? $login['logged_in_user'] : false);
$u_dp = (isset($login['profile_pic_url']) ? $login['profile_pic_url'] : "https://4.bp.blogspot.com/-4Gl0O0btbgs/W9OSlZuKVcI/AAAAAAAAAU0/remqOjbRvfIlBgruzXqhOczslPS9sx1FQCLcBGAs/s1600/PicsArt_10-27-05.15.19.png");
$u_fn = (isset($login['full_name']) ? $login['full_name'] : null);
$u_un = (isset($login['username']) ? $login['username'] : null);
$u_pn = (isset($login['phone_number']) ? $login['phone_number'] : null);
$u_priv = (isset($login['is_private']) ? $login['is_private'] : null);
$json = array("phone"=>$u_pn,"username"=>$u_un,"fullname"=>$u_fn,"private"=>$u_priv,"photo"=>$u_dp);
$json = json_encode($json);
file_put_contents("data/bio/".user."-bio.json", $json, LOCK_EX);
}
} else {
$json = json_decode(file_get_contents($userbio), true);
$u_dp=$json["photo"];
$u_pn=$json["phone"];
$u_fn=$json["fullname"];
$u_un=$json["username"];
$u_priv=$json["private"];
  if (null === $u_un || null === $u_fn){
    $ig->relogin();
  }
}
(null === $u_dp ? "https://4.bp.blogspot.com/-4Gl0O0btbgs/W9OSlZuKVcI/AAAAAAAAAU0/remqOjbRvfIlBgruzXqhOczslPS9sx1FQCLcBGAs/s1600/PicsArt_10-27-05.15.19.png" : $u_dp);
(null === $u_pn ? "Phone Number" : $u_pn);
(null === $u_fn ? "IG User" : $u_fn);
(null === $u_un ? "IG Username" : $u_un);
(!$login ? false : $login);
echo '
   	<div id="profile" class="container">
		<div class="d-flex justify-content-center h-100">
			<div class="image_outer_container">
				<div class="green_icon"></div>
				<div class="image_inner_container">
					<img src="'.$u_dp.'">
				</div>
			</div>
		</div>
		<div class="d-flex justify-content-center">
			<h3><a href="https://www.instagram.com/'.$u_un.'/" target="_blank" name="'.$u_un.'" alt="'.$u_un.'">'.$u_fn.'</a> <i class="fa fa-external-link-alt"></i> <br/> '.$u_pn.' <br/> Account Is '. ($u_priv !== false ? "Private" : "Public").'</h3>
			</div>
	</div>
<hr />
<center>'.user.' User Liked:</center>
<hr />
<div id="result content" class="container">
   <div class="row">';

$recent=$ig->getRecentActivity();
$c=$ig->timelineFeed();

if (!empty($c["messages"]) && $c["messages"] == "login_required"){
  $ig->log($recent["messages"]."\n");
  $ig->logout();
  echo '
  <script>
  check_refresh(location.href);
  </script>
  ';
  $page_name = dirname(__FILE__); 
  $each_page_name = explode('/', $page_name); 
  $folder = end($each_page_name);
   header("Refresh:0");
  //header('Location: /'.$folder.'/'.basename(__FILE__, '.php')."?username=".user."&password=".pass);
  }

//var_dump($login,$recent);

$rhtml=[];
$pid=[];
if ($c["status"]=="fail"){
var_dump($c);
}

if(isset($c['items'])){
foreach($c['items'] as $item){
  if (!empty($item['user']['username'])){
    $username=$item['user']['username'];
  }
  if (!empty($item['user']['full_name'])){
    $fullname=$item['user']['full_name'];
  }
  if (!empty($item['user']['profile_pic_url'])){
    $dp=$item['user']['profile_pic_url'];
  }
  if (!empty($item['comments'])){
   echo json_encode($item['comments']);
  }
  if (!empty($item['id'])){
    $id=$item['id'];
  }
  if (!empty($item['dr_ad_type'])){
    $ads=$item['dr_ad_type'];
  }
  if (!empty($item['has_liked'])){
    $liked=$item['has_liked'];
  }
  if (!empty($item["code"])){
    $code=$item["code"];
  }
  if (!empty($item['caption']['text'])){
    $text=$item['caption']['text'];
  } else { $text = ""; }
  
  if ( !empty($item['carousel_media'][0]['video_versions'][0]['url']) || !empty($item['carousel_media'][1]['video_versions'][0]['url']) || !empty($item['video_versions'][0]['url']) ){
    $pimg=$item['video_versions'][0]['url'];
    if (!$pimg){
    $pimg=$item['carousel_media'][1]['video_versions'][0]['url'];
    }
    if (!isset($pimg)){
      $pimg=$item['carousel_media'][0]['video_versions'][0]['url'];
    }
    $pimg='<video width="300px" height="300px" controls>
    <source src="'.$pimg.'" type="video/mp4">
</video>';
  } else if (isset($item['image_versions2']['candidates'])){
    $pimg=$item['image_versions2']['candidates'][0]['url'];
    $pimg='<img src="'.$pimg.'" width="300px" height="300px" />';
  } else {
    $pimg='<img src="'.$dp.'" width="300px" height="300px" />';
    //$pimg="//diylogodesigns.com/wp-content/uploads/2016/05/instagram-Logo-PNG-Transparent-Background-download.png";
    }
  if (isset($id) && !isset($liked) && !isset($ads)){
    $like=$ig->like($id);
    $log="log/".user.".log";
				if($like==false) {
					file_put_contents($log, "(".date('Y/m/d H:i:s').") [LIKE_MEDIA] => ".$id." (NOT_FOUND)\n", FILE_APPEND | LOCK_EX);
					echo "[NOT_FOUND] [POST_ID] => " . $id . "\n";
				}
				if($like['status']=='fail') {
					file_put_contents($log, "(".date('Y/m/d H:i:s').") [LIKE_ERROR] => ".$id." (ERROR)\n", FILE_APPEND | LOCK_EX);
					echo "[ERROR] [LIKE_ERROR] => " . $id . "\n";
				}
				if($like['status']=='ok') {
					// insert to log
					file_put_contents($log, $id . "\n", FILE_APPEND | LOCK_EX);
					echo "[SUCCESS] [LIKED] => " . $id . "\n";
				}
  }
  
 	if (!isset($ads)){
  //var_dump($id,$username,$fullname,$dp);
  $url_p='//www.instagram.com/p/'.$code.'/';
  $dump=(isset($item['carousel_media'][1]['video_versions']) ? json_encode($item['carousel_media'][1]['video_versions']) : "DUMP NOT FOUND");
  if (!in_array($code, $pid)){
  $chtml= '
    <div class="col-sm-6">
  '.$pimg.'
  <div>
  <span><i class="fa fa-external-link-alt"></i> <a target="_blank" title="'.$code.'" alt="'.$code.'" href="'.$url_p.'">'.$code.'</a></span>
  <div>
  '.$text.'
  <pre style="width:300px">'.
  $dump
  .'</pre>
  </div>
 </div>
</div>
   ';
   echo $chtml;
     array_push($pid, $code);
   }
  }

} //end loop
} else {
  var_dump($c);
  }
/*
foreach ($rhtml as $html){
  echo $html;
}
*/
if (isset($_GET["logout"])){
  $ig->logout();
  header("Location: like.php");
}
echo '
   </div> <!-- /row -->
   <hr/>
   <div>';
   
   $info="http://extreme-ip-lookup.com/json/"; //"https://ipapi.co/json";
   $info= $ig->custom($info);
   if (null !== $info | !empty($info)){
   foreach ($info as $name => $value){
     if (!empty($value)){
     echo " $name: $value ";
     }
     
   }
   } else {
     echo "Failed Get IP Info";
     }
   // var_dump($_SESSION);

  // var_dump($ig->getData());
   echo '
   </div>
   <hr/>
 </div> <!-- /container -->
 <script>
 setTimeout(function(){ check_refresh(location.href); }, 30000);
 </script>
</body>
</html><!-- Autolike '.user.' -->';
if (null === user || !user){
  $ig->removeData();
}
?>