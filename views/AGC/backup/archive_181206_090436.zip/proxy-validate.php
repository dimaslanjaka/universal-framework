<?php
  if (isset($_GET["clear"])){
    file_put_contents("proxy-alive.txt","");
  }
function TestProxy($proxy)
{
  $fisier = fopen("proxy-alive.txt", "a"); // Here we will write the good ones
  $splited = explode(':',$proxy); // Separate IP and port
  if($con = @fsockopen($splited[0], $splited[1], $eroare, $eroare_str, 3)) 
  {
    fwrite($fisier, $proxy); // Check if we can connect to that IP and port
    print $proxy."<br/>"; // Show the proxy
    fclose($con); // Close the socket handle
  }
  fclose($fisier);
}

$fisier = file_get_contents('proxy.txt'); // Read the file with the proxy list
$linii = explode("\n", $fisier); // Get each proxy

//for($i = 0; $i < count($linii) - 1; $i++) TestProxy($linii[$i]); // Test each proxy

$alives = file_get_contents("proxy-alive.txt");

$file = file("proxy.txt");
for ($i = max(0, count($file)-50); $i < count($file); $i++) {
  $prx = $file[$i];
  if (strpos($alives, $prx) == false){
    TestProxy($prx);
  }
}

file_put_contents('proxy-alive.txt', implode('', file('proxy-alive.txt', FILE_SKIP_EMPTY_LINES)));