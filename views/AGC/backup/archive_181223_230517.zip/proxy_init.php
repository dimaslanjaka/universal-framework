<?php
error_reporting(1);
header("Content-Type: text/plain; charset=utf-8");
require_once("vendor/autoload.php");
       if (!is_dir("cache")){
         $oldmask = umask(0);
         mkdir("cache", 0777);
         umask($oldmask);
       }
if(isset($_GET["clean"]) || isset($_POST["clean"])){
//------- remove proxy if greater than 10k and 3k left
$log = 'proxy.txt';
$fp = file($log, FILE_SKIP_EMPTY_LINES);
$min = 10000;
$max = count($fp);
$x_amount_of_lines = $max-$min;
//echo ($max."/".$min."/".$x_amount_of_lines."=");
if ($x_amount_of_lines >= 3000){
  $file = file($log);
  $line = $file[0];
  $file = array_splice($file, $min, $x_amount_of_lines);
  file_put_contents($log, implode($file));
  //$file = array_splice($file, 2, $x_amount_of_lines);
  //$file = array_splice($file, 0, 0, array($line, "\n"));
}
//------- unique Proxy
$lines = file('proxy.txt');
$lines = array_unique($lines);
file_put_contents('proxy.txt', implode($lines));
file_put_contents("cache/cache.php", "");
echo "Cleaned";
//readfile("proxy.txt");
} else {
//echo "add ?tool&clean for cleaning\n";
//echo "add ?tool&refresh for refreshing all victim\n";
$pr = new Proxy(); //("cache/cache.php");
   // $pr->initDefaultProxies(); 
// $pr->add($address, $regexppatern);
//*** Set Regex Variable ***//
$regex_ip_port = '/([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}):?([0-9]{1,6})?/m';
$regex_br = '#(.*?):(\d{1,4})<br />\n#';
$regex_a = '#(.*?):(\d{1,4})</a>\n#';
$regex_all = '#(.*?):(\d{1,4}).*?\n#';
$regex_td = '#<td>(.*?):(\d{1,4})</td>#';
$regex_ip = '/([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})/m';
//$ig=new Instagram();
//$curl=new curl();
//echo $curl->fetch("https://www.proxynova.com/proxy-server-list/port-80/");

//*** Add New Initialization ***//
$url = ["http://spys.one/en/https-ssl-proxy/","https://www.my-proxy.com/free-proxy-list.html","https://www.my-proxy.com/free-transparent-proxy.html","https://www.my-proxy.com/free-elite-proxy.html","https://www.my-proxy.com/free-anonymous-proxy.html","http://www.httptunnel.ge/ProxyListForFree.aspx","http://spys.me/proxy.txt"];
shuffle($url);
foreach ($url as $urls){
$pr->add($urls, $regex_ip_port);
$pr->add($urls, $regex_br);
}
//$ig=new Instagram();
//$url="http://spys.me/proxy.txt";
//$pr->add($url, $regex_ip);
//$pr->add($url, $regex_br);
//$pr->add("https://www.proxynova.com/proxy-server-list/port-80/", $regex_ip);
$proxy = $pr->getProxies();
$proxy = array_unique($proxy);
//var_dump($proxy);
/*
//$proxy = preg_replace('/(<a(.*?)>)/m', '', $proxy);
//$proxy = preg_replace('/(<\/a>)/m', '', $proxy);
//var_dump($proxy);
*/
$result = "";
foreach ($proxy as $prx){
echo $prx . "\n"; $result .=$prx."\n";
}
if (!empty($result)){
  file_put_contents("proxy.txt", $prx, PHP_EOL | LOCK_EX | FILE_APPEND);
}
}