<?php
session_start();
ob_start();
require('vendor/autoload.php');
require('dom.php');
//require 'translate.php';
use \Curl\Curl;
//use Stichoza\GoogleTranslate\TranslateClient;
//$tr = new TranslateClient();
//$tr->setUrlBase('http://translate.google.cn/translate_a/single');
//$tr->setSource('id');
//$tr->setTarget('en');
//echo $tr->translate();
$curl = new Curl();
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
 $headers[] = 'Connection: Keep-Alive';
 $headers[] = 'Cache-Control: max-age=0';
 $headers[] = 'Upgrade-Insecure-Requests: 1';
 $headers[] = 'DNT: 1';
 $headers[] = 'Keep-Alive: 300';
 $headers[] = 'Content-type: */*;charset=UTF-8';
 $headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
 $headers[] = "Accept-Language: en-us,en;q=0.5";
 $headers[] = "Pragma: no-cache";
 $headers[] = "Origins: https://translate.google.co.id";
$curl->setHeaders($headers);
$useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";
$curl->setUserAgent($useragent);
$curl->setReferrer("https://translate.google.co.id/m/translate");
$curl->setOpt(CURLOPT_ENCODING, 'gzip');
$curl->setOpt(CURLOPT_AUTOREFERER, true);
$curl->setOpt(CURLOPT_SSL_VERIFYPEER, false);
$curl->setOpt(CURLOPT_CAINFO, realpath("cacert.pem"));
$curl->setOpt(CURLOPT_COOKIESESSION, true);
$curl->setOpt(CURLOPT_RETURNTRANSFER, true);
$curl->setOpt(CURLOPT_FOLLOWLOCATION, true);
$curl->setCookieFile("cookie.txt"); $curl->setCookieJar("cookie.txt");
/*
if (isset($_GET["proxy"])){
$proxy = $_GET["proxy"];
} else if (isset($_SESSION["proxy"])){
$proxy = $_SESSION["proxy"];
} else {
$proxy = "37.98.175.251:81";
}
if (!empty($proxy)){
$curl->setProxy($proxy);
$curl->setProxyTunnel();
}*/
$query = $_GET["q"] or die("query parameter required");
$url = 'http://www.google.co.uk/search?q='.$query;
 $curl->get($url);
 $re = $curl->response;
 $html = str_get_html($re);
 foreach ($html->find("a") as $a){
  if ($a->hasAttribute("href") && strpos($a->href, '/url?q=') !== false){
   $a->href = "https://www.google.co.uk".$a->href;
   echo $a->href . "<br/>";
  }
 }
 //echo $html->save();