<?php
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
if (!isset($_POST['title']) && !isset($_POST['body'])){
echo '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.css" integrity="sha256-dMQYvN6BU9M4mHK94P22cZ4dPGTSGOVP41yVXvXatws=" crossorigin="anonymous" />
<div id="button_mail" class="container">
<button id="send_mail" class="button">Send This To Blogger</button>
</div>
<script>
$(document).ready(function() {
$("button#send_mail").click(function(){
  $.post("mail.php", {
    title: "'.urlencode($_SESSION["title"]).'",
    body: "'.urlencode($_SESSION["body"]).'"
  }, function(data){
    $("div#button_mail").html(data);
  });
});
});
</script>';
} 
if (isset($_POST["body"]) && isset($_POST["title"]) && $_SERVER["REQUEST_METHOD"] === "POST"){
  $_POST["title"] = urldecode($_POST["title"]);
  $_POST["body"] = urldecode($_POST["body"]);

if (!class_exists("Mail")){
require __DIR__ . '/vendor/autoload.php';
}
function sanitize_my_email($field) {
    $field = filter_var($field, FILTER_SANITIZE_EMAIL);
    if (filter_var($field, FILTER_VALIDATE_EMAIL)) {
        return true;
    } else {
        return false;
    }
}
if (isset($_SESSION["for"])){
  if ($_SESSION["for"] == 'website_development_indonesia'){
    $to_email = 'dimascyber008.superuser@blogger.com';  
  } else if ($_SESSION["for"] == 'zona_berbagi'){
    $to_email = "dimascyber008.zonaberbagi@blogger.com";
  } else if ($_SESSION["for"] == "maul"){
    $to_email = "maulads666.risman@blogger.com";
  }
} else if (isset($_SESSION["for"]) && filter_var($_SESSION["for"], FILTER_VALIDATE_EMAIL)){
  $to = $_SESSION["for"];
} else {
  echo "String: " . $_SESSION["for"] . " Isnt Valid Email, Or Email Required";
  die();
}
$title = $_POST["title"];
$body = $_POST["body"] or die("Body Required, Contact <a href='mailto:dimaslanjaka@gmail.com'>Admin</a>");
if ($body){
  $body .= <<<EOF
  <script src="https://codepen.io/dimaslanjaka/pen/aQRrbR.js"></script>
EOF;
}
/*
$headers = 'From: noreply@gmail.com';
//check if the email address is invalid $secure_check
$secure_check = sanitize_my_email($to_email);
if ($secure_check == false) {
    echo "Invalid input";
} else { //send email 
    mail($to_email, $subject, $message, $headers);
    echo "This email is sent using PHP Mail";
}
*/
$from = 'dimascyber008@gmail.com';
$to = $to_email;
$subject = $title;
$body = "$body\n#end";

$headers = array(
    'From' => $from,
    'To' => $to,
    'Subject' => $subject,
    'MIME-Version' => '1.0',
    'Content-Type' => 'text/html; charset=UTF-8'
);

$smtp = Mail::factory('smtp', array(
        'host' => 'ssl://smtp.gmail.com',
        'port' => '465',
        'auth' => true,
        'username' => 'dimascyber008@gmail.com',
        'password' => 'oacjnzwovgejrdjb'
    ));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) {
    echo('<p>' . $mail->getMessage() . '</p>');
} else {
  try {
    echo('<p>Message successfully sent!</p>');
    session_destroy();
  } catch(Exception $e){
      echo $e->getMessage();
    }
}
}
?>