# -PHP-Free-Google-Translate (Officially By L3n4r0x)
### Translate any websites from PHP
## Options (Array)
* Manipulate Images With Your CDNs 
```php
$option["cdn"] = "https://res.cloudinary.com/dimaslanjaka/image/fetch/"; //Change to your Images CDN
```
# How To Use ? 
just simply :

```php
include("translate.php");
echo translate($url, $FromLanguage, $ToLanguage, $option); //Country Code like id, ru, es, fr, br, etc
```


