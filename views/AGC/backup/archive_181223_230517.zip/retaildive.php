<?php
session_start();
ob_start();
require __DIR__ . '/vendor/autoload.php';
use \Curl\Curl;
$curl = new Curl();
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
 $headers[] = 'Connection: Keep-Alive';
 $headers[] = 'Cache-Control: max-age=0';
 $headers[] = 'Upgrade-Insecure-Requests: 1';
 $headers[] = 'DNT: 1';
 $headers[] = 'Keep-Alive: 300';
 $headers[] = 'Content-type: */*;charset=UTF-8';
 $headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
 $headers[] = "Accept-Language: en-us,en;q=0.5";
 $headers[] = "Pragma: no-cache";
 $headers[] = "Origins: https://translate.google.co.id";
$curl->setHeaders($headers);
$curl->setUserAgent("Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36");
$curl->setReferrer("https://translate.google.co.id/m/translate");
$curl->setOpt(CURLOPT_ENCODING, 'gzip');
$curl->setOpt(CURLOPT_AUTOREFERER, true);
$curl->setOpt(CURLOPT_SSL_VERIFYPEER, false);
$curl->setOpt(CURLOPT_CAINFO, realpath("cacert.pem"));
$curl->setOpt(CURLOPT_COOKIESESSION, true);
$curl->setOpt(CURLOPT_RETURNTRANSFER, true);
$curl->setOpt(CURLOPT_FOLLOWLOCATION, true);
$curl->setCookieFile("cookie.txt"); $curl->setCookieJar("cookie.txt");



$url = "https://www.retaildive.com";
if (isset($_GET["path"])){
  $url .= $_GET["path"];
}

$page = $curl->get($url);
$html = str_get_html($page);

if (!isset($_GET["path"])){
  foreach($html->find("a") as $tag){
    $p = parse_url($tag->href);
    $tag->href="?path=".$p["path"];
  }
  foreach($html->find("link,img,script") as $css){
    if ($css->tag == 'link' && !preg_match('/^https?\:\/\//m', $css->href)){
      $css->href=$url.$css->href;
    }
    if (preg_match('(script|img)', $css->tag) && strpos($css->src, $url) == false){
      $css->src=$url.$css->src;
    }
  }
  echo $html->save();
}
if (isset($_GET["path"])){
$image = $html->find("meta[property=og:image]",0)->content;
$image = preg_replace('/(^https?\:\/\/)/m', '', $image);
$image = trim($image);
$cdn = "https://cdn.staticaly.com/img/";

$title = $html->find('title',0)->plaintext;
$title = preg_replace('(retail dive|\|)', '', strtolower($title));
$title = trim(ucwords($title));
$title = trim($title);

$c = $html->find(".article-wrapper",0);
foreach ($c->find("div,img,a,style,script") as $tag){
  if ($tag !== 'img' && empty(trim($tag->innertext))){
    $tag->outertext='';
  }
  if ($tag->tag == 'a' && $tag->hasAttribute('href')){
    $href = explode('/', $tag->href);
    $kw = end($href);
    $kw = preg_replace('/[^A-Za-z ]/m', ' ', $kw);
    $kw = trim(strtolower($kw));
    $kw = trim($kw);
    if (empty($kw)){
      $kw = "PHP";
    }
    $tag->href = "https://web-manajemen.blogspot.com/p/search.html?q=".$kw;
    $tag->target='_blank';
  }
  if ($tag->hasAttribute("class")){
    if (preg_match("(share\-buttons|editor\-box|article\-topic|help\-text)", $tag->class)){
      $tag->outertext="";
    }
    $tag->removeAttribute("class");
  }
  if (preg_match('(style|script)', $tag->tag)){
    $tag->outertext="";
  }
  if (preg_match('(a|img)', $tag->tag)){
    $tag->alt = $title;
    $tag->title = $title;
  }
}
echo "<img src='$cdn$image' title='$title' alt='$title' class='img-thumbnail'/>";
echo $c->outertext;
echo "<h1 for='title'>$title</h1>";
}

if (isset($_GET["path"])){
  $dir = "articles";
  $tl = "id";
  $sl = "en";
  $no_add_title=1;
  include(realpath("saver.php"));
}

