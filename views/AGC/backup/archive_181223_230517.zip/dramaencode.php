<?php
session_start();
ob_start();
header('Access-Control-Allow-Origin: *');
header("X-Robots-Tag: index, nofollow", true);
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
ob_start();
require __DIR__ . '/vendor/autoload.php';
//require __DIR__ . '/dom.php';
//require 'translate.php';
use \Curl\Curl;
use Stichoza\GoogleTranslate\TranslateClient;
$tr = new TranslateClient();
$tr->setUrlBase('http://translate.google.cn/translate_a/single');
$tr->setSource('id');
$tr->setTarget('en');
//echo $tr->translate();
$curl = new Curl();
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
 $headers[] = 'Connection: Keep-Alive';
 $headers[] = 'Cache-Control: max-age=0';
 $headers[] = 'Upgrade-Insecure-Requests: 1';
 $headers[] = 'DNT: 1';
 $headers[] = 'Keep-Alive: 300';
 $headers[] = 'Content-type: */*;charset=UTF-8';
 $headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
 $headers[] = "Accept-Language: en-us,en;q=0.5";
 $headers[] = "Pragma: no-cache";
 $headers[] = "Origins: https://www.revdl.com";
$curl->setHeaders($headers);
$curl->setUserAgent($_SERVER["HTTP_USER_AGENT"]);
$curl->setReferrer("https://www.facebook.com");
$curl->setOpt(CURLOPT_ENCODING , 'gzip');

$curl->setCookieFile("cookie.txt"); $curl->setCookieJar("cookie.txt");

$u='https://www.dramaencode.com';
if (!isset($_GET["path"])){
  $homepage=1;
}
if (isset($_GET["path"])){
  $u .=$_GET["path"]; 
} else if (isset($_GET["s"])){
  $u .='/?s='.$_GET["s"];
  $searchpage = 1;
}
$tp=$curl->get($u);
$html = str_get_html($tp);
$_SESSION["title"] = $html->find("title",0)->plaintext;
$c = $html->find('.entry-content',0);
if (null == $c){
  unset($c);
  $c = $html;
}
foreach ($c->find("div,script,a,form,span,img") as $tag){
  if ($tag->hasAttribute("class") && $tag->getAttribute("class") == "mh-social-bottom"){
    $tag->outertext="";
  }
  if ($tag->tag == 'form'){
    $tag->attr["action"]='?s=';
  }
  if ($tag->tag == 'script'){
    if (isset($tag->src) && strpos($tag->src, 'safelinku.com') !== false){
      $tag->outertext='';
    }
  }
  if ($tag->tag == 'img'){
    if ($tag->hasAttribute("data-lazy-src")){
      $tag->src=$tag->attr["data-lazy-src"];
    }
    $tag->src = 'https://res.cloudinary.com/dimaslanjaka/image/fetch/'.$tag->src;
  }
  if (preg_match('(a|b|i|h2|h3|h4|h5|h1)', strtolower($tag->tag))){
    if ($tag->hasAttribute("class")){
      $tag->class = 'notranslate '.$tag->class;
    } else {
      $tag->class = 'notranslate';
    }
  }
  if ($tag->tag == 'a'){
    $a = $tag;
  $href = $a->href;
  $a->target = '_blank';
  if (strpos($href, "https://www.dramaencode.com") !== false){
    if (isset($searchpage) || isset($homepage)){
      $href = str_replace("https://www.dramaencode.com", "?path=", $href);
    } else if (!isset($searchpage) || !isset($homepage)) {
      $href = str_replace("https://www.dramaencode.com", "", $href);
      $href = preg_replace('(\/|[0-9]+)', '', $href);
      $href = str_replace('-', ' ', $href);
      $href = "https://web-manajemen.blogspot.com/p/search.html?q=".$href;
    }
    $a->href = $href;
  }
  }
}
$o = $c->outertext;
$rev=array('>revdl<','>RevDl<','>revdl<','>Revdl<','> revdl<','>dramaencode.com<','>RevDL<','>revDL<','>www.dramaencode.com<');
$o = str_replace($rev, '> Website Manajemen Indonesia <', $o);
$o = str_replace('Kesusahan download di dramaencode', 'Tutorial Download', $o);
echo $o;
echo '<!--original-->';
if (isset($_GET["path"])){
  $dir = "movies";
  $sl = "id";
  $tl = "en";
  include(realpath("saver.php"));
}