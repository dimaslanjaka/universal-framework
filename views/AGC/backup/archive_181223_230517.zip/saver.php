<?php
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}

if (isset($_GET["path"])){
  if ($sl){
    $_SESSION["sl"] = $sl;
  } if ($tl){
    $_SESSION["tl"] = $tl;
  } if ($dir){
    $_SESSION["dir"] = $dir;
  }
       if (!is_dir($dir)){
         $oldmask = umask(0);
         mkdir($dir, 0777);
         umask($oldmask);
       }  
  $output = $_SESSION["body"] = ob_get_contents();
  ob_clean();
  ob_start();
  if (!$dir && !$sl && !$tl){
    die("Dir, Target Language, Source Language Doesnt Set");
  } else {
    echo $_SESSION["body"];
  }

include(realpath("translate.js.php"));

  if (empty($_SESSION["body"])){
    die("Session Body Failed Render");
  }
  $path = urldecode($_GET["path"]);
  $f = preg_replace('/(((https?)\:\/\/)?www\.revdl\.com|\/)/', "",$path);
  if (!preg_match('/\.html$/i', $f)){
    $f .='.html';
  }
  if (strpos($_SESSION["body"], "for='title'") == false && !isset($no_add_title) || strpos($_SESSION["body"], 'for="title"') == false && !isset($no_add_title)){
    $b ="<h1 for='title' class='notranslate'>".$_SESSION["title"]."</h1>";
  } else {
    $b = "";
  }
  $b .="<div>".$_SESSION["body"]."</div>";
  if (preg_match('(barees|storage)', $_SERVER["HTTP_HOST"])){
  $_SESSION["target_translate"] = "http://".$_SERVER["HTTP_HOST"]."/$dir/".$f;
  } else {
    $_SESSION["target_translate"] = "http://dimaslanjaka-storage.000webhostapp.com/$dir/".$f;
  }
  echo '<hr/><center><a href="index.php?sl='.$sl.'&tl='.$tl.'">Send This To Blogger</a></center><hr/>';
  if (!file_exists("$dir/".$f)){
    file_put_contents("$dir/".$f, $b . PHP_EOL, LOCK_EX);
  } else if (isset($_GET["save"])){
    file_put_contents("$dir/".$f, $b . PHP_EOL, LOCK_EX);
  }
}

?>