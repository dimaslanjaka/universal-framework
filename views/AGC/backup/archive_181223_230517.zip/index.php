<?php
session_start();
ob_start();

require __DIR__ . '/vendor/autoload.php';

use \Curl\Curl;

$curl = new Curl();
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
 $headers[] = 'Connection: Keep-Alive';
 $headers[] = 'Cache-Control: max-age=0';
 $headers[] = 'Upgrade-Insecure-Requests: 1';
 $headers[] = 'DNT: 1';
 $headers[] = 'Keep-Alive: 300';
 $headers[] = 'Content-type: */*;charset=UTF-8';
 $headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
 $headers[] = "Accept-Language: en-us,en;q=0.5";
 $headers[] = "Pragma: no-cache";
 $headers[] = "Origins: https://translate.google.co.id";
$curl->setHeaders($headers);
//$curl->setUserAgent($_SERVER["HTTP_USER_AGENT"]);
$curl->setUserAgent('Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36');
$curl->setReferrer("https://translate.google.co.id/m/translate");
$curl->setOpt(CURLOPT_ENCODING, 'gzip');
$curl->setOpt(CURLOPT_AUTOREFERER, true);
$curl->setOpt(CURLOPT_SSL_VERIFYPEER, false);
$curl->setOpt(CURLOPT_RETURNTRANSFER, true);
$curl->setOpt(CURLOPT_FOLLOWLOCATION, true);
$curl->setCookieFile("cookie.txt"); $curl->setCookieJar("cookie.txt");

function parsetry($thetr){
  global $curl;
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($thetr);

try {
  $iFrame = $dom->getElementsByTagName('iframe')->item(0);
  if (empty($iFrame)){
    throw new Exception("The field is undefined.");
  }
  $iFramesrc = $iFrame->getAttribute('src');
  if (strpos($iFramesrc, "googleusercontent") !== false){
    $thetr2 = $curl->get($iFramesrc);
    $filter = $thetr2;
  }
} catch (Exception $e){
$A = $dom->getElementsByTagName('a')->item(0);
$Ahref = $A->getAttribute("href") or $A->getAttribute("HREF");
  if (strpos($Ahref, "googleusercontent") !== false){
    $thetr2 = $curl->get($Ahref);
    $filter = $thetr2;
  }
}
$dom->saveHTML();
return $filter;
}
if (!function_exists("fixhtml")){
function fixhtml($html){
$domnew = new \DOMDocument('1.0', 'UTF-8');
libxml_use_internal_errors(true);
$domnew->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
$xpath = new DOMXpath($domnew); 
return $domnew->saveHTML();
}
}

function translate($url, $hl, $tl){
  global $curl;
$urltotranslate = $url;
if (!isset($tl)){
$tl = "en";
}
if (!isset($hl)){
$hl = "auto";
}

$usg1 = substr(md5(microtime()),rand(0,26),5);
$usg2 = substr(md5(microtime()),rand(0,26),5);
$usg3 = substr(md5(microtime()),rand(0,26),5);
$multiplehash = "1000,1500002,15700002,15700022,15700122,15700124,15700149,15700168,15700173,15700186,15700201";
$thetr = $curl->get("https://translate.googleusercontent.com/translate_c?depth=3&nv=1&rurl=translate.google.com&sl=".$hl."&sp=nmt4&tl=".$tl."&u=".$urltotranslate."&xid=".$multiplehash."&usg=".$usg1."_".$usg2."-".$usg3);

$filter = parsetry($thetr);

if (!preg_match('/(\<\!\-\-original\-\-\>)/m', $filter)){
  $filter = parsetry($filter);
}

$domnew = new \DOMDocument('1.0', 'UTF-8');
libxml_use_internal_errors(true);
$domnew->loadHTML(mb_convert_encoding($filter, 'HTML-ENTITIES', 'UTF-8'));
$xpath = new DOMXpath($domnew);

$head = $domnew->getElementsByTagName('head')->item(0);
$body = $domnew->getElementsByTagName('body')->item(0);

$modlink = $xpath->query('//a');
foreach ($modlink as $link){
$href = $link->getAttribute('href');
$url_parts = parse_url($href);
if (false !== parse_str($url_parts['query'], $url_query)){

if (strpos($link->getAttribute('rel'), 'related') === false){
if (!isset($query['lang'])){
$hrefd = urldecode ($url_query['u']);
} else {
$hrefd = urldecode ($url_query['u']) . "&lang=" . $query['lang'];
}
}
$link->setAttribute('href', $hrefd);

} else {
  die("Reload pagenya gan, Server Overload");
}
}

$spans = $xpath->query('//span');
foreach ($spans as $span){
if (strpos($span->getAttribute("class"), "google-src-text") !== false){
$span->parentNode->removeChild($span);
}
}

$iframes = $xpath->query('//iframe');
foreach ($iframes as $iframe){
if (strpos($iframe->getAttribute("id"), "gt-nvframe") !== false){
$iframe->parentNode->removeChild($iframe);
}
}

$scripts = $xpath->query('//script');
foreach ($scripts as $script){
$transreg=array($script->nodeValue, $script->getAttribute('src'));
foreach ($transreg as $matches){
if (preg_match('/(translate|wtsrt_|_addload)/mi', $matches)){
$script->parentNode->removeChild($script);
}
} //End array each
}

$getalltags = $xpath->query('//*');
foreach ($getalltags as $tag){
if (preg_match('(iframe|audio|embed|video)', $tag->tagName)){
  if ($tag->hasAttribute("src")){
    $src = $tag->getAttribute('src');
    $url_parts = parse_url($src);
    parse_str($url_parts['query'], $url_query);
    $src = urldecode($url_query["u"]);
    $tag->setAttribute('src', $src);
  }
}
  if ($tag->tagName == 'h1' && $tag->hasAttribute('for') && $tag->getAttribute('for') == 'title'){
   $_SESSION["title"] = $tag->textContent;
  }
if (!empty($tag->getAttribute("onmouseover"))){
$tag->removeAttribute("onmouseover");
}
if (!empty($tag->getAttribute("onmouseout"))){
$tag->removeAttribute("onmouseout");
}
if (strpos($tag->getAttribute("title"), "000webhost") !== false){
$tag->parentNode->removeChild($tag);
}
if (preg_match('/(X-Translated-By)/mi', $tag->getAttribute("http-equiv"))){
$tag->parentNode->removeChild($tag);
}
}
if ($body->hasAttribute("style")){
  $body->removeAttribute("style");
}
//return $body->ownerDocument->saveHTML($body);
/*
if (isset($_GET["grab"])){
$a_html_title = $domnew->getElementsByTagName('title');
$a_html_title = $a_html_title->item(0)->nodeValue;
if (!empty($a_html_title)){
  $_SESSION["title"] = $a_html_title;
}
}*/
 return $domnew->savehtml($body);
// return $domnew->saveHTML();
}

if (isset($_GET["for"])){
  $_SESSION["for"] = $_GET["for"];
} else if (isset($_POST["for"])){
  $_SESSION["for"] = $_POST["for"];
}

if (isset($_GET["clean"])){
  session_destroy();
  header("Location: index.php");
}

if (isset($_GET["proxy"])){
  $_SESSION["proxy"] = $_GET["proxy"];
  if (isset($_SESSION["last_page"])){
   header("Location: ".$_SESSION["last_page"]);
  }
} else if (isset($_POST["proxy"])){
  $_SESSION["proxy"] = $_POST["proxy"];
  if (isset($_SESSION["last_page"])){
   header("Location: ".$_SESSION["last_page"]);
  }
}

if (!isset($_SESSION["for"])){
    echo '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Choose Email</title>';
    echo $curl->get('https://codepen.io/dimaslanjaka/pen/WYogEL.html');
    echo $curl->get('https://codepen.io/dimaslanjaka/pen/mQRdoR.html');

 echo "<div class='container'>Choose For Whos This Article Will Be !!</div>";
  $output = ob_get_contents();
  ob_clean();
  ob_start();
  echo fixhtml($output);
  die(); 
}

if (isset($_GET["set_proxy"])){
  echo '<title>Choose Proxy</title>';
  echo '<meta name="description" content="'.(isset($_SESSION["last_page"]) ? $_SESSION["last_page"] : "Set Proxy").'"/>';
  echo $curl->get("https://codepen.io/dimaslanjaka/pen/xQqXVR.html");
  $output = ob_get_contents();
  ob_clean();
  ob_start();
  echo fixhtml($output);
  die();
}
//die(var_dump($_SESSION));
if (!isset($_SESSION["target_translate"])){
  echo '<meta name="viewport" content="width=device-width, initial-scale=1"><title>Target Translate ? | Insurance Loan</title><link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous"><script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <style>
  * { word-wrap: break-word; max-width: 100%; }
  </style>
  ';
  echo $curl->get("https://codepen.io/dimaslanjaka/pen/xQRzoy.html");
  echo '<div class="container">'.serialize($_SESSION). serialize($_COOKIE).'</div>';
  echo $curl->get('https://codepen.io/dimaslanjaka/pen/mQRdoR.html');
  echo "<div class='container'>You must define target translate</div>";
  $output = ob_get_contents();
  ob_clean();
  ob_start();
  echo fixhtml($output);
  die();
}
if (isset($_SESSION["target_translate"])){
$i = $_SESSION["target_translate"];
$fn = explode('/', $i);
if (!preg_match("/\.html$/i", $i)){
  die("File must HTML mime type");
}
if (empty($fn)){ die("url explode failed"); }
$fn = end($fn);
if (isset($_SESSION["dir"])){
  $dir = $_SESSION["dir"].'/';
} else if (strpos($i, '/movies/') !== false){
  $dir = 'movies/';
} else if (preg_match('(\/apk\/|revdl)', $i)){
  $dir = "apk/";
} else if (preg_match('(\/mp3\/)', $i)){
  $dir = 'mp3/';
}

if (isset($_SESSION["tl"])){
  $tl=$_SESSION["tl"];
} else if (isset($_GET["tl"])){
  $tl = $_GET["tl"];
} else {
  $tl="en";
}
if (isset($_SESSION["sl"])){
  $sl=$_SESSION["sl"];
} else if (isset($_GET["sl"])){
  $sl = $_GET["sl"];
} else {
  $sl="id";
}

$c = '<!--translated-->' . translate($i, $sl, $tl);
$c = preg_replace('/(\<body\>|\<\/body\>)/mi', '', $c);
$c = trim($c);
if (preg_match('/(Additional, a 404 error found to handle the request|The server encountered an internal error or misconfiguration and was unable to complete your request|404\. That\'s an error)/m', $c)){
  echo $_SESSION["target_translate"]."<br/>";
  die("Error: (Harap kontak Admin). ".$c);
} else if (isset($_GET["dump"])){
  echo $c;
  die();
}

$_SESSION["body"] = $c;
if (!file_exists($dir.$fn)){
  file_put_contents($dir.$fn, $c . PHP_EOL, LOCK_EX);
  echo "saved & translated\n";
} else {
  $exists = file_get_contents($dir.$fn);
  if (strpos($exists, '<!--translated-->') === false){
    file_put_contents($dir.$fn, $c . PHP_EOL, LOCK_EX);
    echo "Translated\n";
  }
}
echo "<hr/>Article Will be sent to ".$_SESSION["for"]."\n<hr/>";
echo "You can change it, must be restart from <a href='/index.php?clean'>Here</a>";
include(realpath("mail.php"));
} //session target_translate