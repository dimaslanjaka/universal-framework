<?php
session_start();
ob_start();
require __DIR__ . '/vendor/autoload.php';

use \Curl\Curl;
$curl = new Curl();
$curl->setUserAgent($_SERVER["HTTP_USER_AGENT"]);
$curl->setReferrer("https://www.facebook.com");
session_start();
//$url = "https://www.bagas31.info/2018/10/magix-vegas-pro-16-build-307-full-version.html";

if (!isset($_GET["path"])){
  $url = "https://www.bagas31.info";
  $curl->get($url);
  $page = $curl->response;
  $html = str_get_html($page);
  $_SESSION["title"] = $html->find("title",0)->plaintext;
  foreach ($html->find("a,script,h1,h2,h3,h4,h5") as $tag){
  if (preg_match("(h1|h2|h3|h4|h5|a)", $tag->tag)){
    if ($tag->hasAttribute("class")){
      $tag->setAttribute("class", "notranslate ".$tag->getAttribute("class"));
    } else {
      $tag->setAttribute("class", "notranslate");
    }
  }
    if ($tag->tag == 'script'){
      $tag->outertext='';
    }
   if ($tag->tag == 'a'){
    $href = $tag->href;
    $href = str_replace("https://www.bagas31.info","?path=", $href);
    $tag->href = $href;
    $tag->target = "_blank";
   }
  }
  echo $html->save();
  die();
}
$url = (strpos($_GET["path"], "https://www.bagas31.info") !== false ? $_GET["path"] : "https://www.bagas31.info".$_GET["path"]);
$page = $curl->get($url);
$html = str_get_html($page);
$_SESSION["title"] = $html->find("title",0)->plaintext;
$_SESSION["title"] = preg_replace('/(BAGAS31|BAGAS31.com|BAGAS31.info)/i', "Website Development Indonesia", $_SESSION['title']);
$c1 = $html->find(".entry-content",0);
foreach ($c1->find(".post-terkait,.box-kanan,.g-ytsubscribe,#box-bottom,meta,.ddnbtn,.crp_related") as $c){
$c->outertext='';
}
$html->find('center a',0)->outertext='';
foreach ($html->find('h1,h2,h3,h4,h5,a') as $tag){
  if (preg_match("(h1|h2|h3|h4|h5|a)", $tag->tag)){
    if ($tag->hasAttribute("class")){
      $tag->setAttribute("class", "notranslate ".$tag->getAttribute("class"));
    } else {
      $tag->setAttribute("class", "notranslate");
    }
  }
}
foreach ($c1->find("center,div,span,i,b,strong,p,a,img") as $tag){
  
  if ($tag->tag !== 'img'){
   if(trim($tag->innertext) == '') {
        $tag->outertext = '';
   }
  } else {
    $tag->setAttribute("src", "https://res.cloudinary.com/dimaslanjaka/image/fetch/".$tag->src);
    if ($tag->hasAttribute("srcset")){$tag->removeAttribute("srcset");}
    if ($tag->hasAttribute("sizes")){$tag->removeAttribute("sizes");}
  }
  if ($tag->tag == 'a'){
    if (preg_match('(telolet)', $tag->href)){
      $href = parse_url($tag->href);
      $hrefx = parse_str($href["query"], $hr);
      if (isset($hr["go"])){
        $tag->href = "https://dimaslanjaka.github.io/page/safelink.html?url=".$hr["go"];
      }
    }
    if (preg_match('/(https:\/\/www.bagas31.info\/|https:\/\/www.bagas31.info|https:\/\/www.bagas31.com\/|https:\/\/www.bagas31.com)/i', strtolower($tag->href))){
      $href = explode("/", $tag->href);
      $href = end($href);
      $href = preg_replace('(\.html|[^a-zA-Z ])', ' ', $href);
      $href = preg_replace('/\s+/', ' ',$href);
      $href = trim($href);
      $href = "https://web-manajemen.blogspot.com/p/search.html?q=".$href;
      $tag->setAttribute("href", $href);
      $tag->target="_blank";
    }
    if (!isset($tag->attr["alt"]) || empty($tag->alt)){
      $tag->attr["alt"] = $_SESSION["title"];
    }
    if (!isset($tag->attr["title"]) || empty($tag->title)){
      $tag->attr["title"] = $_SESSION["title"];
    }
  }
  if (!empty($tag->getAttribute("style"))){
$tag->removeAttribute("style");
}
  if (!empty($tag->getAttribute("itemprop"))){
    if (preg_match("/(image|logo)/", $tag->getAttribute("itemprop"))){
      $tag->outertext='';
    }
  }
}

$c1html = $c1->outertext;
$c1html = preg_replace("/(BAGAS31.com|BAGAS31.info)/m", "Web Development Indonesia", $c1html);
echo $c1html.'<center><small>'.$_SESSION['title'].'</small></center>';

$tl='en';
$sl='id';
$dir='apk';
include(realpath("saver.php"));
?>