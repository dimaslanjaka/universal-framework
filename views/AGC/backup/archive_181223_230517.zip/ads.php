<?php
$mgid=<<<EOF
<div id="M311413ScriptRootC206250">
        <div id="M311413PreloadC206250">
        Loading...    </div>
        <script>
                (function(){
            var D=new Date(),d=document,b='body',ce='createElement',ac='appendChild',st='style',ds='display',n='none',gi='getElementById';
            var i=d[ce]('iframe');i[st][ds]=n;d[gi]("M311413ScriptRootC206250")[ac](i);try{var iw=i.contentWindow.document;iw.open();iw.writeln("<ht"+"ml><bo"+"dy></bo"+"dy></ht"+"ml>");iw.close();var c=iw[b];}
            catch(e){var iw=d;var c=d[gi]("M311413ScriptRootC206250");}var dv=iw[ce]('div');dv.id="MG_ID";dv[st][ds]=n;dv.innerHTML=206250;c[ac](dv);
            var s=iw[ce]('script');s.async='async';s.defer='defer';s.charset='utf-8';s.src="//jsc.mgid.com/w/e/webmanajemen.xyz.206250.js?t="+D.getYear()+D.getMonth()+D.getDate()+D.getHours();c[ac](s);})();
    </script>
</div>
EOF;
define("mgid", $mgid, true);
$jquery=<<<EOF
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
EOF;
define("jQuery", $jquery, true);
$ads1=<<<EOF
<!--//****** Ads Area No 1 Start ******//-->
<div style="overflow:auto">
<div id="SC_TBlock_487364" class="SC_TBlock">loading...</div>
</div>
<!--//****** Ads Area No 1 End ******//-->
EOF;
define("ads1", $ads1, true);
$ads2=<<<EOF
<!--//****** Ads Area No 2 Start ******//-->
<div style="overflow:auto">
<div id="SC_TBlock_450933" class="SC_TBlock">loading...</div>
</div>
<script type="text/javascript">
    (sc_adv_out = window.sc_adv_out || []).push({
        id : "450933",
        domain : "n.ads1-adnow.com"
    });
</script>
<script type="text/javascript" src="//st-n.ads1-adnow.com/js/adv_out.js"></script>
<script src="//st-n.ads1-adnow.com/js/ads.js"  type="text/javascript"></script>
<!--//****** Ads Area No 2 END ******//-->
EOF;
define("ads2", $ads2, true);
$adres1=<<<EOF
<!--//****** Adsense Responsive 1 Start ******//-->
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="2600604346" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
<!--//****** Adsense Responsive 1 End ******//-->
EOF;
define("adres1", $adres1, true);
$adres2=<<<EOF
<!--//****** Adsense Responsive 2 Start ******//-->
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="4025331886" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
<!--//****** Adsense Responsive 2 End ******//-->
EOF;
define("adres2", $adres2, true);
$adres3=<<<EOF
<!--//****** Adsense Responsive 3 Start ******//-->
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="7267894124" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
<!--//****** Adsense Responsive 3 End ******//-->
EOF;
define("adres3", $adres3, true);
$adtext=<<<EOF
<!--//****** Adsense Text Only Start ******//-->
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="4163345568" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
<!--//****** Adsense Text Only End ******//-->
EOF;
define("adtext", $adtext, true);
$scriptadsense=<<<EOF
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
EOF;
define("scriptadsense", $scriptadsense, true);
$pagead=<<<EOF
<!--//****** PageAd & AutoAd Adsense Start ******//-->
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-7975270895217217",
          enable_page_level_ads: true
     });
</script>
<!--//****** PageAd & AutoAd Adsense End ******//-->
EOF;
define("pagead", $pagead, true);
$exoclick=<<<EOF
<!--//****** Exoclick Banner Ads Start ******//-->
<div class="text-center">
<iframe src="//ads.exdynsrv.com/iframe.php?idzone=2935872&size=300x250" width="300" height="250"></iframe>
</div>
<!--//****** Exoclick Banner Ads End ******//-->
EOF;
define("exoclick", $exoclick, true);
$auto=<<<EOF
<script>
var f=$('iframe');
  if ( f.parent().is( "div" ) ) {
    setInterval(function(){ f.unwrap(); }, 30000);
  } else {
    setInterval(function(){ f.wrap( "<div></div>" ); }, 30000);
  }
</script>
EOF;
define("auto_impress", $auto, true);
$bouncerate = <<<EOF
    <script>
        ! function() {
            var t;
            try {
                for (t = 0; 10 > t; ++t) history.pushState({}, "", "#!/view");
                onpopstate = function(t) {
                    t.state && location.replace("https://linkshrink.net/zslz="+document.referer);
                }
            } catch (o) {
    document.getElementById("log").innerHTML = o.message;                    
            }
        }();
    </script>
EOF;
define("bouncerate", $bouncerate, true);
$disable_keyboard = <<<EOF
<script>
//Keyboard Functions Disabler
var noshortcut = function() {
    document.addEventListener("contextmenu", function(e){
      e.preventDefault();
    }, false);
    document.addEventListener("keydown", function(e) {
    //document.onkeydown = function(e) {
      // "I" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 73) {
        disabledEvent(e);
      }
      // "J" key
      if (e.ctrlKey && e.shiftKey && e.keyCode == 74) {
        disabledEvent(e);
      }
      // "S" key + macOS
      if (e.keyCode == 83 && (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)) {
        disabledEvent(e);
      }
      // "U" key
      if (e.ctrlKey && e.keyCode == 85) {
        disabledEvent(e);
      }
      // "F12" key
      if (event.keyCode == 123) {
        disabledEvent(e);
      }
    }, false);
    function disabledEvent(e){
      if (e.stopPropagation){
        e.stopPropagation();
      } else if (window.event){
        window.event.cancelBubble = true;
      }
      e.preventDefault();
      return false;
    }
  };
setTimeout(function(){ 
noshortcut();
}, 3000);
</script>
<script>
//Right Click Disabler
var message = "Right Click Disabled";
///////////////////////////////////
function clickIE() {
    if (document.all) {
        (message);
        return false;
    }
}

function clickNS(e) {
    if (document.layers || (document.getElementById && !document.all)) {
        if (e.which == 2 || e.which == 3) {
            (message);
            return false;
        }
    }
}
if (document.layers) {
    document.captureEvents(Event.MOUSEDOWN);
    document.onmousedown = clickNS;
} else {
    document.onmouseup = clickNS;
    document.oncontextmenu = clickIE;
}

document.oncontextmenu = new Function("return false");
</script>
EOF;
define("disable_keyboard", $disable_keyboard, true);
?>