<?php
require_once __DIR__.'/vendor/autoload.php';

if (session_status() == PHP_SESSION_NONE) {
  session_start();
}

define('CREDENTIALS_PATH', 'tmp/'.determine_user().'.json');
$_SESSION["CREDENTIALS_PATH"] = CREDENTIALS_PATH;
define('SECRET_JSON', 'client_secret_439429450847-2r1oa7oj8r0hghopmaasi1brdbc3f2vj.apps.googleusercontent.com.json', true);
$DEVELOPER_KEY = "AIzaSyBYr0oEXIBLNXg4otQXfFO5fnomPQsDx4I";
define("KEY", $DEVELOPER_KEY, true);
define("REDIRECT_URI", 'http://' . $_SERVER['HTTP_HOST'] . '/callback.php', true);

function getClient() {
  $client = new Google_Client();
  $client->setApplicationName('AGC_BLOGGER');
  $client->setDeveloperKey(KEY);
  
  $client->setScopes( array( 'https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/userinfo.profile', 'https://www.googleapis.com/auth/plus.me', 'https://www.googleapis.com/auth/youtube.force-ssl' ) );
  
  $client->setAuthConfig(SECRET_JSON);
  $client->setAccessType('offline');
  $client->setRedirectUri( REDIRECT_URI );

  // Load previously authorized credentials from a file.
  $credentialsPath = expandHomeDirectory(CREDENTIALS_PATH);
  if (file_exists($credentialsPath)) {
    $accessToken = json_decode(file_get_contents($credentialsPath), true);
    if (isset($accessToken["error"])){
      unlink($credentialsPath);
      $auth_url = $client->createAuthUrl();
      return header('Location: ' . filter_var($auth_url, FILTER_SANITIZE_URL));
    }
  } else {
    $auth_url = $client->createAuthUrl();
    $_SESSION["auth_URL"] = $auth_url;

    try {
    $authCode = $_GET["code"];
    $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
    file_put_contents($credentialsPath, json_encode($accessToken));
    } catch(Exception $e){
      return header('Location: ' . filter_var($auth_url, FILTER_SANITIZE_URL));
    }
  }
  
  if (is_array($accessToken) && isset($accessToken["error"])){
    include("login.php");
    exit;
  } else {
    $client->setAccessToken($accessToken);
  }

  // Refresh the token if it's expired.
  if ($client->isAccessTokenExpired()) {
    try {
      $client->fetchAccessTokenWithRefreshToken( $client->getRefreshToken() );
      file_put_contents( $credentialsPath, json_encode( $client->getAccessToken() ) );
    } catch(Exception $e){
      if (file_exists(CREDENTIALS_PATH)){
        unlink(CREDENTIALS_PATH);
      }
      return header('Location: ' . filter_var($auth_url, FILTER_SANITIZE_URL));
    }
  }
  return $client;
}

function getClient2() {
  $client = new Google_Client();
  $client->setApplicationName("AGC_BLOGGER");
  $client->setDeveloperKey(KEY);
  
  $client->addScope( 'https://www.googleapis.com/auth/youtube' );
  $client->addScope( 'https://www.googleapis.com/auth/youtube.force-ssl' );
  $client->addScope( 'https://www.googleapis.com/auth/blogger' );
  
  $client->addScope( 'https://www.googleapis.com/auth/books' );
  $client->addScope( 'https://www.googleapis.com/auth/calendar' );
  //$client->addScope( 'https://www.googleapis.com/auth/cloud-platform' );
  $client->addScope( 'https://www.googleapis.com/auth/analytics' );
  $client->addScope( 'https://www.googleapis.com/auth/analytics.edit' );
  $client->addScope( 'https://www.googleapis.com/auth/analytics.manage.users' );
  $client->addScope( 'https://www.googleapis.com/auth/webmasters' );
  $client->addScope( 'https://www.googleapis.com/auth/youtubepartner-channel-audit' );
  $client->addScope( 'https://www.googleapis.com/auth/youtubepartner' );
  $client->addScope( 'https://www.googleapis.com/auth/userinfo.email' );
  $client->addScope( 'https://www.googleapis.com/auth/userinfo.profile' );
  $client->addScope( 'https://www.googleapis.com/auth/plus.me' );
  
  $client->setAuthConfig(SECRET_JSON);
  $client->setAccessType('offline');
  $client->setRedirectUri( REDIRECT_URI );
  
  if (file_exists($credentialsPath)) {
    $accessToken = json_decode(file_get_contents($credentialsPath), true);
  } else if (!isset($_GET['code'])) {
      $authUrl = $client->createAuthUrl();
      return header("Location: " . $authUrl);
  } else {  
    $authCode = trim($_GET["code"]);
    $accessToken = $client->fetchAccessTokenWithAuthCode( $authCode ); 
    file_put_contents( CREDENTIALS_PATH, json_encode($accessToken) );
  }
  
  try {//
    $client->setAccessToken($accessToken);
  } catch(Exception $e){
    $authUrl = $client->createAuthUrl();
    return header("Location: " . $authUrl);
  }
  if ($client->isAccessTokenExpired()) {
    $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
    file_put_contents( $credentialsPath, json_encode($client->getAccessToken()) );
  }
  return $client;
}



?>