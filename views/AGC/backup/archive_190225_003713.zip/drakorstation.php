<?php
session_start();
ob_start();
require __DIR__ . '/vendor/autoload.php';
use \Curl\Curl;
$curl = new Curl();
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
 $headers[] = 'Connection: Keep-Alive';
 $headers[] = 'Cache-Control: max-age=0';
 $headers[] = 'Upgrade-Insecure-Requests: 1';
 $headers[] = 'DNT: 1';
 $headers[] = 'Keep-Alive: 300';
 $headers[] = 'Content-type: */*;charset=UTF-8';
 $headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
 $headers[] = "Accept-Language: en-us,en;q=0.5";
 $headers[] = "Pragma: no-cache";
 $headers[] = "Origins: https://translate.google.co.id";
$curl->setHeaders($headers);
$curl->setUserAgent("Mozilla/5.0 (Linux; Android 7.0; Redmi Note 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Mobile Safari/537.36");
$curl->setReferrer("https://translate.google.co.id/m/translate");
$curl->setOpt(CURLOPT_ENCODING, 'gzip');
$curl->setOpt(CURLOPT_AUTOREFERER, true);
$curl->setOpt(CURLOPT_SSL_VERIFYPEER, false);
$curl->setOpt(CURLOPT_CAINFO, realpath("cacert.pem"));
$curl->setOpt(CURLOPT_COOKIESESSION, true);
$curl->setOpt(CURLOPT_RETURNTRANSFER, true);
$curl->setOpt(CURLOPT_FOLLOWLOCATION, true);
$curl->setCookieFile("cookie.txt"); $curl->setCookieJar("cookie.txt");


$url = "http://drakorstation.com";
if (isset($_GET['path'])){
  $url .= $_GET['path'];
}
$curl->get($url);

$page = $curl->response;
$html = str_get_html($page);

if (!isset($_GET['path'])){
  foreach ($html->find('a') as $a){
   // "((https?|ftp)://)?"
    $a->href = preg_replace('/(((https?)\:\/\/)?drakorstation.com)/', '?path=', $a->href);
  }
  echo $html->save();
  die();
}

$title = $html->find('title',0)->plaintext;
$title = preg_replace('(drakorstation)','', strtolower($title));
$_SESSION['title'] = $title = "Download ".trim(ucwords($title));

foreach ($html->find(".post_content") as $c){
  foreach ($c->find('a') as $a){
    $a->title=$title;
    $a->alt=$title;
    $a->rel='nofollow noopener noreferer';
    $match = parse_url($url);
    $match_href = parse_url($a->href);
    $href_scheme = (isset($match_href["scheme"]) ? $match_href["scheme"] : 'http');
    $x = $href_scheme.'://'.$match['host'];
    if (strpos($a->href, $match['host']) !== false){
      $a->href = str_replace($x, '?path=', $a->href);
    }
  }
  foreach ($c->find("img") as $img){
    $img->width='100%';
    $img->height='auto';
    $img->alt=$title;
    $img->title=$title;
    $img->src = "https://res.cloudinary.com/dimaslanjaka/image/fetch/".$img->src;
    if ($img->hasAttribute('srcset')){
      $img->removeAttribute('srcset');
    }
    if ($img->hasAttribute('sizes')){
      $img->removeAttribute('sizes');
    }
  }
  $chtml = $c->outertext;
  $rev=array('>drakorstation.com<','>Drakorstation.com<','>DrakorStation.com<');
  $chtml = str_replace($rev, '> Website Manajemen Indonesia <', $chtml);
  $chtml = trim($chtml);
  echo $chtml;
  echo "<h1 for='title' class='notranslate'>$title</h1>";
}

if (isset($_GET["path"])){
  $output = ob_get_contents();
  ob_clean();
  ob_start();
  $_SESSION["body"] = $output;
  echo $output;
  
$tl ='en';
$sl ='id';
$dir = 'movies';
include(realpath("saver.php"));
}