<?php
require_once("vendor/autoload.php");

function ExtC($name){
  $value = $_COOKIE[$name];
  setcookie($name, $value, time() + (86400 * 3), "/");
}