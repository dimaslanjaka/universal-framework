<?php
session_start();
ob_start();
require __DIR__ . '/vendor/autoload.php';
//require __DIR__ . '/dom.php';
//require 'translate.php';
use \Curl\Curl;
//use \simple_html_dom\simple_html_dom;
//use Stichoza\GoogleTranslate\TranslateClient;
//$tr = new TranslateClient();
//$tr->setUrlBase('http://translate.google.cn/translate_a/single');
//$tr->setSource('id');
//$tr->setTarget('en');
//echo $tr->translate();
$curl = new Curl();
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
 $headers[] = 'Connection: Keep-Alive';
 $headers[] = 'Cache-Control: max-age=0';
 $headers[] = 'Upgrade-Insecure-Requests: 1';
 $headers[] = 'DNT: 1';
 $headers[] = 'Keep-Alive: 300';
 $headers[] = 'Content-type: */*;charset=UTF-8';
 $headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
 $headers[] = "Accept-Language: en-us,en;q=0.5";
 $headers[] = "Pragma: no-cache";
 $headers[] = "Origins: https://translate.google.co.id";
$curl->setHeaders($headers);
$useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";
$curl->setUserAgent($useragent);
$curl->setReferrer("https://translate.google.co.id/m/translate");
$curl->setOpt(CURLOPT_ENCODING, 'gzip');
$curl->setOpt(CURLOPT_AUTOREFERER, true);
$curl->setOpt(CURLOPT_SSL_VERIFYPEER, false);
$curl->setOpt(CURLOPT_CAINFO, realpath("cacert.pem"));
$curl->setOpt(CURLOPT_COOKIESESSION, true);
$curl->setOpt(CURLOPT_RETURNTRANSFER, true);
$curl->setOpt(CURLOPT_FOLLOWLOCATION, true);
$curl->setCookieFile("cookie.txt"); $curl->setCookieJar("cookie.txt");
/*
if (isset($_GET["proxy"])){
$proxy = $_GET["proxy"];
} else if (isset($_SESSION["proxy"])){
$proxy = $_SESSION["proxy"];
} else {
$proxy = "37.98.175.251:81";
}
if (!empty($proxy)){
$curl->setProxy($proxy);
$curl->setProxyTunnel();
}*/
$url = "https://paling-top21.blogspot.com/2018/11/cara-aktivasi-microsoft-office-2007.html";

function parsetry($thetr){
  global $curl;
$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($thetr);

try {
  $iFrame = $dom->getElementsByTagName('iframe')->item(0) or null;
  if (null === $iFrame){
    throw new Exception("The field is undefined.");
  } else {
    $iFramesrc = $iFrame->getAttribute('src');
    if (strpos($iFramesrc, "googleusercontent") !== false){
      $thetr2 = $curl->get($iFramesrc);
      $filter = $thetr2;
    }
  }
} catch (Exception $e){
$A = $dom->getElementsByTagName('a')->item(0) or null;
if (null === $A){
  throw new Exception($e->getMessage()." The ~A~ field is undefined.");
  } else {
$Ahref = $A->getAttribute("href") or $A->getAttribute("HREF");
   if (strpos($Ahref, "googleusercontent") !== false){
    $thetr2 = $curl->get($Ahref);
    $filter = $thetr2;
   }
  }
}
if (empty($filter)){
  return Exception;
  } else {
    return $filter;
    }
}

function translate($url, $hl, $tl){
  global $curl;
$urltotranslate = $url;
if (!isset($tl)){
$tl = "en";
}
if (!isset($hl)){
$hl = "auto";
}

$usg1 = substr(md5(microtime()),rand(0,26),5);
$usg2 = substr(md5(microtime()),rand(0,26),5);
$usg3 = substr(md5(microtime()),rand(0,26),5);
$multiplehash = "1000,1500002,15700002,15700022,15700122,15700124,15700149,15700168,15700173,15700186,15700201";
$thetr = $curl->get("https://translate.googleusercontent.com/translate_c?depth=3&nv=1&rurl=translate.google.com&sl=".$hl."&sp=nmt4&tl=".$tl."&u=".$urltotranslate."&xid=".$multiplehash."&usg=".$usg1."_".$usg2."-".$usg3);
$filter = parsetry($thetr);
try {
 if (strpos($filter, '<a href="https://translate.googleusercontent.com') !== false){
  $filter = parsetry($filter);
 } 
 if (strpos($filter, '<iframe src="https://translate.googleusercontent.com') !== false){
  $filter = parsetry($filter);
 }
} catch(Exception $e){
  if (strpos($filter, '<iframe src="https://translate.googleusercontent.com') !== false){
    $filter = parsetry($filter);
   }
   if (strpos($filter, '<a href="https://translate.googleusercontent.com') !== false){
    $filter = parsetry($filter);
   } 
  }

$domnew = new \DOMDocument('1.0', 'UTF-8');
libxml_use_internal_errors(true);
$domnew->loadHTML(mb_convert_encoding($filter, 'HTML-ENTITIES', 'UTF-8'));
$xpath = new DOMXpath($domnew);

$head = $domnew->getElementsByTagName('head')->item(0);
$body = $domnew->getElementsByTagName('body')->item(0);

$modlink = $xpath->query('//a');
foreach ($modlink as $link){
$href = $link->getAttribute('href');
$url_parts = parse_url($href);
if (false !== parse_str($url_parts['query'], $url_query)){

if (strpos($link->getAttribute('rel'), 'related') === false){
if (!isset($query['lang'])){
$hrefd = urldecode ($url_query['u']);
} else {
$hrefd = urldecode ($url_query['u']) . "&lang=" . $query['lang'];
}
}
$link->setAttribute('href', $hrefd);

} else {
  die("Reload pagenya gan, Server Overload");
}
}

$spans = $xpath->query('//span');
foreach ($spans as $span){
if (strpos($span->getAttribute("class"), "google-src-text") !== false){
$span->parentNode->removeChild($span);
}
}

$iframes = $xpath->query('//iframe');
foreach ($iframes as $iframe){
if (strpos($iframe->getAttribute("id"), "gt-nvframe") !== false){
$iframe->parentNode->removeChild($iframe);
}
}

$scripts = $xpath->query('//script');
foreach ($scripts as $script){
$transreg=array($script->nodeValue, $script->getAttribute('src'));
foreach ($transreg as $matches){
if (preg_match('/(translate|wtsrt_|_addload)/mi', $matches)){
$script->parentNode->removeChild($script);
}
} //End array each
}

$getalltags = $xpath->query('//*');
foreach ($getalltags as $tag){
  if ($tag->tagName == 'h1' && $tag->hasAttribute('for') && $tag->getAttribute('for') == 'title'){
   $_SESSION["title"] = $tag->textContent;
  }
if (!empty($tag->getAttribute("onmouseover"))){
$tag->removeAttribute("onmouseover");
}
if (!empty($tag->getAttribute("onmouseout"))){
$tag->removeAttribute("onmouseout");
}
if (strpos($tag->getAttribute("title"), "000webhost") !== false){
$tag->parentNode->removeChild($tag);
}
if (preg_match('/(X-Translated-By)/mi', $tag->getAttribute("http-equiv"))){
$tag->parentNode->removeChild($tag);
}
}
if (null !== $body && $body->hasAttribute("style")){
  $body->removeAttribute("style");
}
//return $body->ownerDocument->saveHTML($body);
if (isset($_GET["grab"])){
$a_html_title = $domnew->getElementsByTagName('title');
$a_html_title = $a_html_title->item(0)->nodeValue;
if (!empty($a_html_title)){
  $_SESSION["title"] = $a_html_title;
}
}
 return $domnew->savehtml($body);
// return $domnew->saveHTML();
}

echo translate($url, "id", "en");