<?php
header('Content-Type: text/plain; charset=utf-8');
if (strpos(strtolower(serialize($_COOKIE)), 'filemanager' === false)){
  require __DIR__ . '/vendor/autoload.php';
}
session_start();
var_dump($_SESSION, $_COOKIE);