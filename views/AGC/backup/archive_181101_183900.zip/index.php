<?php header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0"); header("Cache-Control: post-check=0, pre-check=0", false); header("Pragma: no-cache"); ?>
<!DOCTYPE html>
<html lang="en" class="">
	<head>
          <title>Dimas Lanjaka Web-Based Projects</title>
		<script src="//static.codepen.io/assets/editor/live/console_runner-ce3034e6bde3912cc25f83cccb7caa2b0f976196f2f2d52303a462c826d54a73.js"></script>
		<script src="//static.codepen.io/assets/editor/live/css_reload-2a5c7ad0fe826f66e054c6020c99c1e1c63210256b6ba07eb41d7a4cb0d0adab.js"></script>
		<meta charset="UTF-8" />

		<meta name="robots" content="nofollow, index" />

		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

		<meta http-equiv="Page-Enter" content="blendTrans(Duration=1.0)" />

		<meta http-equiv="Page-Exit" content="blendTrans(Duration=1.0)" />

		<meta http-equiv="Site-Enter" content="blendTrans(Duration=1.0)" />

		<meta http-equiv="Site-Exit" content="blendTrans(Duration=1.0)" />

		<link rel="shortcut icon" type="image/x-icon" href="//static.codepen.io/assets/favicon/favicon-8ea04875e70c4b0bb41da869e81236e54394d63638a1ef12fa558a4a835f1164.ico" />

		<link rel="mask-icon" type="" href="//static.codepen.io/assets/favicon/logo-pin-f2d2b6d2c61838f7e76325261b7195c27224080bc099486ddd6dccb469b8e8e6.svg" color="#111" />

		<link rel="canonical" href="https://codepen.io/dimaslanjaka/pen/EdMrQa" />

		<link href="https://fonts.googleapis.com/css?family=Amatic+SC|Bai+Jamjuree|Rajdhani&amp;subset=latin-ext" rel="stylesheet" />

		<style class="cp-pen-styles">body {
      background-color: rgb(243, 244, 245);
      padding: 0;
      margin: 0;
      /* font-family: 'Amatic SC', cursive; */
      font-family: 'Rajdhani', sans-serif;
      letter-spacing: .1em;
      font-size: 1.5em;
      text-align: center;
      max-width: 100%;
      max-height: 100%;
      }
      .over-container {
        height: 100vh;
        display: flex;
        justify-content: center;
        align-content: center;
      }
      .container {
        align-self: center;
      }
      .search-container {
        justify-self: center;
        margin-bottom: 15px;
      }
      .search {
        border: none;
        border-bottom: 3px solid rgb(86, 94, 101);
        height: 46px;
        font-family: inherit;
        font-size: inherit;
        background-color: rgb(243, 244, 245);
        color: rgb(174, 180, 184);
        width: 60%;
      }
      .search:focus {
        outline: none;
      }
      .search::placeholder {
        color: rgb(174, 180, 184);
      }
      input {
        border: none;
      }
      .menu {
        min-width: auto;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
      }
      .tiles {
        padding: 0.5em;
        display: flex;
        flex-direction: column;
      }
      .button {
        text-decoration: none;
        background-color: rgb(86, 94, 101);
        color: rgb(218, 220, 222);
        padding: 7px 30px;
      }
      .tile1 {
        background: rgb(149, 199, 174);
        color: rgb(86, 94, 101);
        padding: 7px 30px;
      }
      .tile2 {
        background-color: rgb(199, 174, 149);
        color: rgb(86, 94, 101);
        padding: 7px 30px;
      }
      .tile3 {
        background-color: rgb(199, 149, 174);
        color: rgb(86, 94, 101);
        padding: 7px 30px;
      }
      .tile4 {
        background-color: rgb(149, 174, 199);
        color: rgb(86, 94, 101);
        padding: 7px 30px;
      }
      .tile5 {
        background-color: rgb(174, 199, 149);
        color: rgb(86, 94, 101);
        padding: 7px 30px;
      }
      .tile6 {
        background-color: rgb(174, 149, 199);
        color: rgb(86, 94, 101);
        padding: 7px 30px;
      }
      a:hover {
        background-color: #343c43;
      }
      /* {
        max-width: 100%;
        max-height: 100%;
      }*/
    
		</style>
	</head>
	<body onload="document.searchform.q.focus();">
		<!--meta name="viewport" content="width=1024">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="viewport" content="width=1024"-->
		<div class="over-container">
			<div class="container">
			<h1>Web-based Project</h1>
				<div class="search-container">
					<form action="https://www.google.com/search" class="searchform" method="get" name="searchform" target="_blank">
						<input autocomplete="off" class="form-control search" name="q" placeholder="search" required="required" type="text" />

					</form>
				</div>
				<div class="menu">
					<div class="tiles">
						<div class="tile1">social</div>
						<a href="https://www.facebook.com/dimaslanjaka1/" target="_blank" class="button">facebook</a>
						<a href="https://plus.google.com/108171489708218648681/" class="button">Google Plus</a>
						<a href="https://www.youtube.com/channel/UCGNaoefvJRfd15fo-LQ0zvg" class="button">youtube</a>
					</div>
					<div class="tiles">
						<div class="tile2">Repo</div>
						<a href="https://github.com/dimaslanjaka/" class="button">Github</a>
						<a href="https://codepen.io/dimaslanjaka/pens/public/" class="button">Codepen</a>
						<!--a href="https://www.google.pl/maps" class="button">mapy</a>
						<a href="https://translate.google.com/" class="button">tłumacz</a>
						<a href="https://photos.google.com/" class="button">zdjęcia</a-->
					</div>
					<div class="tiles">
						<div class="tile3">interests</div>
						<a href="https://web-manajemen.blogspot.com/search/label/Tips & Tricks?max-results=8" class="button">Tips & Tricks</a>
						<a href="https://web-manajemen.blogspot.com/search/label/PHP?max-results=8" class="button">PHP</a>
						<a href="https://web-manajemen.blogspot.com/search/label/Javascript?max-results=8" class="button">Javascript</a>
						<a href="https://web-manajemen.blogspot.com/search/label/Durango?max-results=8" class="button">Durango</a>
						<a href="https://web-manajemen.blogspot.com/search/label/Adsense?max-results=8" class="button">Adsense</a>
					</div>
					<div class="tiles">
						<div class="tile4">Services</div>
						<a href="instagram/" class="button">Autolike Instagram</a>
						<a href="instagram/login-fb.php" class="button">Autolike Facebook</a>
						<!--a href="https://jakdojade.pl/szczecin/trasa/" class="button">jakdojade</a-->
					</div>
				</div> <!--/menu-->
			</div> <!--/container-->
		</div> <!--/over container-->
	</body>
</html>