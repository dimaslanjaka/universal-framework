<?php

$_SESSION["result"] = [];
$logg = array();
if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
/*
while (1){
   if (!empty($logg)){
         //$_SESSION["result"] = $logg;
         var_dump($logg);
   }
}
*/
function cook(){
$data = unserialize($_COOKIE['result']);
return $data;
}
function setx($log){
  //array_push( $_SESSION["result"], $log);
 $_SESSION["result"][] = $log;
 if (!isset($_COOKIE["result"])){
    setcookie("result", serialize($_SESSION["result"]), time() + (360/*seconds*/ * 30), "/v2/");
 } else {
    $combined = array_merge(cook(),$_SESSION["result"]);
    $combined = array_unique($combined);
    setcookie("result", serialize($combined), time() + (360/*seconds*/ * 30), "/v2/");
 }
 return true;
}

function dumpx(){
if (!empty($_SESSION["result"])){
   $log = "";
   foreach ($_SESSION["result"] as $l){
      $log.=$l;
      }
      return $log;
}
}

if (isset($_GET["show"])){
foreach (cook() as $log){
echo nl2br($log);
}}
?>