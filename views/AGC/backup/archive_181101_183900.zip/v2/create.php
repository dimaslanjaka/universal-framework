<?php
if ($_SERVER['REQUEST_METHOD'] == "POST"){
   
if(isset($_POST['msg']) && isset($_POST['namefile'])) {
if (file_exists('tokens/'.$_POST['namefile'].'.txt')) {
unlink('tokens/'.$_POST['namefile'].'.txt');
}
    $data = $_POST['msg'];
    $ret = file_put_contents('tokens/'.$_POST['namefile'].'.txt', $data, FILE_APPEND | LOCK_EX);
    if($ret === false) {
        die('There was an error writing this file');
    }
    else {
        //echo "$ret bytes written to file";
        echo '
        Your AutoLike Was Performed, You can close this tab. Your autolike will be run in 
        Your autolike will run in a few minutes.
        <a href="#" onclick="location.href=\'/\';">close this message</a>
        ';
    }
}
else {
   echo 'no post data to process';
}

}