<?php
session_start();
ob_start();
?><!DOCTYPE HTML>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Bot Reaction Facebook v2</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous" />
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-7975270895217217",
          enable_page_level_ads: true
     });
</script>
<style>
#ajax,.input-group,form{margin-top:20px}
*{word-wrap: break-word;max-width;100%;}
</style>
<script>
function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
        //expires = "; expires=2030";
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}

</script>
</head>
<body>
<div class="container">
<blockquote>Belum punya akses token ?. <a href="http://simpleliker.net/ss/token_myfbliker.php" target="_blank">Klik Disini</a> untuk mendapatkan akses token.</blockquote>
<center>
<div id="fb-root"></div>
<script>
/*
var checkLogin;
   FB.init( { 
   appId : 182383652179465, 
   status : true, // check login status 
   cookie : true, // enable cookies to allow the server to access the session 
   xfbml : true, // parse XFBML
   autoLogAppEvents : true,
   version : 'v3.1'
   } );*/

(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.12&appId=182383652179465&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

var userLogin;
var userLogout;
var checkLogin;

$(document).ready(function(){
checkLogin = function(){
FB.getLoginStatus(function(response) {
   if (response.authResponse) {
      var tokens = response.authResponse.accessToken;
      $("#info").html("Logged In As: <br/>");
      if (response.status === 'connected') {
         FB.api(response.authResponse.userID+"?fields=id,name,email",function(response) {
          $("#info").append("Name: "+response.name+"<br/>Email: "+response.email+"<br/>Tokens: "+tokens);
         });
         setCookie('uid',response.authResponse.userID,1);
         setCookie("ready", 1, 1);
         } else if (response.status === 'not_authorized' || response.status === 'authorization_expired') {
            $("#info").html("Please Log Into App Below");
         }
      } else {
   $("#info").html("Not Logged In, Please Login Before (Bellow)");
      //window.location.href="flush.php";
         }
  
     $("#info").append(response);
     });
     }

     userLogout = function() {
    FB.getLoginStatus(function(response) {
        if (response && response.status === 'connected') {
            FB.logout(function(response) {
                document.location.reload();
            });
        }
    });
}
    userLogin = function(){ 
    
FB.getLoginStatus(function(response) {
  if (response.status === 'connected') {
     var days = 1;
    var uid = response.authResponse.userID;
    var accessToken = response.authResponse.accessToken;
    setCookie('uid',uid,days);
    var ready = getCookie("ready");
    if (ready == null) {
      window.location.reload();
      setCookie("ready",1,days);
    }
  } else if (response.status === 'not_authorized') {
    alert("Please allow app to logged in");
  } else {
    // the user isn't logged in to Facebook.
    eraseCookie("uid");
    eraseCookie("ready");
  }
 });
     };
});

</script>
<?php
 if (!isset($_COOKIE["uid"])) {
?>
<pre>
<b id="info"></b>
<script>
setTimeout(function(){ 
checkLogin();
}, 3000);
</script>
</pre>
<div class="fb-login-button" data-width="280" data-max-rows="1" data-size="large" data-button-type="login_with" data-show-faces="true" data-auto-logout-link="true" data-use-continue-as="true" onlogin="userLogin();"></div>
</center>
<blockquote>Sebelumnya anda logout dulu bila tombol diatas sudah menyatakan login. Lalu login kembali, untuk mencatat anda boleh masuk melewati situs ini atau tidak. (IP Restriction). <i>Atau klik <b>refresh</b> dibawah ini</i></blockquote>
<?php
 } else {
    ?>
<pre>
<b id="info"></b>
<script>
setTimeout(function(){ 
checkLogin();
}, 3000);
</script>
</pre>
    <button onclick='window.location.href="flush.php";' class='btn btn-primary'>Logout</button>
    <?php
    }
if(isset($_COOKIE['uid'])){
$user = $_COOKIE['uid'];
?>
<form id="fire" class="form-group" action="?ready" method="POST">
 <div class="input-group">
 <span class="input-group-addon">Token</span>
 <input id="msg" type="text" class="form-control" name="msg" placeholder="Input Your Tokens Here" />
 <input id="submitmsg" type="submit" name="submit" class="btn btn-block btn-primary" value="My Token Ready" />
 </div>
</form>
<script>
var form = $("#fire");
var inputBox = $("#msg");
var submitButton = $("#submitmsg");
submitButton.click(function(){
var getval = $("#msg").val();
setCookie('token',getval,1);
});
</script>
<?php
if (strpos($_SERVER['REQUEST_URI'],'ready') !== false) {
?>
<style>#fire{display:none}</style>
<center><button class='btn btn-primary btn-block' id='ajax'>Perform My Autolike</button></center>
<?php
}
?>
<div class="result"></div>
<script>
var msg = $('input[name="msg"]').val();
$("#ajax").click(function(e) {
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "create.php",
        data: { 
            namefile: getCookie('uid'), 
            msg: getCookie('token')
        },
        success: function(result) {
            document.write(result);
        },
        error: function(result) {
            document.write(result);
        }
    });
});
</script>
<?php
} else {
?>
<center>
Awaiting Login Facebook... <a href="" class="btn btn-primary left d-inline-block" onclick="userLogin();">Reload/Refresh</a>
</center>
<?php
}
?>

<div class="row">
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="2600604346" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="4025331886" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="7267894124" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
</div>

</div>

<script type="text/javascript">
var myArray = ['https://web-manajemen.blogspot.com/p/a.html?u='];
var safelink = myArray[Math.floor(Math.random() * myArray.length)];
var protectedLinks = /(dimaslanjaka|bing.com|google.com|linkedin.com|facebook.com|pinterest.com|digg.com|twitter.com|blogger.com|ask.com|secretnetworkforces|sembilanan.tk|webmanajemen.xyz|linkshrink.net|afu.php|nullrefer.com)/
$( 'a' ).each(function() {
if (this.href.match( protectedLinks ) ){
    $(this).attr('href', $(this).attr('href'));
  } else {
    $(this).attr('href', safelink+encodeURIComponent($(this).attr('href')));
  }
});
</script>
</body>
</html>
<?php
$output = ob_get_contents();
ob_clean();
ob_start();
include("minify.php");
echo minify_html($output);
?>