<?php
@ini_set('output_buffering',0);
@ini_set('max_execution_time',0);
//header("Content-type: application/json; charset=utf-8");
//session_start();
//*** Copyright Dimas Lanjaka ***//
//*** BOT REACTION FACEBOOK ***//
//error_reporting(0);
   include("function.php");
   include("config.php");
   include("log.php");
// react.php?type=(TYPE REACTION)&token=(YOUR ACCESS TOKEN)
// http://127.0.0.1/reaction.php?type=HAHA&token=EAAAAAYsX7TsBAgaHpfsYad7xehpUsXbOcfD0bZAbjFdMnaW47nqm

function post_data($url, $post=null){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
if($post != null){
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
}
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$exec = curl_exec($ch);
curl_close($ch);
return $exec;
}

if(!empty($_GET['token'])) {
$access_token = $_GET['token'];
} else {
   //die('Token Not Found');
   }

if(!empty($_GET['type'])) {
$type = $_GET['type'];
} else {
    $type = [
    "LIKE","LOVE","HAHA","WOW","SAD"
    /*,"ANGRY"*/];
    shuffle($type);
    $type = $type[array_rand($type)];
   //die('Reaction Type Not Found');
   }

if(!isset($_GET["max"])) {
   $max = 5;
   } else {
      $max = $_GET["max"];
      }

function gethome($access_token, $max=null){
   if (null === $max){
      $max = 5;
      }
   $url = 'https://graph.facebook.com/v2.11/me/home?fields=id&limit='.$max.'&access_token='.$access_token;
   return post_data($url);
}

function send_r($homepost, $access_token, $type){
   $stat = json_decode($homepost, true);
   if (count($stat['data']) > 0){
   for ($i = 1; $i <= count($stat['data']); $i++) {
   $id = $stat['data'][$i - 1]['id'];
   $post_react = "https://graph.facebook.com/v2.11/".$id."/reactions?";
   $type_react = array(
   "type"=>$type,
   "method"=>"post",
   "access_token"=>$access_token
   );
   $check_post = $post_react . "token=" . $access_token;
   if (isset($_GET["exec"])){
      $send = post_data($post_react, $type_react);
      return $id;
   } else {
      return $check_post;
      }
   }
   } // data not empty
}


if (!isset($_GET["token"])){
   
foreach(file(select_file()) as $line) {
   if (!isset($access_token)){
   $access_token = $line;
   }
   //echo 'https://graph.facebook.com/v2.11/me/home?fields=id&limit='.$max.'&access_token='.$access_token;
   $home = gethome($access_token, 5);
   $send = send_r($home, $access_token, $type);
   if (null !== $send){
      $id = 'Content ID : '.$send.' <span style="color:green"> [SUCCESS]</span> Reacted '.$type.' ✓<br>';
      setx($id);
      echo $id;
   }
   sleep(3);
}

} else {
   $home = gethome($access_token, 5);
   $send = send_r($home, $access_token, $type);
   if (null !== $send){
      $id = 'Content ID : '.$send.' <span style="color:green"> [SUCCESS]</span> Reacted '.$type.' ✓<br>';
      setx($id);
      echo $id;
   }
   }
?>