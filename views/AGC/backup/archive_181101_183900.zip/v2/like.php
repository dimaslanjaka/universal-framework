<?php
@ini_set('output_buffering',0);
@ini_set('max_execution_time',0);
header("Content-type: application/json; charset=utf-8");
//session_start();

	include ("function.php");
	include ("config.php");
	include ("log.php");
	$LOG = "";

if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
	
 $cookies_value = "";
if (!isset($_GET["token"])){
echo "Jalankan ini dengan Cronjob 5 menit 1x\n\n";
echo "URL Cronjob: " .  working_domain . strtok($_SERVER["REQUEST_URI"],'?') . "?max=5&token=" . (isset($_GET['token']) ? $_GET['token'] : 'Your_Access_Token') . "\n\n";
echo "You can specify a maximum of posts that will be liked by changing max=5\n\n";
}
/*
function select_file($dir = 'tokens')
{
    $files = glob($dir . '/*.txt');
    $file = array_rand($files);
    return $files[$file];
}
*/
$curlopt["cookiefile"] = "./cookie.txt";

$token = (isset($_GET['token']) ? $_GET['token'] : exit('Please Input ?token=your_access_token_here'));

$max = (isset($_GET['max']) ? $_GET['max'] : "5");

if (null !== $token && null !== $max){
define("max", $max, true);
define("token", $token, true);
}

if(strlen(trim(token)) > 100){

function gethome($token, $max){
$home = "https://graph.beta.facebook.com/me/home?fields=id,likes,comments.field(id,user_likes)&limit=".$max."&access_token=".$token;
global $curlopt;
$gethome = fetch($home, $curlopt);
return $gethome;
}

function getcomments($token, $id, $max){
$url = "https://graph.beta.facebook.com/".$id."/comments?fields=id,likes&limit=".$max."&access_token=".$token;
global $curlopt;
$get = fetch($url, $curlopt);
return $get;
}

function sendlike($token, $id){
$url = "https://graph.beta.facebook.com/".$id."/likes?method=post&access_token=".$token;
global $curlopt;
$send = fetch($url, $curlopt);
return $send;
}
//_____ Get Homepage Posts
$home = json_decode( gethome(token, max) , true );

    if ($home !== null && !empty($home)){
//$home["data"][0]["likes"]["data"]
foreach ($home["data"] as $data){
//var_dump($data);
//_____ Like Posts
if (empty($data["likes"]["data"][0])){
if (null !== sendlike(token, $data["id"])){
 $p_liked = $data["id"] . " Post Liked\n";
 $LOG.=$p_liked;
 //setx($p_liked);
 //echo $p_liked;
}
}
//_____ Like Comments
 if ( !empty ( $data["comments"] )){
  $com = getcomments(token, $data["id"], max);
  $com = json_decode($com, true);
  foreach ($com["data"] as $i => $cdata){
  // var_dump($data);
   if (empty($cdata["likes"]["data"][0])){
   if (null !== sendlike(token, $cdata["id"])){
   $c_liked = $cdata["id"] . " Comment Liked\n";
   $LOG.=$c_liked;
   //setx($c_liked);
   //echo $c_liked;
   }
   }
    if ($i > 0 && $i % 5 == 0) {
        sleep(3);
    }
  }
 }
}
    } else { //Json Null //Token Error
       $json_null = "Token Error";
       $LOG.=$json_null;
       //setx($json_null);
       //echo $json_null;
       }

} //If string token valid
setx($LOG);
foreach (cook() as $log){
echo $log;
}