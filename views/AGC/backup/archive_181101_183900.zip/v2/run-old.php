<?php
@ini_set('output_buffering',0);
@ini_set('display_errors', 0);
@ini_set('max_execution_time',60);
@set_time_limit(0);
@ignore_user_abort(1);
error_reporting(0);

date_default_timezone_set('Asia/Jakarta');
$datex = date('m/d/Y h:i:s a', time());
file_put_contents("access-log.txt", $datex . " | " . $_SERVER['HTTP_USER_AGENT'] . "\n", FILE_APPEND);

function select_file($dir = 'tokens')
{
    $files = glob($dir . '/*.txt');
    $file = array_rand($files);
    return $files[$file];
}

function auto($url)
{
    $data = curl_init();
    curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($data, CURLOPT_URL, $url);
    $hasil = curl_exec($data);
    curl_close($data);
    return $hasil;
}

foreach(file(select_file()) as $line) {
   $access_token = $line;

if (file_exists('target_status')) {
    $log = json_encode(file('target_status'));
} else {
    $log = '';
}
if (file_exists('target_comment')) {
    $log2 = json_encode(file('target_comment'));
} else {
    $log2 = '';
}

$stat = json_decode(auto('https://graph.beta.facebook.com/me/home?fields=id,likes,comments.field(id,user_likes)&limit=5&access_token=' . $access_token), true);
for ($i = 1; $i <= count($stat[data]); $i++) {
    if (!ereg($stat[data][$i - 1][id], $log)) {
        $x = $stat[data][$i - 1][id] . "\n";
        $y = fopen('target_status', 'a');
        fwrite($y, $x);
        fclose($y);
echo "Postid: " . $x;
echo "Comments!: " . $stat[likes];
/*
        auto('https://graph.beta.facebook.com/' . $stat[data][$i - 1][id] . '/likes?method=post&access_token=' . $access_token);
        echo '<span style="color:#0E0101">' . $stat[data][$i - 1][id] . '</span> <span style="color:green"> Like Status OK </span>
';
*/
    } 
    else 
    {
        $foxdamn = json_decode(auto('https://graph.beta.facebook.com/' . $stat[data][$i - 1][id] . '/comments?fields=id&access_token=' . $access_token), true);
        for ($e = 1; $e <= count($foxdamn[data]); $e++) {
            if (!ereg($foxdamn[data][$e - 1][id], $log2)) {
                $q = $foxdamn[data][$e - 1][id] . "\n";
                $w = fopen('target_comment', 'a');
                fwrite($w, $q);
                fclose($w);
echo "Comments: " . $q;
/*
                auto('https://graph.beta.facebook.com/' . $foxdamn[data][$e - 1][id] . '/likes?method=post&access_token=' . $access_token);
                echo ('id komen : ' . $foxdamn[data][$e - 1][id] . ' <span style="color:green"> Like Komen OK </span>
');
*/
            }
        }
    }
    flush();
    ob_flush();
    sleep(0);
}
unlink('target_comment');
unlink('target_status');
}

?>