<?php
//include("function.php");
//include("config.php");
include("dom.php");
ob_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0"); 
header("Cache-Control: post-check=0, pre-check=0", false); 
header("Pragma: no-cache");

function fetch( $url, $z=null ) {
$_SESSION["peek"] = $url;
            $ch =  curl_init();
if (strpos($url, "https") !== false){
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
}
            $useragent = isset($z['useragent']) ? $z['useragent'] : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2';
            if (isset($z["dump"])) curl_setopt($ch, CURLOPT_HEADER, 1);
            if (isset($z["headers"])) curl_setopt($ch, CURLOPT_HTTPHEADER, $z["headers"]); 
            curl_setopt( $ch, CURLOPT_URL, $url );
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
            curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
            curl_setopt( $ch, CURLOPT_POST, isset($z['post']) );

            if( isset($z['post']) )         curl_setopt( $ch, CURLOPT_POSTFIELDS, $z['post'] );
            if( isset($z['refer']) )        curl_setopt( $ch, CURLOPT_REFERER, $z['refer'] );
/*
if (isset($_SESSION["prxwork"])){
curl_setopt($ch, CURLOPT_PROXY, $_SESSION["prxwork"]);
} else */
if (isset($z["proxy"])){
curl_setopt($ch, CURLOPT_PROXY, $z["proxy"]);
}
            curl_setopt( $ch, CURLOPT_USERAGENT, $useragent );
            curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, ( isset($z['timeout']) ? $z['timeout'] : 5 ) );

$cookie = (isset($z['cookiefile']) ? $z['cookiefile'] : realpath("cookies.txt"));
            curl_setopt( $ch, CURLOPT_COOKIEJAR,  $cookie );
            curl_setopt( $ch, CURLOPT_COOKIEFILE, $cookie );

if (isset($z['verbose'])){
curl_setopt($ch, CURLOPT_VERBOSE, true);
}
            $result = curl_exec( $ch );
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$_SESSION["ContentType"] = $contentType;
$info = curl_getinfo($ch);
if (isset($z["dumpinfo"])){
var_dump($info);
}
            curl_close( $ch );
if ($info['http_code'] == 200) {
/*
if (!isset($_SESSION["prxwork"])){
$_SESSION["prxwork"] = $z["proxy"];
}
*/
            return $result;
 } else {
  return null;
 }
}

function num($digits=null){ 
return rand(pow(10, $digits-1), pow(10, $digits)-1);
}

function QURL($str){
   $url_parts = parse_url($str);
   if (isset($url_parts['query'])){
      parse_str($url_parts['query'], $url_query);
      return $url_query;
   }
}

function dotranslate($url, $hl, $tl, $opt=null){
$urltotranslate = $url;
if (!isset($tl)){
$tl = "en";
}
if (!isset($hl)){
$hl = "auto";
}
$cookie_file = 'cookies.txt';
if (file_exists($cookie_file)){
/*if (!is_writable($cookie_file)) {
chmod($cookie_file, 0755);
chmod("../tmp", 0755);
}*/
} else { $f = fopen($cookie_file, "w+"); fclose($f); chmod($cookie_file, 0777); }
$options['cookiefile'] = realpath($cookie_file);
$usg1 = substr(md5(microtime()),rand(0,26),5);
$usg2 = substr(md5(microtime()),rand(0,26),5);
$usg3 = substr(md5(microtime()),rand(0,26),5);
$multiplehash = "1000,1500002,15700002,15700022,15700122,15700124,15700149,15700168,15700173,15700186,15700201";
$multiplehash = num(4).",".num(7).",".num(8).",".num(8).",".num(8).",".num(8).",".num(8).",".num(8).",".num(8).",".num(8).",".num(8);
$options['refer'] = 'https://translate.google.co.id/m/translate';
$options['timeout'] = 60;
$thetr = fetch("https://translate.googleusercontent.com/translate_c?depth=3&nv=1&rurl=translate.google.com&sl=".$hl."&sp=nmt4&tl=".$tl."&u=".$urltotranslate."&xid=".$multiplehash."&usg=".$usg1."_".$usg2."-".$usg3, $options);

$dom = new DOMDocument();
libxml_use_internal_errors(true);
$dom->loadHTML($thetr);
$iFrame = $dom->getElementsByTagName('iframe')->item(0);
$iFramesrc = $iFrame->getAttribute('src');
$dom1 = fetch($iFramesrc, $options);
$dom2 = new DOMDocument();
libxml_use_internal_errors(true);
$dom2->loadHTML($dom1);
$redirect = $dom2->getElementsByTagName('a')->item(0);
$redirectsrc = $redirect->getAttribute('href');
$dom2r = fetch($redirectsrc, $options);
$dom3 = new DOMDocument();
libxml_use_internal_errors(true);
$dom3->loadHTML($dom2r);
$xpath = new DOMXpath($dom3);
$all = $xpath->query('//*');
foreach ($all as $tag){

if ($tag->nodeName === "body"){
if (!empty($tag->getAttribute("style"))){
$tag->removeAttribute("style");
}
} //Body's

if ($tag->nodeName === "a"){
$href = $tag->getAttribute('href');
$tag->setAttribute("href", QURL(htmlspecialchars_decode($href))["u"]);
}

if ($tag->nodeName === "img"){
   if (isset($opt["cdn"])){
if (strpos($tag->getAttribute('src'), 'cloudinary') === false){
$tag->setAttribute('src', $opt["cdn"] . $tag->getAttribute('src'));
}
   }
($tag->hasAttribute('srcset') ? $tag->removeAttribute('srcset') : false);
($tag->hasAttribute('sizes') ? $tag->removeAttribute('sizes') : false);
($tag->hasAttribute('title') ? $tag->removeAttribute('title') : false);
($tag->hasAttribute('alt') ? $tag->removeAttribute('alt') : false);
} // images

(!empty($tag->getAttribute("lang")) ? $tag->removeAttribute("lang") : false);
(!empty($tag->getAttribute("onmouseover")) ? $tag->removeAttribute("onmouseover") : false);
(!empty($tag->getAttribute("onmouseout")) ? $tag->removeAttribute("onmouseout") : false);

if (strpos($tag->getAttribute("title"), "000webhost") !== false){
$tag->parentNode->removeChild($tag);
} //Remove 000webhost
if (preg_match('/(X-Translated-By)/mi', $tag->getAttribute("http-equiv"))){
$tag->parentNode->removeChild($tag);
} //Remove meta X-Translated-By
if ($tag->nodeName === "span"){
if (strpos($tag->getAttribute("class"), "google-src-text") !== false){
$tag->parentNode->removeChild($tag);
}
} //Spans
if ($tag->nodeName === "iframe"){
if (strpos($tag->getAttribute("id"), "gt-nvframe") !== false){
$tag->parentNode->removeChild($tag);
}
} //Iframes
if ($tag->nodeName === "script"){
$transreg=array($tag->nodeValue, $tag->getAttribute('src'));
foreach ($transreg as $matches){
if (preg_match('/(translate|wtsrt_|_addload|netbro_cache_analytics)/mi', $matches)){
$tag->parentNode->removeChild($tag);
}
} //--- End array each
} //Scripts
if ($tag->nodeName === "style"){
if (strpos($tag->nodeValue, "google-src-text") !== false){
$tag->parentNode->removeChild($tag);
}
} // CSS
foreach($xpath->query('//*[contains(attribute::class, "notranslate")]') as $e ) {
   $attr = $e->attributes;
   $attr = $e->getAttribute("class");
   $attr = str_replace("notranslate", "text", $attr);
   $e->setAttribute("class", $attr);
}

} // manipulate
return $dom3->saveHTML();
}

$url = "https://www.bridging-the-gap.com/erd-entity-relationship-diagram/";
 $html = dotranslate($url, "en", "id");
 $html = str_get_html($html);
 //--- article content
 $ar = $html->find('div[id=content]', 0);
 $html = $ar->outertext;
 echo $html;

?>