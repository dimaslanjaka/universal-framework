<?php
require_once 'config.php';

class Instagram
{
  protected $username;
  protected $password;

  protected $uuid;
  protected $device_id;
  protected $username_id;
  protected $token;
  protected $isLoggedIn = false;
  protected $rank_token;
  public $IGDataPath;
  public $proxy;
  public $LOG;
  public $tokenfile;
  public $userIdFile;
  public $cookiefile;
  public $proxyType;

  public function __construct()
  {
      global $L3N4R0X;
      global $proxy;
      $this->username = $L3N4R0X['ig'][0];
      $this->password = $L3N4R0X['ig'][1];
      $this->uuid = $this->generateUUID(true);
      $this->device_id = $this->generateDeviceId(md5($L3N4R0X['ig'][0].$L3N4R0X['ig'][1]));
      if (!is_dir("data")){
        $oldmask = umask(0);
        mkdir("data", 0777);
        umask($oldmask);
      }
      if (!is_dir("data/removed")){
        $oldmask = umask(0);
        mkdir("data/removed", 0777);
        umask($oldmask);
      }
      if (!is_dir("tokens")){
        $oldmask = umask(0);
        mkdir("tokens", 0777);
        umask($oldmask);
      }
      if (!is_dir("tokens/removed")){
        $oldmask = umask(0);
        mkdir("tokens/removed", 0777);
        umask($oldmask);
      }
      if (!is_dir("log")){
        $oldmask = umask(0);
        mkdir("log", 0777);
        umask($oldmask);
       }
       if (!is_dir("cache")){
         $oldmask = umask(0);
         mkdir("cache", 0777);
         umask($oldmask);
       }
       if (!is_dir("data/bio")){
         $oldmask = umask(0);
         mkdir("data/bio", 0777);
         umask($oldmask);
       }
      $this->IGDataPath = 'cache/';
      $this->LOG = 'log/';
      $this->proxy = (isset($proxy) ? $proxy : null);
      //var_dump($this->proxy);
      if (null !== $this->proxy){
      $this->proxyType="HTTP"; //HTTP SOCKS4 SOCKS5
      }
      //$this->proxy = (isset($_SESSION["proxy"]) ? $_SESSION["proxy"] : null);
      $this->cookiefile=$this->IGDataPath.$this->username."-cookies.log";
      $this->userIdFile=$this->IGDataPath.$this->username."-userId.log";
      $this->tokenfile=$this->IGDataPath.$this->username."-token.log";
      if (file_exists($this->cookiefile) && file_exists($this->userIdFile) && file_exists($this->tokenfile)) {
          $this->isLoggedIn = true;
          $this->username_id = trim(file_get_contents($this->userIdFile)); //trim()
          $this->rank_token = $this->username_id.'_'.$this->uuid;
          $this->token = trim(file_get_contents($this->tokenfile)); //trim()
      }
  }

  public function getData($dir = 'data') {
  $files = glob($dir . '/*.json');
  $file = array_rand($files);
  return $files[$file]; 
  }
  
  public function removeData(){
    $datalogin="data/".$this->username.".json";
   // file_put_contents("data/igremoved.log", $this->username." Was Removed\n") : false);
     (file_exists($datalogin) ? rename($datalogin, "data/removed/$datalogin") : false);
     (file_exists($this->tokenfile) ? unlink($this->tokenfile) : false);
     (file_exists($this->cookiefile) ? unlink($this->cookiefile) : false);
     (file_exists($this->userIdFile) ? unlink($this->userIdFile) : false);
     return $this->username." Was Removed From Bot";   
  }

  public function login()
  {
      if (!$this->isLoggedIn) {
          $fetch = $this->request('si/fetch_headers/?challenge_type=signup&guid='.$this->generateUUID(false), null, true);
          preg_match('#Set-Cookie: csrftoken=([^;]+)#', $fetch[0], $token);

          $data = [
          'device_id'           => $this->device_id,
          'guid'                => $this->uuid,
          'phone_id'            => $this->generateUUID(true),
          'username'            => $this->username,
          'password'            => $this->password,
          'login_attempt_count' => '0',
           ];

          $login = $this->request('accounts/login/', $this->generateSignature(json_encode($data)), true);
          if (!empty($login[1]['logged_in_user']['pk'])){
          $this->username_id = $login[1]['logged_in_user']['pk'];
          file_put_contents($this->IGDataPath.$this->username.'-userId.log', $this->username_id);
          $this->rank_token = $this->username_id.'_'.$this->uuid;
          preg_match('#Set-Cookie: csrftoken=([^;]+)#', $login[0], $match);
          $this->token = $match[1];
          file_put_contents($this->IGDataPath.$this->username.'-token.log', $this->token);
          $this->isLoggedIn = true;

          return $login[1];
          } else {
            $failed["messages"] = "Login Failed";
            $failed["status"] = "fail";
            return $failed;
            }
      }
  }
  
  public function saveBio($login)
  {
  $userbio="data/bio/".$this->username."-bio.json";
 // var_dump($userbio);
  //$login=$this->login();
    if (/*!file_exists($userbio) && */!empty($login)){
    $login=(isset($login['logged_in_user']) ? $login['logged_in_user'] : false);
    $u_dp = (isset($login['profile_pic_url']) ? $login['profile_pic_url'] : null);
    $u_fn = (isset($login['full_name']) ? $login['full_name'] : null);
    $u_un = (isset($login['username']) ? $login['username'] : null);
    $u_pn = (isset($login['phone_number']) ? $login['phone_number'] : null);
    $u_priv = (isset($login['is_private']) ? $login['is_private'] : null);
    $json = array("phone"=>$u_pn,"username"=>$u_un,"fullname"=>$u_fn,"private"=>$u_priv,"photo"=>$u_dp);
    $json = json_encode($json);
    file_put_contents("data/bio/".$this->username."-bio.json", $json, LOCK_EX);
    }
    return "successful writen to ".$userbio;
  }
  
  public function log($text){
    if (isset($this->username) || null !== $this->username){
    $text = (strpos($text, "\n") !== false ? $text : $text."\n");
    $log=$this->LOG.$this->username.".log";
    file_put_contents($log, $text, FILE_APPEND | LOCK_EX);
    return "Log Writen to ".$log;
    } else {
      return "Log Write Failed";
    }
  }
  
  public function logout(){
    (file_exists($this->cookiefile) ? unlink($this->cookiefile) : false);
    (file_exists($this->userIdFile) ? unlink($this->userIdFile) : false);
    (file_exists($this->tokenfile) ? unlink($this->tokenfile) : false);
    (!file_exists($this->LOG.$this->username.".log") ? file_put_contents($this->LOG.$this->username.".log", "Logged Out\n") : false);
    //session_destroy();
    return $this->request('accounts/logout')[1];
  }
  
  public function relogin(){
    $this->logout();
    $login=$this->login();
    if ($login["status"] !== "fail" && isset($login["logged_in_user"])){
     $this->saveBio($login);
    }
  }
  
  public function timelineFeed()
  {
        return $this->request('feed/timeline/')[1];
  }
  
  public function custom($endpoint=null){
    $return = $this->request($endpoint)[1];
    return $return;
  }
  
  public function getRecentActivity()
  {
      $activity = $this->request('news/inbox/?')[1];
      return $activity;
  }

  public function getUserId()
  {
      return $this->username_id;
  }
  
  public function getUserFeed($usernameId)
  {
      $userFeed = $this->request("feed/user/".$usernameId."/?rank_token=$this->rank_token&ranked_content=true&")[1];

      return $userFeed;
  }

  public function like($mediaId)
  {
      $data = json_encode([
        '_uuid'      => $this->uuid,
        '_uid'       => $this->username_id,
        '_csrftoken' => $this->token,
        'media_id'   => $mediaId,
    ]);

      return $this->request("media/".$mediaId."/like/", $this->generateSignature($data))[1];
  }
  
  public function getComments($id, $limit = 0) {
    //$comments = json_decode(file_get_contents('https://api.instagram.com/v1/' . 'media/'. $image->id . '/comments?access_token='. $data->access_token)); 
    
    return $this->request('media/'.$id.'/comments')[1];//, true, array('count' => $limit))[1];
    }
  
  public function likeComment($id){
  return $this->custom('comments/'.$id);
  }
  
  public function comment($mediaId, $commentText)
  {
      $data = json_encode([
        '_uuid'          => $this->uuid,
        '_uid'           => $this->username_id,
        '_csrftoken'     => $this->token,
        'comment_text'   => $commentText,
    ]);

      return $this->request("media/".$mediaId."/comment/", $this->generateSignature($data))[1];
  }

  public function follow($userId)
  {
      $data = json_encode([
        '_uuid'      => $this->uuid,
        '_uid'       => $this->username_id,
        'user_id'    => $userId,
        '_csrftoken' => $this->token,
    ]);

      return $this->request("friendships/create/".$userId."/", $this->generateSignature($data))[1];
  }

    public function generateSignature($data)
    {
        global $L3N4R0X;
        $hash = hash_hmac('sha256', $data, $L3N4R0X['ig'][4]);

        return 'ig_sig_key_version=4&signed_body='.$hash.'.'.urlencode($data);
    }

    public function generateDeviceId($seed)
    {
        $volatile_seed = filemtime(__DIR__);
        return 'android-'.substr(md5($seed.$volatile_seed), 16);
    }

    public function generateUUID($type)
    {
        $uuid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
      mt_rand(0, 0xffff), mt_rand(0, 0xffff),
      mt_rand(0, 0xffff),
      mt_rand(0, 0x0fff) | 0x4000,
      mt_rand(0, 0x3fff) | 0x8000,
      mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );

        return $type ? $uuid : str_replace('-', '', $uuid);
    }

    protected function buildBody($bodies, $boundary)
    {
        $body = '';
        foreach ($bodies as $b) {
            $body .= '--'.$boundary."\r\n";
            $body .= 'Content-Disposition: '.$b['type'].'; name="'.$b['name'].'"';
            if (isset($b['filename'])) {
                $ext = pathinfo($b['filename'], PATHINFO_EXTENSION);
                $body .= '; filename="'.'pending_media_'.number_format(round(microtime(true) * 1000), 0, '', '').'.'.$ext.'"';
            }
            if (isset($b['headers']) && is_array($b['headers'])) {
                foreach ($b['headers'] as $header) {
                    $body .= "\r\n".$header;
                }
            }

            $body .= "\r\n\r\n".$b['data']."\r\n";
        }
        $body .= '--'.$boundary.'--';

        return $body;
    }

    protected function request($endpoint, $post = null, $login = false)
    {
        global $L3N4R0X;
        $headers = [
        'Connection: close',
        'Accept: */*',
        'Content-type: application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie2: $Version=1',
        'Accept-Language: en-US',
        ];

        $ch = curl_init();

        if (strpos($endpoint, "://") !== false){
          curl_setopt($ch, CURLOPT_URL, $endpoint);
        } else {
          curl_setopt($ch, CURLOPT_URL, $L3N4R0X['ig'][2].$endpoint);
        }
        curl_setopt($ch, CURLOPT_USERAGENT, $L3N4R0X['ig'][3]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_VERBOSE, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        //curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $cookie = $this->cookiefile;
        if (!file_exists($cookie)){
         $fh = fopen($cookie, 'w') or die("Can't create file");
        }
        if (isset($_SESSION["cookiefile"])){
          $cookie=$_SESSION["cookiefile"];
        }
        curl_setopt($ch, CURLOPT_COOKIEFILE, realpath($cookie));
        curl_setopt($ch, CURLOPT_COOKIEJAR, realpath($cookie));
        
        if (null !== $this->proxy){
          curl_setopt($ch, CURLOPT_PROXY, $this->proxy);
        curl_setopt($ch, CURLOPT_PROXYTYPE, "CURLPROXY_$this->proxyType"); 
        curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
        }

        if ($post) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }

        $resp = curl_exec($ch);
        $header_len = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($resp, 0, $header_len);
        $body = substr($resp, $header_len);

        curl_close($ch);

        return [$header, json_decode($body, true)];
    }
}

class curl{
  public $proxy;
  public $result;
  public $cookie;
  public $temp;
  
  public function __construct()
  {
    global $option;
    $this->temp="cache";
       if (!is_dir($this->temp)){
         $oldmask = umask(0);
         mkdir($this->temp, 0777);
         umask($oldmask);
       }
       
    //($option ? global $option : false);
    $this->proxy=($option["proxy"] ? $option["proxy"] : false);
    $this->result=($option["result"] ? $option["result"] : false);
    $this->cookie=($option["cookiefile"] ? $option["cookiefile"] : ($option["cookie"] ? $option["cookie"] : false));
  }
  
public function fetch( $url, $option=null ) 
{
  $_SESSION["peek"] = $url;
  $ch =  curl_init();
  if (strpos($url, "https://") !== false)
  {
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  }
  $useragent = isset($option['useragent']) ? $option['useragent'] : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0.2) Gecko/20100101 Firefox/10.0.2';
  if (isset($option["dump"]))
  {
    curl_setopt($ch, CURLOPT_HEADER, 1);
  }
  if (isset($option["headers"]))
  {
    curl_setopt($ch, CURLOPT_HTTPHEADER, $option["headers"]);
  } 
    curl_setopt( $ch, CURLOPT_URL, $url ) or die("URL NOT FOUND");
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
            curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
            curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
            curl_setopt( $ch, CURLOPT_POST, isset($option['post']) );

            if( isset($option['post']) )         curl_setopt( $ch, CURLOPT_POSTFIELDS, $option['post'] );
            if( isset($option['refer']) )        curl_setopt( $ch, CURLOPT_REFERER, $option['refer'] );

if (isset($option["proxy"])){
curl_setopt($ch, CURLOPT_PROXY, $option["proxy"]);
}
            curl_setopt( $ch, CURLOPT_USERAGENT, $useragent );
            curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, ( isset($option['timeout']) ? $option['timeout'] : 5 ) );

$cookie = (isset($option['cookiefile']) ? $option['cookiefile'] : realpath($this->temp."/current_cookies.txt"));
            curl_setopt( $ch, CURLOPT_COOKIEJAR,  $cookie );
            curl_setopt( $ch, CURLOPT_COOKIEFILE, $cookie );

if (isset($option['verbose'])){
curl_setopt($ch, CURLOPT_VERBOSE, true);
}
            $result = curl_exec( $ch );
$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$_SESSION["ContentType"] = $contentType;
$info = curl_getinfo($ch);
if (isset($option["dumpinfo"])){
var_dump($info);
}
            curl_close( $ch );
if ($info['http_code'] == 200) {
/*
if (!isset($_SESSION["prxwork"])){
$_SESSION["prxwork"] = $option["proxy"];
}
*/
            return $result;
} else {
  return curl_error($ch);
}
    }
}

/*
   @author Petter Kjelkenes
   @support kjelkenes@gmail.com
   @modified By Dimas Lanjaka
   Class to fetch random proxies. You may use these proxies to open connections with CURL or whatever you want to use the proxies for.

   HOWTO:
   $pr = new Proxy('PROXYCACHE_FILE.php');
   $pr->initDefaultProxies();  // Get default proxies, if these dont work, you should use $pr->add($address, $regexppatern);
   $proxy = $pr->getProxies(); // gets proxies like this: array( 0 => ip:port, 1 => ip:port , ..... and so on .... )

*/

class Proxy{
    // Stores proxies.
    public $store=array();

    // Cache store for proxies.
    private $file = '';

public function http_get_contents($url)
{
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_TIMEOUT, 1);
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
  if(FALSE === ($retval = curl_exec($ch))) {
    return curl_error($ch);
  } else {
    return $retval;
  }
}
public function get_contents($url){
$file = $url;
$contents = preg_match("/^http/", $file) ? $this->http_get_contents($file) : file_get_contents($file);
return $contents;
}

    // Constructs the class.
    // @param $f File cache location for proxies, this file will have an array of proxies that are working. You may specify it as EMPTY( '' ) if you dont want to cache proxy list! File extension must be .php.
    //           By default it generates a file called __FILE_PROXY_CACHE.php that contains the proxies cached.
    public function __construct($f='cache/cache.php'){
        if ($f)
        {
          $this->file = $f;
        }
        
        if ($this->file && file_exists($this->file))
        {
            include $this->file;

            if (isset($s) && is_array($s))$this->store = $s;
        }

    }


    // Adds default proxy list, these sites may be down so you must maybe create your own handlers...
    public function initDefaultProxies(){
        $this->add('http://www.ip-adress.com/proxy_list/',
            "#<td>(.*?):(\d{1,4})</td>#");

        $this->add('http://www.digitalcybersoft.com/ProxyList/fresh-proxy-list.shtml?',
            "#(.*?):(\d{1,4}).*?\n#");

        $this->add('http://www.secretip.com/proxylist.php',
            "#(.*?):(\d{1,4})<br />\n#");

        $this->add('http://www.proxyserverprivacy.com/free-proxy-list.shtml',
            "#(.*?):(\d{1,4})<br />\n#");
    }


    // Gets the proxies in associve array ( ip:port )
    public function getProxies(){
        $ip = array();
        foreach($this->store as $p){
          if ($p["port"])
          {
            $ip[] = $p['proxy'].':'.$p['port'];
          } else {
              //$ip[0]="NO PORT FOUND \n";
              $ip[] = $p['proxy'];
            }
        }
        return $ip;
    }

    // Use this when adding own handlers to add proxy to list.
    public function debugadd($adr, $regexp){
        unset($this->store);
        $this->add($adr,$regexp);
        echo "<pre>",print_r($this->store),"</pre>";

        die();

    }
    
    public function html($url){
      return $this->get_contents($url);
    }
    
    public function getIP($url, $re)
    {
      
    }

    // Use this to add a site to the proxy array.
    public function add($adr, $regexp){
        if (!$this->timeupdate($adr))
        {
          return false;
        }
        if (strpos($adr, "<body>") !== false) {
          $c=$adr;
        } else {
        $c = file_get_contents($adr);
        if (!$c)
        {
          $c = $this->get_contents($adr);
        }
        if (!$c)
        {
          $curl = new curl();
          $c = $curl->fetch($adr);
        }
        }
        if ($c){
            $matches = array();
            preg_match_all($regexp,$c,$matches);
            if (count($matches) > 0){
                foreach($matches[0] as $k => $m){
                  //if (!$iponly){
                  $port = intval($matches[2][$k]) or null;

                  $ip = trim($matches[1][$k]);
                  $st = array('proxy' => $ip, 'port' => $port, 'site' => md5($adr), 'time' => time());
                 /* } else {
                    $port = null;
                    $ip = trim($matches[1][$k]);
                    $st = array('proxy' => $ip, 'port' => $port, 'site' => md5($adr), 'time' => time());
                  }*/
                    if (/*$port && */!$this->inStore($st))
                    {
                     $this->store[]=$st;
                    }
                }

                if (count($this->store) > 0)
                {
                  $this->dump();
                }
            }
           // return "Added OK!";
        } // end if $c
    }


    private function inStore($st){
        foreach($this->store as $s){
            if ($s['proxy']==$st['proxy'] && $s['port']==$st['port'])
            {
              return true;
            }
        }
        return false;
    }

    private function dump(){
        if ($this->file)
        {
          file_put_contents($this->file, '<?php $s = '.var_export($this->store,true).'; ?>');
        }
    }

    private function timeupdate($adr){
        foreach($this->store as $s){
            if ($s['site']==md5($adr)){
                if (time() > ($s['time']+(60*60*2)) ){
                    return false;
                }
            }
        }
        return true;

    }
}


?>