<?php
function listing($dir="./tokens/removed",$extension="txt"){
  (!isset($dir) ? die("directory not found") : false);
$thelist[]="";
if ($handle = opendir($dir)) { //'.'
    while (false !== ($file = readdir($handle)))
    {
        if ($file != "." && $file != ".." && strtolower(substr($file, strrpos($file, '.') + 1)) == $extension)
        {
         $ft=filemtime($dir."/".$file);
         $timefile=date("F d Y H:i:s.",$ft);
          $thelist["time"][]=$timefile;
          $filelink=$dir."/".$file;
          $filetext=str_replace(".txt","",$file);
            $thelist["link"][]= '<a class="text-danger w3-text-red" href="//web-manajemen.blogspot.com/?#'.$filelink.'">'.$filetext.'</a> at '.$timefile;
            $thelist[]=$file;
        }
    }
    closedir($handle);
}
return $thelist;
}
?>