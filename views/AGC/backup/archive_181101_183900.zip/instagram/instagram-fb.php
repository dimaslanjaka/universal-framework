<?php
include("function.php");
include("dom.php");
//header("Content-Type: application/json");

if (isset($_POST["user"])){
$user=$_POST["user"];
} else if (isset($_GET["user"])){
$user=$_GET["user"];
} else {
  $user = null;
  }
if (isset($_POST["pass"])){
$pass=$_POST["pass"];
} else if (isset($_GET["pass"])){
$pass=$_GET["pass"];
} else {
  $pass = null;
  }
  
if (null === $user && null === $pass || empty($user) && empty($pass)){
$file = randfile("data","facebook");
$file = file_get_contents($file);
if (!empty($file)){
  $json = json_decode($file,true);
  $user = $json["username"];
  $pass = $json["password"];
}
}
//var_dump($user,$pass);

if (isset($user) && null !== $user && null === $pass){
  $file = "data/$user.facebook";
  //echo $file;
  if (!file_exists($file)){
    die("$user not found");
  } else
  if (file_exists($file)){
    $file = file_get_contents($file);
    $json = json_decode($file, true);
    //var_dump($json);
    $user = $json["username"];
    $pass = $json["password"];
  }
}
//var_dump($user,$pass);
 //die($user.$pass);
$_SESSION["user"]=$user;
$_SESSION["pass"]=$pass;
if (!file_exists("cache/$user.txt")){
  file_put_contents("cache/$user.txt","",LOCK_EX);
}
$loginopt["cookiefile"]=$opt["cookiefile"]=$ToKeN["cookiefile"]="cache/$user.txt";
$login_url="https://www.facebook.com/login.php";
$loginopt["post"]="email=$user&pass=$pass&Login=Masuk";
$login = fetch($login_url,$loginopt);

if (isset($_GET["login"])){
echo $login;
die();
} else if (isset($_GET["logout"])){
$fullPath = __DIR__ . "/cache/" ; 
array_map('unlink', glob( "$fullPath*.txt"));
echo "All cache Removed";
die();
}

$token_url="https://www.facebook.com/v1.0/dialog/oauth?response_type=token&display=popup&client_id=124024574287414&redirect_uri=https://www.instagram.com/accounts/signup/&scope=user_actions.books,user_actions.music,user_actions.video,user_checkins,user_education_history,user_events,user_games_activity,user_groups,user_hometown,user_interests,user_likes,user_location,user_notes,user_photo_video_tags,user_photos,user_questions,user_relationship_details,user_relationships,user_religion_politics,user_status,user_subscriptions,user_videos,user_website,user_work_history,friends_about_me,friends_actions.books,friends_actions.music,friends_actions.news,friends_actions.video,friends_activities,friends_birthday,friends_checkins,friends_education_history,friends_events,friends_games_activity,friends_groups,friends_hometown,friends_interests,friends_likes,friends_location,friends_notes,friends_photo_video_tags,friends_photos,friends_questions,friends_relationship_details,friends_relationships,friends_religion_politics,friends_status,friends_subscriptions,friends_videos,friends_website,friends_work_history,ads_read,email,publish_checkins&format=json&sdk=android";
//die($token_url);
$opt["refer"]="https://www.instagram.com/accounts/signup/";
$opt["dump"]=1;
$instagram= fetch($token_url,$opt);
//die($instagram);
if (preg_match("/(anda belum masuk ke facebook|you have not logged in to facebook)/m", strtolower($instagram))){
  echo $login;
  die();
}
//die("user logged in");
if (false !== $instagram || null !== $instagram || !empty($instagram)){
$html=str_get_html($instagram);
$postdata="";
foreach ($html->find("*[name]") as $attr){
  if ($attr->tag !== "meta"){
  $a=$attr->attr;
  if (isset($a["name"]) && strpos(strtolower($a["name"]), "skip") === false){
    if (!empty($a["value"])){
  $postdata.= $a["name"]."=".$a["value"]."&";
    } else {
      $postdata.=$a["name"]."&";
    }
  }}
}
$ToKeN["post"]=urldecode($postdata);
//die($token["post"]);
$ToKeN["refer"]=$token_url;
$ToKeN["dump"]=1;
$action=$html->find("*[action]",0);
$action_url="https://www.facebook.com".$action->attr["action"];
$tokenhtml = fetch($action_url, $ToKeN);

$result=array();

if (preg_match("/access_token=(.*?)&expires_in/mi", $tokenhtml, $r_app)){
  $result[] = $r_app[1];
} else if (preg_match("/access_token=(.*?)&expires_in/mi", $instagram, $r_app)){
  $result[]= $r_app[1];
} else {
  echo $tokenhtml;
}
$result=array_unique($result);
$result=array_filter($result);
echo "<hr/>";
$json = json_encode($result);
$json = json_decode($json,true);
$tokens = $json[0];
//var_dump($tokens);
//die();
echo $tokens;
if (!empty($result) && !empty($json)){
file_put_contents(__DIR__."/tokens/$user-instagram.txt",$tokens, LOCK_EX);
}
echo "<hr/>";
} /* if null !== instagram||false !== $instagram */
?>