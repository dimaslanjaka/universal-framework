<?php
session_start();
@ini_set('output_buffering',0);
@ini_set('display_errors', 0);
@ini_set('max_execution_time',60);
@set_time_limit(0);
@ignore_user_abort(1);
//error_reporting(0);

$datex = date('m/d/Y h:i:s a', time());
file_put_contents("access-log.txt", $datex . " | " . $_SERVER['HTTP_USER_AGENT'] . "\n", FILE_APPEND | LOCK_EX);
$curlopt["cookiefile"] = "cache/cookies.txt";
global $curlopt;

if (session_status() == PHP_SESSION_NONE) { 
      session_start(); 
}
$_SESSION['like']=[];
$_SESSION['react']=[];

include("function.php");
include("config.php");
//include("log.php");
$css = <<<EOF
<style>
*{word-wrap: break-word}
</style>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
EOF;
echo $css;
function url($url){
      $url = '<a href="' . $url . '">' . $url . '</a>';
      return $url;
      }

foreach(file(select_file('tokens')) as $line) {
   $access_token = $line;
   $like = current_dir . "like.php?token=" . $access_token . "&max=5";
   $_SESSION["like"][] = $like;
   $react = current_dir . "react.php?exec&token=" . $access_token . "&max=5";
   $_SESSION["react"][] = $react;
   
/*
?>
<div id="like">Likes</div>
<div id="react">Reactions</div>
<script>
$.ajax({
   url:"<?php echo $like; ?>",
    type:'GET',
     success: function(data){
       $('#like').html(data);
     }
});
$.ajax({
   url:"<?php echo $react; ?>",
    type:'GET',
     success: function(data){
       $('#react').html(data);
     }
});
</script>
<?php
      */
      if (!isset($_GET["show_url"]) || !isset($_GET['show'])){
   if (null !== fetch($react, $curlopt)){
      //echo url($react)."<hr/>";
      echo "Reaction Performed<hr/>";
   }
   if (null !== fetch($like, $curlopt)){
      //echo "<hr/>".url($like);
      echo "Like Performed<hr/>";
   }
   
      } elseif (!isset($_GET['show'])) {
         echo "<hr/>".url($like)."<hr/>".url($react);
      }
      
}

?>