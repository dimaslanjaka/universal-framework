<?php
@ini_set('memory_limit', '256M'); //-1
@ini_set('output_buffering',0);
//@ini_set('display_errors', 0);
@ini_set('max_execution_time',0);
@set_time_limit(0);
@ignore_user_abort(1);
//error_reporting(0);
error_reporting(-1);
//error_reporting(1 & ~ E_WARNING);
date_default_timezone_set('Asia/Jakarta');
ob_start();

$log[]="";

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$datex = date('m/d/Y h:i:s a', time());
file_put_contents("log/access-log.txt", $datex . " | " . (isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : "null") . "\n", FILE_APPEND | LOCK_EX);

function curl($url)
{
  $ch = curl_init();
  curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt ($ch, CURLOPT_URL, $url);
  curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
  curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, true);
  curl_setopt($ch, CURLOPT_HEADER, true);
  curl_setopt($ch, CURLOPT_NOBODY, true);
  $content = curl_exec ($ch);
  $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
  curl_close ($ch);
  return $contentType;
}
function select_file($dir = 'data') {
  $files = glob($dir . '/*.json');
  $file = array_rand($files);
  return $files[$file]; 
}
$rfile = file(select_file());
$loopf = glob('data/*.{json}', GLOB_BRACE);
$loopt = glob('tokens/*.{txt}', GLOB_BRACE);
$loopx = array_merge($loopf,$loopt);

$html = <<<EOF
<style>
*{word-wrap:break-word}
</style>
<body><script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script>
const mins = 1;
document.write("Result Will Be Updated in "+mins+" minutes<hr/>");
</script>
EOF;
echo $html;

//$count = count($loopf);
//echo $count;
//for($i = 0; $i <= count($loopf); $i++) {
//  $jsonfile = realpath($loopf[$i]);

foreach ($loopx as $i => $file){
  
  $json = file_get_contents($file);
  global $json;
  
  if (strlen($json) < 150 && !isset($_GET["fb"])){
  $json = json_decode($json, true);
  $user = $json[0]["username"];
  $pass = $json[0]["password"];
  $_SESSION["username"] = $user;
  $_SESSION["password"] = $pass;
  $minutes = "20";
  $user = base64_encode("username=".$user);
  $pass = base64_encode("password=".$pass);
  $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/instagram/like.php?".base64_decode($user)."&".base64_decode($pass);
  $log[].=$url;
  //curl($url);
  echo '<script>
  const url'.$i.' = "like.php?"+window.atob(\''.$user.'\')+"&"+window.atob(\''.$pass.'\');
  </script>';
} else if (strlen($json) > 150 && !isset($_GET["ig"])){
  $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]/instagram/like-fb.php?token=".$json;
  $log[].=$url;
 echo '<script>
   const url'.$i.' = "like-fb.php?token='.$json.'";
   </script>'; 
}
  
  echo '<script>
setInterval(run'.$i.', mins * 60 * 1000);
function run'.$i.'(){
$.ajax({
  url:url'.$i.', 
  type:"GET", 
  success: function(data){
    $("body").html(data+"<hr/>"); 
    } 
});
}
run'.$i.'();
</script>';
  //include("manual.php");
  
}

if (isset($_GET["exec"]) || isset($_POST["exec"])){
  shuffle($log);
foreach ($log as $l){
if (null !== curl($l)){
  echo $l . " OK\n<br/>";
}
sleep(3);
}
}
?>