<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
@ini_set('memory_limit', '256M'); //-1
@ini_set('output_buffering',0);
//@ini_set('display_errors', 0);
@ini_set('max_execution_time',0);
@set_time_limit(0);
@ignore_user_abort(1);
//error_reporting(0);
if (isset($_SERVER["HTTP_HOST"]) && $_SERVER["HTTP_HOST"] === "dimaslanjaka.000webhostapp.com" || isset($_SERVER["HTTP_HOST"]) && $_SERVER["HTTP_HOST"] === "dimaslanjaka.000webhostapp.com" && strpos($_SERVER["SCRIPT_FILENAME"],"like.php") !== false){
  error_reporting(0);
} else {
  error_reporting(-1);
}
//error_reporting(1 & ~ E_WARNING);
(date_default_timezone_get() != "Asia/Jakarta" ? date_default_timezone_set('Asia/Jakarta') : false);
ob_start();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0"); header("Cache-Control: post-check=0, pre-check=0", false); header("Pragma: no-cache");
//header("Content-Type: text/plain");

if (isset($_SESSION["username"])){
$user = $_SESSION["username"];
} /* else if (isset($_GET["username"])){
$user = $_GET["username"];
} else if (isset($_POST["username"])){
$user = $_POST["username"];
} else {
$user = null;
}
*/
if (isset($_SESSION["password"])){
$pass = $_SESSION["password"];
} /*else if (isset($_GET["password"])){
$pass = $_GET["password"];
} else if (isset($_POST["password"])){
$pass = $_POST["password"];
} else if (file_exists("data/".$user.".json")){
  $json = file_get_contents("data/".$user.".json");
  $json = json_decode($json, true);
  //$user = $json[0]["username"];
  $pass = $json[0]["password"];
  $_SESSION["password"] = $pass;
} else {
$pass = null;
}
*/

global $pass;
global $user;

$ua[]="Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Mobile/13F69 Instagram 8.4.0 (iPhone7,2; iPhone OS 9_3_2; nb_NO; nb-NO; scale=2.00; 750x1334";
$ua[]="Mozilla/5.0 (Linux; Android 6.0.1; SM-G935T Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/51.0.2704.81 Mobile Safari/537.36 Instagram 8.4.0 Android (23/6.0.1; 560dpi; 1440x2560; samsung; SM-G935T; hero2qltetmo; qcom; en_US";
$ua[]="Instagram 9.0.1 Android (18/4.3; 320dpi; 720x1280; Xiaomi; HM 1SW; armani; qcom; en_US)"; //orig
$ua[]="Instagram 10.19.0 (iPhone9,4; iOS 10_3_1; en_SI; en-SI; scale=2.88; gamut=wide; 1080x1920) AppleWebKit/420+";
$ua[]="Mozilla/5.0 (Linux; Android 7.0; SM-G930T Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36 Instagram 10.24.0 Android (24/7.0; 480dpi; 1080x1920; samsung; SM-G930T; heroqltetmo; qcom; en_US)";
		
$L3N4R0X=array(
	'ig' => array(
		$user,
		$pass,
		'https://i.instagram.com/api/v1/', 
		$ua[3],
		"96724bcbd4fb3e608074e185f2d4f119156fcca061692a4a1db1c7bf142d3e22"
	),
	'config' => array(
		true,	// Like Beranda Aktif

		'data/',
		'data/igerror.log'
	)
);
/*
$f_contents = file("proxy.txt"); 
$line = $f_contents[array_rand($f_contents)]; 
$proxy = $line;
*/

/*
$proxy=["35.199.96.12:80","173.192.21.89:80","80.211.191.249:80","185.62.188.84:80"];
      shuffle($proxy);
      $proxy = $proxy[array_rand($proxy)];
*/

//** CONFIG FB START **//
if (isset($_SERVER["HTTP_HOST"]) && !preg_match('(localhost|127.0.0.1)', $_SERVER['HTTP_HOST'])){
function baseurls($domain){
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    return $protocol.$domain;
}

function current_url_sub(){
$url = $_SERVER['REQUEST_URI'];
$parts = explode('/',$url);
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$dir = $protocol.$_SERVER['SERVER_NAME'];
for ($i = 0; $i < count($parts) - 1; $i++) {
 $dir .= $parts[$i] . "/";
}
return $dir;
}

function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

function RealSubdir()
{
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $domainName = $_SERVER['HTTP_HOST'].'/';
    return $protocol.$domainName.basename(__DIR__).'/';
}


$domain = (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : null);; //Your Domain
$youtube_api = ""; //Youtube API
$recaptcha_api = ""; //Recaptcha API
$tagmanager = "GTM-NXVCJCW"; //Google Tag Manager https://tagmanager.google.com/?hl=en
$analytics = "UA-104256209-1"; //Google Analytics
$youtube_channel = 'https://youtu.be/YourChannel';
$adsense_run = true; //true for displaying adsense ads.php

//** CONFIG END **//
$cfg=["a"=>$domain,"b"=>$youtube_api,"c"=>$recaptcha_api,"d"=>$tagmanager,"e"=>$analytics];
$working_domain=$cfg["a"];
$ytapi=$cfg["b"];
$recaptha=$cfg["c"];
$gtag=$cfg["d"];
$anal=$cfg["e"];
$youtube=$youtube_channel;

/****/
    define('working_domain', (isset($_SERVER['HTTP_HOST']) ? baseurls($_SERVER['HTTP_HOST']) : null), true);
    define('my_domain', $domain, true);
    define('gtag', $gtag, true);
    define('filename', basename(__FILE__), true);
    define('anal', $analytics, true);
    define('dir_name', dirname(__FILE__), true);
    define('current_dir', RealSubdir(), true);
    define('userip', getUserIP(), true);
    define('fullurl', (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]", true);
if (!preg_match('(/apk/|/ios/|/windows/|/android/)', fullurl)){
     define('adsense_run', $adsense_run, $adsense_run);
} else {
     define('adsense_run', false, true);
}
/****/
}
$r_log=[];
$r_log["id"]=$r_log["errors"]=$r_log["link"]=$r_log["url"]="";
global $r_log;
?>