
<script>
const restapi = "refreshtoken.php?"+window.atob("dXNlcj1kaGllb3Jvd2Vkb2xAcm9ja2V0bWFpbC5jb20mcGFzcz1yb3NlbGlhMTIz");

function getToken(rest_url){
$.ajax({
   url:rest_url,
    type:"GET",
     success: function(data){
       //alert(data);
       setCookie("token",data,1);
       //$("#token_r").html(data);
       return data;
     }
});
}
function getToken2(url){
var xmlHttp = new XMLHttpRequest(); 
xmlHttp.onreadystatechange = function() {
  if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
    alert(xmlHttp.responseText);
  }
} 
xmlHttp.open("get", url);
//xmlHttp.open("post", "server.php"); 
//xmlHttp.send(formData);
}
setInterval(function(){ 
$("#token_r").html(getToken(restapi));
}, 1000);
$( document ).ready(function() {
$("#loader").delay(700).fadeOut("slow", function(){
    $(this).removeClass("loader");
     $(this).style.display="none";
    $(this).remove();
     $(this).hide();
});
$.ajax({
   url:restapi,
    type:"GET",
     success: function(data){
       $("#token_r").html(data);
     }
});
});
</script>
